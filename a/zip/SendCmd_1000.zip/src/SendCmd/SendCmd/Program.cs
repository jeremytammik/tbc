#region Header
// SendCmd/Program.cs
//
// Demonstrate sending keyboard input to Revit Architecture 2009.
//
// Copyright (C) 2008 by Jeremy Tammik, Autodesk Inc.
// All rights reserved.
// 2008-02-07 initial implementation for Revit 2009 beta 1
// 2008-12-04 updated for Revit 2009 Build 20080915_2100 and posted to blog
#endregion // Header

#region Namespaces
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
#endregion // Namespaces

namespace SendCmd
{
  /// <summary>
  /// Demonstrate sending keyboard input to Revit Architecture 2009.
  /// 2008-02-07 initial implementation for Revit 2009 beta 1
  /// 2008-12-04 updated for Revit 2009 Build 20080915_2100 and posted to blog
  /// </summary>
  class Program
  {
    //
    // get a handle to an application window:
    //
    [DllImport( "USER32.DLL" )]
    public static extern IntPtr FindWindow( 
      string lpClassName, string lpWindowName );
    //
    // activate an application window:
    //
    [DllImport( "USER32.DLL" )]
    public static extern bool SetForegroundWindow( 
      IntPtr hWnd );

    //
    // Obtain a handle to the Revit Architecture 2009 application. 
    // The window class and window name can be retrieved using the Visual Studio Spy++ tool.
    // Actually, just the class name is sufficient.
    //
    // Revit 2009 beta 1:
    //
    //string window_caption = "Revit Architecture 2009 - Preview Beta - [Project1 - Floor Plan: Level 1]";
    //string window_class_name_project_open = "Afx:00400000:8:00010011:00000000:00230C09";
    //string window_class_name_zero = "Afx:00400000:8:00010011:00000000:130C0667";
    //
    // Revit 2009 Build 20080915_2100:
    //
    const string _window_class_name_zero 
      = "Afx:00400000:8:00010011:00000000:007B05A1";
    //string window_caption = "Revit Architecture 2009";
    const string _window_class_name_project_open 
      = "Afx:00400000:8:00010011:00000000:007B05A1";
    //string window_caption = "Revit Architecture 2009 - [Project1 - Floor Plan: Level 1]";

    static int Main( string[] args )
    {
      //
      // retrieve window handle if a project is opened in Revit:
      //
      IntPtr revitHandle = FindWindow( _window_class_name_project_open, null );
      //
      // try alternative window class if no project is open in Revit:
      //
      if( IntPtr.Zero == revitHandle )
      {
        revitHandle = FindWindow( _window_class_name_zero, null );
      }
      //
      // verify that Revit is running:
      //
      if( IntPtr.Zero == revitHandle )
      {
        Console.WriteLine( "Unable to find Revit window. Is Revit Architecture 2009 beta 1 up and running yet?" );
        return 1;
      }
      //
      // make Revit the foreground application and send it some input:
      //
      SetForegroundWindow( revitHandle );
      //
      // send the F1 key to open help:
      //
      SendKeys.SendWait( "{F1}" );
      //
      // "Ctrl + F10, Left Arrow, Left Arrow, Down Arrow, Up Arrow, Enter" brings up the about box:
      //
      SetForegroundWindow( revitHandle );
      SendKeys.SendWait( "^{F10}{LEFT}{LEFT}{DOWN}{UP}{ENTER}" );
      return 0;
    }
  }
}
