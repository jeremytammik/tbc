﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SpatialAnalysis.Geometry;

namespace SpatialAnalysis.ExternalConnection
{
    public interface IVisualize
    {
        void VisualizeBoundary(UV[] points, double elevation);
        void VisualizeLine(UVLine line, double elevation);
        void VisualizePoint(UV pnt, double size, double elevation);
        void VisualizeLines(ICollection<UVLine> lines, double elevation);
        UV PickPoint(string message);
    }
}
