﻿using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Net;
using System.IO;

namespace GrabJpg
{
  class Program
  {
    const string _url =
      "http://www.ggb.ch/webcam.php?e_1__getimage=1";

    static void Main( string[] args )
    {
      using( WebClient client = new WebClient() )
      {
        byte[] data = client.DownloadData( _url );

        using( Image img = Image.FromStream( 
          new MemoryStream( data ) ) )
        {
          string filename = "a.jpg";
          img.Save( filename, ImageFormat.Jpeg );
          Process.Start( filename ); // test display
        }
      }
    }
  }
}
