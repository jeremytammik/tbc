﻿namespace AdnRvtCloudConsole
{
    partial class CloudConsoleCtrl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CloudConsoleCtrl));
            this._panelMain = new System.Windows.Forms.Panel();
            this._panelCtrl = new System.Windows.Forms.Panel();
            this._tvModels = new AdnRvtCloudConsole.TreeViewMultiSelect();
            this._panelTop = new System.Windows.Forms.Panel();
            this._panelTop2 = new System.Windows.Forms.Panel();
            this._panelProgress = new System.Windows.Forms.Panel();
            this._panelBrowse = new System.Windows.Forms.Panel();
            this._tbFilename = new System.Windows.Forms.TextBox();
            this._bBrowse = new System.Windows.Forms.Button();
            this._bUpload = new System.Windows.Forms.Button();
            this._panelTop1 = new System.Windows.Forms.Panel();
            this.imageList1 = new System.Windows.Forms.ImageList();
            this._panelMain.SuspendLayout();
            this._panelCtrl.SuspendLayout();
            this._panelTop.SuspendLayout();
            this._panelTop2.SuspendLayout();
            this._panelBrowse.SuspendLayout();
            this.SuspendLayout();
            // 
            // _panelMain
            // 
            this._panelMain.Controls.Add(this._panelCtrl);
            this._panelMain.Controls.Add(this._panelTop);
            this._panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelMain.Location = new System.Drawing.Point(0, 0);
            this._panelMain.Name = "_panelMain";
            this._panelMain.Size = new System.Drawing.Size(432, 577);
            this._panelMain.TabIndex = 0;
            // 
            // _panelCtrl
            // 
            this._panelCtrl.Controls.Add(this._tvModels);
            this._panelCtrl.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelCtrl.Location = new System.Drawing.Point(0, 76);
            this._panelCtrl.Name = "_panelCtrl";
            this._panelCtrl.Size = new System.Drawing.Size(432, 501);
            this._panelCtrl.TabIndex = 1;
            // 
            // _tvModels
            // 
            this._tvModels.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tvModels.Indent = 24;
            this._tvModels.ItemHeight = 32;
            this._tvModels.Location = new System.Drawing.Point(0, 0);
            this._tvModels.Name = "_tvModels";
            this._tvModels.Size = new System.Drawing.Size(432, 501);
            this._tvModels.Sorted = true;
            this._tvModels.TabIndex = 0;
            // 
            // _panelTop
            // 
            this._panelTop.Controls.Add(this._panelTop2);
            this._panelTop.Controls.Add(this._panelTop1);
            this._panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this._panelTop.Location = new System.Drawing.Point(0, 0);
            this._panelTop.Name = "_panelTop";
            this._panelTop.Size = new System.Drawing.Size(432, 76);
            this._panelTop.TabIndex = 0;
            // 
            // _panelTop2
            // 
            this._panelTop2.Controls.Add(this._panelProgress);
            this._panelTop2.Controls.Add(this._panelBrowse);
            this._panelTop2.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelTop2.Location = new System.Drawing.Point(0, 36);
            this._panelTop2.Name = "_panelTop2";
            this._panelTop2.Size = new System.Drawing.Size(432, 40);
            this._panelTop2.TabIndex = 1;
            // 
            // _panelProgress
            // 
            this._panelProgress.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelProgress.Location = new System.Drawing.Point(0, 22);
            this._panelProgress.Name = "_panelProgress";
            this._panelProgress.Size = new System.Drawing.Size(432, 18);
            this._panelProgress.TabIndex = 1;
            // 
            // _panelBrowse
            // 
            this._panelBrowse.Controls.Add(this._tbFilename);
            this._panelBrowse.Controls.Add(this._bBrowse);
            this._panelBrowse.Controls.Add(this._bUpload);
            this._panelBrowse.Dock = System.Windows.Forms.DockStyle.Top;
            this._panelBrowse.Location = new System.Drawing.Point(0, 0);
            this._panelBrowse.Name = "_panelBrowse";
            this._panelBrowse.Size = new System.Drawing.Size(432, 22);
            this._panelBrowse.TabIndex = 0;
            // 
            // _tbFilename
            // 
            this._tbFilename.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tbFilename.Location = new System.Drawing.Point(0, 0);
            this._tbFilename.Name = "_tbFilename";
            this._tbFilename.Size = new System.Drawing.Size(325, 20);
            this._tbFilename.TabIndex = 2;
            // 
            // _bBrowse
            // 
            this._bBrowse.Dock = System.Windows.Forms.DockStyle.Right;
            this._bBrowse.Location = new System.Drawing.Point(325, 0);
            this._bBrowse.Name = "_bBrowse";
            this._bBrowse.Size = new System.Drawing.Size(32, 22);
            this._bBrowse.TabIndex = 0;
            this._bBrowse.Text = "...";
            this._bBrowse.UseVisualStyleBackColor = true;
            this._bBrowse.Click += new System.EventHandler(this._bBrowse_Click);
            // 
            // _bUpload
            // 
            this._bUpload.Dock = System.Windows.Forms.DockStyle.Right;
            this._bUpload.Location = new System.Drawing.Point(357, 0);
            this._bUpload.Name = "_bUpload";
            this._bUpload.Size = new System.Drawing.Size(75, 22);
            this._bUpload.TabIndex = 1;
            this._bUpload.Text = "Upload...";
            this._bUpload.UseVisualStyleBackColor = true;
            this._bUpload.Click += new System.EventHandler(this.bUpload_Click);
            // 
            // _panelTop1
            // 
            this._panelTop1.Dock = System.Windows.Forms.DockStyle.Top;
            this._panelTop1.Location = new System.Drawing.Point(0, 0);
            this._panelTop1.Name = "_panelTop1";
            this._panelTop1.Size = new System.Drawing.Size(432, 36);
            this._panelTop1.TabIndex = 0;
            this._panelTop1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Mouse_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "cloud.png");
            this.imageList1.Images.SetKeyName(1, "props.png");
            this.imageList1.Images.SetKeyName(2, "INV_Model_Solidbody_Active_Browser_16x16.ico");
            this.imageList1.Images.SetKeyName(3, "INV_Assembly_Doc_Active_Browser_16x16.ico");
            this.imageList1.Images.SetKeyName(4, "Autocad_logo.png");
            this.imageList1.Images.SetKeyName(5, "Revit.ico");
            // 
            // CloudConsoleCtrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._panelMain);
            this.DoubleBuffered = true;
            this.Name = "CloudConsoleCtrl";
            this.Size = new System.Drawing.Size(432, 577);
            this._panelMain.ResumeLayout(false);
            this._panelCtrl.ResumeLayout(false);
            this._panelTop.ResumeLayout(false);
            this._panelTop2.ResumeLayout(false);
            this._panelBrowse.ResumeLayout(false);
            this._panelBrowse.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel _panelMain;
        private System.Windows.Forms.Panel _panelCtrl;
        private System.Windows.Forms.Panel _panelTop;
        private System.Windows.Forms.Panel _panelTop2;
        private System.Windows.Forms.Panel _panelBrowse;
        private System.Windows.Forms.Button _bBrowse;
        private System.Windows.Forms.Button _bUpload;
        private System.Windows.Forms.Panel _panelTop1;
        private System.Windows.Forms.TextBox _tbFilename;
        private System.Windows.Forms.Panel _panelProgress;
        private TreeViewMultiSelect _tvModels;
        private System.Windows.Forms.ImageList imageList1;
    }
}
