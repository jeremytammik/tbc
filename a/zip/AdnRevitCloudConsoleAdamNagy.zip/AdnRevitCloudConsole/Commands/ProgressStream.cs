﻿/// Notice : Code written by Dimitris Papadimitriou - http://www.papadi.gr
/// Code is provided to be used freely but without any warranty of any kind
using System;
using System.IO;


namespace AdnRvtCloudConsole
{
  /////////////////////////////////////////////////////////////////////////////
  // A stream which can fire event to notify about its progress
  //
  /////////////////////////////////////////////////////////////////////////////
  class ProgressStream : Stream
  {
    private readonly Stream _stream;
    private readonly long _length;
    private long _bytesRead;

    public event EventHandler<ProgressChangedEventArgs> ProgressChanged;

    public class ProgressChangedEventArgs : EventArgs
    {
      public long BytesRead;
      public long Length;

      public ProgressChangedEventArgs(long BytesRead, long Length)
      {
        this.BytesRead = BytesRead;
        this.Length = Length;
      }
    }

    public ProgressStream(Stream stream)
    {
      this._stream = stream;

      _length = stream.Length;

      _bytesRead = 0;

      if (ProgressChanged != null)
        ProgressChanged(this, new ProgressChangedEventArgs(_bytesRead, _length));
    }

    public double GetProgress()
    {
      return ((double)_bytesRead) / _stream.Length;
    }

    public override bool CanRead
    {
      get { return true; }
    }

    public override bool CanSeek
    {
      get { return false; }
    }

    public override bool CanWrite
    {
      get { return false; }
    }

    public override void Flush() { }

    public override long Length
    {
      get
      {
        throw new Exception("The method or operation is not implemented.");
      }
    }

    public override long Position
    {
      get
      {
        return _bytesRead;
      }
      set
      {
        throw new Exception("The method or operation is not implemented.");
      }
    }

    public override int Read(byte[] buffer, int offset, int count)
    {
      int result = _stream.Read(buffer, offset, count);

      _bytesRead += result;

      if (ProgressChanged != null)
        ProgressChanged(this, new ProgressChangedEventArgs(_bytesRead, _length));

      return result;
    }

    public override long Seek(long offset, SeekOrigin origin)
    {
      throw new Exception("Method not implemented.");
    }

    public override void SetLength(long value)
    {
      throw new Exception("Method not implemented.");
    }

    public override void Write(byte[] buffer, int offset, int count)
    {
      throw new Exception("Method not implemented.");
    }
  }
}
