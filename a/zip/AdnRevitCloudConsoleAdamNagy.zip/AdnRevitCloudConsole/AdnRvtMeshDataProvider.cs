﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Adam Nagy 2012 - ADN/Developer Technical Services
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using AdnMeshDataUtils;
using System.IO;

using Autodesk.Revit;
using Autodesk.Revit.DB;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.UI;

namespace AdnRvtCloudConsole
{
  class AdnRvtMeshDataProvider : AdnMeshDataProvider
  {
    private Options mOptions;
    private Autodesk.Revit.ApplicationServices.Application mApplication;
    private Document mDoc;
    //private List<AdnMeshData> mMeshData;
    private List<double> mCoords, mNormals;
    private Color mColor;
    private byte mAlpha;

    /////////////////////////////////////////////////////////////////////////////
    // 
    //
    /////////////////////////////////////////////////////////////////////////////
    public AdnRvtMeshDataProvider()
    {

    }

    /////////////////////////////////////////////////////////////////////////////
    // 
    //
    /////////////////////////////////////////////////////////////////////////////
    public bool MeshModel(
        Document doc,
        string fileName,
        bool compress)
    {
      mDoc = doc;
      mApplication = mDoc.Application;
      mOptions = mApplication.Create.NewGeometryOptions();
      mOptions.DetailLevel = ViewDetailLevel.Fine;
      //mMeshData = new List<AdnMeshData>();

      try
      {
        ClearEntities();

        GetMeshData();



        return true;
      }
      catch (Exception ex)
      {
        return false;
      }
    }

    private void GetMeshData()
    {
      foreach (Element elem in GetAllModelElements(mDoc))
      {
        DrawElement(elem);
      }
    }

    double[] GetCenter()
    {
      double[] min = { double.PositiveInfinity, double.PositiveInfinity, double.PositiveInfinity };
      double[] max = { double.NegativeInfinity, double.NegativeInfinity, double.NegativeInfinity };
      for (int i = 0; i < mCoords.Count; i += 3)
      {
        if (min[0] > mCoords[i])
          min[0] = mCoords[i];

        if (min[1] > mCoords[i + 1])
          min[1] = mCoords[i + 1];

        if (min[2] > mCoords[i + 2])
          min[2] = mCoords[i + 2];

        if (max[0] < mCoords[i])
          max[0] = mCoords[i];

        if (max[1] < mCoords[i + 1])
          max[1] = mCoords[i + 1];

        if (max[2] < mCoords[i + 2])
          max[2] = mCoords[i + 2];
      }

      return new double[] 
      {
        min[0] + (max[0] - min[0]) / 2.0,
        min[1] + (max[1] - min[1]) / 2.0,
        min[2] + (max[2] - min[2]) / 2.0,
      };
    }

    private void AddFacet(
        XYZ p1,
        XYZ p2,
        XYZ p3,
        List<double> coordList)
    {
      coordList.Add(p1.X);
      coordList.Add(p1.Y);
      coordList.Add(p1.Z);

      coordList.Add(p2.X);
      coordList.Add(p2.Y);
      coordList.Add(p2.Z);

      coordList.Add(p3.X);
      coordList.Add(p3.Y);
      coordList.Add(p3.Z);
    }

    int ConvertClr(byte r, byte g, byte b, byte a)
    {
      return (r << 24) + (g << 16) + (b << 8) + a;
    }

    private IList<Element> GetAllModelElements(Document doc)
    {
      List<Element> elements = new List<Element>();

      FilteredElementCollector collector = new FilteredElementCollector(doc).WhereElementIsNotElementType();

      foreach (Element e in collector)
      {
        if (e.Category != null)
        {
          elements.Add(e);
        }
      }

      return elements;
    }

    private void DrawElement(Element elem)
    {
      if (elem is Group)
      {
        Group group = (Group)elem;
        IList<ElementId> memberIds = group.GetMemberIds();

        foreach (ElementId id in memberIds)
        {
          Element elm = mDoc.GetElement(id);
          DrawElement(elem);
        }
      }
      else
      {
        GeometryElement geom = elem.get_Geometry(mOptions);
        if ((geom != null))
        {
          // If a family instance then we need the version 
          // that is transformed into the model space
          if (elem is FamilyInstance)
            geom = geom.GetTransformed(Transform.Identity);

          DrawElement(elem, geom);
        }
      }
    }

    private void DrawElement(Element element, GeometryElement elementGeom)
    {
      if (elementGeom == null)
      {
        return;
      }

      foreach (GeometryObject geomObject in elementGeom)
      {
        if (geomObject is GeometryInstance)
        {
          DrawInstance(element, (GeometryInstance)geomObject);
        }
        else if (geomObject is Solid)
        {
          DrawSolid(element, (Solid)geomObject);
        }
      }
    }

    private void DrawInstance(Element element, GeometryInstance geomInstance)
    {
      GeometryElement geomSymbol = default(GeometryElement);
      geomSymbol = geomInstance.SymbolGeometry;

      if ((geomSymbol != null))
      {
        DrawElement(element, geomSymbol);
      }
    }

    private void DrawMesh(Element element, Face geomFace, Mesh geomMesh)
    {
      int i = 0;

      for (i = 0; i <= geomMesh.NumTriangles - 1; i++)
      {
        MeshTriangle triangle = geomMesh.get_Triangle(i);

        // Calculate normal
        /*
        XYZ u = triangle.get_Vertex(1).Subtract(triangle.get_Vertex(0));
        XYZ v = triangle.get_Vertex(2).Subtract(triangle.get_Vertex(0));
        XYZ n = u.CrossProduct(v).Normalize();
        */

        AddFacet(
          triangle.get_Vertex(0),
          triangle.get_Vertex(1),
          triangle.get_Vertex(2),
          mCoords);

        XYZ [] normals = new XYZ[3];
        for (int j = 0; j < 3; j++)
        {
          UV uv = geomFace.Project(triangle.get_Vertex(j)).UVPoint;
          normals[j] = geomFace.ComputeNormal(uv);
        }

        AddFacet(
          normals[0],
          normals[1],
          normals[2],
          mNormals);
      }
    }

    private void DrawSolid(Element element, Solid geomSolid)
    {
      if (geomSolid.Faces.Size > 0)
      {
        mCoords = new List<double>();
        mNormals = new List<double>();
        mColor = new Color(128, 128, 128);
        mAlpha = 255;

        foreach (Face face in geomSolid.Faces)
        {
          DrawFace(element, face);
        }

        double[] center = GetCenter();

        string metadataId = Guid.NewGuid().ToString();

        AdnMeshData meshData = new AdnMeshData(
           mCoords.ToArray(),
           mNormals.ToArray(),
           center,
           new int[] { ConvertClr(mColor.Red, mColor.Green, mColor.Blue, mAlpha) },
           metadataId);

        AdnMetaData metaData = new AdnMetaData(
            meshData.Id,
            new AdnMetaDataElement[]
                    {                          
                        new AdnMetaDataElement("Category", "Element", element.Category.Name.ToString()),
                        new AdnMetaDataElement("Name", "Element", element.Name)
                    });

        AddMeshEntity(meshData, metaData);
      }
    }

    private void DrawFace(Element element, Face geomFace)
    {
      Material mat = (Material)mDoc.GetElement(geomFace.MaterialElementId);

      if (mat != null)
      {
        mColor = mat.Color;
        mAlpha = (byte)((100 - mat.Transparency) * 2.55);
      }

      DrawMesh(element, geomFace, geomFace.Triangulate());
    }
  }
}
