================================================
                Revit Model Uploader 
================================================
------------------
RevitModelUploader
------------------

Description
-----------
This sample demonstrates how to store geometrical data 
on an Amazon Simple Storage Service (S3) account, so 
that it could be accessed by the Revit Model Viewer iOS 
application

System Requirements
-------------------
This sample is based on the 
<Revit SDK>\Samples\Viewers\ElementViewer sample and is
written using Visual Studio 2010 
The sample requires the Amazon SDK for .NET to be installed
on the machine:
http://aws.amazon.com/sdkfornet/

Usage
-----
You need to fill in the access key id and secret key parameters 
in the CreateAmazonS3Client() function call inside Main.vb with 
your Amazon S3 account credentials 
You also need to place the ModelUploader.addin file in the appropriate 
folder (see below) and then modify the <Assembly> part so that
it points to the dll created by the project

Possible *.addin file locations:

For Windows XP: 

C:\Documents and Settings\All Users\Application Data\
Autodesk\Revit\Addins\2011\

or 

C:\Documents and Settings\<your login>\Application Data\
Autodesk\Revit\Addins\2011\

(The first location will make the plugin available to all users of
your computer, while the second is for your use only.)

For Vista/Windows 7:

C:\ProgramData\Autodesk\Revit\Addins\2011\

or 

C:\Users\<your login>\AppData\Roaming\Autodesk\Revit\Addins\2011\

(The first location will make the plugin available to all users 
of your computer, while the second is for your use only.) 

Uninstallation
--------------
Not applicable. 

Known Issues
------------

Author
------
This sample was written by Adam Nagy of Developer Technical Services.

Acknowledgements
----------------

Further Reading
---------------

Feedback
--------

Release History
---------------

1.0    Original release

(C) Copyright 2012 by Autodesk, Inc. 

Permission to use, copy, modify, and distribute this software in
object code form for any purpose and without fee is hereby granted, 
provided that the above copyright notice appears in all copies and 
that both that copyright notice and the limited warranty and
restricted rights notice below appear in all supporting 
documentation.

AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
UNINTERRUPTED OR ERROR FREE.