﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB;

namespace SelectionChangedExample
{
    public class SelectionChangedWatcher
    {
        public event EventHandler SelectionChanged;

        private UIApplication uiApplication;
        private string selectionUID;

        public SelectionChangedWatcher(UIControlledApplication application) {
            application.ControlledApplication.DocumentOpened += new EventHandler<Autodesk.Revit.DB.Events.DocumentOpenedEventArgs>(ControlledApplication_DocumentOpened);
            application.Idling += new EventHandler<Autodesk.Revit.UI.Events.IdlingEventArgs>(application_Idling);
        }

        private List<Element> m_Selection;
        /// <summary>
        /// Stores a list of all currently selected elements.
        /// </summary>
        public List<Element> Selection {
            get {
                return m_Selection;
            }
            set {
                m_Selection = value;
            }
        }        

        void ControlledApplication_DocumentOpened(object sender, Autodesk.Revit.DB.Events.DocumentOpenedEventArgs e) {
            //--there does not seem to be a global reference to an Application object.
            //--so we store a reference by listening to the DocumentOpened event
            if (uiApplication == null) {
                uiApplication = new UIApplication(e.Document.Application);
            }
        }
        
        void application_Idling(object sender, Autodesk.Revit.UI.Events.IdlingEventArgs e) {  
            //--Idling events happen when the application has nothing else to do,
            //--however, they can happen very frequently and the user will experience a lag if this code takes a significant amount of time to execute
            //--here we store a variable "selectionUID" that contains a concatenated list of all IDs for the last selection
            //--we compare this string to a similar string for the current selection to check whether anything has changed
            if (uiApplication == null) return;
            if (uiApplication.ActiveUIDocument == null) return;
            SelElementSet selected = uiApplication.ActiveUIDocument.Selection.Elements;
            if (selected.Size == 0) {
                if (m_Selection != null && m_Selection.Count > 0) {
                    //--if something was selected previously, and now the selection is empty, report the change
                    HandleSelectionChange(selected);
                }
            } else {//--elements are selected
                if (m_Selection == null) {           
                    //--previous selection was null, report the change
                    HandleSelectionChange(selected);
                } else {
                    if (m_Selection.Count != selected.Size) {
                        //--size has changed, no need to check selectionUID, report the change
                        HandleSelectionChange(selected);
                    } else {//--count is the same... compare UID to see if selection has changed
                        string uid = "";                        
                        foreach (Element elem in selected) {                            
                            uid += "_" + elem.Id;
                        }
                        if (uid != selectionUID) {
                            //--the current concatenation of element ids doesn't match the previous one, report the change
                            HandleSelectionChange(selected);
                        }
                    }
                }
            }
        }

        private void HandleSelectionChange(SelElementSet selected) {
            //--store the current list of elements in the Selection property
            //--also populate the selectionUID with the current selection's ids
            m_Selection = new List<Element>();
            selectionUID = "";
            foreach (Element elem in selected) {
                m_Selection.Add(elem);
                selectionUID += "_" + elem.Id;
            }
            Call_SelectionChanged();
        }

        private void Call_SelectionChanged() {
            if (SelectionChanged != null) {
                SelectionChanged(this, new EventArgs());
            }
        }
    }
}

