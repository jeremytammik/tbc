#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
#endregion

namespace PurgeSpaces
{
  [Transaction( TransactionMode.Manual )]
  public class Command : IExternalCommand
  {
    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Application app = uiapp.Application;
      Document doc = uidoc.Document;

      // Retrieve elements from database

      List<ElementId> ids 
        = new List<ElementId>(
          new FilteredElementCollector( doc )
            .OfClass( typeof( SpatialElement ) )
            .Where( e => e is Room )
            .Cast<Room>()
            .Where<Room>( r => 1e-9 > r.Area )
            .Select<Element,ElementId>( e => e.Id ) );

      // Filtered element collector is iterable

      int n = ids.Count<ElementId>();

      if( 0 < n )
      {
        using( Transaction t = new Transaction( doc ) )
        {
          t.Start( "Purge Rooms" );

          int nUnplacedRooms = 0;
          int nRedundantRooms = 0;
          int nElements = 0;

          foreach( ElementId id in ids )
          {
            Debug.Print( doc.GetElement( id ).Name );
            nElements += doc.Delete( id ).Count;

            if( 1 == nElements )
            {
              ++nRedundantRooms;
            }
            else
            {
              ++nUnplacedRooms;
            }
          }

          t.Commit();

          TaskDialog.Show( "Purge Rooms", string.Format( 
            "{0} rooms ({1} redundant, {2} unplaced, {3} total elements) deleted.",
            nRedundantRooms + nUnplacedRooms, 
            nRedundantRooms, nUnplacedRooms, 
            nElements ) );
        }
      }
      return Result.Succeeded;
    }
  }
}
