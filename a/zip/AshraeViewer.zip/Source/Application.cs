// (C) Copyright 2011 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software
// in object code form for any purpose and without fee is hereby
// granted, provided that the above copyright notice appears in
// all copies and that both that copyright notice and the limited
// warranty and restricted rights notice below appear in all
// supporting documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK,
// INC. DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL
// BE UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is
// subject to restrictions set forth in FAR 52.227-19 (Commercial
// Computer Software - Restricted Rights) and DFAR 252.227-7013(c)
// (1)(ii)(Rights in Technical Data and Computer Software), as
// applicable.
//

// .NET common used namespaces
using System;
using System.Windows.Media.Imaging;
using System.Drawing;
using System.IO;
using System.Collections.Generic;
using System.Text;

// Revit.NET common used namespaces
using Autodesk.Revit;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.Attributes;

namespace ADNPlugin.Revit.RMEAshraeViewer
{
  // The main application level entry. 

  [Transaction(TransactionMode.Manual)]
  [Regeneration(RegenerationOption.Manual)]
  public class AshraeGraphicsApplication : IExternalApplication
  {
    public Result OnStartup(UIControlledApplication application)
    {
      AddRibbon(application);
      return Result.Succeeded;
    }

    public Result OnShutdown(UIControlledApplication application)
    {
      return Result.Succeeded;
    }

    // Create a simple ribbon push button for the command. 

    public void AddRibbon(UIControlledApplication application)
    {
      RibbonPanel panel = application.CreateRibbonPanel("ASHRAE");

      System.Reflection.Assembly a = 
        System.Reflection.Assembly.GetExecutingAssembly();
      string assemblyName = a.Location;
      string className = 
        "ADNPlugin.Revit.RMEAshraeViewer." +
        "AshraeGraphicsCommand";

      PushButtonData pbData = 
        new PushButtonData(
          "Select Table", "Select Table", assemblyName, className
        );
      PushButton pb = panel.AddItem(pbData) as PushButton;
      pb.LargeImage = IconToBitmapImage(Resource1.Fitting);
    }

    // Helper function: convert an icon to a bitmap image.
    
    private BitmapImage IconToBitmapImage(Icon icon)
    {
      Bitmap bitmap = icon.ToBitmap();
      MemoryStream strm = new MemoryStream();
      bitmap.Save(strm, System.Drawing.Imaging.ImageFormat.Png);

      BitmapImage bitmapImage = new BitmapImage();
      bitmapImage.BeginInit();
      strm.Seek(0, SeekOrigin.Begin);
      bitmapImage.StreamSource = strm;
      bitmapImage.EndInit();

      return bitmapImage;
    }
  }
}
