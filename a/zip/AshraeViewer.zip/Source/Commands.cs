﻿// (C) Copyright 2011 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software
// in object code form for any purpose and without fee is hereby
// granted, provided that the above copyright notice appears in
// all copies and that both that copyright notice and the limited
// warranty and restricted rights notice below appear in all
// supporting documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK,
// INC. DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL
// BE UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is
// subject to restrictions set forth in FAR 52.227-19 (Commercial
// Computer Software - Restricted Rights) and DFAR 252.227-7013(c)
// (1)(ii)(Rights in Technical Data and Computer Software), as
// applicable.
//

// .NET common used namespaces
using System.Collections.Generic;

// Revit.NET common used namespaces
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.Attributes;

namespace ADNPlugin.Revit.RMEAshraeViewer
{
  // The main command class 

  [Transaction(TransactionMode.Manual)]
  [Regeneration(RegenerationOption.Manual)]
  [Journaling(JournalingMode.NoCommandData)]
  class AshraeGraphicsCommand : IExternalCommand
  {

    // The member variables and access methods 

    private static UIDocument m_rvtUIDoc;

    private static Document m_rvtDoc;
    public static Document RevitDocument
    {
      get { return m_rvtDoc; }
    }

    static Dictionary<Element, string> _dictElementLossTable;
    public static Dictionary<Element, string> DictElementLossTable
    {
      get { return _dictElementLossTable; }
    }

    // The main entry point for the external command 

    public Autodesk.Revit.UI.Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements
    )
    {
      UIApplication m_rvtUIApp = commandData.Application;
      Application m_rvtApp = m_rvtUIApp.Application;
      m_rvtUIDoc = m_rvtUIApp.ActiveUIDocument;
      m_rvtDoc = m_rvtUIDoc.Document;

      // Get the list of duct fittings from the ASHRAE tables
      // and display in a form. 
        
      try
      {
        GetDuctFittingsOriginalTables();
        string origTable = GetFirstFittingsLossTableParamValue();

        AshraeGraphicsForm frm =
          new AshraeGraphicsForm(origTable);
        frm.ShowDialog();

        return Autodesk.Revit.UI.Result.Succeeded;
      }
      catch (System.Exception e)
      {
        message += e.ToString();
        return Autodesk.Revit.UI.Result.Failed;
      }
    }

    // Get a set of duct fittings from the pre-selection  
    // and save their original loss table values in the dictionary. 

    private static void GetDuctFittingsOriginalTables()
    {
      _dictElementLossTable = new Dictionary<Element, string>();

      Categories categories = m_rvtDoc.Settings.Categories;
      BuiltInCategory bicDuctFitting =
        BuiltInCategory.OST_DuctFitting;
      ElementId idDuctFitting =
        categories.get_Item(bicDuctFitting).Id;

      SelElementSet selElemSet = m_rvtUIDoc.Selection.Elements;
      foreach (Element elem in selElemSet)
      {
        FamilyInstance d = elem as FamilyInstance;
        if (d != null)
        {
          if (d.Category.Id == idDuctFitting)
          {
            Parameter p =
              elem.get_Parameter(
                BuiltInParameter.RBS_DUCT_FITTING_LOSS_TABLE_PARAM
              );

            // If the kind of system is not defined (supply vs.
            // return), Revit does not know what tables to apply,
            // and this value can be blank. We want to catch it here.

            try 
            {
                string val = p.AsString().Trim();
                _dictElementLossTable.Add(elem, val);
            }
            catch 
            {
                ; // no Ashrae value.  
            }

          }
        }
      }
    }

    // Return the first loss table parameter value from the 
    // current list of duct fittings.  

    private static string GetFirstFittingsLossTableParamValue()
    {
      string lossTableValue = string.Empty;
      foreach (Element e in _dictElementLossTable.Keys)
      {
        Parameter p =
          e.get_Parameter(
            BuiltInParameter.RBS_DUCT_FITTING_LOSS_TABLE_PARAM
          );
        string val = p.AsString().Trim();
        if (val.Length > 0)
        {
          lossTableValue = val;
          break;
        }
      }
      return lossTableValue;
    }
  }
}


