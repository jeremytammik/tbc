﻿// (C) Copyright 2011 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software
// in object code form for any purpose and without fee is hereby
// granted, provided that the above copyright notice appears in
// all copies and that both that copyright notice and the limited
// warranty and restricted rights notice below appear in all
// supporting documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK,
// INC. DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL
// BE UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is
// subject to restrictions set forth in FAR 52.227-19 (Commercial
// Computer Software - Restricted Rights) and DFAR 252.227-7013(c)
// (1)(ii)(Rights in Technical Data and Computer Software), as
// applicable.
//

// .NET common used namespaces
using System.Drawing;
using System.Windows.Forms;

namespace ADNPlugin.Revit.RMEAshraeViewer
{
  class ImageHelper
  {
    enum Orientation { Portrait, Landscape, Undefined };

    // Helper method: adjust the scale of the Ashrea image 
    // to fit the given picture box area on the dialog. 

    public static Bitmap ScaleImage(
      string key, PictureBox pictureBox
    )
    {
      Image img =
        AshraeImageReader.StringImageDictionary[key];

      const int kMargin = 10;
      int imgH = img.Height;
      int imgW = img.Width;
      int boxH = pictureBox.Height - kMargin;
      int boxW = pictureBox.Width - kMargin;  
      double multiplier = 1.0;  
  
      // If image is more height oriented than the box,
      // then adjust its size based on box height

      if ((double)imgH/imgW > (double)boxH/boxW)
        multiplier = (double)boxH / imgH;
      else
        multiplier = (double)boxW / imgW;

      Bitmap finalImg =
        new Bitmap(
          img, (int)(img.Width * multiplier),
          (int)(img.Height * multiplier)
        );
      return finalImg;
    }
  }
}
