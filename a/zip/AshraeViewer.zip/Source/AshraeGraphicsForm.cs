﻿// (C) Copyright 2011 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software
// in object code form for any purpose and without fee is hereby
// granted, provided that the above copyright notice appears in
// all copies and that both that copyright notice and the limited
// warranty and restricted rights notice below appear in all
// supporting documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK,
// INC. DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL
// BE UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is
// subject to restrictions set forth in FAR 52.227-19 (Commercial
// Computer Software - Restricted Rights) and DFAR 252.227-7013(c)
// (1)(ii)(Rights in Technical Data and Computer Software), as
// applicable.
//

// .NET common used namespaces
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

// Revit.NET common used namespaces
using Autodesk.Revit.DB;

namespace ADNPlugin.Revit.RMEAshraeViewer
{

  // The main form for Ashrae viewer

  public partial class AshraeGraphicsForm : System.Windows.Forms.Form
  {
    // Member variables 

    string _curTable = null;

    AshraeHelper.EnumCategory _curCategory;
    AshraeHelper.EnumFunction _curFunction;
    AshraeHelper.EnumGeometry _curGeometry;

    // Create the main form. 
    // origTable is a string indicating the first of 
    // the selected fitting types.   

    public AshraeGraphicsForm(string origTable)
    {
      InitializeComponent();
      ConfigButtons();

      PopulateListBox();

      int indx = lbData.FindString(origTable);
      if (indx > 0)
      {
        lbData.SelectedIndex = indx;
      }
    }

    // Initializing the buttons on the form  

    private void ConfigButtons()
    {
      // Category buttons 

      rbCategory1.Tag = AshraeHelper.EnumCategory.Entries;
      rbCategory2.Tag = AshraeHelper.EnumCategory.Exits;
      rbCategory3.Tag = AshraeHelper.EnumCategory.Elbows;
      rbCategory4.Tag = AshraeHelper.EnumCategory.Transitions;
      rbCategory5.Tag = AshraeHelper.EnumCategory.Junctions;
      rbCategory6.Tag = AshraeHelper.EnumCategory.Obstructions;
      rbCategory7.Tag =
        AshraeHelper.EnumCategory.FandAndSystemInteractions;
      rbCategory8.Tag =
        AshraeHelper.EnumCategory.DuctMountedEquipment;
      rbCategory9.Tag = AshraeHelper.EnumCategory.Dampers;
      rbCategory10.Tag = AshraeHelper.EnumCategory.Hoods;
      rbCategoryAll.Tag = AshraeHelper.EnumCategory.All;

      // Geometry buttons 

      rbGeometryFlatOval.Tag = AshraeHelper.EnumGeometry.FlatOval;
      rbGeometryRectangular.Tag =
        AshraeHelper.EnumGeometry.Rectangular;
      rbGeometryRound.Tag = AshraeHelper.EnumGeometry.Round;
      rbGeometryAll.Tag = AshraeHelper.EnumGeometry.All;

      // Function buttons 

      rbFunctionExhaustReturn.Tag =
        AshraeHelper.EnumFunction.ExhaustReturn;
      rbFunctionSupply.Tag = AshraeHelper.EnumFunction.Supply;
      rbFunctionAll.Tag = AshraeHelper.EnumFunction.All;

      // Default settings are All 

      rbCategoryAll.Checked = true;
      rbGeometryAll.Checked = true;
      rbFunctionAll.Checked = true;
    }

    // Initializing the ListBox in the middle with the name of
    // fittings.

    private void PopulateListBox()
    {
      lbData.Items.Clear();

      foreach (
        string name in AshraeImageReader.StringImageDictionary.Keys
      )
      {
        if (AshraeHelper.IsCategory(name, _curCategory) &&
            AshraeHelper.IsFunction(name, _curFunction) &&
            AshraeHelper.IsGeometry(name, _curGeometry))
        {
          lbData.Items.Add(name);
        }
      }
    }

    // Callback function when a radio button is changed.  

    private void radioButton_CheckedChanged(
      object sender, EventArgs e
    )
    {
      RadioButton rb = (RadioButton)sender;
      if (rb.Checked)
      {
        if (rb.Name.StartsWith("rbGeometry"))
        {
          _curGeometry = (AshraeHelper.EnumGeometry)rb.Tag;
        }

        if (rb.Name.StartsWith("rbCategory"))
        {
          _curCategory = (AshraeHelper.EnumCategory)rb.Tag;
        }

        if (rb.Name.StartsWith("rbFunction"))
        {
          _curFunction = (AshraeHelper.EnumFunction)rb.Tag;
        }

        PopulateListBox();
      }
    }

    // Callback function when the select in the list box is changed.

    private void lbData_SelectedValueChanged(
      object sender, EventArgs e
    )
    {
      _curTable = lbData.SelectedItem.ToString();
      RefreshImage();
      RefreshStatus();
    }

    // Refresh a text in the status bar with the current info. 

    private void RefreshStatus()
    {
      tsStatusLabel.Text =
        AshraeHelper.GetTableDescription(_curTable);
    }

    // Refresh the image on the form with the currect selection. 

    private void RefreshImage()
    {
      if (_curTable != null)
        pbImage.Image =
          ImageHelper.ScaleImage(_curTable, pbImage);
    }

    // Callback function when the size of the window is changed.  

    private void AshraeGraphicsForm_Resize(
      object sender, EventArgs e
    )
    {
      RefreshImage();
    }
    
    // Callback function when "Show Table" button is clicked. 

    private void btnShowTable_Click(object sender, EventArgs e)
    {
      try
      {
        // Read the table data. 

        List<string> linesList = new List<string>();
        string file = AshraeHelper.TableFilePath(_curTable);
        StreamReader sr = new StreamReader(file);
        while (sr.Peek() >= 0)
        {
          linesList.Add(sr.ReadLine());
        }

        // Display the table form. 

        AshraeTableForm frm = new AshraeTableForm();
        frm.rtbData.Lines = linesList.ToArray();
        frm.ShowDialog();
      }
      catch
      {
      }
    }

    // Callback function when the Cancel button is clicked. 

    private void btnCancel_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    // When the new value is invalid, we revert back to the original
    // value.

    private void RevertInvalidValues()
    {
      Transaction t =
        new Transaction(
          AshraeGraphicsCommand.RevitDocument, 
          "Revert invalid fitting values"
        );
      using (t)
      {
        t.Start();
        foreach (
          Element elem in
            AshraeGraphicsCommand.DictElementLossTable.Keys
        )
        {
          Parameter p =
            elem.get_Parameter(
              BuiltInParameter.RBS_DUCT_FITTING_LOSS_TABLE_PARAM
            );

          // If the value is not the same as the current table value, 
          // Revit did not accept it. Revert back to the original. 

          if (string.Compare(p.AsString(), _curTable, true) != 0)
          {
            p.Set(
              AshraeGraphicsCommand.DictElementLossTable[elem]
            );
          }

        }
        t.Commit();
      }
    }

    // Set the "Ashrae Table" property of the selected fittings 
    // to the new value

    private void SetValues()
    {
      string transName =
        string.Format("Set fitting ASHRAE table to {0}", _curTable);
      Transaction t =
        new Transaction(
          AshraeGraphicsCommand.RevitDocument, transName
        );
      using (t)
      {
        t.Start();
        foreach (
          Element elem in
            AshraeGraphicsCommand.DictElementLossTable.Keys
          )
        {
          Parameter p =
            elem.get_Parameter(
              BuiltInParameter.RBS_DUCT_FITTING_LOSS_TABLE_PARAM
            );
          
          // Can be set to invalid value, which will be reverted
          // by Revit, but may not set to the original value
          
          bool wasSet = p.Set(_curTable);
        }
        t.Commit();
      }
    }

    // Callback function when OK button is clicked. 

    private void btnOK_Click(object sender, EventArgs e)
    {
      string transName =
        string.Format("Set fitting ASHRAE table to {0}", _curTable);
      TransactionGroup tg =
        new TransactionGroup(
          AshraeGraphicsCommand.RevitDocument, transName
        );
      tg.Start();
      SetValues();
      RevertInvalidValues();
      tg.Assimilate();
      this.Close();
    }

  }
}
