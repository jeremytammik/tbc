================================================
      Plugin of the Month, April 2011
Brought to you by the Autodesk Developer Network
================================================
-------------
Ashrae Viewer
-------------

Description
-----------
This plugin can be used to view ASHRAE Table Data and
accompanying images explaining the data.

System Requirements
-------------------
This plugin has been tested with Revit MEP 2011 and 2012. 
It requires .NET Framework 3.5 for 2011 release, and 3.5 or 4.0
for 2012 release. 

A pre-built version of the plugin has been provided under 2011
and 2012 folders for corresponding release versions. 
They should work on 32- and 64-bit Windows systems.

The source code has been provided as a Visual Studio 2008 project
containing C# code (not required to run the plugin).

Installation
------------
The following is written using Revit MEP 2011. If you are using
Revit MEP 2012, please read the release number as "2012"  

1. Copy the plugin module "ADNPlugin-RMEAshraeViewer.dll" to 
a location on your local system (For example, your Revit-based 
application's root program folder).

2. Open the .addin manifest file, 
"ADNPlugin-RMEAshraeViewer.addin" in Notepad.  
Modify the following line to match the location of the plugin
module that you have just copied if it is different: 

<Assembly>C:\Program Files\Autodesk\Revit MEP 2011\
Program\ADNPlugin-RMEAshraeViewer.dll</Assembly>

Save and close the file. 

3. Copy the above .addin file you just modified to one of the 
following locations: 

For Windows XP: 

C:\Documents and Settings\All Users\Application Data\
Autodesk\Revit\Addins\2011\

or 

C:\Documents and Settings\<your login>\Application Data\
Autodesk\Revit\Addins\2011\

(The first location will make the plugin available to all users of
your computer, while the second is for your use only.)

For Vista/Windows 7:

C:\ProgramData\Autodesk\Revit\Addins\2011\

or 

C:\Users\<your login>\AppData\Roaming\Autodesk\Revit\Addins\2011\

(The first location will make the plugin available to all users 
of your computer, while the second is for your use only.) 

4. Once installed, "ASHRAE" panel and the "Select Table" command 
becomes available in your Revit MEP.  
Go to "Add-ins" tab >> "ASHRAE" panel. 
You should see "Select Table" command button there. 

Usage
-----
Inside your Revit MEP application, go to "Add-ins" tab >> 
"ASHRAE" panel >> "Select Table" to start the command. 

If you have a fitting selected in the user interface before running
"Select Table", the specific fitting will be selected in the dialog,
and you can select a different fitting type. Click OK to apply
changes.

If the selected fitting type is not compatible with the preselected
fitting, the change will be omitted.

If nothing is selected, you can use it to check all the 
available ASHRAE data.

You can also click "Show Table" to see the table data for each part.
The data comes from individual table file stored under 
"C:\Program Files\Autodesk\Revit MEP 2011\Program\Ashrae\" 

Uninstallation
--------------
Simply removing "ADNPlugin-RMEAshraeViewer.addin" file from 
your installation folder will uninstall the plugin. 

Known Issues
------------

Author
------
This plugin was written by Martin Schmid of Autodesk's AEC Industry
Success team. 

Acknowledgements
----------------

Further Reading
---------------
For more information on developing with Revit, please visit the
Revit Developer Center at http://www.autodesk.com/developrevit

Feedback
--------
Email us at labs.plugins@autodesk.com with feedback or requests for
enhancements.

Release History
---------------

1.0    Original release


(C) Copyright 2011 by Autodesk, Inc. 

Permission to use, copy, modify, and distribute this software in
object code form for any purpose and without fee is hereby granted, 
provided that the above copyright notice appears in all copies and 
that both that copyright notice and the limited warranty and
restricted rights notice below appear in all supporting 
documentation.

AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
UNINTERRUPTED OR ERROR FREE.