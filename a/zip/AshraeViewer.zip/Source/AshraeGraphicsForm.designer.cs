﻿namespace ADNPlugin.Revit.RMEAshraeViewer
{
    partial class AshraeGraphicsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.pbImage = new System.Windows.Forms.PictureBox();
          this.rbFunctionSupply = new System.Windows.Forms.RadioButton();
          this.rbFunctionExhaustReturn = new System.Windows.Forms.RadioButton();
          this.groupBox1 = new System.Windows.Forms.GroupBox();
          this.rbFunctionAll = new System.Windows.Forms.RadioButton();
          this.groupBox2 = new System.Windows.Forms.GroupBox();
          this.rbGeometryAll = new System.Windows.Forms.RadioButton();
          this.rbGeometryFlatOval = new System.Windows.Forms.RadioButton();
          this.rbGeometryRound = new System.Windows.Forms.RadioButton();
          this.rbGeometryRectangular = new System.Windows.Forms.RadioButton();
          this.groupBox3 = new System.Windows.Forms.GroupBox();
          this.rbCategoryAll = new System.Windows.Forms.RadioButton();
          this.rbCategory1 = new System.Windows.Forms.RadioButton();
          this.rbCategory10 = new System.Windows.Forms.RadioButton();
          this.rbCategory8 = new System.Windows.Forms.RadioButton();
          this.rbCategory9 = new System.Windows.Forms.RadioButton();
          this.rbCategory7 = new System.Windows.Forms.RadioButton();
          this.rbCategory5 = new System.Windows.Forms.RadioButton();
          this.rbCategory6 = new System.Windows.Forms.RadioButton();
          this.rbCategory4 = new System.Windows.Forms.RadioButton();
          this.rbCategory2 = new System.Windows.Forms.RadioButton();
          this.rbCategory3 = new System.Windows.Forms.RadioButton();
          this.lbData = new System.Windows.Forms.ListBox();
          this.btnCancel = new System.Windows.Forms.Button();
          this.btnOK = new System.Windows.Forms.Button();
          this.btnShowTable = new System.Windows.Forms.Button();
          this.ssStatus = new System.Windows.Forms.StatusStrip();
          this.tsStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
          this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
          this.panel1 = new System.Windows.Forms.Panel();
          this.panel2 = new System.Windows.Forms.Panel();
          ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
          this.groupBox1.SuspendLayout();
          this.groupBox2.SuspendLayout();
          this.groupBox3.SuspendLayout();
          this.ssStatus.SuspendLayout();
          this.tableLayoutPanel1.SuspendLayout();
          this.panel1.SuspendLayout();
          this.panel2.SuspendLayout();
          this.SuspendLayout();
          // 
          // pbImage
          // 
          this.pbImage.BackColor = System.Drawing.Color.White;
          this.pbImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
          this.pbImage.Dock = System.Windows.Forms.DockStyle.Fill;
          this.pbImage.Location = new System.Drawing.Point(353, 12);
          this.pbImage.Margin = new System.Windows.Forms.Padding(3, 12, 7, 3);
          this.pbImage.Name = "pbImage";
          this.pbImage.Size = new System.Drawing.Size(432, 499);
          this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
          this.pbImage.TabIndex = 0;
          this.pbImage.TabStop = false;
          // 
          // rbFunctionSupply
          // 
          this.rbFunctionSupply.AutoSize = true;
          this.rbFunctionSupply.Location = new System.Drawing.Point(13, 20);
          this.rbFunctionSupply.Name = "rbFunctionSupply";
          this.rbFunctionSupply.Size = new System.Drawing.Size(57, 17);
          this.rbFunctionSupply.TabIndex = 1;
          this.rbFunctionSupply.Text = "Supply";
          this.rbFunctionSupply.UseVisualStyleBackColor = true;
          this.rbFunctionSupply.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbFunctionExhaustReturn
          // 
          this.rbFunctionExhaustReturn.AutoSize = true;
          this.rbFunctionExhaustReturn.Location = new System.Drawing.Point(13, 41);
          this.rbFunctionExhaustReturn.Name = "rbFunctionExhaustReturn";
          this.rbFunctionExhaustReturn.Size = new System.Drawing.Size(106, 17);
          this.rbFunctionExhaustReturn.TabIndex = 2;
          this.rbFunctionExhaustReturn.Text = "Exhaust / Return";
          this.rbFunctionExhaustReturn.UseVisualStyleBackColor = true;
          this.rbFunctionExhaustReturn.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // groupBox1
          // 
          this.groupBox1.Controls.Add(this.rbFunctionAll);
          this.groupBox1.Controls.Add(this.rbFunctionSupply);
          this.groupBox1.Controls.Add(this.rbFunctionExhaustReturn);
          this.groupBox1.Location = new System.Drawing.Point(10, 3);
          this.groupBox1.Name = "groupBox1";
          this.groupBox1.Size = new System.Drawing.Size(181, 90);
          this.groupBox1.TabIndex = 3;
          this.groupBox1.TabStop = false;
          this.groupBox1.Text = "Fitting Function";
          // 
          // rbFunctionAll
          // 
          this.rbFunctionAll.AutoSize = true;
          this.rbFunctionAll.Location = new System.Drawing.Point(13, 62);
          this.rbFunctionAll.Name = "rbFunctionAll";
          this.rbFunctionAll.Size = new System.Drawing.Size(36, 17);
          this.rbFunctionAll.TabIndex = 3;
          this.rbFunctionAll.Text = "All";
          this.rbFunctionAll.UseVisualStyleBackColor = true;
          this.rbFunctionAll.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // groupBox2
          // 
          this.groupBox2.Controls.Add(this.rbGeometryAll);
          this.groupBox2.Controls.Add(this.rbGeometryFlatOval);
          this.groupBox2.Controls.Add(this.rbGeometryRound);
          this.groupBox2.Controls.Add(this.rbGeometryRectangular);
          this.groupBox2.Location = new System.Drawing.Point(10, 99);
          this.groupBox2.Name = "groupBox2";
          this.groupBox2.Size = new System.Drawing.Size(181, 111);
          this.groupBox2.TabIndex = 4;
          this.groupBox2.TabStop = false;
          this.groupBox2.Text = "Geometry";
          // 
          // rbGeometryAll
          // 
          this.rbGeometryAll.AutoSize = true;
          this.rbGeometryAll.Location = new System.Drawing.Point(13, 83);
          this.rbGeometryAll.Name = "rbGeometryAll";
          this.rbGeometryAll.Size = new System.Drawing.Size(36, 17);
          this.rbGeometryAll.TabIndex = 4;
          this.rbGeometryAll.Text = "All";
          this.rbGeometryAll.UseVisualStyleBackColor = true;
          this.rbGeometryAll.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbGeometryFlatOval
          // 
          this.rbGeometryFlatOval.AutoSize = true;
          this.rbGeometryFlatOval.Location = new System.Drawing.Point(13, 62);
          this.rbGeometryFlatOval.Name = "rbGeometryFlatOval";
          this.rbGeometryFlatOval.Size = new System.Drawing.Size(67, 17);
          this.rbGeometryFlatOval.TabIndex = 3;
          this.rbGeometryFlatOval.Text = "Flat Oval";
          this.rbGeometryFlatOval.UseVisualStyleBackColor = true;
          this.rbGeometryFlatOval.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbGeometryRound
          // 
          this.rbGeometryRound.AutoSize = true;
          this.rbGeometryRound.Location = new System.Drawing.Point(13, 20);
          this.rbGeometryRound.Name = "rbGeometryRound";
          this.rbGeometryRound.Size = new System.Drawing.Size(57, 17);
          this.rbGeometryRound.TabIndex = 1;
          this.rbGeometryRound.Text = "Round";
          this.rbGeometryRound.UseVisualStyleBackColor = true;
          this.rbGeometryRound.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbGeometryRectangular
          // 
          this.rbGeometryRectangular.AutoSize = true;
          this.rbGeometryRectangular.Location = new System.Drawing.Point(13, 41);
          this.rbGeometryRectangular.Name = "rbGeometryRectangular";
          this.rbGeometryRectangular.Size = new System.Drawing.Size(83, 17);
          this.rbGeometryRectangular.TabIndex = 2;
          this.rbGeometryRectangular.Text = "Rectangular";
          this.rbGeometryRectangular.UseVisualStyleBackColor = true;
          this.rbGeometryRectangular.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // groupBox3
          // 
          this.groupBox3.Controls.Add(this.rbCategoryAll);
          this.groupBox3.Controls.Add(this.rbCategory1);
          this.groupBox3.Controls.Add(this.rbCategory10);
          this.groupBox3.Controls.Add(this.rbCategory8);
          this.groupBox3.Controls.Add(this.rbCategory9);
          this.groupBox3.Controls.Add(this.rbCategory7);
          this.groupBox3.Controls.Add(this.rbCategory5);
          this.groupBox3.Controls.Add(this.rbCategory6);
          this.groupBox3.Controls.Add(this.rbCategory4);
          this.groupBox3.Controls.Add(this.rbCategory2);
          this.groupBox3.Controls.Add(this.rbCategory3);
          this.groupBox3.Location = new System.Drawing.Point(10, 216);
          this.groupBox3.Name = "groupBox3";
          this.groupBox3.Size = new System.Drawing.Size(181, 258);
          this.groupBox3.TabIndex = 5;
          this.groupBox3.TabStop = false;
          this.groupBox3.Text = "Category";
          // 
          // rbCategoryAll
          // 
          this.rbCategoryAll.AutoSize = true;
          this.rbCategoryAll.Location = new System.Drawing.Point(12, 230);
          this.rbCategoryAll.Name = "rbCategoryAll";
          this.rbCategoryAll.Size = new System.Drawing.Size(36, 17);
          this.rbCategoryAll.TabIndex = 11;
          this.rbCategoryAll.Text = "All";
          this.rbCategoryAll.UseVisualStyleBackColor = true;
          this.rbCategoryAll.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbCategory1
          // 
          this.rbCategory1.AutoSize = true;
          this.rbCategory1.Location = new System.Drawing.Point(12, 20);
          this.rbCategory1.Name = "rbCategory1";
          this.rbCategory1.Size = new System.Drawing.Size(57, 17);
          this.rbCategory1.TabIndex = 10;
          this.rbCategory1.Text = "Entries";
          this.rbCategory1.UseVisualStyleBackColor = true;
          this.rbCategory1.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbCategory10
          // 
          this.rbCategory10.AutoSize = true;
          this.rbCategory10.Location = new System.Drawing.Point(12, 209);
          this.rbCategory10.Name = "rbCategory10";
          this.rbCategory10.Size = new System.Drawing.Size(56, 17);
          this.rbCategory10.TabIndex = 9;
          this.rbCategory10.Text = "Hoods";
          this.rbCategory10.UseVisualStyleBackColor = true;
          this.rbCategory10.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbCategory8
          // 
          this.rbCategory8.AutoSize = true;
          this.rbCategory8.Location = new System.Drawing.Point(12, 167);
          this.rbCategory8.Name = "rbCategory8";
          this.rbCategory8.Size = new System.Drawing.Size(144, 17);
          this.rbCategory8.TabIndex = 7;
          this.rbCategory8.Text = "Duct mounted equipment";
          this.rbCategory8.UseVisualStyleBackColor = true;
          this.rbCategory8.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbCategory9
          // 
          this.rbCategory9.AutoSize = true;
          this.rbCategory9.Location = new System.Drawing.Point(12, 188);
          this.rbCategory9.Name = "rbCategory9";
          this.rbCategory9.Size = new System.Drawing.Size(67, 17);
          this.rbCategory9.TabIndex = 8;
          this.rbCategory9.Text = "Dampers";
          this.rbCategory9.UseVisualStyleBackColor = true;
          this.rbCategory9.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbCategory7
          // 
          this.rbCategory7.AutoSize = true;
          this.rbCategory7.Location = new System.Drawing.Point(12, 146);
          this.rbCategory7.Name = "rbCategory7";
          this.rbCategory7.Size = new System.Drawing.Size(151, 17);
          this.rbCategory7.TabIndex = 6;
          this.rbCategory7.Text = "Fan and system interaction";
          this.rbCategory7.UseVisualStyleBackColor = true;
          this.rbCategory7.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbCategory5
          // 
          this.rbCategory5.AutoSize = true;
          this.rbCategory5.Location = new System.Drawing.Point(12, 104);
          this.rbCategory5.Name = "rbCategory5";
          this.rbCategory5.Size = new System.Drawing.Size(70, 17);
          this.rbCategory5.TabIndex = 4;
          this.rbCategory5.Text = "Junctions";
          this.rbCategory5.UseVisualStyleBackColor = true;
          this.rbCategory5.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbCategory6
          // 
          this.rbCategory6.AutoSize = true;
          this.rbCategory6.Location = new System.Drawing.Point(12, 125);
          this.rbCategory6.Name = "rbCategory6";
          this.rbCategory6.Size = new System.Drawing.Size(84, 17);
          this.rbCategory6.TabIndex = 5;
          this.rbCategory6.Text = "Obstructions";
          this.rbCategory6.UseVisualStyleBackColor = true;
          this.rbCategory6.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbCategory4
          // 
          this.rbCategory4.AutoSize = true;
          this.rbCategory4.Location = new System.Drawing.Point(12, 83);
          this.rbCategory4.Name = "rbCategory4";
          this.rbCategory4.Size = new System.Drawing.Size(76, 17);
          this.rbCategory4.TabIndex = 3;
          this.rbCategory4.Text = "Transitions";
          this.rbCategory4.UseVisualStyleBackColor = true;
          this.rbCategory4.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbCategory2
          // 
          this.rbCategory2.AutoSize = true;
          this.rbCategory2.Location = new System.Drawing.Point(12, 41);
          this.rbCategory2.Name = "rbCategory2";
          this.rbCategory2.Size = new System.Drawing.Size(47, 17);
          this.rbCategory2.TabIndex = 1;
          this.rbCategory2.Text = "Exits";
          this.rbCategory2.UseVisualStyleBackColor = true;
          this.rbCategory2.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // rbCategory3
          // 
          this.rbCategory3.AutoSize = true;
          this.rbCategory3.Location = new System.Drawing.Point(12, 62);
          this.rbCategory3.Name = "rbCategory3";
          this.rbCategory3.Size = new System.Drawing.Size(59, 17);
          this.rbCategory3.TabIndex = 2;
          this.rbCategory3.Text = "Elbows";
          this.rbCategory3.UseVisualStyleBackColor = true;
          this.rbCategory3.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
          // 
          // lbData
          // 
          this.lbData.Dock = System.Windows.Forms.DockStyle.Fill;
          this.lbData.FormattingEnabled = true;
          this.lbData.IntegralHeight = false;
          this.lbData.Location = new System.Drawing.Point(203, 12);
          this.lbData.Margin = new System.Windows.Forms.Padding(3, 12, 3, 3);
          this.lbData.Name = "lbData";
          this.lbData.Size = new System.Drawing.Size(144, 499);
          this.lbData.TabIndex = 6;
          this.lbData.SelectedValueChanged += new System.EventHandler(this.lbData_SelectedValueChanged);
          // 
          // btnCancel
          // 
          this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
          this.btnCancel.Location = new System.Drawing.Point(357, 3);
          this.btnCancel.Name = "btnCancel";
          this.btnCancel.Size = new System.Drawing.Size(75, 23);
          this.btnCancel.TabIndex = 9;
          this.btnCancel.Text = "Cancel";
          this.btnCancel.UseVisualStyleBackColor = true;
          this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
          // 
          // btnOK
          // 
          this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
          this.btnOK.Location = new System.Drawing.Point(276, 3);
          this.btnOK.Name = "btnOK";
          this.btnOK.Size = new System.Drawing.Size(75, 23);
          this.btnOK.TabIndex = 8;
          this.btnOK.Text = "OK";
          this.btnOK.UseVisualStyleBackColor = true;
          this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
          // 
          // btnShowTable
          // 
          this.btnShowTable.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                      | System.Windows.Forms.AnchorStyles.Right)));
          this.btnShowTable.Location = new System.Drawing.Point(10, 480);
          this.btnShowTable.Margin = new System.Windows.Forms.Padding(7, 3, 3, 3);
          this.btnShowTable.Name = "btnShowTable";
          this.btnShowTable.Size = new System.Drawing.Size(181, 23);
          this.btnShowTable.TabIndex = 7;
          this.btnShowTable.Text = "Show Table";
          this.btnShowTable.UseVisualStyleBackColor = true;
          this.btnShowTable.Click += new System.EventHandler(this.btnShowTable_Click);
          // 
          // ssStatus
          // 
          this.ssStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsStatusLabel});
          this.ssStatus.Location = new System.Drawing.Point(0, 544);
          this.ssStatus.Name = "ssStatus";
          this.ssStatus.Size = new System.Drawing.Size(792, 22);
          this.ssStatus.TabIndex = 8;
          this.ssStatus.Text = "statusStrip1";
          // 
          // tsStatusLabel
          // 
          this.tsStatusLabel.Name = "tsStatusLabel";
          this.tsStatusLabel.Size = new System.Drawing.Size(76, 17);
          this.tsStatusLabel.Text = "Select a fitting";
          // 
          // tableLayoutPanel1
          // 
          this.tableLayoutPanel1.ColumnCount = 3;
          this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
          this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
          this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
          this.tableLayoutPanel1.Controls.Add(this.pbImage, 2, 0);
          this.tableLayoutPanel1.Controls.Add(this.lbData, 1, 0);
          this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
          this.tableLayoutPanel1.Controls.Add(this.panel2, 2, 1);
          this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
          this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
          this.tableLayoutPanel1.Name = "tableLayoutPanel1";
          this.tableLayoutPanel1.RowCount = 2;
          this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
          this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
          this.tableLayoutPanel1.Size = new System.Drawing.Size(792, 544);
          this.tableLayoutPanel1.TabIndex = 9;
          // 
          // panel1
          // 
          this.panel1.Controls.Add(this.btnShowTable);
          this.panel1.Controls.Add(this.groupBox1);
          this.panel1.Controls.Add(this.groupBox2);
          this.panel1.Controls.Add(this.groupBox3);
          this.panel1.Location = new System.Drawing.Point(3, 3);
          this.panel1.Name = "panel1";
          this.panel1.Size = new System.Drawing.Size(194, 508);
          this.panel1.TabIndex = 7;
          // 
          // panel2
          // 
          this.panel2.Controls.Add(this.btnCancel);
          this.panel2.Controls.Add(this.btnOK);
          this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
          this.panel2.Location = new System.Drawing.Point(350, 514);
          this.panel2.Margin = new System.Windows.Forms.Padding(0);
          this.panel2.Name = "panel2";
          this.panel2.Padding = new System.Windows.Forms.Padding(0, 2, 3, 0);
          this.panel2.Size = new System.Drawing.Size(442, 30);
          this.panel2.TabIndex = 8;
          // 
          // AshraeGraphicsForm
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.ClientSize = new System.Drawing.Size(792, 566);
          this.Controls.Add(this.tableLayoutPanel1);
          this.Controls.Add(this.ssStatus);
          this.MinimumSize = new System.Drawing.Size(800, 600);
          this.Name = "AshraeGraphicsForm";
          this.Text = "ASHRAE Graphics";
          this.Resize += new System.EventHandler(this.AshraeGraphicsForm_Resize);
          ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
          this.groupBox1.ResumeLayout(false);
          this.groupBox1.PerformLayout();
          this.groupBox2.ResumeLayout(false);
          this.groupBox2.PerformLayout();
          this.groupBox3.ResumeLayout(false);
          this.groupBox3.PerformLayout();
          this.ssStatus.ResumeLayout(false);
          this.ssStatus.PerformLayout();
          this.tableLayoutPanel1.ResumeLayout(false);
          this.panel1.ResumeLayout(false);
          this.panel2.ResumeLayout(false);
          this.ResumeLayout(false);
          this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbImage;
        private System.Windows.Forms.RadioButton rbFunctionSupply;
        private System.Windows.Forms.RadioButton rbFunctionExhaustReturn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbGeometryFlatOval;
        private System.Windows.Forms.RadioButton rbGeometryRound;
        private System.Windows.Forms.RadioButton rbGeometryRectangular;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rbCategory7;
        private System.Windows.Forms.RadioButton rbCategory5;
        private System.Windows.Forms.RadioButton rbCategory6;
        private System.Windows.Forms.RadioButton rbCategory4;
        private System.Windows.Forms.RadioButton rbCategory2;
        private System.Windows.Forms.RadioButton rbCategory3;
        private System.Windows.Forms.RadioButton rbCategory1;
        private System.Windows.Forms.RadioButton rbCategory10;
        private System.Windows.Forms.RadioButton rbCategory8;
        private System.Windows.Forms.RadioButton rbCategory9;
        private System.Windows.Forms.ListBox lbData;
        private System.Windows.Forms.RadioButton rbFunctionAll;
        private System.Windows.Forms.RadioButton rbGeometryAll;
        private System.Windows.Forms.RadioButton rbCategoryAll;
        private System.Windows.Forms.StatusStrip ssStatus;
        private System.Windows.Forms.ToolStripStatusLabel tsStatusLabel;
        private System.Windows.Forms.Button btnShowTable;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}

