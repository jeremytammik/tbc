﻿// (C) Copyright 2011 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software
// in object code form for any purpose and without fee is hereby
// granted, provided that the above copyright notice appears in
// all copies and that both that copyright notice and the limited
// warranty and restricted rights notice below appear in all
// supporting documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK,
// INC. DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL
// BE UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is
// subject to restrictions set forth in FAR 52.227-19 (Commercial
// Computer Software - Restricted Rights) and DFAR 252.227-7013(c)
// (1)(ii)(Rights in Technical Data and Computer Software), as
// applicable.
//

// .NET common used namespaces
using System.Diagnostics;
using System.IO;

namespace ADNPlugin.Revit.RMEAshraeViewer
{

  // Helper functions

  class AshraeHelper
  {

    // Get the path the Ashrae folder

    public static string AshraePath
    {
      get
      {
        Process p = Process.GetCurrentProcess();
        string revitExeFile = p.MainModule.FileName;
        string revitPath = Path.GetDirectoryName(revitExeFile);
        return Path.Combine(revitPath, "ASHRAE");
      }
    }

    // Get the full path to AshraeGraphics.dll 

    public static string AshraeGraphicsDllFullFilePath
    {
      get
      {
        string ashraeGraphicsDll = "AshraeGraphics.dll";
        return Path.Combine(AshraePath, ashraeGraphicsDll);
      }
    }

    // Read in the description from an Ashrae table.  

    public static string GetTableDescription(string table)
    {
      string description = string.Empty;
      try
      {
        string file = AshraeHelper.TableFilePath(table);
        StreamReader sr = new StreamReader(file);
        sr.ReadLine(); // consume first line
        string line = sr.ReadLine();
        int kPos = line.IndexOf(table);
        int len = table.Length;
        int sPos = len + kPos;
        string descr =
          line.Substring(sPos, line.Length - sPos).Trim();
        sr.Close();
        description = string.Format("{0}: {1}", table, descr);
      }
      catch
      {
        description = "Could not read .tbl file";
      }
      return description;
    }

    // Get the full path to the given Ashrae table 

    public static string TableFilePath(string key)
    {
      string tbl = key + ".tbl";
      string file = Path.Combine(AshraePath, tbl);
      return file;
    }

    // Enumerations for each groupings 

    public enum EnumFunction { All, Supply, ExhaustReturn };
    public enum EnumGeometry { All, Round, Rectangular, FlatOval };
    public enum EnumCategory
    {
      All, Entries, Exits, Elbows, Transitions, Junctions,
      Obstructions, FandAndSystemInteractions,
      DuctMountedEquipment, Dampers, Hoods
    }

    // Test if the given name satisfies current function. 

    public static bool IsFunction(
      string name, EnumFunction curFunction
    )
    {
      bool retVal = false;

      if (
        name.ToUpper().StartsWith("S") &&
        curFunction == EnumFunction.Supply
      )
        retVal = true;

      if (
        name.ToUpper().StartsWith("E") &&
        curFunction == EnumFunction.ExhaustReturn
      )
        retVal = true;

      if (name.ToUpper().StartsWith("C"))  // common
        retVal = true;

      if (curFunction == EnumFunction.All)
        retVal = true;

      return retVal;
    }

    // Test if the given name satisfies current geometry. 

    public static bool IsGeometry(
      string name, EnumGeometry curGeometry
    )
    {
      bool retVal = false;

      string geoChar = name.Substring(1, 1);
      if (geoChar == "D" && curGeometry == EnumGeometry.Round)
        retVal = true;

      if (geoChar == "R" && curGeometry == EnumGeometry.Rectangular)
        retVal = true;

      if (geoChar == "F" && curGeometry == EnumGeometry.FlatOval)
        retVal = true;

      if (curGeometry == EnumGeometry.All)
        retVal = true;

      return retVal;
    }

    // Test if the given name satisfies current category. 

    public static bool IsCategory(
      string name, EnumCategory curCategory
    )
    {
      bool retVal = false;

      string tmpTrimStart = name.Substring(2, name.Length - 2);
      string[] tmpGetPart = tmpTrimStart.Split('-');
      int categoryNumber = int.Parse(tmpGetPart[0]);

      if (categoryNumber == (int)curCategory)
        retVal = true;

      if (curCategory == EnumCategory.All)
        retVal = true;

      return retVal;
    }
  }
}
