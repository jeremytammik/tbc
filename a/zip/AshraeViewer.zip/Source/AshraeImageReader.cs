﻿// (C) Copyright 2011 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software
// in object code form for any purpose and without fee is hereby
// granted, provided that the above copyright notice appears in
// all copies and that both that copyright notice and the limited
// warranty and restricted rights notice below appear in all
// supporting documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK,
// INC. DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL
// BE UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is
// subject to restrictions set forth in FAR 52.227-19 (Commercial
// Computer Software - Restricted Rights) and DFAR 252.227-7013(c)
// (1)(ii)(Rights in Technical Data and Computer Software), as
// applicable.
//

// .NET common used namespaces
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;

namespace ADNPlugin.Revit.RMEAshraeViewer
{

  // The main class to read Ashrae images from the Ashrae graphics dll.   
  // The module AshraeGraphics.dll is stored under the following folder: 
  // C:\Program Files\Autodesk\Revit MEP 2011\Program\Ashrae

  class AshraeImageReader
  {

    // Declare unmanaged functions that we want to use from managed code
    // in order to process images. 

    [DllImport("kernel32.dll", SetLastError = true)]
    public extern static IntPtr LoadLibraryEx(
      string lpFileName, IntPtr hFile, int dwFlags
    );

    [DllImport("kernel32.dll", SetLastError = true)]
    public extern static bool EnumResourceNames(
      IntPtr hModule,
      [MarshalAs(UnmanagedType.LPStr)] string lpszType,
      EnumResNameProc lpEnumFunc, IntPtr lParam
    );

    public delegate bool EnumResNameProc(
      IntPtr hModule, IntPtr lpszType, IntPtr lpszName, IntPtr lParam
    );

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr FindResource(
      IntPtr hModule, string lpName, string lpType
     );

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr LoadResource(
      IntPtr hModule, IntPtr hResInfo
    );

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool FreeLibrary(IntPtr hModule);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern uint SizeofResource(
      IntPtr hModule, IntPtr hResInfo
    );

    // The dictionary to store the images. 

    static Dictionary<string, Image> _stringImageDictionary;

    public static Dictionary<string, Image> StringImageDictionary
    {
      get
      {
        if (_stringImageDictionary == null)
        {
          _stringImageDictionary = new Dictionary<string, Image>();
          ProcessImages();
        }
        return _stringImageDictionary;
      }

    }

    // Load Ashrae graphics dll, process each image of the type wmf,
    // and store in the dictionary. 

    private static void ProcessImages()
    {
      // Load Ashrae graphics module. 

      IntPtr hModule =
        LoadLibraryEx(
          AshraeHelper.AshraeGraphicsDllFullFilePath,
          IntPtr.Zero,
          2
        );

      // Enumerate resources of type .wmf 

      EnumResourceNames(
        hModule,
        "WMF",
        new EnumResNameProc(ListCallback),
        IntPtr.Zero
      );

      FreeLibrary(hModule);
    }

    // Callback function to be called for each enumerated resource name. 

    private static bool ListCallback(
      IntPtr hModule, IntPtr lpszType, IntPtr lpszName, IntPtr lParam
    )
    {
      string asString = Marshal.PtrToStringAnsi(lpszName);
      string asType = Marshal.PtrToStringAnsi(lpszType);

      IntPtr hResource = FindResource(hModule, asString, asType);
      IntPtr resource = LoadResource(hModule, hResource);
      UInt32 resSize = SizeofResource(hModule, hResource);
      byte[] resByteData = new byte[resSize];
      Marshal.Copy(resource, resByteData, 0, (int)resSize);
      MemoryStream resDataStream = new MemoryStream(resByteData);
      Image img = Image.FromStream(resDataStream);

      string[] name = asString.Split('.');
      _stringImageDictionary.Add(name[0], img);

      return true;
    }
  }
}
