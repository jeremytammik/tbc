#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Analysis;
using Autodesk.Revit.UI;
using Application = Autodesk.Revit.ApplicationServices.Application;
using CreationApp = Autodesk.Revit.Creation.Application;
using View = Autodesk.Revit.DB.View;
#endregion

namespace Apollonian
{
  [Transaction( TransactionMode.Manual )]
  public class Command : IExternalCommand
  {
    #region String formatting and parsing
    /// <summary>
    /// Return a string for a real number
    /// formatted to two decimal places.
    /// </summary>
    public static string RealString( double a )
    {
      return a.ToString( "0.##" );
    }

    /// <summary>
    /// Return an integer parsed 
    /// from the given string.
    /// </summary>
    static int StringToInt( string s )
    {
      return int.Parse( s );
    }

    /// <summary>
    /// Return a real number parsed 
    /// from the given string.
    /// </summary>
    static double StringToReal( string s )
    {
      return double.Parse( s );
    }

    /// <summary>
    /// Return an XYZ point or vector 
    /// parsed from the given string.
    /// </summary>
    static XYZ StringToPoint( string s )
    {
      s.TrimStart( new char[] { '(', ' ' } );
      s.TrimEnd( new char[] { ')', ' ' } );
      string[] a = s.Split( new char[] { ',', ' ' } );
      return ( 3 == a.Length )
        ? new XYZ(
            StringToReal( a[0] ),
            StringToReal( a[1] ),
            StringToReal( a[2] ) )
        : null;
    }
    #endregion // String formatting and parsing

    #region Web service request and JSON deserialisation
    // http://through-the-interface.typepad.com/through_the_interface/2012/04/consuming-data-from-a-restful-web-service-inside-autocad-using-net.html
    static dynamic ApollonianPackingWs(
      double r,
      int numSteps,
      bool circles )
    {
      string json = null;

      // Call our web-service synchronously (this 
      // isn't ideal, as it blocks the UI thread)

      HttpWebRequest request =
        WebRequest.Create(
        //"http://localhost:64114/api/"
          "http://apollonian.cloudapp.net/api/"
          + ( circles ? "circles" : "spheres" )
          + "/" + r.ToString()
          + "/" + numSteps.ToString()
        ) as HttpWebRequest;

      // Get the response

      using(
        HttpWebResponse response =
          request.GetResponse() as HttpWebResponse
        )
      {
        // Get the response stream

        StreamReader reader =
          new StreamReader(
            response.GetResponseStream() );

        // Extract our JSON results

        json = reader.ReadToEnd();
      }

      if( !String.IsNullOrEmpty( json ) )
      {
        // Use our dynamic JSON converter to 
        // populate/return our list of results

        var serializer = new JavaScriptSerializer();
        serializer.RegisterConverters(
          new[] { new DynamicJsonConverter() }
        );

        // We need to make sure we have enough space 
        // for our JSON, as the default limit may well 
        // get exceeded

        serializer.MaxJsonLength = 50000000;

        return serializer.Deserialize( json,
          typeof( List<object> ) );
      }
      return null;
    }
    #endregion // Web service request and JSON deserialisation

    #region AVF Functionality
    void CreateAvfDisplayStyle(
      Document doc,
      View view )
    {
      using( Transaction t = new Transaction( doc ) )
      {
        t.Start( "Create AVF Style" );
        AnalysisDisplayColoredSurfaceSettings
          coloredSurfaceSettings = new
            AnalysisDisplayColoredSurfaceSettings();

        coloredSurfaceSettings.ShowGridLines = false;

        AnalysisDisplayColorSettings colorSettings
          = new AnalysisDisplayColorSettings();

        AnalysisDisplayLegendSettings legendSettings
          = new AnalysisDisplayLegendSettings();

        legendSettings.ShowLegend = false;

        AnalysisDisplayStyle analysisDisplayStyle
          = AnalysisDisplayStyle
            .CreateAnalysisDisplayStyle( doc,
              "Paint Solid", coloredSurfaceSettings,
              colorSettings, legendSettings );

        view.AnalysisDisplayStyleId
          = analysisDisplayStyle.Id;

        t.Commit();
      }
    }

    static int _schemaId = -1;

    void PaintSolids(
      Document doc,
      IList<SolidAndLevel> solids )
    {
      Application app = doc.Application;

      View view = doc.ActiveView;

      if( view.AnalysisDisplayStyleId
        == ElementId.InvalidElementId )
      {
        CreateAvfDisplayStyle( doc, view );
      }

      SpatialFieldManager sfm
        = SpatialFieldManager.GetSpatialFieldManager(
          view );

      if( null == sfm )
      {
        sfm = SpatialFieldManager
          .CreateSpatialFieldManager( view, 1 );
      }

      if( _schemaId != -1 )
      {
        IList<int> results
          = sfm.GetRegisteredResults();

        if( !results.Contains( _schemaId ) )
        {
          _schemaId = -1;
        }
      }

      if( _schemaId == -1 )
      {
        AnalysisResultSchema resultSchema
          = new AnalysisResultSchema(
            "PaintedSolids", "Description" );

        _schemaId = sfm.RegisterResult( resultSchema );
      }

      foreach( SolidAndLevel sl in solids )
      {
        FaceArray faces = sl.Solid.Faces;
        Transform trf = Transform.Identity;

        foreach( Face face in faces )
        {
          int idx = sfm.AddSpatialFieldPrimitive(
            face, trf );

          IList<UV> uvPts = new List<UV>( 1 );

          uvPts.Add( face.GetBoundingBox().Min );

          FieldDomainPointsByUV pnts
            = new FieldDomainPointsByUV( uvPts );

          List<double> doubleList
            = new List<double>( 1 );

          doubleList.Add( sl.Level );

          IList<ValueAtPoint> valList
            = new List<ValueAtPoint>( 1 );

          valList.Add( new ValueAtPoint( doubleList ) );

          FieldValues vals = new FieldValues( valList );

          sfm.UpdateSpatialFieldPrimitive(
            idx, pnts, vals, _schemaId );
        }
      }
    }
    #endregion // AVF Functionality

    #region Spherical solid creation
    /// <summary>
    /// Create and return a solid sphere with
    /// a given radius and centre point.
    /// </summary>
    static public Solid CreateSphereAt(
      CreationApp creapp,
      XYZ centre,
      double radius )
    {
      // Use the standard global coordinate system 
      // as a frame, translated to the sphere centre.

      Frame frame = new Frame( centre,
        XYZ.BasisX, XYZ.BasisY, XYZ.BasisZ );

      // Create a vertical half-circle loop;
      // this must be in the frame location.

      Arc arc = creapp.NewArc(
        centre - radius * XYZ.BasisZ,
        centre + radius * XYZ.BasisZ,
        centre + radius * XYZ.BasisX );

      Line line = creapp.NewLineBound(
        arc.get_EndPoint( 1 ),
        arc.get_EndPoint( 0 ) );

      CurveLoop halfCircle = new CurveLoop();
      halfCircle.Append( arc );
      halfCircle.Append( line );

      List<CurveLoop> loops = new List<CurveLoop>( 1 );
      loops.Add( halfCircle );

      return GeometryCreationUtilities
        .CreateRevolvedGeometry(
          frame, loops, 0, 2 * Math.PI );
    }
    #endregion // Spherical solid creation

    class SolidAndLevel
    {
      public Solid Solid { get; set; }
      public int Level { get; set; }
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Application app = uiapp.Application;
      CreationApp creapp = app.Create;
      Document doc = uidoc.Document;

      if( !( doc.ActiveView is View3D ) )
      {
        message
          = "Please run this commahnd in a 3D view.";

        return Result.Failed;
      }

      XYZ centre = XYZ.Zero;
      double radius = 100.0;
      int steps = 3;

      using( Form1 f = new Form1() )
      {
        if( DialogResult.OK != f.ShowDialog() )
        {
          return Result.Cancelled;
        }
        centre = StringToPoint( f.GetCentre() );
        radius = StringToReal( f.GetRadius() );
        steps = StringToInt( f.GetLevel() );
      }

      // Time the web service operation

      Stopwatch sw = Stopwatch.StartNew();

      dynamic res = ApollonianPackingWs(
        radius, steps, false );

      sw.Stop();

      double timeWs = sw.Elapsed.TotalSeconds;

      // Create solids, going through our "dynamic"
      // list, accessing each property dynamically

      sw = Stopwatch.StartNew();

      List<SolidAndLevel> solids
        = new List<SolidAndLevel>();

      Dictionary<int, int> counters
        = new Dictionary<int, int>();

      foreach( dynamic tup in res )
      {
        double rad = System.Math.Abs( (double) tup.R );

        Debug.Assert( 0 < rad,
          "expected positive sphere radius" );

        XYZ cen = new XYZ( (double) tup.X,
          (double) tup.Y, (double) tup.Z );

        int lev = tup.L;

        Solid s = CreateSphereAt( creapp, cen, rad );

        solids.Add( new SolidAndLevel
        {
          Solid = s,
          Level = lev
        } );

        if( !counters.ContainsKey( lev ) )
        {
          counters[lev] = 0;
        }
        ++counters[lev];
      }

      sw.Stop();

      double timeSpheres = sw.Elapsed.TotalSeconds;

      // Set up AVF and paint solids

      sw = Stopwatch.StartNew();

      PaintSolids( doc, solids );

      sw.Stop();

      double timeAvf = sw.Elapsed.TotalSeconds;

      int total = 0;
      string counts = string.Empty;
      List<int> keys = new List<int>( counters.Keys );
      keys.Sort();
      foreach( int key in keys )
      {
        if( 0 < counts.Length )
        {
          counts += ",";
        }
        int n = counters[key];
        counts += n.ToString();
        total += n;
      }

      string report = string.Format(
        "{0} levels retrieved with following sphere "
        + "counts: {1} = total {2}; times in seconds "
        + "for web service {3}, sphere creation {4} "
        + "and AVF {5}.",
        counters.Count, counts, total,
        RealString( timeWs ),
        RealString( timeSpheres ),
        RealString( timeAvf ) );

      TaskDialog.Show( "Apollonian Packing", report );

      return Result.Succeeded;
    }
  }
}
