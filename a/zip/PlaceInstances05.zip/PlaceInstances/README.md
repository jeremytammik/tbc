PlaceInstances
==============

This is a Revit add-in to place family instances at locations read from selected text file.

For more information, please refer to The Building Coder blog at

http://thebuildingcoder.typepad.com
