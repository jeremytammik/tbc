﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HelixToolkit.Wpf;
using System.Windows.Media.Media3D;

namespace HelixToolkitInRevitOne.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string MODEL_PATH = @"C:\Users\FolkertvanLeeuwen\source\repos\Helix Toolkit in Revit 2017 test\Model.stl";
        public MainWindow()
        {
            InitializeComponent();

            /*IList<Point3D> points = new List<Point3D>();
            points.Add(new Point3D(0, 0, 0));
            points.Add(new Point3D(0, 1000, 0));
            points.Add(new Point3D(1000, 1000, 0));
            points.Add(new Point3D(1000, 0, 0));

            IList<Point3D> points2 = new List<Point3D>();
            points2.Add(new Point3D(0, 0, 1000));
            points2.Add(new Point3D(0, 1000, 1000));
            points2.Add(new Point3D(1000, 1000, 1000));
            points2.Add(new Point3D(1000, 0, 1000));

            IList<Point> point = new List<Point>();
            point.Add(new Point(0, 0));
            point.Add(new Point(0, 1000));
            point.Add(new Point(1000, 1000));
            point.Add(new Point(1000, 0));

            Vector3D v = new Vector3D(0, 0, 1);

            // Create a meshbuilder and add the Polygon to it
            var meshBuilder = new MeshBuilder(false, false);
            meshBuilder.AddPolygon(points);
            meshBuilder.AddPolygon(points2);

            GeometryModel3D geomModel = new GeometryModel3D { Geometry = meshBuilder.ToMesh(), Material = Materials.Red, BackMaterial = Materials.Blue };
            ModelVisual3D visual = new ModelVisual3D();

            visual.Content = geomModel;
            viewPort3d.Children.Add(visual);

            ModelVisual3D device3D = new ModelVisual3D();
            device3D.Content = Display3d(MODEL_PATH);
            // Add to view port
            viewPort3d.Children.Add(device3D);*/
        }

        private Model3D Display3d(string model)
        {
            Model3D device = null;
            try
            {
                //Adding a gesture here
                viewPort3d.RotateGesture = new MouseGesture(MouseAction.LeftClick);

                //Import 3D model file
                ModelImporter import = new ModelImporter();

                //Load the 3D model file
                device = import.Load(model);
            }
            catch (Exception e)
            {
                // Handle exception in case can not find the 3D model file
                MessageBox.Show("Exception Error : " + e.StackTrace);
            }
            return device;
        }

    }
}
