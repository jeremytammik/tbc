//
// (C) Copyright 2003-2010 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//  

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;

namespace Revit.SDK.Samples.Materials.CS
{
  /// <summary>
  /// Implements the Revit add-in IExternalCommand interface.
  /// </summary>
  [Transaction( TransactionMode.Automatic )]
  [Regeneration( RegenerationOption.Automatic )]
  [Journaling( JournalingMode.NoCommandData )]
  public class Command2 : IExternalCommand
  {
    #region IExternalCommand Members Implementation

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      try
      {
        UIApplication uiapp = commandData.Application;
        Document doc = uiapp.ActiveUIDocument.Document;

        Autodesk.Revit.Creation.Application creApp
          = doc.Application.Create;

        Autodesk.Revit.Creation.Document creDoc
          = doc.Create;

        ///////////////////////////////////////////////////////////////////////
        // Working with Materials

        Autodesk.Revit.DB.Materials materials 
          = doc.Settings.Materials;

        // Create a new RGB material.

        Material pureRed = materials.get_Item( 
          "Pure_Red" );

        if( pureRed == null )
        {
          pureRed = materials.AddGeneric( "Pure_Red" );

          pureRed.Color = new Color( 255, 0, 0 );
        }

        // Create a new "bitmap" material from an 
        // existing one and change some qualities.
        // You cannot change the bitmap or other 
        // "RenderApearance" aspects as they are 
        // stored generically as "Assets".

        Material metalChrome = materials.get_Item( 
          "Metal - Chrome - Custom" );

        if( metalChrome == null )
        {
          Material existingMetalChrome 
            = materials.get_Item( "Metal - Chrome" );

          if( existingMetalChrome != null )
          {
            // input the new name and 
            // duplicate is returned.

            metalChrome = existingMetalChrome
              .Duplicate( "Metal - Chrome - Custom" );

            metalChrome.Shininess = 128; // maximum
          }

          // note MaterialParameters is a base class 
          // and can actually be one of 
          //
          // MaterialConcreteParameters, 
          // MaterialGenericParameters, 
          // MaterialOtherParameters,
          // MaterialSteelParameters, 
          // MaterialWoodParameters
          //
          // These are the Revit parameters stored 
          // with the material in Revit.

          MaterialParameters mps 
            = MaterialParametersFactory
              .CreateMaterialParameters( metalChrome );

          // an example of how to use the sample's 
          // PropertyDescriptor to get the asset's 
          // .NET properties;
          //
          // This is the asset:

          Autodesk.Revit.Utility.Asset asset 
            = metalChrome.RenderAppearance;

          RenderAppearanceDescriptor rad 
            = new RenderAppearanceDescriptor( asset );

          PropertyDescriptorCollection 
            props = rad.GetProperties();

          // crude method for getting the properties 
          // into something readable.

          string s = "Material Asset Properties";

          TaskDialog dlg = new TaskDialog( s );

          dlg.MainInstruction = "Metal Chrome " + s;

          s = string.Empty;

          foreach( PropertyDescriptor prop in props )
          {
            s += "\n cat: " + prop.Category
              + " | name: " + prop.Name
              + " | value: " + prop.GetValue( rad );
          }

          dlg.MainContent = s;
          dlg.Show();
        }

        ///////////////////////////////////////////////////////////////////////
        // Curved wall creation and material assignment

        Level level1 = GetLevel( doc, "Level 1" );

        // Build wall creation location information 

        XYZ xAxis = new XYZ( 1, 0, 0 );
        XYZ yAxis = new XYZ( 0, 1, 0 );
        XYZ center = new XYZ( 0, 0, 0 );

        Arc geomArc = creApp.NewArc( center, 20, 0.0, 
          Math.PI / 2, xAxis, yAxis );

        // Create a wall using the arc

        Wall curveWall = creDoc.NewWall( 
          geomArc, level1, false );

        // Assign RGB colors to wall (dynamically 
        // created above... new RGB material called 
        // Pure_Red). 
        //
        // This is the RGB color when "shaded" and 
        // rendered. It is not the "wireframe" color, 
        // though.
        //
        // Note that you can also control the visible 
        // color of elements in the active view by 
        // "Visibility/Control". See the 
        // VisibilityControl sample for details.

        // Walls have a layering structure so you can 
        // assign different materials to each layer.

        WallType wt = curveWall.WallType;

        CompoundStructureLayerArray wallLayers 
          = wt.CompoundStructure.Layers;

        foreach( CompoundStructureLayer layer 
          in wallLayers )
        {
          layer.Material = pureRed;
        }

        ///////////////////////////////////////////////////////////////////////
        // Furniture material assignment

        // Here we will find an existing piece of 
        // furniture and duplicate the symbol...

        string i_desk_name = "60\" x 30\" Student";
        string m_desk_name = "1525 x 762mm Student";

        FamilySymbol symbDesk = FindFamilySymbol(
          doc, m_desk_name );

        symbDesk = symbDesk.Duplicate( 
          "Desk with Chrome Hardware" ) as FamilySymbol;

        // Assign materials to the different aspects of it.
        //
        // In the case of family content, the materials 
        // are handled through varying parameters, so 
        // you will need to know the details of the 
        // symbols you want to change materials for.

        ParameterSet a = symbDesk.Parameters;

        foreach( Parameter p in a )
        {
          Definition d = p.Definition;

          if( d.ParameterType == ParameterType.Material )
          {
            switch( d.Name )
            {
              case "Top Material":
                // here we keep default, but you 
                // could change it if needed.
                break;

              case "Body Material":
                // here we keep default, but you 
                // could change it if needed.
                break;

              case "Handle/Leg Material":
                p.Set( metalChrome.Id );
                break;
            }
          }
        }

        // Add an instance with the new material assigned

        FamilyInstance instDesk = creDoc
          .NewFamilyInstance( center, symbDesk, 
            StructuralType.NonStructural );

        ///////////////////////////////////////////////////////////////////////
        // Floor creation and material assignment (similar to wall)

        // Build floor creation location information 

        XYZ xAxisFloor = new XYZ( 1, 0, 0 );
        XYZ yAxisFloor = new XYZ( 0, 1, 0 );
        XYZ centerFloor = new XYZ( 0, 0, 0 );
        XYZ pt1Floor = new XYZ( 20.0, 0, 0 );
        XYZ pt2Floor = new XYZ( 0, 20.0, 0 );

        Line geomLine1Floor = creApp.NewLine( 
          centerFloor, pt1Floor, true );

        Arc geomArcFloor = creApp.NewArc( 
          centerFloor, 20.0, 0.0, Math.PI / 2, 
          xAxisFloor, yAxisFloor );

        Line geomLine2Floor = creApp.NewLine( 
          pt2Floor, centerFloor, true );

        CurveArray curves = new CurveArray();

        curves.Append( geomLine1Floor );
        curves.Append( geomArcFloor );
        curves.Append( geomLine2Floor );

        Floor floor = creDoc.NewFloor( curves, false );

        FloorType ft = floor.FloorType;

        CompoundStructureLayerArray floorLayers 
            = ft.CompoundStructure.Layers;

        // Same idea as the layering structure in walls...

        foreach( CompoundStructureLayer layer 
          in floorLayers )
        {
          layer.Material = pureRed;
        }
        return Result.Succeeded;
      }
      catch( Exception e )
      {
        // Exception raised, report it by 
        // Revit error reporting mechanism. 

        message = e.ToString();
        return Result.Failed;
      }
    }

    /// <summary>
    /// Return the element type matching the given name.
    /// </summary>
    private FamilySymbol FindFamilySymbol( 
      Document doc, 
      string symbolName )
    {
      FilteredElementCollector a 
        = new FilteredElementCollector( doc )
          .WhereElementIsElementType();

      var query = from element in a 
        where element.Name == symbolName 
        select element;

      Element elemType = query.Single<Element>();

      return elemType as FamilySymbol;
    }

    /// <summary>
    /// Return the level matching the given name.
    /// </summary>
    private Level GetLevel( 
      Document doc, 
      string name )
    {
      Level levelDesired = null;

      FilteredElementCollector a = 
        new FilteredElementCollector( doc )
          .OfClass( typeof( Level ) );

      foreach( Level level in a )
      {
        if( level.Name.Equals( name ) )
        {
          levelDesired = level;
          break;
        }
      }
      return levelDesired;
    }
    #endregion IExternalCommand Members Implementation
  }
}
