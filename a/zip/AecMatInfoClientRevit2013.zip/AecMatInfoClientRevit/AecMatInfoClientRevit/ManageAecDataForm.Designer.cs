﻿namespace AecMatInfoClientRevit
{
  partial class ManageAecDataForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose( bool disposing )
    {
      if( disposing && ( components != null ) )
      {
        components.Dispose();
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.getButton = new System.Windows.Forms.Button();
      this.uploadButton = new System.Windows.Forms.Button();
      this.matCostLabel = new System.Windows.Forms.Label();
      this.matRegionLabel = new System.Windows.Forms.Label();
      this.matUnitLabel = new System.Windows.Forms.Label();
      this.matSpecLabel = new System.Windows.Forms.Label();
      this.matNameLabel = new System.Windows.Forms.Label();
      this.costBox = new System.Windows.Forms.TextBox();
      this.regionBox = new System.Windows.Forms.TextBox();
      this.matUnitBox = new System.Windows.Forms.TextBox();
      this.matSpecBox = new System.Windows.Forms.TextBox();
      this.matNameBox = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // getButton
      // 
      this.getButton.Location = new System.Drawing.Point( 128, 271 );
      this.getButton.Margin = new System.Windows.Forms.Padding( 2 );
      this.getButton.Name = "getButton";
      this.getButton.Size = new System.Drawing.Size( 142, 19 );
      this.getButton.TabIndex = 23;
      this.getButton.Text = "Get Material Info";
      this.getButton.UseVisualStyleBackColor = true;
      this.getButton.Click += new System.EventHandler( this.getButton_Click );
      // 
      // uploadButton
      // 
      this.uploadButton.Location = new System.Drawing.Point( 128, 239 );
      this.uploadButton.Margin = new System.Windows.Forms.Padding( 2 );
      this.uploadButton.Name = "uploadButton";
      this.uploadButton.Size = new System.Drawing.Size( 142, 19 );
      this.uploadButton.TabIndex = 22;
      this.uploadButton.Text = "Upload Material Info";
      this.uploadButton.UseVisualStyleBackColor = true;
      this.uploadButton.Click += new System.EventHandler( this.uploadButton_Click );
      // 
      // matCostLabel
      // 
      this.matCostLabel.AutoSize = true;
      this.matCostLabel.Location = new System.Drawing.Point( 50, 197 );
      this.matCostLabel.Margin = new System.Windows.Forms.Padding( 2, 0, 2, 0 );
      this.matCostLabel.Name = "matCostLabel";
      this.matCostLabel.Size = new System.Drawing.Size( 69, 13 );
      this.matCostLabel.TabIndex = 21;
      this.matCostLabel.Text = "Cost per unit:";
      // 
      // matRegionLabel
      // 
      this.matRegionLabel.AutoSize = true;
      this.matRegionLabel.Location = new System.Drawing.Point( 76, 152 );
      this.matRegionLabel.Margin = new System.Windows.Forms.Padding( 2, 0, 2, 0 );
      this.matRegionLabel.Name = "matRegionLabel";
      this.matRegionLabel.Size = new System.Drawing.Size( 44, 13 );
      this.matRegionLabel.TabIndex = 20;
      this.matRegionLabel.Text = "Region:";
      // 
      // matUnitLabel
      // 
      this.matUnitLabel.AutoSize = true;
      this.matUnitLabel.Location = new System.Drawing.Point( 24, 107 );
      this.matUnitLabel.Margin = new System.Windows.Forms.Padding( 2, 0, 2, 0 );
      this.matUnitLabel.Name = "matUnitLabel";
      this.matUnitLabel.Size = new System.Drawing.Size( 96, 13 );
      this.matUnitLabel.TabIndex = 19;
      this.matUnitLabel.Text = "Measurement Unit:";
      // 
      // matSpecLabel
      // 
      this.matSpecLabel.AutoSize = true;
      this.matSpecLabel.Location = new System.Drawing.Point( 11, 62 );
      this.matSpecLabel.Margin = new System.Windows.Forms.Padding( 2, 0, 2, 0 );
      this.matSpecLabel.Name = "matSpecLabel";
      this.matSpecLabel.Size = new System.Drawing.Size( 111, 13 );
      this.matSpecLabel.TabIndex = 18;
      this.matSpecLabel.Text = "Material Specification:";
      // 
      // matNameLabel
      // 
      this.matNameLabel.AutoSize = true;
      this.matNameLabel.Location = new System.Drawing.Point( 42, 17 );
      this.matNameLabel.Margin = new System.Windows.Forms.Padding( 2, 0, 2, 0 );
      this.matNameLabel.Name = "matNameLabel";
      this.matNameLabel.Size = new System.Drawing.Size( 78, 13 );
      this.matNameLabel.TabIndex = 17;
      this.matNameLabel.Text = "Material Name:";
      // 
      // costBox
      // 
      this.costBox.Location = new System.Drawing.Point( 128, 194 );
      this.costBox.Margin = new System.Windows.Forms.Padding( 2 );
      this.costBox.Name = "costBox";
      this.costBox.Size = new System.Drawing.Size( 144, 20 );
      this.costBox.TabIndex = 16;
      // 
      // regionBox
      // 
      this.regionBox.Location = new System.Drawing.Point( 128, 149 );
      this.regionBox.Margin = new System.Windows.Forms.Padding( 2 );
      this.regionBox.Name = "regionBox";
      this.regionBox.Size = new System.Drawing.Size( 144, 20 );
      this.regionBox.TabIndex = 15;
      // 
      // matUnitBox
      // 
      this.matUnitBox.Location = new System.Drawing.Point( 128, 104 );
      this.matUnitBox.Margin = new System.Windows.Forms.Padding( 2 );
      this.matUnitBox.Name = "matUnitBox";
      this.matUnitBox.Size = new System.Drawing.Size( 144, 20 );
      this.matUnitBox.TabIndex = 14;
      // 
      // matSpecBox
      // 
      this.matSpecBox.Location = new System.Drawing.Point( 128, 59 );
      this.matSpecBox.Margin = new System.Windows.Forms.Padding( 2 );
      this.matSpecBox.Name = "matSpecBox";
      this.matSpecBox.Size = new System.Drawing.Size( 144, 20 );
      this.matSpecBox.TabIndex = 13;
      // 
      // matNameBox
      // 
      this.matNameBox.Location = new System.Drawing.Point( 128, 14 );
      this.matNameBox.Margin = new System.Windows.Forms.Padding( 2 );
      this.matNameBox.Name = "matNameBox";
      this.matNameBox.Size = new System.Drawing.Size( 144, 20 );
      this.matNameBox.TabIndex = 12;
      // 
      // ManageAecDataForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF( 6F, 13F );
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size( 286, 309 );
      this.Controls.Add( this.getButton );
      this.Controls.Add( this.uploadButton );
      this.Controls.Add( this.matCostLabel );
      this.Controls.Add( this.matRegionLabel );
      this.Controls.Add( this.matUnitLabel );
      this.Controls.Add( this.matSpecLabel );
      this.Controls.Add( this.matNameLabel );
      this.Controls.Add( this.costBox );
      this.Controls.Add( this.regionBox );
      this.Controls.Add( this.matUnitBox );
      this.Controls.Add( this.matSpecBox );
      this.Controls.Add( this.matNameBox );
      this.Name = "ManageAecDataForm";
      this.Text = "ManageAecDataForm";
      this.ResumeLayout( false );
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button getButton;
    private System.Windows.Forms.Button uploadButton;
    private System.Windows.Forms.Label matCostLabel;
    private System.Windows.Forms.Label matRegionLabel;
    private System.Windows.Forms.Label matUnitLabel;
    private System.Windows.Forms.Label matSpecLabel;
    private System.Windows.Forms.Label matNameLabel;
    private System.Windows.Forms.TextBox costBox;
    private System.Windows.Forms.TextBox regionBox;
    private System.Windows.Forms.TextBox matUnitBox;
    private System.Windows.Forms.TextBox matSpecBox;
    private System.Windows.Forms.TextBox matNameBox;
  }
}