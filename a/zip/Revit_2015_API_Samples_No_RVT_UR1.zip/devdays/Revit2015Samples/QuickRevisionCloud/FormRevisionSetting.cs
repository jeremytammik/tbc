﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Autodesk.Revit.DB;

namespace QuickRevisionCloud
{
    public partial class FormRevisionSetting : System.Windows.Forms.Form
    {
        public static RevisionNumberType numbericType = RevisionNumberType.Numeric;
        public static string errorDescription = "'s type is not right";
        public static string issuedBy = "Autodesk";


        public FormRevisionSetting()
        {
            InitializeComponent();
        }

        private void FormRevisionSetting_Load(object sender, EventArgs e)
        {
            //this.comboBox2.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            comboBox1.SelectedIndex = 1;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
                numbericType = RevisionNumberType.Numeric;
            else if (comboBox2.SelectedIndex == 1)
                numbericType = RevisionNumberType.Alphabetic;
            else
                numbericType = RevisionNumberType.None;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            errorDescription = comboBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            issuedBy = textBox2.Text;
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            errorDescription = comboBox1.Text;
        }
    }
}
