﻿namespace Revit.Addin.ScheduleImages
{
   partial class AddImageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddImageForm));
         this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
         this.buttonSingleImage = new System.Windows.Forms.Button();
         this.buttonMultiImages = new System.Windows.Forms.Button();
         this.buttonFolder = new System.Windows.Forms.Button();
         this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
         this.SuspendLayout();
         // 
         // buttonSingleImage
         // 
         this.buttonSingleImage.Location = new System.Drawing.Point(12, 12);
         this.buttonSingleImage.Name = "buttonSingleImage";
         this.buttonSingleImage.Size = new System.Drawing.Size(85, 31);
         this.buttonSingleImage.TabIndex = 2;
         this.buttonSingleImage.Text = "&Single";
         this.buttonSingleImage.UseVisualStyleBackColor = true;
         this.buttonSingleImage.Click += new System.EventHandler(this.buttonSingleImage_Click);
         // 
         // buttonMultiImages
         // 
         this.buttonMultiImages.Location = new System.Drawing.Point(103, 12);
         this.buttonMultiImages.Name = "buttonMultiImages";
         this.buttonMultiImages.Size = new System.Drawing.Size(85, 31);
         this.buttonMultiImages.TabIndex = 2;
         this.buttonMultiImages.Text = "&Multi Images";
         this.buttonMultiImages.UseVisualStyleBackColor = true;
         this.buttonMultiImages.Click += new System.EventHandler(this.buttonMultiImages_Click);
         // 
         // buttonFolder
         // 
         this.buttonFolder.Location = new System.Drawing.Point(194, 12);
         this.buttonFolder.Name = "buttonFolder";
         this.buttonFolder.Size = new System.Drawing.Size(85, 31);
         this.buttonFolder.TabIndex = 2;
         this.buttonFolder.Text = "&By Folder";
         this.buttonFolder.UseVisualStyleBackColor = true;
         this.buttonFolder.Click += new System.EventHandler(this.buttonFolder_Click);
         // 
         // openFileDialog
         // 
         this.openFileDialog.FileName = "Select Images to Add";
         this.openFileDialog.Filter = resources.GetString("openFileDialog.Filter");
         // 
         // AddImageForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(290, 55);
         this.Controls.Add(this.buttonFolder);
         this.Controls.Add(this.buttonMultiImages);
         this.Controls.Add(this.buttonSingleImage);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "AddImageForm";
         this.ShowIcon = false;
         this.ShowInTaskbar = false;
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
         this.Text = "Add Images";
         this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Button buttonSingleImage;
        private System.Windows.Forms.Button buttonMultiImages;
        private System.Windows.Forms.Button buttonFolder;
        private System.Windows.Forms.OpenFileDialog openFileDialog;

    }
}