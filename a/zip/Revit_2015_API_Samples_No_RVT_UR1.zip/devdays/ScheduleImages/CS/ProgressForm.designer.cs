﻿namespace Revit.Addin.ScheduleImages
{
    partial class ProgressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProgressForm));
         this.progressLabel = new System.Windows.Forms.Label();
         this.progressBar = new System.Windows.Forms.ProgressBar();
         this.label7 = new System.Windows.Forms.Label();
         this.pictureBox1 = new System.Windows.Forms.PictureBox();
         ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
         this.SuspendLayout();
         // 
         // progressLabel
         // 
         this.progressLabel.AutoSize = true;
         this.progressLabel.Location = new System.Drawing.Point(12, 7);
         this.progressLabel.Name = "progressLabel";
         this.progressLabel.Size = new System.Drawing.Size(126, 13);
         this.progressLabel.TabIndex = 12;
         this.progressLabel.Text = "Operation is in progress...";
         // 
         // progressBar
         // 
         this.progressBar.Location = new System.Drawing.Point(15, 28);
         this.progressBar.Name = "progressBar";
         this.progressBar.Size = new System.Drawing.Size(333, 20);
         this.progressBar.TabIndex = 13;
         // 
         // label7
         // 
         this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
         this.label7.Location = new System.Drawing.Point(15, 59);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(406, 2);
         this.label7.TabIndex = 20;
         this.label7.Text = "label7";
         // 
         // pictureBox1
         // 
         this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
         this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
         this.pictureBox1.Location = new System.Drawing.Point(366, 7);
         this.pictureBox1.Name = "pictureBox1";
         this.pictureBox1.Size = new System.Drawing.Size(65, 61);
         this.pictureBox1.TabIndex = 22;
         this.pictureBox1.TabStop = false;
         // 
         // ProgressForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(437, 71);
         this.Controls.Add(this.pictureBox1);
         this.Controls.Add(this.label7);
         this.Controls.Add(this.progressBar);
         this.Controls.Add(this.progressLabel);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "ProgressForm";
         this.ShowIcon = false;
         this.ShowInTaskbar = false;
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
         this.Text = "Operation Title";
         ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
         this.ResumeLayout(false);
         this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label progressLabel;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}