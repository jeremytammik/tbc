﻿namespace Revit.Addin.ScheduleImages
{
   partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
         this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
         this.label1 = new System.Windows.Forms.Label();
         this.textBoxFrom = new System.Windows.Forms.TextBox();
         this.buttonFrom = new System.Windows.Forms.Button();
         this.buttonRun = new System.Windows.Forms.Button();
         this.buttonDbg = new System.Windows.Forms.Button();
         this.label2 = new System.Windows.Forms.Label();
         this.textBoxCount = new System.Windows.Forms.TextBox();
         this.SuspendLayout();
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Location = new System.Drawing.Point(13, 21);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(44, 13);
         this.label1.TabIndex = 0;
         this.label1.Text = "Images:";
         // 
         // textBoxFrom
         // 
         this.textBoxFrom.Location = new System.Drawing.Point(75, 18);
         this.textBoxFrom.Name = "textBoxFrom";
         this.textBoxFrom.Size = new System.Drawing.Size(255, 20);
         this.textBoxFrom.TabIndex = 1;
         // 
         // buttonFrom
         // 
         this.buttonFrom.Location = new System.Drawing.Point(336, 15);
         this.buttonFrom.Name = "buttonFrom";
         this.buttonFrom.Size = new System.Drawing.Size(75, 23);
         this.buttonFrom.TabIndex = 2;
         this.buttonFrom.Text = "&Browse...";
         this.buttonFrom.UseVisualStyleBackColor = true;
         this.buttonFrom.Click += new System.EventHandler(this.buttonBrowse_Click);
         // 
         // buttonRun
         // 
         this.buttonRun.Location = new System.Drawing.Point(336, 52);
         this.buttonRun.Name = "buttonRun";
         this.buttonRun.Size = new System.Drawing.Size(75, 23);
         this.buttonRun.TabIndex = 3;
         this.buttonRun.Text = "Go -->!";
         this.buttonRun.UseVisualStyleBackColor = true;
         this.buttonRun.Click += new System.EventHandler(this.buttonRun_Click);
         // 
         // buttonDbg
         // 
         this.buttonDbg.Location = new System.Drawing.Point(255, 52);
         this.buttonDbg.Name = "buttonDbg";
         this.buttonDbg.Size = new System.Drawing.Size(75, 23);
         this.buttonDbg.TabIndex = 3;
         this.buttonDbg.Text = "dbg";
         this.buttonDbg.UseVisualStyleBackColor = true;
         this.buttonDbg.Click += new System.EventHandler(this.buttonDbg_Click);
         // 
         // label2
         // 
         this.label2.AutoSize = true;
         this.label2.Location = new System.Drawing.Point(13, 52);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(57, 13);
         this.label2.TabIndex = 0;
         this.label2.Text = "Images #: ";
         // 
         // textBoxCount
         // 
         this.textBoxCount.Location = new System.Drawing.Point(75, 49);
         this.textBoxCount.Name = "textBoxCount";
         this.textBoxCount.Size = new System.Drawing.Size(65, 20);
         this.textBoxCount.TabIndex = 1;
         // 
         // MainForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(418, 86);
         this.Controls.Add(this.buttonDbg);
         this.Controls.Add(this.buttonRun);
         this.Controls.Add(this.buttonFrom);
         this.Controls.Add(this.textBoxCount);
         this.Controls.Add(this.textBoxFrom);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.label1);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "MainForm";
         this.ShowIcon = false;
         this.ShowInTaskbar = false;
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
         this.Text = "Image Generator";
         this.ResumeLayout(false);
         this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxFrom;
        private System.Windows.Forms.Button buttonFrom;
        private System.Windows.Forms.Button buttonRun;
        private System.Windows.Forms.Button buttonDbg;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxCount;

    }
}