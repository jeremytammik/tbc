﻿namespace Revit.Addin.ScheduleImages
{
   partial class SettingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
         this.checkBoxAutoReload = new System.Windows.Forms.CheckBox();
         this.checkBoxDMU = new System.Windows.Forms.CheckBox();
         this.button1 = new System.Windows.Forms.Button();
         this.buttonOK = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // checkBoxAutoReload
         // 
         this.checkBoxAutoReload.AutoSize = true;
         this.checkBoxAutoReload.Location = new System.Drawing.Point(29, 16);
         this.checkBoxAutoReload.Name = "checkBoxAutoReload";
         this.checkBoxAutoReload.Size = new System.Drawing.Size(237, 17);
         this.checkBoxAutoReload.TabIndex = 0;
         this.checkBoxAutoReload.Text = "Auto reload images after document openning";
         this.checkBoxAutoReload.UseVisualStyleBackColor = true;
         this.checkBoxAutoReload.CheckedChanged += new System.EventHandler(this.checkBoxAutoReload_CheckedChanged);
         // 
         // checkBoxDMU
         // 
         this.checkBoxDMU.AutoSize = true;
         this.checkBoxDMU.Location = new System.Drawing.Point(29, 46);
         this.checkBoxDMU.Name = "checkBoxDMU";
         this.checkBoxDMU.Size = new System.Drawing.Size(220, 17);
         this.checkBoxDMU.TabIndex = 0;
         this.checkBoxDMU.Text = "Update image on changing Rebar Shape";
         this.checkBoxDMU.UseVisualStyleBackColor = true;
         this.checkBoxDMU.Visible = false;
         // 
         // button1
         // 
         this.button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
         this.button1.Location = new System.Drawing.Point(203, 77);
         this.button1.Name = "button1";
         this.button1.Size = new System.Drawing.Size(75, 23);
         this.button1.TabIndex = 1;
         this.button1.Text = "Cancel";
         this.button1.UseVisualStyleBackColor = true;
         this.button1.Click += new System.EventHandler(this.button1_Click);
         // 
         // buttonOK
         // 
         this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
         this.buttonOK.Location = new System.Drawing.Point(122, 77);
         this.buttonOK.Name = "buttonOK";
         this.buttonOK.Size = new System.Drawing.Size(75, 23);
         this.buttonOK.TabIndex = 1;
         this.buttonOK.Text = "OK";
         this.buttonOK.UseVisualStyleBackColor = true;
         this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
         // 
         // SettingForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(290, 112);
         this.Controls.Add(this.buttonOK);
         this.Controls.Add(this.button1);
         this.Controls.Add(this.checkBoxDMU);
         this.Controls.Add(this.checkBoxAutoReload);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "SettingForm";
         this.ShowIcon = false;
         this.ShowInTaskbar = false;
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
         this.Text = "Settings";
         this.ResumeLayout(false);
         this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBoxAutoReload;
        private System.Windows.Forms.CheckBox checkBoxDMU;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonOK;


    }
}