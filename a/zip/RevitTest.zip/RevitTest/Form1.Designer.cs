﻿namespace RevitTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bnLoadFamily = new System.Windows.Forms.Button();
            this.bnLoadFamilyWithILoadOptions = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bnLoadFamily
            // 
            this.bnLoadFamily.Location = new System.Drawing.Point(12, 12);
            this.bnLoadFamily.Name = "bnLoadFamily";
            this.bnLoadFamily.Size = new System.Drawing.Size(129, 23);
            this.bnLoadFamily.TabIndex = 0;
            this.bnLoadFamily.Text = "LoadFamily";
            this.bnLoadFamily.UseVisualStyleBackColor = true;
            this.bnLoadFamily.Click += new System.EventHandler(this.bnLoadFamily_Click);
            // 
            // bnLoadFamilyWithILoadOptions
            // 
            this.bnLoadFamilyWithILoadOptions.Location = new System.Drawing.Point(147, 12);
            this.bnLoadFamilyWithILoadOptions.Name = "bnLoadFamilyWithILoadOptions";
            this.bnLoadFamilyWithILoadOptions.Size = new System.Drawing.Size(190, 23);
            this.bnLoadFamilyWithILoadOptions.TabIndex = 1;
            this.bnLoadFamilyWithILoadOptions.Text = "LoadFamily with ILoadOptions";
            this.bnLoadFamilyWithILoadOptions.UseVisualStyleBackColor = true;
            this.bnLoadFamilyWithILoadOptions.Click += new System.EventHandler(this.bnLoadFamilyWithILoadOptions_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 75);
            this.Controls.Add(this.bnLoadFamilyWithILoadOptions);
            this.Controls.Add(this.bnLoadFamily);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bnLoadFamily;
        private System.Windows.Forms.Button bnLoadFamilyWithILoadOptions;
    }
}