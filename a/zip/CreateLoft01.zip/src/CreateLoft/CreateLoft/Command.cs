#region Namespaces
using System;
using System.Collections.Generic;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.Diagnostics;
#endregion

namespace CreateLoft
{
  [Transaction( TransactionMode.Manual )]
  public class Command : IExternalCommand
  {
    static Form CreateLoftForm( Document doc, point[] start, point[] end )
    {
      Form loftForm = null;
      ReferenceArrayArray ref_ar_ar = new ReferenceArrayArray();

      ref_ar_ar.Append( sectionLineRef( doc, start ) );

      ref_ar_ar.Append( sectionLineRef( doc, end ) );

      loftForm = doc.FamilyCreate.NewLoftForm( true, ref_ar_ar );
      return loftForm;
    }

    static ReferenceArray sectionLineRef( Document doc, point[] sectionCoords )
    {
      ReferenceArray curves = new ReferenceArray();

      XYZ start = doc.Application.Create.NewXYZ();
      XYZ end = doc.Application.Create.NewXYZ();

      for( int i = 0; i < sectionCoords.Length - 1; i++ )
      {
        start = doc.Application.Create.NewXYZ( sectionCoords[i].x, sectionCoords[i].y, sectionCoords[i].z );
        end = doc.Application.Create.NewXYZ( sectionCoords[i + 1].x, sectionCoords[i + 1].y, sectionCoords[i + 1].z );
        ModelCurve modelcurve = MakeLine( doc, start, end );
        //lineIds.Add( modelcurve.Id );
        curves.Append( modelcurve.GeometryCurve.Reference );
      }
      return curves;
    }
    
    static ModelCurve MakeLine( Document doc, XYZ ptA, XYZ ptB )
    {
      Autodesk.Revit.ApplicationServices.Application app = doc.Application;

      // Create plane by the points
      Line line = app.Create.NewLine( ptA, ptB, true );
      XYZ norm = ptA.CrossProduct( ptB );

      if( norm.GetLength() == 0 ) norm = XYZ.BasisZ;
      Plane plane = app.Create.NewPlane( norm, ptB );
      SketchPlane skplane = doc.FamilyCreate.NewSketchPlane( plane );
      
      // Create line here
      ModelCurve modelcurve = doc.FamilyCreate.NewModelCurve( line, skplane );

      return modelcurve;
    }

    class point
    {
      public double x, y, z;

      public point( double X, double Y, double Z )
      {
        x = X;
        y = Y;
        z = Z;
      }
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Application app = uiapp.Application;
      Document doc = uidoc.Document;

      try
      {
        Transaction transaction = new Transaction( doc );

        if( transaction.Start( "surface" ) == TransactionStatus.Started )
        {
          point[] start = new point[10];
          point[] end = new point[10];
          double x = 0.0;
          double z = 0.0;
          for( int i = 0; i < 10; ++i )
          {
            if( i % 2 != 0 )
            {
              x += 1;
            }
            else
            {
              z += 1;
            }
            start[i] = new point( x, 0, z );
            end[i] = new point( x, 10, z );
          }
          CreateLoftForm( doc, start, end );
          transaction.Commit();
        }
        else
        {
          transaction.RollBack();
        }
      }
      catch( Exception e )
      {
        Debug.Print( e.Message );
        TaskDialog.Show( "error", e.ToString() );
      }
      return Result.Succeeded;
    }
  }
}
