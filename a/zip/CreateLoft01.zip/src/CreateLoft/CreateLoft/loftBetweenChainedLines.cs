﻿
public class section : IExternalCommand
{
    public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
    {
        uiApp = commandData.Application;
        uidoc = uiApp.ActiveUIDocument;
        document = uidoc.Document;
        try
        {
            Transaction transaction = new Transaction(document);

            if (transaction.Start("surface") == TransactionStatus.Started)
            {
                point[] start = new point[10];
                point[] end = new point[10];
                double x = 0.0;
                double z = 0.0;
                for (int i = 0; i < 10; i++)
                {
                    if (i % 2 != 0)
                    {
                        x += 1;
                    }
                    else
                    {
                        z += 1;
                    }
                    start[i] = new point(x, 0, z);
                    end[i] = new point(x, 10, z);
                }

                CreateLoftForm(document, start, end);
                transaction.Commit();
            }
            else
            {
                transaction.RollBack();
            }


        }
        catch (Exception e)
        {
            TaskDialog.Show("error", e.ToString());
        }
    }

    static public Form CreateLoftForm(Autodesk.Revit.DB.Document document, point[] start, point[] end)
    {
        Form loftForm = null;
        ReferenceArrayArray ref_ar_ar = new ReferenceArrayArray();

        ref_ar_ar.Append(sectionLineRef(document, start));

        ref_ar_ar.Append(sectionLineRef(document, end));

        loftForm = document.FamilyCreate.NewLoftForm(true, ref_ar_ar);
        return loftForm;
    }


    static public ReferenceArray sectionLineRef(Autodesk.Revit.DB.Document document, point[] sectionCoords)
    {
        ReferenceArray curves = new ReferenceArray();

        XYZ start = document.Application.Create.NewXYZ();
        XYZ end = document.Application.Create.NewXYZ();

        for (int i = 0; i < sectionCoords.Length - 1; i++)
        {
            start = document.Application.Create.NewXYZ(sectionCoords[i].x, sectionCoords[i].y, sectionCoords[i].z);
            end = document.Application.Create.NewXYZ(sectionCoords[i + 1].x, sectionCoords[i + 1].y, sectionCoords[i + 1].z);
            ModelCurve modelcurve = MakeLine(document, start, end);
            lineIds.Add(modelcurve.Id);
            curves.Append(modelcurve.GeometryCurve.Reference);

        }
        return curves;
    }
    static public ModelCurve MakeLine(Autodesk.Revit.DB.Document doc, XYZ ptA, XYZ ptB)
    {
        Autodesk.Revit.ApplicationServices.Application app = doc.Application;
        // Create plane by the points
        Line line = app.Create.NewLine(ptA, ptB, true);
        XYZ norm = ptA.CrossProduct(ptB);

        if (norm.GetLength() == 0) norm = XYZ.BasisZ;
        Plane plane = app.Create.NewPlane(norm, ptB);
        SketchPlane skplane = doc.FamilyCreate.NewSketchPlane(plane);
        // Create line here
        ModelCurve modelcurve = doc.FamilyCreate.NewModelCurve(line, skplane);

        return modelcurve;
    }
    public class point
    {
        public double x, y, z;

        public point(double X, double Y, double Z)
        {
            x = X;
            y = Y;
            z = Z;
        }
    }

}