top.HlpSys.search.data.registerSearchDataProvider("", function (q, r) {var c = 0;var m = 100;var f = SearchResultsProvider.mergeResult;var w = top.HlpSys.search.ui.showWarning;var p = top.HlpSys.search.ui.updateProgress;if (!r) {r = new Array();}if ("/".match(q)) {r = f(r,[[3,100,[3]],[1,4,[9,15,33,62]],[6,1,[8]],[4,2,[17,59]]]);c++;}; 
if ("2000".match(q)) {r = f(r,[[8,1,[32]]]);c++;}; 
if ("2004".match(q)) {r = f(r,[[8,1,[33]]]);c++;}; 
if ("2007".match(q)) {r = f(r,[[8,1,[34]]]);c++;}; 
if ("2017".match(q)) {r = f(r,[[1,2,[69,76]]]);c++;}; 
if ("3".match(q)) {r = f(r,[[4,1,[47]]]);c++;}; 
if ("32".match(q)) {r = f(r,[[1,1,[79]]]);c++;}; 
if ("3D".match(q)) {r = f(r,[[1,1,[53]],[4,1,[39]]]);c++;}; 
if ("64".match(q)) {r = f(r,[[1,1,[-72]]]);c++;}; 
if ("activ".match(q)) {r = f(r,[[4,1,[-24]]]);c++;}; 
if ("After".match(q)) {r = f(r,[[4,1,[4]]]);c++;}; 
if ("AIA".match(q)) {r = f(r,[[7,1,[30]]]);c++;}; 
if ("allow".match(q)) {r = f(r,[[4,1,[28]]]);c++;}; 
if ("appli".match(q)) {r = f(r,[[5,2,[6,-39]]]);c++;}; 
if ("ar".match(q)) {r = f(r,[[1,4,[35,42,70,83]],[4,1,[-46]]]);c++;}; 
if ("area".match(q)) {r = f(r,[[7,1,[-58]]]);c++;}; 
if ("Autocad".match(q)) {r = f(r,[[8,1,[30]]]);c++;}; 
if ("Autodesk".match(q)) {r = f(r,[[1,2,[-27,-67]]]);c++;}; 
if ("Base".match(q)) {r = f(r,[[8,3,[28,42,-49]]]);c++;}; 
if ("base".match(q)) {r = f(r,[[1,1,[-21]],[7,1,[44]]]);c++;}; 
if ("bit".match(q)) {r = f(r,[[1,2,[73,80]]]);c++;}; 
if ("Black".match(q)) {r = f(r,[[5,1,[43]]]);c++;}; 
if ("bottom".match(q)) {r = f(r,[[4,1,[-42]]]);c++;}; 
if ("BS1192".match(q)) {r = f(r,[[7,1,[32]]]);c++;}; 
if ("buttons:".match(q)) {r = f(r,[[4,1,[48]]]);c++;}; 
if ("Cancel".match(q)) {r = f(r,[[4,1,[67]]]);c++;}; 
if ("Centimet".match(q)) {r = f(r,[[7,1,[52]]]);c++;}; 
if ("charg".match(q)) {r = f(r,[[2,1,[-6]]]);c++;}; 
if ("Check".match(q)) {r = f(r,[[6,2,[24,30]]]);c++;}; 
if ("clear".match(q)) {r = f(r,[[6,1,[-34]]]);c++;}; 
if ("click".match(q)) {r = f(r,[[5,2,[-11,19]],[8,1,[18]],[7,1,[-11]],[6,3,[-13,-25,32]],[4,4,[-29,50,62,68]]]);c++;}; 
if ("close".match(q)) {r = f(r,[[4,1,[-70]]]);c++;}; 
if ("color".match(q)) {r = f(r,[[5,4,[36,-38,46,48]]]);c++;}; 
if ("compat".match(q)) {r = f(r,[[1,1,[71]]]);c++;}; 
if ("contain".match(q)) {r = f(r,[[8,1,[64]]]);c++;}; 
if ("Coordin".match(q)) {r = f(r,[[7,1,[42]]]);c++;}; 
if ("copi".match(q)) {r = f(r,[[8,1,[-23]]]);c++;}; 
if ("CP38".match(q)) {r = f(r,[[7,1,[31]]]);c++;}; 
if ("creat".match(q)) {r = f(r,[[1,1,[38]]]);c++;}; 
if ("Current".match(q)) {r = f(r,[[4,1,[20]]]);c++;}; 
if ("Default".match(q)) {r = f(r,[[7,1,[29]]]);c++;}; 
if ("defin".match(q)) {r = f(r,[[1,1,[47]],[5,1,[50]],[7,1,[-6]],[4,1,[-55]]]);c++;}; 
if ("Defin".match(q)) {r = f(r,[[5,1,[16]],[7,1,[17]]]);c++;}; 
if ("delet".match(q)) {r = f(r,[[5,1,[-30]]]);c++;}; 
if ("determin".match(q)) {r = f(r,[[8,1,[-25]]]);c++;}; 
if ("dialog".match(q)) {r = f(r,[[5,4,[3,-9,15,24]],[8,2,[17,69]],[7,3,[5,-9,16]],[6,3,[5,-11,17]],[4,105,[3,11,-13,34,45,54]]]);c++;}; 
if ("directori".match(q)) {r = f(r,[[8,2,[-12,62]]]);c++;}; 
if ("Directori".match(q)) {r = f(r,[[8,1,[35]]]);c++;}; 
if ("disk".match(q)) {r = f(r,[[1,1,[-64]],[8,100,[-4]]]);c++;}; 
if ("displai".match(q)) {r = f(r,[[5,1,[10]],[8,1,[70]],[7,1,[10]],[6,1,[12]],[4,1,[12]]]);c++;}; 
if ("doe".match(q)) {r = f(r,[[2,1,[-7]],[1,1,[51]],[4,1,[37]]]);c++;}; 
if ("draw".match(q)) {r = f(r,[[3,100,[4]],[1,5,[-8,-14,32,-50,61]],[8,101,[3,16]],[0,100,[2]],[4,104,[2,10,-16,-36,58]]]);c++;}; 
if ("Draw".match(q)) {r = f(r,[[2,1,[3]],[1,1,[5]],[5,1,[14]],[8,1,[7]],[6,1,[16]],[4,3,[7,44,72]]]);c++;}; 
if ("drawings/view".match(q)) {r = f(r,[[5,1,[8]]]);c++;}; 
if ("drive".match(q)) {r = f(r,[[8,1,[14]]]);c++;}; 
if ("DWG".match(q)) {r = f(r,[[1,3,[-22,-24,-44]],[5,2,[-41,-54]],[8,1,[10]],[7,1,[-49]]]);c++;}; 
if ("Entiti".match(q)) {r = f(r,[[7,1,[-22]]]);c++;}; 
if ("Export".match(q)) {r = f(r,[[1,1,[25]],[5,2,[-18,22]],[7,104,[1,-3,-13,26,56]]]);c++;}; 
if ("export".match(q)) {r = f(r,[[7,2,[7,18]]]);c++;}; 
if ("extens".match(q)) {r = f(r,[[2,1,[4]],[1,3,[6,-20,-56]],[8,1,[8]],[4,2,[8,73]]]);c++;}; 
if ("Extension".match(q)) {r = f(r,[[1,1,[66]]]);c++;}; 
if ("famili".match(q)) {r = f(r,[[8,2,[45,58]]]);c++;}; 
if ("Feet".match(q)) {r = f(r,[[7,1,[55]]]);c++;}; 
if ("file".match(q)) {r = f(r,[[1,1,[45]],[5,1,[55]],[8,5,[11,24,38,53,-65]],[7,1,[50]]]);c++;}; 
if ("File".match(q)) {r = f(r,[[5,1,[-49]]]);c++;}; 
if ("file:".match(q)) {r = f(r,[[5,1,[42]]]);c++;}; 
if ("folder".match(q)) {r = f(r,[[8,1,[63]]]);c++;}; 
if ("follow".match(q)) {r = f(r,[[8,2,[-40,-55]]]);c++;}; 
if ("format:".match(q)) {r = f(r,[[8,2,[41,56]]]);c++;}; 
if ("free".match(q)) {r = f(r,[[2,1,[-5]]]);c++;}; 
if ("freez".match(q)) {r = f(r,[[5,1,[-7]],[4,3,[22,-57,-65]]]);c++;}; 
if ("Freez".match(q)) {r = f(r,[[3,100,[1]],[2,1,[-2]],[1,2,[-4,49]],[5,1,[13]],[8,2,[-6,-15]],[6,1,[15]],[0,100,[1]],[4,105,[1,-6,-9,35,-43,-71]]]);c++;}; 
if ("freeze:".match(q)) {r = f(r,[[4,1,[-19]]]);c++;}; 
if ("frozen".match(q)) {r = f(r,[[1,3,[19,-31,60]],[5,1,[-33]],[8,100,[2]],[6,2,[-10,-21]]]);c++;}; 
if ("Gener".match(q)) {r = f(r,[[1,100,[1]]]);c++;}; 
if ("ha".match(q)) {r = f(r,[[8,2,[39,54]]]);c++;}; 
if ("hard".match(q)) {r = f(r,[[8,1,[-13]]]);c++;}; 
if ("import".match(q)) {r = f(r,[[1,1,[43]],[5,1,[-40]]]);c++;}; 
if ("Import".match(q)) {r = f(r,[[1,1,[23]],[5,1,[-35]]]);c++;}; 
if ("Inche".match(q)) {r = f(r,[[7,1,[54]]]);c++;}; 
if ("includ".match(q)) {r = f(r,[[1,1,[-52]],[4,1,[-38]]]);c++;}; 
if ("individu".match(q)) {r = f(r,[[6,1,[19]]]);c++;}; 
if ("inform".match(q)) {r = f(r,[[1,100,[2]]]);c++;}; 
if ("instal".match(q)) {r = f(r,[[1,1,[81]]]);c++;}; 
if ("intern".match(q)) {r = f(r,[[7,1,[46]]]);c++;}; 
if ("Invert".match(q)) {r = f(r,[[5,1,[47]]]);c++;}; 
if ("ISO13567".match(q)) {r = f(r,[[7,1,[33]]]);c++;}; 
if ("launch".match(q)) {r = f(r,[[4,1,[-5]]]);c++;}; 
if ("Layer".match(q)) {r = f(r,[[7,4,[20,-23,25,27]]]);c++;}; 
if ("Licens".match(q)) {r = f(r,[[2,100,[1]]]);c++;}; 
if ("licens".match(q)) {r = f(r,[[2,1,[-9]]]);c++;}; 
if ("Linetyp".match(q)) {r = f(r,[[7,1,[34]]]);c++;}; 
if ("list".match(q)) {r = f(r,[[6,2,[-29,-36]]]);c++;}; 
if ("mechan".match(q)) {r = f(r,[[1,1,[26]]]);c++;}; 
if ("Meter".match(q)) {r = f(r,[[7,1,[53]]]);c++;}; 
if ("Millimet".match(q)) {r = f(r,[[7,1,[51]]]);c++;}; 
if ("Model".match(q)) {r = f(r,[[7,1,[36]]]);c++;}; 
if ("model".match(q)) {r = f(r,[[1,1,[12]]]);c++;}; 
if ("multipl".match(q)) {r = f(r,[[6,1,[-22]]]);c++;}; 
if ("name".match(q)) {r = f(r,[[8,8,[29,-36,43,47,50,-51,60,67]]]);c++;}; 
if (c>m) {w('results.limit',false); return r}; 
if ("necessari".match(q)) {r = f(r,[[5,1,[52]],[8,1,[-26]]]);c++;}; 
if ("New".match(q)) {r = f(r,[[7,1,[24]]]);c++;}; 
if ("newli".match(q)) {r = f(r,[[1,1,[-37]]]);c++;}; 
if ("None".match(q)) {r = f(r,[[6,1,[31]]]);c++;}; 
if ("object".match(q)) {r = f(r,[[1,1,[-11]]]);c++;}; 
if ("offer".match(q)) {r = f(r,[[1,1,[-57]]]);c++;}; 
if ("OK".match(q)) {r = f(r,[[4,1,[61]]]);c++;}; 
if ("onli".match(q)) {r = f(r,[[4,1,[23]]]);c++;}; 
if ("open".match(q)) {r = f(r,[[5,1,[-21]],[4,2,[-31,-52]]]);c++;}; 
if ("Option".match(q)) {r = f(r,[[5,104,[1,-2,12,20,23]],[8,1,[19]],[7,3,[4,12,15]],[4,2,[49,53]]]);c++;}; 
if ("option".match(q)) {r = f(r,[[1,1,[58]],[8,1,[22]],[7,100,[2]]]);c++;}; 
if ("order".match(q)) {r = f(r,[[8,1,[-20]]]);c++;}; 
if ("overwrit".match(q)) {r = f(r,[[8,1,[-68]]]);c++;}; 
if ("Paper".match(q)) {r = f(r,[[7,1,[38]]]);c++;}; 
if ("paramet".match(q)) {r = f(r,[[1,1,[48]],[5,2,[5,-51]],[7,1,[8]],[4,1,[56]]]);c++;}; 
if ("parameters:".match(q)) {r = f(r,[[5,1,[17]],[8,1,[27]],[7,1,[19]]]);c++;}; 
if ("place".match(q)) {r = f(r,[[1,1,[36]]]);c++;}; 
if ("polylin".match(q)) {r = f(r,[[7,1,[-59]]]);c++;}; 
if ("Preserv".match(q)) {r = f(r,[[5,1,[45]]]);c++;}; 
if ("printout".match(q)) {r = f(r,[[6,1,[9]]]);c++;}; 
if ("process".match(q)) {r = f(r,[[4,1,[66]]]);c++;}; 
if ("product".match(q)) {r = f(r,[[1,1,[78]]]);c++;}; 
if ("Project".match(q)) {r = f(r,[[7,1,[45]]]);c++;}; 
if ("properti".match(q)) {r = f(r,[[7,1,[-21]]]);c++;}; 
if ("rang".match(q)) {r = f(r,[[4,1,[-15]]]);c++;}; 
if ("Remov".match(q)) {r = f(r,[[5,1,[27]]]);c++;}; 
if ("requir".match(q)) {r = f(r,[[2,1,[-8]]]);c++;}; 
if ("Revit".match(q)) {r = f(r,[[1,5,[29,65,68,-75,-82]]]);c++;}; 
if ("room".match(q)) {r = f(r,[[7,1,[57]]]);c++;}; 
if ("save".match(q)) {r = f(r,[[1,1,[59]],[5,1,[53]],[8,3,[-9,-37,-52]]]);c++;}; 
if ("Save".match(q)) {r = f(r,[[8,100,[1]]]);c++;}; 
if ("scale".match(q)) {r = f(r,[[7,2,[35,41]]]);c++;}; 
if ("section".match(q)) {r = f(r,[[7,1,[14]]]);c++;}; 
if ("select".match(q)) {r = f(r,[[5,3,[-4,26,37]],[8,1,[-21]],[6,5,[-6,-18,23,-27,-35]],[4,1,[-14]]]);c++;}; 
if ("Select".match(q)) {r = f(r,[[1,1,[40]],[6,102,[1,-3,14]],[4,3,[26,30,32]]]);c++;}; 
if ("separ".match(q)) {r = f(r,[[1,1,[-7]]]);c++;}; 
if ("Share".match(q)) {r = f(r,[[7,1,[47]]]);c++;}; 
if ("sheet".match(q)) {r = f(r,[[1,1,[-55]],[4,1,[-41]]]);c++;}; 
if ("softwar".match(q)) {r = f(r,[[1,1,[77]]]);c++;}; 
if ("sourc".match(q)) {r = f(r,[[5,2,[-28,-31]]]);c++;}; 
if ("space".match(q)) {r = f(r,[[7,2,[37,39]]]);c++;}; 
if ("specifi".match(q)) {r = f(r,[[8,2,[-48,-66]]]);c++;}; 
if ("stai".match(q)) {r = f(r,[[1,1,[17]]]);c++;}; 
if ("Standard".match(q)) {r = f(r,[[7,1,[28]]]);c++;}; 
if ("start".match(q)) {r = f(r,[[4,1,[-64]]]);c++;}; 
if ("state".match(q)) {r = f(r,[[1,1,[-13]]]);c++;}; 
if ("support".match(q)) {r = f(r,[[1,1,[-84]]]);c++;}; 
if ("system".match(q)) {r = f(r,[[7,1,[43]]]);c++;}; 
if ("target".match(q)) {r = f(r,[[8,1,[-61]]]);c++;}; 
if ("thi".match(q)) {r = f(r,[[6,2,[26,33]],[4,3,[51,63,69]]]);c++;}; 
if ("unchang".match(q)) {r = f(r,[[1,1,[18]]]);c++;}; 
if ("Unit".match(q)) {r = f(r,[[7,1,[48]]]);c++;}; 
if ("user".match(q)) {r = f(r,[[1,1,[-46]]]);c++;}; 
if ("Using".match(q)) {r = f(r,[[1,1,[3]],[8,1,[5]]]);c++;}; 
if ("version".match(q)) {r = f(r,[[1,1,[74]]]);c++;}; 
if ("version:".match(q)) {r = f(r,[[8,1,[31]]]);c++;}; 
if ("view".match(q)) {r = f(r,[[3,100,[2]],[1,7,[10,16,34,39,41,54,63]],[5,2,[29,32]],[6,104,[2,4,7,20,-28]],[4,7,[18,21,25,27,33,40,60]]]);c++;}; 
if ("View".match(q)) {r = f(r,[[5,1,[-25]],[8,4,[44,46,57,59]],[7,1,[40]]]);c++;}; 
if ("views/draw".match(q)) {r = f(r,[[5,1,[34]]]);c++;}; 
if ("white".match(q)) {r = f(r,[[5,1,[-44]]]);c++;}; 
if ("®".match(q)) {r = f(r,[[1,2,[28,30]]]);c++;}; 
return r;});
// SIG // Begin signature block
// SIG // MIIZNgYJKoZIhvcNAQcCoIIZJzCCGSMCAQExCzAJBgUr
// SIG // DgMCGgUAMGcGCisGAQQBgjcCAQSgWTBXMDIGCisGAQQB
// SIG // gjcCAR4wJAIBAQQQEODJBs441BGiowAQS9NQkAIBAAIB
// SIG // AAIBAAIBAAIBADAhMAkGBSsOAwIaBQAEFPKXtgOx4xW0
// SIG // VKpq8bXXhZAs/UHnoIIUMDCCA+4wggNXoAMCAQICEH6T
// SIG // 6/t8xk5Z6kuad9QG/DswDQYJKoZIhvcNAQEFBQAwgYsx
// SIG // CzAJBgNVBAYTAlpBMRUwEwYDVQQIEwxXZXN0ZXJuIENh
// SIG // cGUxFDASBgNVBAcTC0R1cmJhbnZpbGxlMQ8wDQYDVQQK
// SIG // EwZUaGF3dGUxHTAbBgNVBAsTFFRoYXd0ZSBDZXJ0aWZp
// SIG // Y2F0aW9uMR8wHQYDVQQDExZUaGF3dGUgVGltZXN0YW1w
// SIG // aW5nIENBMB4XDTEyMTIyMTAwMDAwMFoXDTIwMTIzMDIz
// SIG // NTk1OVowXjELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5
// SIG // bWFudGVjIENvcnBvcmF0aW9uMTAwLgYDVQQDEydTeW1h
// SIG // bnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIENBIC0g
// SIG // RzIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
// SIG // AQCxrLNJVEuXHBIK2CV5kSJXKm/cuCbEQ3Nrwr8uUFr7
// SIG // FMJ2jkMBJUO0oeJF9Oi3e8N0zCLXtJQAAvdN7b+0t0Qk
// SIG // a81fRTvRRM5DEnMXgotptCvLmR6schsmTXEfsTHd+1Fh
// SIG // AlOmqvVJLAV4RaUvic7nmef+jOJXPz3GktxK+Hsz5HkK
// SIG // +/B1iEGc/8UDUZmq12yfk2mHZSmDhcJgFMTIyTsU2sCB
// SIG // 8B8NdN6SIqvK9/t0fCfm90obf6fDni2uiuqm5qonFn1h
// SIG // 95hxEbziUKFL5V365Q6nLJ+qZSDT2JboyHylTkhE/xni
// SIG // RAeSC9dohIBdanhkRc1gRn5UwRN8xXnxycFxAgMBAAGj
// SIG // gfowgfcwHQYDVR0OBBYEFF+a9W5czMx0mtTdfe8/2+xM
// SIG // gC7dMDIGCCsGAQUFBwEBBCYwJDAiBggrBgEFBQcwAYYW
// SIG // aHR0cDovL29jc3AudGhhd3RlLmNvbTASBgNVHRMBAf8E
// SIG // CDAGAQH/AgEAMD8GA1UdHwQ4MDYwNKAyoDCGLmh0dHA6
// SIG // Ly9jcmwudGhhd3RlLmNvbS9UaGF3dGVUaW1lc3RhbXBp
// SIG // bmdDQS5jcmwwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDgYD
// SIG // VR0PAQH/BAQDAgEGMCgGA1UdEQQhMB+kHTAbMRkwFwYD
// SIG // VQQDExBUaW1lU3RhbXAtMjA0OC0xMA0GCSqGSIb3DQEB
// SIG // BQUAA4GBAAMJm495739ZMKrvaLX64wkdu0+CBl03X6ZS
// SIG // nxaN6hySCURu9W3rWHww6PlpjSNzCxJvR6muORH4KrGb
// SIG // sBrDjutZlgCtzgxNstAxpghcKnr84nodV0yoZRjpeUBi
// SIG // JZZux8c3aoMhCI5B6t3ZVz8dd0mHKhYGXqY4aiISo1EZ
// SIG // g362MIIEozCCA4ugAwIBAgIQDs/0OMj+vzVuBNhqmBsa
// SIG // UDANBgkqhkiG9w0BAQUFADBeMQswCQYDVQQGEwJVUzEd
// SIG // MBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xMDAu
// SIG // BgNVBAMTJ1N5bWFudGVjIFRpbWUgU3RhbXBpbmcgU2Vy
// SIG // dmljZXMgQ0EgLSBHMjAeFw0xMjEwMTgwMDAwMDBaFw0y
// SIG // MDEyMjkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMR0wGwYD
// SIG // VQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjE0MDIGA1UE
// SIG // AxMrU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNl
// SIG // cyBTaWduZXIgLSBHNDCCASIwDQYJKoZIhvcNAQEBBQAD
// SIG // ggEPADCCAQoCggEBAKJjCzlEuLsjp0RJuw7/ofBhClOT
// SIG // sJjbrSwPSsVu/4Y8U1UPFc4EPyv9qZaW2b5heQtbyUyG
// SIG // duXgQ0sile7CK0PBn9hotI5AT+6FOLkRxSPyZFjwFTJv
// SIG // TlehroikAtcqHs1L4d1j1ReJMluwXplaqJ0oUA4X7pbb
// SIG // YTtFUR3PElYLkkf8q672Zj1HrHBy55LnX80QucSDZJQZ
// SIG // vSWA4ejSIqXQugJ6oXeTW2XD7hd0vEGGKtwITIySjJEt
// SIG // nndEH2jWqHR32w5bMotWizO92WPISZ06xcXqMwvS8aMb
// SIG // 9Iu+2bNXizveBKd6IrIkri7HcMW+ToMmCPsLvalPmQjh
// SIG // EChyqs0CAwEAAaOCAVcwggFTMAwGA1UdEwEB/wQCMAAw
// SIG // FgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/
// SIG // BAQDAgeAMHMGCCsGAQUFBwEBBGcwZTAqBggrBgEFBQcw
// SIG // AYYeaHR0cDovL3RzLW9jc3Aud3Muc3ltYW50ZWMuY29t
// SIG // MDcGCCsGAQUFBzAChitodHRwOi8vdHMtYWlhLndzLnN5
// SIG // bWFudGVjLmNvbS90c3MtY2EtZzIuY2VyMDwGA1UdHwQ1
// SIG // MDMwMaAvoC2GK2h0dHA6Ly90cy1jcmwud3Muc3ltYW50
// SIG // ZWMuY29tL3Rzcy1jYS1nMi5jcmwwKAYDVR0RBCEwH6Qd
// SIG // MBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0yMDQ4LTIwHQYD
// SIG // VR0OBBYEFEbGaaMOShQe1UzaUmMXP142vA3mMB8GA1Ud
// SIG // IwQYMBaAFF+a9W5czMx0mtTdfe8/2+xMgC7dMA0GCSqG
// SIG // SIb3DQEBBQUAA4IBAQB4O7SRKgBM8I9iMDd4o4QnB28Y
// SIG // st4l3KDUlAOqhk4ln5pAAxzdzuN5yyFoBtq2MrRtv/Qs
// SIG // JmMz5ElkbQ3mw2cO9wWkNWx8iRbG6bLfsundIMZxD82V
// SIG // dNy2XN69Nx9DeOZ4tc0oBCCjqvFLxIgpkQ6A0RH83Vx2
// SIG // bk9eDkVGQW4NsOo4mrE62glxEPwcebSAe6xp9P2ctgwW
// SIG // K/F/Wwk9m1viFsoTgW0ALjgNqCmPLOGy9FqpAa8VnCwv
// SIG // SRvbIrvD/niUUcOGsYKIXfA9tFGheTMrLnu53CAJE3Hr
// SIG // ahlbz+ilMFcsiUk/uc9/yb8+ImhjU5q9aXSsxR08f5Lg
// SIG // w7wc2AR1MIIFhTCCBG2gAwIBAgIQKcFbP6rNUmpOZ708
// SIG // Tn4/8jANBgkqhkiG9w0BAQUFADCBtDELMAkGA1UEBhMC
// SIG // VVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYD
// SIG // VQQLExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTswOQYD
// SIG // VQQLEzJUZXJtcyBvZiB1c2UgYXQgaHR0cHM6Ly93d3cu
// SIG // dmVyaXNpZ24uY29tL3JwYSAoYykxMDEuMCwGA1UEAxMl
// SIG // VmVyaVNpZ24gQ2xhc3MgMyBDb2RlIFNpZ25pbmcgMjAx
// SIG // MCBDQTAeFw0xMjA3MjUwMDAwMDBaFw0xNTA5MjAyMzU5
// SIG // NTlaMIHIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2Fs
// SIG // aWZvcm5pYTETMBEGA1UEBxMKU2FuIFJhZmFlbDEWMBQG
// SIG // A1UEChQNQXV0b2Rlc2ssIEluYzE+MDwGA1UECxM1RGln
// SIG // aXRhbCBJRCBDbGFzcyAzIC0gTWljcm9zb2Z0IFNvZnR3
// SIG // YXJlIFZhbGlkYXRpb24gdjIxHzAdBgNVBAsUFkRlc2ln
// SIG // biBTb2x1dGlvbnMgR3JvdXAxFjAUBgNVBAMUDUF1dG9k
// SIG // ZXNrLCBJbmMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
// SIG // ggEKAoIBAQCoYmDrmd0Gq8ezSsDlfgaJFEFplNPNhWzM
// SIG // 2uFQaYAB/ggpQ11+N4B6ao+TqrNIWDIqt3JKhaU889nx
// SIG // l/7teWGwuOurstI2Z0bEDhXiXam/bicK2HVLyntliQ+6
// SIG // tT+nlgfN8tgB2NzM0BpE1YCnU2b6DwQw4V7BV+/F//83
// SIG // yGFOpePlumzXxNw9EKWkaq81slmmTxf7UxZgP9PGbLw8
// SIG // gLAPk4PTJI97+5BBqhkLb1YqSfWn3PNMfsNKhw/VwAN0
// SIG // dRKeM6H8SkOdz+osr+NyH86lsKQuics4fwK5uFSHQHsI
// SIG // t6Z0tqWvminRqceUi9ugRlGryh9X1ZqCqfL/ggdzYa3Z
// SIG // AgMBAAGjggF7MIIBdzAJBgNVHRMEAjAAMA4GA1UdDwEB
// SIG // /wQEAwIHgDBABgNVHR8EOTA3MDWgM6Axhi9odHRwOi8v
// SIG // Y3NjMy0yMDEwLWNybC52ZXJpc2lnbi5jb20vQ1NDMy0y
// SIG // MDEwLmNybDBEBgNVHSAEPTA7MDkGC2CGSAGG+EUBBxcD
// SIG // MCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LnZlcmlz
// SIG // aWduLmNvbS9ycGEwEwYDVR0lBAwwCgYIKwYBBQUHAwMw
// SIG // cQYIKwYBBQUHAQEEZTBjMCQGCCsGAQUFBzABhhhodHRw
// SIG // Oi8vb2NzcC52ZXJpc2lnbi5jb20wOwYIKwYBBQUHMAKG
// SIG // L2h0dHA6Ly9jc2MzLTIwMTAtYWlhLnZlcmlzaWduLmNv
// SIG // bS9DU0MzLTIwMTAuY2VyMB8GA1UdIwQYMBaAFM+Zqep7
// SIG // JvRLyY6P1/AFJu/j0qedMBEGCWCGSAGG+EIBAQQEAwIE
// SIG // EDAWBgorBgEEAYI3AgEbBAgwBgEBAAEB/zANBgkqhkiG
// SIG // 9w0BAQUFAAOCAQEA2OkGvuiY7TyI6yVTQAYmTO+MpOFG
// SIG // C8MflHSbofJiuLxrS1KXbkzsAPFPPsU1ouftFhsXFtDQ
// SIG // 8rMTq/jwugTpbJUREV0buEkLl8AKRhYQTKBKg1I/puBv
// SIG // bkJocDE0pRwtBz3xSlXXEwyYPcbCOnrM3OZ5bKx1Qiii
// SIG // vixlcGWhO3ws904ssutPFf4mV5PDi3U2Yp1HgbBK/Um/
// SIG // FLr6YAYeZaA8KY1CfQEisF3UKTwm72d7S+fJf++SOGea
// SIG // K0kumehVcbavQJTOVebuZ9V+qU0nk1lMrqve9BnQK69B
// SIG // QqNZu77vCO0wm81cfynAxkOYKZG3idY47qPJOgXKkwmI
// SIG // 2+92ozCCBgowggTyoAMCAQICEFIA5aolVvwahu2WydRL
// SIG // M8cwDQYJKoZIhvcNAQEFBQAwgcoxCzAJBgNVBAYTAlVT
// SIG // MRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UE
// SIG // CxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6MDgGA1UE
// SIG // CxMxKGMpIDIwMDYgVmVyaVNpZ24sIEluYy4gLSBGb3Ig
// SIG // YXV0aG9yaXplZCB1c2Ugb25seTFFMEMGA1UEAxM8VmVy
// SIG // aVNpZ24gQ2xhc3MgMyBQdWJsaWMgUHJpbWFyeSBDZXJ0
// SIG // aWZpY2F0aW9uIEF1dGhvcml0eSAtIEc1MB4XDTEwMDIw
// SIG // ODAwMDAwMFoXDTIwMDIwNzIzNTk1OVowgbQxCzAJBgNV
// SIG // BAYTAlVTMRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEf
// SIG // MB0GA1UECxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE7
// SIG // MDkGA1UECxMyVGVybXMgb2YgdXNlIGF0IGh0dHBzOi8v
// SIG // d3d3LnZlcmlzaWduLmNvbS9ycGEgKGMpMTAxLjAsBgNV
// SIG // BAMTJVZlcmlTaWduIENsYXNzIDMgQ29kZSBTaWduaW5n
// SIG // IDIwMTAgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
// SIG // ggEKAoIBAQD1I0tepdeKuzLp1Ff37+THJn6tGZj+qJ19
// SIG // lPY2axDXdYEwfwRof8srdR7NHQiM32mUpzejnHuA4Jnh
// SIG // 7jdNX847FO6G1ND1JzW8JQs4p4xjnRejCKWrsPvNamKC
// SIG // TNUh2hvZ8eOEO4oqT4VbkAFPyad2EH8nA3y+rn59wd35
// SIG // BbwbSJxp58CkPDxBAD7fluXF5JRx1lUBxwAmSkA8taEm
// SIG // qQynbYCOkCV7z78/HOsvlvrlh3fGtVayejtUMFMb32I0
// SIG // /x7R9FqTKIXlTBdOflv9pJOZf9/N76R17+8V9kfn+Bly
// SIG // 2C40Gqa0p0x+vbtPDD1X8TDWpjaO1oB21xkupc1+NC2J
// SIG // AgMBAAGjggH+MIIB+jASBgNVHRMBAf8ECDAGAQH/AgEA
// SIG // MHAGA1UdIARpMGcwZQYLYIZIAYb4RQEHFwMwVjAoBggr
// SIG // BgEFBQcCARYcaHR0cHM6Ly93d3cudmVyaXNpZ24uY29t
// SIG // L2NwczAqBggrBgEFBQcCAjAeGhxodHRwczovL3d3dy52
// SIG // ZXJpc2lnbi5jb20vcnBhMA4GA1UdDwEB/wQEAwIBBjBt
// SIG // BggrBgEFBQcBDARhMF+hXaBbMFkwVzBVFglpbWFnZS9n
// SIG // aWYwITAfMAcGBSsOAwIaBBSP5dMahqyNjmvDz4Bq1EgY
// SIG // LHsZLjAlFiNodHRwOi8vbG9nby52ZXJpc2lnbi5jb20v
// SIG // dnNsb2dvLmdpZjA0BgNVHR8ELTArMCmgJ6AlhiNodHRw
// SIG // Oi8vY3JsLnZlcmlzaWduLmNvbS9wY2EzLWc1LmNybDA0
// SIG // BggrBgEFBQcBAQQoMCYwJAYIKwYBBQUHMAGGGGh0dHA6
// SIG // Ly9vY3NwLnZlcmlzaWduLmNvbTAdBgNVHSUEFjAUBggr
// SIG // BgEFBQcDAgYIKwYBBQUHAwMwKAYDVR0RBCEwH6QdMBsx
// SIG // GTAXBgNVBAMTEFZlcmlTaWduTVBLSS0yLTgwHQYDVR0O
// SIG // BBYEFM+Zqep7JvRLyY6P1/AFJu/j0qedMB8GA1UdIwQY
// SIG // MBaAFH/TZafC3ey78DAJ80M5+gKvMzEzMA0GCSqGSIb3
// SIG // DQEBBQUAA4IBAQBWIuY0pMRhy0i5Aa1WqGQP2YyRxLvM
// SIG // DOWteqAif99HOEotbNF/cRp87HCpsfBP5A8MU/oVXv50
// SIG // mEkkhYEmHJEUR7BMY4y7oTTUxkXoDYUmcwPQqYxkbdxx
// SIG // kuZFBWAVWVE5/FgUa/7UpO15awgMQXLnNyIGCb4j6T9E
// SIG // mh7pYZ3MsZBc/D3SjaxCPWU21LQ9QCiPmxDPIybMSyDL
// SIG // kB9djEw0yjzY5TfWb6UgvTTrJtmuDefFmvehtCGRM2+G
// SIG // 6Fi7JXx0Dlj+dRtjP84xfJuPG5aexVN2hFucrZH6rO2T
// SIG // ul3IIVPCglNjrxINUIcRGz1UUpaKLJw9khoImgUux5Ol
// SIG // SJHTMYIEcjCCBG4CAQEwgckwgbQxCzAJBgNVBAYTAlVT
// SIG // MRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UE
// SIG // CxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE7MDkGA1UE
// SIG // CxMyVGVybXMgb2YgdXNlIGF0IGh0dHBzOi8vd3d3LnZl
// SIG // cmlzaWduLmNvbS9ycGEgKGMpMTAxLjAsBgNVBAMTJVZl
// SIG // cmlTaWduIENsYXNzIDMgQ29kZSBTaWduaW5nIDIwMTAg
// SIG // Q0ECECnBWz+qzVJqTme9PE5+P/IwCQYFKw4DAhoFAKBw
// SIG // MBAGCisGAQQBgjcCAQwxAjAAMBkGCSqGSIb3DQEJAzEM
// SIG // BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
// SIG // BgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBT/GvCjRRje
// SIG // 4djePMvc86C82jg2LTANBgkqhkiG9w0BAQEFAASCAQBS
// SIG // pU4SJbr/fUtwzgZsExtJeufoOmB3QImYTXTTX5E7J9RL
// SIG // 1j8uxzLxmKDYeDXJJHD0oLFSyKuLkOIVvt5Xj0YO0M0N
// SIG // nNz9g1tLZFW/l6oQlWIKSZvrwhCj2Z+91UCdT1pIdwfq
// SIG // okCadbjz0o9GzWoms6EXSAD7/iCT2SvOGcT+4olnaOzU
// SIG // nbqPgFf0MtOKQaXd9ji2IML5sWPkF7ecO9MdLSYQORu6
// SIG // FwuM2FI5zFHVMG5GtYyJqxhekn6aGJB2//bjHcJMrDQT
// SIG // UXGUL+xhyWCz45/OLdzlAkuRFgkrBnMbmWENbkIQzidJ
// SIG // RULK07RcKuKf8tCW4MSsn80wz89uGBfZoYICCzCCAgcG
// SIG // CSqGSIb3DQEJBjGCAfgwggH0AgEBMHIwXjELMAkGA1UE
// SIG // BhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0
// SIG // aW9uMTAwLgYDVQQDEydTeW1hbnRlYyBUaW1lIFN0YW1w
// SIG // aW5nIFNlcnZpY2VzIENBIC0gRzICEA7P9DjI/r81bgTY
// SIG // apgbGlAwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzEL
// SIG // BgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE1MDMw
// SIG // NTE1MDI0OFowIwYJKoZIhvcNAQkEMRYEFMrjCoalfYhp
// SIG // me1qE4WAGFAZYnK/MA0GCSqGSIb3DQEBAQUABIIBAJIm
// SIG // wrdXViUzat5lwayFT6SAk9NKKCaGW188+WrYnVLrZElt
// SIG // sNVqq9/IjHTtIV57pB/GKNpMlwGWlEtOSDCU/31LrJJg
// SIG // F6z6gVfyIki42SZzPYYmSVPN8zsEFY88GItxG+8RGY9U
// SIG // s66t6Iw6MtwlEQrZz39WcQLnzhDpHBepK3B1XHZUljQg
// SIG // QDB3NaebtdjxUBxof1Hygu423RzYtpgP1HqsxkgkH+Qz
// SIG // TBZJ3Gnvd7ofF7YfOITFT4/3bLzS9eugM4KP1CdWP/ME
// SIG // YtD08qMDEA/8HcGlsLqsM6tlzsM684ZCUvQtEgBfRrPZ
// SIG // 8UOoi5zRyuOVD8/N7ZtM1tzjU9AmrK8=
// SIG // End signature block
