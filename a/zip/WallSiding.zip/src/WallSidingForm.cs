using System;
using System.Windows.Forms;

namespace CH_Revit
{
  public partial class WallSidingForm : Form
  {
    WallProfiles m_dataBuffer;

    public WallSidingForm(WallProfiles dataBuffer)
    {
      InitializeComponent();

      m_dataBuffer = dataBuffer; 
    }

    private void WallSidingForm_Load(object sender, EventArgs e)
    {
      cboSidingType.DataSource = m_dataBuffer.sidingTypes;
      cboSidingType.DisplayMember = "Name";
    }

    private void okButton_Click(object sender, EventArgs e)
    {
      m_dataBuffer.SelectedSidingType = cboSidingType.SelectedItem;
    }
  }
}
