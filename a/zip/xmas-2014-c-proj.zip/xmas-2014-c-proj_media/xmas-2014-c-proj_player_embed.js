var oeTags = '<img src="xmas-2014-c-proj_media/xmas-2014-c-proj.gif" width="640" height="200" alt=""/>';         
document.write( oeTags );
