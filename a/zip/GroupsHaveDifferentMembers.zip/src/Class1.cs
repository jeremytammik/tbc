﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI.Events;

[TransactionAttribute(TransactionMode.Manual)]
[RegenerationAttribute(RegenerationOption.Manual)]
public class RevitCommand : IExternalCommand
{
  ElementId _idRotatedGroup = null;
  GroupType _gt = null;
  Group _group = null;

  public Result Execute( 
    ExternalCommandData commandData, 
    ref string messages, 
    ElementSet elements )
  {
    UIApplication app = commandData.Application;

    app.Application.FailuresProcessing 
      += new EventHandler<FailuresProcessingEventArgs>( 
        OnFailuresProcessing );

    return Result.Succeeded;
  }

  private void OnFailuresProcessing( 
    object sender, 
    FailuresProcessingEventArgs e )
  {
    FailuresAccessor failuresAccessor 
      = e.GetFailuresAccessor();

    Document doc = failuresAccessor.GetDocument();
    Application app = doc.Application;

    UIApplication uiapp = new UIApplication( app );

    String transactionName 
      = failuresAccessor.GetTransactionName();

    IList<FailureMessageAccessor> fmas 
      = failuresAccessor.GetFailureMessages();
    
    if( fmas.Count == 0 )
    {
      e.SetProcessingResult( 
        FailureProcessingResult.Continue );
      return;
    }

    if( transactionName.Equals( "Rotate" ) )
    {
      foreach( FailureMessageAccessor fma in fmas )
      {
        FailureDefinitionId id 
          = fma.GetFailureDefinitionId();

        FailureResolutionType st 
          = fma.GetCurrentResolutionType();

        fma.SetCurrentResolutionType( 
          FailureResolutionType.FixElements );

        ICollection<ElementId> collection
          = fma.GetFailingElementIds();

        foreach( ElementId eId in collection )
        {
          _idRotatedGroup = eId;
        }

        uiapp.Idling
          += new EventHandler<IdlingEventArgs>(
            OnIdling );

        // get the group type name here before resolving. 
        // store it for later assigning it back.

        // this element is one element in the group:

        Element elemSub = doc.get_Element( 
          _idRotatedGroup );

        _group = elemSub.Group;
        _gt = _group.GroupType;

        failuresAccessor.ResolveFailure( fma );
      }
    }
    e.SetProcessingResult( 
      FailureProcessingResult.ProceedWithCommit );
  }

  public void OnIdling( 
    object sender, 
    IdlingEventArgs e )
  {
    Application app = sender as Application;

    Debug.Assert( null != app,
      "expected a valid Revit application instance" );

    UIApplication uiapp = new UIApplication( app );

    // replace the element type to the original one

    Document doc = uiapp.ActiveUIDocument.Document;
    Transaction trans = new Transaction( doc );
    trans.Start( "change group type" );

    // assign the original group type.

    _group.GroupType = _gt;

    trans.Commit();

    // remove the Idling event to prevent CPU heavily 
    // occupied by run this method but doing nothing.

    uiapp.Idling 
      -= new EventHandler<IdlingEventArgs>( 
        OnIdling );
  }
}
