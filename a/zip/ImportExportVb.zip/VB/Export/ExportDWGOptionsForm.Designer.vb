﻿' 
' (C) Copyright 2003-2009 by Autodesk, Inc. 
' 
' Permission to use, copy, modify, and distribute this software in 
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and 
' restricted rights notice below appear in all supporting 
' documentation. 
' 
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF 
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE 
' UNINTERRUPTED OR ERROR FREE. 
' 
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer 
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii) 
' (Rights in Technical Data and Computer Software), as applicable. 
' 

Namespace Revit.SDK.Samples.ImportExport.VB
    ''' <summary> 
    ''' Provide a dialog which provides the options of lower priority information for export 
    ''' </summary> 
    Partial Class ExportDWGOptionsForm
        ''' <summary> 
        ''' Required designer variable. 
        ''' </summary> 
        Private components As System.ComponentModel.IContainer = Nothing

        ''' <summary> 
        ''' Clean up any resources being used. 
        ''' </summary> 
        ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param> 
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

#Region "Windows Form Designer generated code"

        ''' <summary> 
        ''' Required method for Designer support - do not modify 
        ''' the contents of this method with the code editor. 
        ''' </summary> 
        Private Sub InitializeComponent()
            Me.labelLayersAndProperties = New System.Windows.Forms.Label()
            Me.comboBoxLayersAndProperties = New System.Windows.Forms.ComboBox()
            Me.labelLinetypeScaling = New System.Windows.Forms.Label()
            Me.comboBoxLinetypeScaling = New System.Windows.Forms.ComboBox()
            Me.labelCoorSystem = New System.Windows.Forms.Label()
            Me.comboBoxCoorSystem = New System.Windows.Forms.ComboBox()
            Me.labelDWGUnit = New System.Windows.Forms.Label()
            Me.comboBoxDWGUnit = New System.Windows.Forms.ComboBox()
            Me.labelSolids = New System.Windows.Forms.Label()
            Me.comboBoxSolids = New System.Windows.Forms.ComboBox()
            Me.checkBoxExportingAreas = New System.Windows.Forms.CheckBox()
            Me.buttonOK = New System.Windows.Forms.Button()
            Me.labelLayerSettings = New System.Windows.Forms.Label()
            Me.comboBoxLayerSettings = New System.Windows.Forms.ComboBox()
            Me.buttonCancel = New System.Windows.Forms.Button()
            Me.checkBoxMergeViews = New System.Windows.Forms.CheckBox()
            Me.SuspendLayout()
            ' 
            ' labelLayersAndProperties 
            ' 
            Me.labelLayersAndProperties.AutoSize = True
            Me.labelLayersAndProperties.Location = New System.Drawing.Point(13, 13)
            Me.labelLayersAndProperties.Name = "labelLayersAndProperties"
            Me.labelLayersAndProperties.Size = New System.Drawing.Size(111, 13)
            Me.labelLayersAndProperties.TabIndex = 0
            Me.labelLayersAndProperties.Text = "Layers and properties:"
            ' 
            ' comboBoxLayersAndProperties 
            ' 
            Me.comboBoxLayersAndProperties.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboBoxLayersAndProperties.FormattingEnabled = True
            Me.comboBoxLayersAndProperties.Location = New System.Drawing.Point(16, 30)
            Me.comboBoxLayersAndProperties.Name = "comboBoxLayersAndProperties"
            Me.comboBoxLayersAndProperties.Size = New System.Drawing.Size(301, 21)
            Me.comboBoxLayersAndProperties.TabIndex = 1
            ' 
            ' labelLinetypeScaling 
            ' 
            Me.labelLinetypeScaling.AutoSize = True
            Me.labelLinetypeScaling.Location = New System.Drawing.Point(13, 96)
            Me.labelLinetypeScaling.Name = "labelLinetypeScaling"
            Me.labelLinetypeScaling.Size = New System.Drawing.Size(86, 13)
            Me.labelLinetypeScaling.TabIndex = 0
            Me.labelLinetypeScaling.Text = "Linetype scaling:"
            ' 
            ' comboBoxLinetypeScaling 
            ' 
            Me.comboBoxLinetypeScaling.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboBoxLinetypeScaling.FormattingEnabled = True
            Me.comboBoxLinetypeScaling.Location = New System.Drawing.Point(16, 113)
            Me.comboBoxLinetypeScaling.Name = "comboBoxLinetypeScaling"
            Me.comboBoxLinetypeScaling.Size = New System.Drawing.Size(301, 21)
            Me.comboBoxLinetypeScaling.TabIndex = 3
            ' 
            ' labelCoorSystem 
            ' 
            Me.labelCoorSystem.AutoSize = True
            Me.labelCoorSystem.Location = New System.Drawing.Point(13, 142)
            Me.labelCoorSystem.Name = "labelCoorSystem"
            Me.labelCoorSystem.Size = New System.Drawing.Size(123, 13)
            Me.labelCoorSystem.TabIndex = 0
            Me.labelCoorSystem.Text = "Coordinate system basis:"
            ' 
            ' comboBoxCoorSystem 
            ' 
            Me.comboBoxCoorSystem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboBoxCoorSystem.FormattingEnabled = True
            Me.comboBoxCoorSystem.Location = New System.Drawing.Point(16, 157)
            Me.comboBoxCoorSystem.Name = "comboBoxCoorSystem"
            Me.comboBoxCoorSystem.Size = New System.Drawing.Size(301, 21)
            Me.comboBoxCoorSystem.TabIndex = 4
            ' 
            ' labelDWGUnit 
            ' 
            Me.labelDWGUnit.AutoSize = True
            Me.labelDWGUnit.Location = New System.Drawing.Point(13, 184)
            Me.labelDWGUnit.Name = "labelDWGUnit"
            Me.labelDWGUnit.Size = New System.Drawing.Size(90, 13)
            Me.labelDWGUnit.TabIndex = 0
            Me.labelDWGUnit.Text = "One DWG unit is:"
            ' 
            ' comboBoxDWGUnit 
            ' 
            Me.comboBoxDWGUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboBoxDWGUnit.FormattingEnabled = True
            Me.comboBoxDWGUnit.Location = New System.Drawing.Point(16, 198)
            Me.comboBoxDWGUnit.Name = "comboBoxDWGUnit"
            Me.comboBoxDWGUnit.Size = New System.Drawing.Size(301, 21)
            Me.comboBoxDWGUnit.TabIndex = 5
            ' 
            ' labelSolids 
            ' 
            Me.labelSolids.AutoSize = True
            Me.labelSolids.Location = New System.Drawing.Point(13, 224)
            Me.labelSolids.Name = "labelSolids"
            Me.labelSolids.Size = New System.Drawing.Size(113, 13)
            Me.labelSolids.TabIndex = 0
            Me.labelSolids.Text = "Solids (3D views only):"
            ' 
            ' comboBoxSolids 
            ' 
            Me.comboBoxSolids.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboBoxSolids.FormattingEnabled = True
            Me.comboBoxSolids.Location = New System.Drawing.Point(16, 241)
            Me.comboBoxSolids.Name = "comboBoxSolids"
            Me.comboBoxSolids.Size = New System.Drawing.Size(301, 21)
            Me.comboBoxSolids.TabIndex = 6
            ' 
            ' checkBoxExportingAreas 
            ' 
            Me.checkBoxExportingAreas.AutoSize = True
            Me.checkBoxExportingAreas.Location = New System.Drawing.Point(16, 271)
            Me.checkBoxExportingAreas.Name = "checkBoxExportingAreas"
            Me.checkBoxExportingAreas.Size = New System.Drawing.Size(194, 17)
            Me.checkBoxExportingAreas.TabIndex = 7
            Me.checkBoxExportingAreas.Text = "Export rooms and areas as polylines"
            Me.checkBoxExportingAreas.UseVisualStyleBackColor = True
            ' 
            ' buttonOK 
            ' 
            Me.buttonOK.Location = New System.Drawing.Point(161, 335)
            Me.buttonOK.Name = "buttonOK"
            Me.buttonOK.Size = New System.Drawing.Size(75, 23)
            Me.buttonOK.TabIndex = 0
            Me.buttonOK.Text = "&OK"
            Me.buttonOK.UseVisualStyleBackColor = True
            AddHandler Me.buttonOK.Click, AddressOf Me.buttonOK_Click
            ' 
            ' labelLayerSettings 
            ' 
            Me.labelLayerSettings.AutoSize = True
            Me.labelLayerSettings.Location = New System.Drawing.Point(13, 55)
            Me.labelLayerSettings.Name = "labelLayerSettings"
            Me.labelLayerSettings.Size = New System.Drawing.Size(75, 13)
            Me.labelLayerSettings.TabIndex = 0
            Me.labelLayerSettings.Text = "Layer settings:"
            ' 
            ' comboBoxLayerSettings 
            ' 
            Me.comboBoxLayerSettings.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboBoxLayerSettings.FormattingEnabled = True
            Me.comboBoxLayerSettings.Location = New System.Drawing.Point(16, 72)
            Me.comboBoxLayerSettings.Name = "comboBoxLayerSettings"
            Me.comboBoxLayerSettings.Size = New System.Drawing.Size(301, 21)
            Me.comboBoxLayerSettings.TabIndex = 2
            ' 
            ' buttonCancel 
            ' 
            Me.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.buttonCancel.Location = New System.Drawing.Point(242, 335)
            Me.buttonCancel.Name = "buttonCancel"
            Me.buttonCancel.Size = New System.Drawing.Size(75, 23)
            Me.buttonCancel.TabIndex = 8
            Me.buttonCancel.Text = "&Cancel"
            Me.buttonCancel.UseVisualStyleBackColor = True
            ' 
            ' checkBoxMergeViews 
            ' 
            Me.checkBoxMergeViews.AutoSize = True
            Me.checkBoxMergeViews.Location = New System.Drawing.Point(16, 294)
            Me.checkBoxMergeViews.Name = "checkBoxMergeViews"
            Me.checkBoxMergeViews.Size = New System.Drawing.Size(220, 17)
            Me.checkBoxMergeViews.TabIndex = 9
            Me.checkBoxMergeViews.Text = "Create separate files for each view/sheet"
            Me.checkBoxMergeViews.UseVisualStyleBackColor = True
            ' 
            ' ExportDWGOptionsForm 
            ' 
            Me.AcceptButton = Me.buttonOK
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0F, 13.0F)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.CancelButton = Me.buttonCancel
            Me.ClientSize = New System.Drawing.Size(336, 368)
            Me.Controls.Add(Me.checkBoxMergeViews)
            Me.Controls.Add(Me.buttonCancel)
            Me.Controls.Add(Me.buttonOK)
            Me.Controls.Add(Me.checkBoxExportingAreas)
            Me.Controls.Add(Me.comboBoxSolids)
            Me.Controls.Add(Me.labelSolids)
            Me.Controls.Add(Me.comboBoxDWGUnit)
            Me.Controls.Add(Me.labelDWGUnit)
            Me.Controls.Add(Me.comboBoxCoorSystem)
            Me.Controls.Add(Me.labelCoorSystem)
            Me.Controls.Add(Me.comboBoxLinetypeScaling)
            Me.Controls.Add(Me.labelLinetypeScaling)
            Me.Controls.Add(Me.comboBoxLayerSettings)
            Me.Controls.Add(Me.labelLayerSettings)
            Me.Controls.Add(Me.comboBoxLayersAndProperties)
            Me.Controls.Add(Me.labelLayersAndProperties)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "ExportDWGOptionsForm"
            Me.ShowIcon = False
            Me.ShowInTaskbar = False
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
            Me.Text = "Export DWG Options"
            Me.ResumeLayout(False)

            Me.PerformLayout()
        End Sub

#End Region

        Private labelLayersAndProperties As System.Windows.Forms.Label
        Private comboBoxLayersAndProperties As System.Windows.Forms.ComboBox
        Private labelLinetypeScaling As System.Windows.Forms.Label
        Private comboBoxLinetypeScaling As System.Windows.Forms.ComboBox
        Private labelCoorSystem As System.Windows.Forms.Label
        Private comboBoxCoorSystem As System.Windows.Forms.ComboBox
        Private labelDWGUnit As System.Windows.Forms.Label
        Private comboBoxDWGUnit As System.Windows.Forms.ComboBox
        Private labelSolids As System.Windows.Forms.Label
        Private comboBoxSolids As System.Windows.Forms.ComboBox
        Private checkBoxExportingAreas As System.Windows.Forms.CheckBox
        Private buttonOK As System.Windows.Forms.Button
        Private labelLayerSettings As System.Windows.Forms.Label
        Private comboBoxLayerSettings As System.Windows.Forms.ComboBox
        Private buttonCancel As System.Windows.Forms.Button
        Private checkBoxMergeViews As System.Windows.Forms.CheckBox
    End Class
End Namespace