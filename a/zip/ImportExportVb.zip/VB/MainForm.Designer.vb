﻿' 
' (C) Copyright 2003-2009 by Autodesk, Inc. 
' 
' Permission to use, copy, modify, and distribute this software in 
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and 
' restricted rights notice below appear in all supporting 
' documentation. 
' 
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF 
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE 
' UNINTERRUPTED OR ERROR FREE. 
' 
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer 
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii) 
' (Rights in Technical Data and Computer Software), as applicable. 
' 

Namespace Revit.SDK.Samples.ImportExport.VB
    ''' <summary> 
    ''' Provide a dialog which lets user choose the operation(export or import) 
    ''' </summary> 
    Partial Class MainForm
        ''' <summary> 
        ''' Required designer variable. 
        ''' </summary> 
        Private components As System.ComponentModel.IContainer = Nothing

        ''' <summary> 
        ''' Clean up any resources being used. 
        ''' </summary> 
        ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param> 
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

#Region "Windows Form Designer generated code"

        ''' <summary> 
        ''' Required method for Designer support - do not modify 
        ''' the contents of this method with the code editor. 
        ''' </summary> 
        Private Sub InitializeComponent()
            Me.buttonOK = New System.Windows.Forms.Button()
            Me.buttonCancel = New System.Windows.Forms.Button()
            Me.groupBoxOperation = New System.Windows.Forms.GroupBox()
            Me.comboBoxImport = New System.Windows.Forms.ComboBox()
            Me.comboBoxExport = New System.Windows.Forms.ComboBox()
            Me.radioButtonImport = New System.Windows.Forms.RadioButton()
            Me.radioButtonExport = New System.Windows.Forms.RadioButton()
            Me.groupBoxOperation.SuspendLayout()
            Me.SuspendLayout()
            ' 
            ' buttonOK 
            ' 
            Me.buttonOK.Location = New System.Drawing.Point(103, 112)
            Me.buttonOK.Name = "buttonOK"
            Me.buttonOK.Size = New System.Drawing.Size(75, 23)
            Me.buttonOK.TabIndex = 0
            Me.buttonOK.Text = "&OK"
            Me.buttonOK.UseVisualStyleBackColor = True
            AddHandler Me.buttonOK.Click, AddressOf Me.buttonOK_Click
            ' 
            ' buttonCancel 
            ' 
            Me.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.buttonCancel.Location = New System.Drawing.Point(188, 112)
            Me.buttonCancel.Name = "buttonCancel"
            Me.buttonCancel.Size = New System.Drawing.Size(75, 23)
            Me.buttonCancel.TabIndex = 1
            Me.buttonCancel.Text = "&Cancel"
            Me.buttonCancel.UseVisualStyleBackColor = True
            ' 
            ' groupBoxOperation 
            ' 
            Me.groupBoxOperation.Controls.Add(Me.comboBoxImport)
            Me.groupBoxOperation.Controls.Add(Me.comboBoxExport)
            Me.groupBoxOperation.Controls.Add(Me.radioButtonImport)
            Me.groupBoxOperation.Controls.Add(Me.radioButtonExport)
            Me.groupBoxOperation.Location = New System.Drawing.Point(12, 12)
            Me.groupBoxOperation.Name = "groupBoxOperation"
            Me.groupBoxOperation.Size = New System.Drawing.Size(251, 81)
            Me.groupBoxOperation.TabIndex = 2
            Me.groupBoxOperation.TabStop = False
            Me.groupBoxOperation.Text = "Operation"
            ' 
            ' comboBoxImport 
            ' 
            Me.comboBoxImport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboBoxImport.FormattingEnabled = True
            Me.comboBoxImport.Location = New System.Drawing.Point(72, 51)
            Me.comboBoxImport.Name = "comboBoxImport"
            Me.comboBoxImport.Size = New System.Drawing.Size(161, 21)
            Me.comboBoxImport.TabIndex = 2
            ' 
            ' comboBoxExport 
            ' 
            Me.comboBoxExport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
            Me.comboBoxExport.FormattingEnabled = True
            Me.comboBoxExport.Location = New System.Drawing.Point(72, 19)
            Me.comboBoxExport.Name = "comboBoxExport"
            Me.comboBoxExport.Size = New System.Drawing.Size(161, 21)
            Me.comboBoxExport.TabIndex = 2
            ' 
            ' radioButtonImport 
            ' 
            Me.radioButtonImport.AutoSize = True
            Me.radioButtonImport.Location = New System.Drawing.Point(7, 52)
            Me.radioButtonImport.Name = "radioButtonImport"
            Me.radioButtonImport.Size = New System.Drawing.Size(54, 17)
            Me.radioButtonImport.TabIndex = 1
            Me.radioButtonImport.TabStop = True
            Me.radioButtonImport.Text = "Import"
            Me.radioButtonImport.UseVisualStyleBackColor = True
            ' 
            ' radioButtonExport 
            ' 
            Me.radioButtonExport.AutoSize = True
            Me.radioButtonExport.Checked = True
            Me.radioButtonExport.Location = New System.Drawing.Point(7, 21)
            Me.radioButtonExport.Name = "radioButtonExport"
            Me.radioButtonExport.Size = New System.Drawing.Size(58, 17)
            Me.radioButtonExport.TabIndex = 0
            Me.radioButtonExport.TabStop = True
            Me.radioButtonExport.Text = "Export "
            Me.radioButtonExport.UseVisualStyleBackColor = True
            AddHandler Me.radioButtonExport.CheckedChanged, AddressOf Me.radioButtonExport_CheckedChanged
            ' 
            ' MainForm 
            ' 
            Me.AcceptButton = Me.buttonOK
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0F, 13.0F)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.CancelButton = Me.buttonCancel
            Me.ClientSize = New System.Drawing.Size(278, 145)
            Me.Controls.Add(Me.groupBoxOperation)
            Me.Controls.Add(Me.buttonCancel)
            Me.Controls.Add(Me.buttonOK)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "MainForm"
            Me.ShowIcon = False
            Me.ShowInTaskbar = False
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
            Me.Text = "Export/Import"
            Me.groupBoxOperation.ResumeLayout(False)
            Me.groupBoxOperation.PerformLayout()

            Me.ResumeLayout(False)
        End Sub

#End Region

        Private buttonOK As System.Windows.Forms.Button
        Private buttonCancel As System.Windows.Forms.Button
        Private groupBoxOperation As System.Windows.Forms.GroupBox
        Private radioButtonImport As System.Windows.Forms.RadioButton
        Private radioButtonExport As System.Windows.Forms.RadioButton
        Private comboBoxImport As System.Windows.Forms.ComboBox
        Private comboBoxExport As System.Windows.Forms.ComboBox
    End Class
End Namespace