﻿
using System;
using System.Windows;
using System.Windows.Controls;
using Autodesk.Revit.UI;

namespace VCFCodificationRVT
{

    public partial class CustomPropertiesDockPanel : UserControl, IDockablePaneProvider
    {

        public CustomPropertiesDockPanel() { InitializeComponent(); }

        private void Window_Loaded(object sender, RoutedEventArgs e) { }

        public void SetupDockablePane(DockablePaneProviderData data)
        {
            data.FrameworkElement = this;
            data.VisibleByDefault = false;
            //data.InitialState.DockPosition = DockPosition.Floating;
            //data.EditorInteraction.InteractionType = EditorInteractionType.KeepAlive;
        }

    }

}
