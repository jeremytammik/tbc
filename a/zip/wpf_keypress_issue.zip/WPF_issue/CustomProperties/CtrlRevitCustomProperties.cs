﻿
using System;

namespace VCFCodificationRVT.CustomProperties
{

    public partial class CtrlRevitCustomProperties : System.Windows.Forms.UserControl
    {

        public CtrlRevitCustomProperties() { InitializeComponent(); }

    }

}
