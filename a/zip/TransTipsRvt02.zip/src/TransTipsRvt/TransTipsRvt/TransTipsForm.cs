﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TransTipsRvt
{
  public partial class TransTipsForm : Form
  {
    //bool _translate;

    //public bool Translate
    //{
    //  get
    //  {
    //    return _translate;
    //  }
    //}

    string _srcLangName;
    string _trgLangName;

    public string SourceLanguage
    {
      get
      {
        return _srcLangName;
      }
    }

    public string TargetLanguage
    {
      get
      {
        return _trgLangName;
      }
    }

    public TransTipsForm(
      //List<string> language_codes,
      List<string> language_names,
      string srcName,
      string trgName )
    {
      InitializeComponent();
      comboBoxSource.DataSource = language_names.ToArray<string>();
      comboBoxTarget.DataSource = language_names.ToArray<string>();
      comboBoxSource.SelectedIndex = language_names.IndexOf( srcName );
      comboBoxTarget.SelectedIndex = language_names.IndexOf( trgName );
    }

    private void comboBoxSource_SelectedIndexChanged( object sender, EventArgs e )
    {
      _srcLangName = comboBoxSource.Text;
    }

    private void comboBoxTarget_SelectedIndexChanged( object sender, EventArgs e )
    {
      _trgLangName = comboBoxTarget.Text;
    }

    //private void checkBox1_CheckedChanged( object sender, EventArgs e )
    //{
    //  _translate = checkBox1.Checked;
    //}
  }
}
