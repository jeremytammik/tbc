﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Given a selected wall, find the structural layer and increase its width by 50%.
		/// </summary>
		public void _6_IncreaseStructuralLayerWidthOfSelection()
		{
			string width = Microsoft.VisualBasic.Interaction.InputBox("Structural Layer Width % increase", "Property Utility", "50");
			double percent;
			bool isNumber = double.TryParse(width, out percent);
			if (!isNumber)
				percent = 50;
			double fraction = 1 + (percent/100);
			
			///REMARK:  GetSelectedElement is the first helper-utility method you may want to write and use
			///in all your applications.
			/// 
			Element selElement = GetSelectedElement();
			if (selElement is Wall)  //Find the wall in the selection.
			{
				Transaction tSetWidth = new Transaction( this.ActiveUIDocument.Document, "Set Layer Width");
				tSetWidth.Start();
					double previousWidth =-1;
					double newWidth = -1;
					Wall w = (selElement as Wall);
					//REMARK:  Remember that layer width is a property of the WallType, not not the Wall instance intself.
					WallType wt = w.WallType;
					CompoundStructure cs = wt.GetCompoundStructure();
					CompoundStructureLayer csl = GetStructuralLayer(cs);
					previousWidth = csl.Width;
					csl.Width*=fraction;  //Set the width.
					newWidth = csl.Width;
					//REMARK:  Remember that we need to set all our modified layers back into the CompoundStructure
					//and set our compound structure back into our wall type.
					
					SetStructuralLayer(cs, csl);  //Set the modified layer back into the structure. SPR 223668
					wt.SetCompoundStructure(cs);  //Set the structure back to the WallType.
				tSetWidth.Commit();
				TaskDialog.Show("Property Utility:", "Original layer width: " + previousWidth + Environment.NewLine + "New layer width: " + newWidth);
			}
			
		}
	}
}