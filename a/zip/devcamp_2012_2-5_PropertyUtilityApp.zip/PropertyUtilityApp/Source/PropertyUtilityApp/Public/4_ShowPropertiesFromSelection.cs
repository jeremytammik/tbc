﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;


namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Given a selected family instance or host object, display structural and thermal properties.
		/// </summary>
		public void _4_ShowPropertiesFromSelection()
		{
			//REMARK:  We have three new thermal property objects in Revit2013
			// DB.ThermalAsset -- Used in Materials -- we already went over this.
			// DB.FamilyThermalProperties for Door and Window Families
			// DB.ThermalProperties for host objects, such as walls, floors, ceilings, and roofs.
			Element selElement = GetSelectedElement();
			if (selElement is FamilyInstance)  //Find the family symbol (type)
			{
				FamilyInstance fInstance = selElement as FamilyInstance;
				FamilySymbol fSymbol = fInstance.Symbol;
				//REMARK:  FamilySymbol.GetThermalProperties(), new in 2013.
				FamilyThermalProperties ftProperties = fSymbol.GetThermalProperties();
				if (ftProperties == null)
					return;
				SimpleDisplay dataDisplay = new SimpleDisplay();
				dataDisplay.Html = "<html> <span style='font-family:sans-serif;'>"  +  FamilyThermalPropertySummary(ftProperties)  + "</span></html>";
				dataDisplay.ShowDialog();  //Display properties.
				
			}
			else if (selElement is HostObject)  //Find the wall or other layered assembly.
			{
				ThermalProperties tProperties = GetThermalPropertiesFromHostObject(selElement as HostObject);
				if (tProperties == null)
					return;
				SimpleDisplay dataDisplay = new SimpleDisplay();
				dataDisplay.Html = "<html> <span style='font-family:sans-serif;'>" +  ThermalPropertiesSummary(tProperties) + Environment.NewLine + HostObjectLayerPropertySummary(selElement as HostObject) + "</span></html>";
				dataDisplay.ShowDialog();  //Display properties.
				
			}
			
		}

	}
}