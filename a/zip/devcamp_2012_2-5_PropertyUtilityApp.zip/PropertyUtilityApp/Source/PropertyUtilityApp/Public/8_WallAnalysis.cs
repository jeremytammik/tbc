﻿
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.Windows.Media;
using System.Windows.Media.Imaging;
namespace PropertyUtilityApp
{

	public partial class ThisApplication
	{
		/// <summary>
		/// Given a selected wall, make 2" adjustments to all insulation-layers, record the resulting
		/// changes in the wall's R-Value, and display.
		/// </summary>
		public void _8_WallAnalysis()
		{
			//REMARK:  This method is complicated and has many sub-steps.  Note that all helper classes
			//are in the "WallAnalysisUtility" folder.
			
			Element selElement = GetSelectedElement();		
			if (selElement is Wall)  //Find the wall in the selection.
			{
				Wall wall = (selElement as Wall);
				
				//Get a list of summaries of wall thermal property changes;
				int inchIncrement = 2;
				//REMARK:  Collect data first.
				IList<WallAdjustmentSummary> summaries = WallAdjustmentTrials(wall,inchIncrement);
				
				//Format results for a text and graph display;
				StringBuilder sb = new StringBuilder();
				//REMARK:  A dialog class that support a graph and text display.
				SimpleDisplayWithGraph display = new SimpleDisplayWithGraph();
				
				//Create a quick palette of colors to use in the graph;
				List<SolidColorBrush> colors = new List<SolidColorBrush>();
				colors.Add(Brushes.Black);
				colors.Add(Brushes.Blue);
				colors.Add(Brushes.Red);
				colors.Add(Brushes.Green);
				colors.Add(Brushes.Orange);
				System.Collections.Generic.IEnumerator<SolidColorBrush> ieb = colors.GetEnumerator();
				ieb.MoveNext();
				
				//REMARK:  Print each wall summary, and draw each wall summary's data as a line of a different
				//color in the graph;
				foreach (WallAdjustmentSummary was in summaries)
				{
					
					display.GraphManager.PlotPolyLine(was, ieb.Current);
					//REMARK: -- add text in the same color as its corresponding graph line.
					sb.Append(was.ToFormattedString(ieb.Current) + "<p/>");
					if (!ieb.MoveNext())
					{
						ieb.Reset();
						ieb.MoveNext();
					}
				}
				
				//Show the data dialog.
				display.Html = "<html> <span style='font-family:sans-serif;'>" +  "<h1>Wall Analysis</h1>" + sb.ToString()  + "</span></html>";
				display.ShowDialog();
			}
		}	

	}

}