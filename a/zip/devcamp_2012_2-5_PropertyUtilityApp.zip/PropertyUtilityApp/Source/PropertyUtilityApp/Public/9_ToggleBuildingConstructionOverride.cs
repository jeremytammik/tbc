﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Analysis;

namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Toggle all of the "Building Construction Override" settings in "Heating and Cooling Loads -> Building Construction"
		/// </summary>
		public void _9_ToggleBuildingConstructionOverride()
		{
			FilteredElementCollector fec = new FilteredElementCollector(this.ActiveUIDocument.Document);
			fec.OfClass(typeof(MEPBuildingConstruction));
			
			//Only one MEPBuildingConstruction element exists in the model.
			MEPBuildingConstruction construction = fec.ToElements().Cast<MEPBuildingConstruction>().First();
			Transaction toggleBuildingConstructions = new Transaction(this.ActiveUIDocument.Document, "Toggle Building Construction Overrides");
			toggleBuildingConstructions.Start();
			//REMARK -- This is a nice trick for enumerating through all values of an enum automatically.
			foreach (ConstructionType constructionType in Enum.GetValues(typeof(ConstructionType)).Cast<ConstructionType>())
			{
				//REMARK:  Get/Set BuildingConstructionOverride, new in Revit 2013.
				bool currentOverrideValue = construction.GetBuildingConstructionOverride(constructionType);
				construction.SetBuildingConstructionOverride(constructionType, !currentOverrideValue);
			}
			toggleBuildingConstructions.Commit();
		}
	}
	
}