﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Given a selected wall, find the structural layer and change its material to one selected by the user.
		/// </summary>
		public void _7_SetStructuralLayerMaterialOfSelection()
		{
			string materialName = Microsoft.VisualBasic.Interaction.InputBox("Get Material to set by name", "Property Utility", "NewConcrete__HighConductivity");
			Material selectedMaterial = GetMaterialByName(materialName); //Get a material to set.
			if (selectedMaterial == null)
			{
				TaskDialog.Show("Property Utility:", "Material not found.");
				return;
			}
			Element selElement = GetSelectedElement();
			if (selElement is Wall) //Find the wall in the selection.
			{

				Transaction tSetMaterial = new Transaction( this.ActiveUIDocument.Document, "Set Layer material");
				tSetMaterial.Start();
					string previousMaterialName = null;
					string newMaterialName = null;
					Wall w = (selElement as Wall);
					WallType wt = w.WallType;
					CompoundStructure cs = wt.GetCompoundStructure();
					CompoundStructureLayer csl = GetStructuralLayer(cs);
					//REMARK:  Remember that layer material is a property of the WallType, not not the Wall instance intself.

					previousMaterialName = this.ActiveUIDocument.Document.GetElement(csl.MaterialId).Name;
					newMaterialName = selectedMaterial.Name;
					csl.MaterialId = selectedMaterial.Id;  //Set the material.
					
					//REMARK:  Remember that we need to set all our modified layers back into the CompoundStructure
					//and set our compound structure back into our wall type.
					
					SetStructuralLayer(cs, csl); //Set the modified layer back into the structure.
					wt.SetCompoundStructure(cs);  //Set the structure back to the WallType.
				tSetMaterial.Commit();
				TaskDialog.Show("Property Utility:", "Original layer material: " + previousMaterialName + Environment.NewLine + "New layer material: " + newMaterialName);

			}
						
		}
	}
}