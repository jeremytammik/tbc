﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Create a new concrete material and fill out all its properties explicitly.
		/// </summary>
		public void _3_CreateNewConcreteMaterialFromScratch()
		{
			///Get a name for the material.
			string name = Microsoft.VisualBasic.Interaction.InputBox("Material Name", "Property Utility", "NewConcrete__HighConductivity");
			///Create the basic material and set top-level properties.
			
			
			//REMARK:  Material must have unique names, so do a quick check.
			if (DoesMaterialExist(name))
			{
				TaskDialog.Show("Property Utility:", "Material already exists.");
				return;
			}
			//REMARK:  First, create just the material element with no thermal or structurl asset data.
			Material material = GeneralizedMaterialCreateCore(name, "Masonry");  //The material class

			//Create new structural and thermal assets
			StructuralAsset sAsset = CreateNewConcreteStructuralAsset(name);
			ThermalAsset tAsset = CreateNewConcreteThermalAsset(name);

			//Set those assets into the material we just created.			
			GeneralizedSetMaterialProperties(material, sAsset, tAsset);
		}
	}
}

