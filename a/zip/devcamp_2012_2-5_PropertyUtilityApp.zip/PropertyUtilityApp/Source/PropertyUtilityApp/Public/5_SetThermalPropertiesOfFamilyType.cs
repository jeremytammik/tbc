﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.Xml;
using System.Xml.Linq;


namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Given a selected door or window family instance, select a thermal property set from
		/// constructions.xml and set the family type's thermal properties to those.
		/// </summary>
		public void _5_SetThermalPropertiesOfFamilyType()
		{
			string constructionsPath = GetConstructionsXmlPath();
			if (!System.IO.File.Exists(constructionsPath))
			{
				TaskDialog.Show("Property Utility", "Cannot find GBXML data source.");
				return;
			}
						

			Element selElement = GetSelectedElement();
			if (selElement is FamilyInstance)  //Get the family symbol (type)
			{
				FamilyInstance fInstance = selElement as FamilyInstance;
				FamilySymbol fSymbol = fInstance.Symbol;
				Dictionary<string, string> thermalDictionary;
				
				//Put only door or window thermal definitions into the selection dialog, depending on
				//what was selected.
				
				//REMARK:  The dialog below is just a simple utility to associate the name of a GBXML property
				//set with its data.
				if (fSymbol.Category.Name.Contains("Window"))
					thermalDictionary = BuildThermalPropertyDictionary(constructionsPath, GbxmlElementType.Window);
				else
					thermalDictionary = BuildThermalPropertyDictionary(constructionsPath, GbxmlElementType.Door);
				
				//REMARK:  Depending on whether a door or window is selected, respective door or window thermal
				//property set names will be displayed.
				SelectThermalPropertyDialog stpd = new SelectThermalPropertyDialog(thermalDictionary);
				stpd.ShowDialog();
				string gbxmlId = stpd.selectedId;
				if (string.IsNullOrEmpty(gbxmlId))
				{
				    TaskDialog.Show("Property Utility", "Invalid Selection");
			   	 	return;
				}
			
				//Get the selected FamilyThermalProperties object
				///REMARK:  FamilyThermalProperties is a new class in 2013.
				FamilyThermalProperties ftpSelected = FamilyThermalProperties.Find(this.ActiveUIDocument.Document, gbxmlId);
				if (ftpSelected == null)
				{
			    	TaskDialog.Show("Property Utility", "Family Thermal Properties not found.");
			    	return;
				}
				
				//REMARK: Save the original thermal properties temporarily so we can display
				//a brief comparison.
				//REMARK:  FamilySymbol.GetThermalProperties(), new in 2013.
				FamilyThermalProperties ftpOriginal = fSymbol.GetThermalProperties();
				string originalProperties = "None";
				if (ftpOriginal != null)
					//Store a summary of the original properties.
					originalProperties = this.FamilyThermalPropertySummary(ftpOriginal);  
					
				//Set the type's thermal properties.
				Transaction setThermalProperties = new Transaction(this.ActiveUIDocument.Document, "Set Family Thermal Properties");
				setThermalProperties.Start();
				//REMARK:  FamilySymbol.SetThermalProperties(), new in 2013.
				fSymbol.SetThermalProperties(ftpSelected);
				setThermalProperties.Commit();
				
				//Retreive the type's new properties to validate that they were indeed changed.
				string newProperties = "None";
				FamilyThermalProperties ftpRetreived = fInstance.Symbol.GetThermalProperties();
				if (ftpRetreived != null)
					newProperties = this.FamilyThermalPropertySummary(ftpRetreived);

				//Display a summary of original and new properties.				
				SimpleDisplay dataDialog = new SimpleDisplay();
				dataDialog.Html = "<html> <span style='font-family:sans-serif;'>" +  "<h1>Original Thermal Properties</h1>" + Environment.NewLine + originalProperties + Environment.NewLine + "<h1>New Thermal Properties</h1>" + Environment.NewLine + newProperties + "</span></html>";
				dataDialog.ShowDialog();
			}
		}
		
	
		
	}
	
}