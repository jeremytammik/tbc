﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Create a new material by duplicating an existing Material and its properties.
		/// </summary>
		public void _2_CreateNewConcreteMaterialViaDuplication()
		{
			///Get a suffix to append to to the new material name to distinguish it from the original.
			string suffix = Microsoft.VisualBasic.Interaction.InputBox("Duplicate Material Suffix", "Property Utility", "_StandardConductivity");
			string originalName = "Concrete Masonry Units";
			
			//REMARK:  Material must have unique names, so do a quick check.
			if (DoesMaterialExist(originalName + "-" + suffix))
			{
				TaskDialog.Show("Property Utility:", "Material already exists.");
				return;
			}
						
			///Get a material to duplicate.
			Material materialConcreteOriginal = GetMaterialByName(originalName);
			
			Material materialConcreteAlternate;
			PropertySetElement pseStructuralAlternate;
			PropertySetElement pseThermalAlternate;
			
			//REMARK:  StructuralAsset and ThermalAsset are new classes in 2013.
			StructuralAsset structuralAssetAlternate;
			ThermalAsset thermalAssetAlternate;
			
			///Copy the Material and its Assets and PropertySetElements
			GeneralizedMaterialDuplicate(materialConcreteOriginal, out materialConcreteAlternate, out pseStructuralAlternate, out pseThermalAlternate, out structuralAssetAlternate, out thermalAssetAlternate, suffix);
			
			///Set data on the assets.  Since they are duplicates, setting the data is optional.
			SetConcreteThermalAssetProperties_StandardConductivity(thermalAssetAlternate);
			SetConcreteStructuralAssetProperties(structuralAssetAlternate);

			///REMARK:  We now have copies of the Material, its assets, and its PropertySetElements, and the
			///assets are populated with the data we want.  All we need to do now is set all of this data to the
			///new material.
			 
			///Set the assets in the new PropertySetElements.
			Transaction setProperties = new Transaction(this.ActiveUIDocument.Document, "Set PropertySetElement Assets");
			setProperties.Start();
				//REMARK: SetThermalAsset, SetStructuralAsset are new methods in 2013.
				pseStructuralAlternate.SetStructuralAsset(structuralAssetAlternate);
				pseThermalAlternate.SetThermalAsset(thermalAssetAlternate);
			setProperties.Commit();
			Transaction setMaterial = new Transaction(this.ActiveUIDocument.Document, "Set Material PropertySets");
			
			///Set the new PropertySetElements on the Material.
			setMaterial.Start();
				materialConcreteAlternate.SetMaterialAspectByPropertySet(MaterialAspect.Structural, pseStructuralAlternate.Id);
				materialConcreteAlternate.SetMaterialAspectByPropertySet(MaterialAspect.Thermal, pseThermalAlternate.Id);
			setMaterial.Commit();
		}
	}
}