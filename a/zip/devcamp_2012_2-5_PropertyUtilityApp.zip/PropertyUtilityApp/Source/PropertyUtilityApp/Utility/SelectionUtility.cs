﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Gets the selected element, returns null if none selected.
		/// </summary>
		private Element GetSelectedElement()
		{
			SelElementSet elements = this.ActiveUIDocument.Selection.Elements;
			if ((elements == null) || (elements.IsEmpty))
				return null;
			else
			{
				IEnumerator iElements = elements.GetEnumerator();
			if (iElements.MoveNext())
				return iElements.Current as Element;
			else
				return null;
			}
				
		}
	}
}
	