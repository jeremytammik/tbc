﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.Utility;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using Autodesk.Revit.DB.IFC;


namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{

		/// <summary>
		/// A simple wrapper for the "ConvertUnits" method -- converts a given value in system (API) units to given display units.
		/// </summary>
		private double SystemToDisplayUnits(Nullable<double> valueInSystemUnits, DisplayUnitType outputUnitType) 
		{
			return ExporterIFCUtils.ConvertUnits(this.ActiveUIDocument.Document, valueInSystemUnits.GetValueOrDefault(), outputUnitType);
		}

		
		/// <summary>
		/// A simple wrapper for the "ConvertUnits" method -- converts a given value in system (API) units to given display units.
		/// </summary>
		private XYZ SystemToDisplayUnits(XYZ valueInSystemUnits, DisplayUnitType outputUnitType) 
		{
			double xD =  ExporterIFCUtils.ConvertUnits(this.ActiveUIDocument.Document, valueInSystemUnits[0], outputUnitType);
			double yD =  ExporterIFCUtils.ConvertUnits(this.ActiveUIDocument.Document, valueInSystemUnits[1], outputUnitType);
			double zD =  ExporterIFCUtils.ConvertUnits(this.ActiveUIDocument.Document, valueInSystemUnits[2], outputUnitType);
			return new XYZ(xD, yD, zD);
		}
		
		/// <summary>
		/// Convers a given value in given display units to system (API) units.
		/// </summary>
		private double DisplayUnitsToSystem(double valueInDisplayUnits, DisplayUnitType inputUnitType)
		{

			//Divide the original value by this new value to get the correct cofficient to convert
			//display units to system units.
			double reverseConvertedValue = SystemToDisplayUnits(valueInDisplayUnits, inputUnitType);
			double coefficient = valueInDisplayUnits / reverseConvertedValue;

			//Multiply the original input by this new coefficient and return it.
			return valueInDisplayUnits * coefficient;
		}
		

		
		/// <summary>
		/// Given the name of a property, its value, and the unit type, find the current
		/// UI display unit for that property type and return the value as a formatted string.
		/// </summary>
		private string FormatUnitValue<ValueType>(string name, ValueType value, UnitType unitType = UnitType.UT_Undefined)
		{
			
			StringBuilder sb = new StringBuilder();
			sb.Append("  " + name + " = ");
			
			if (unitType != UnitType.UT_Undefined)  //Add units and also show system type if units exist.
			{
				FormatOptions fopt = this.ActiveUIDocument.Document.ProjectUnit.get_FormatOptions(unitType);
				if (value is double)  //Different handling for double and point values.
				{
					Nullable<double> dvc = value as Nullable<double>;
					double displayValue = SystemToDisplayUnits(dvc, fopt.Units);
					sb.Append(displayValue);
				}
				else
				{
					XYZ xvc = value as XYZ;
					XYZ displayValue = SystemToDisplayUnits(xvc, fopt.Units);
					sb.Append(displayValue.ToString());
				}
				sb.Append(" ");
				sb.Append(fopt.Unitsymbol.ToString());
				sb.Append(" , System/API value: ");
				sb.Append(value);
			}
			else
			{
				sb.Append(value);
			}
			
			return sb.ToString();
		}
		
		

	}
	
}