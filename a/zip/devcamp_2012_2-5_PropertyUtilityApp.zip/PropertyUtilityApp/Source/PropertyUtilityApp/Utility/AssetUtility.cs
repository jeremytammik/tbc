﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.Utility;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Create a new thermal asset of material type "Solid and set the thermal properties on it.
		/// </summary>
		private ThermalAsset CreateNewConcreteThermalAsset(string name)
		{
			ThermalAsset tAsset = new ThermalAsset(name + "-ThermalAsset", ThermalMaterialType.Solid);
			//REMARK: These are hard-coded values for demonstration purposes.
			SetConcreteThermalAssetProperties_HighConductivity(tAsset);
			return tAsset;
		}
		
		/// <summary>
		/// Create a new structural asset of asset-class "Concrete" and set the structural properties on it.
		/// </summary>
		private StructuralAsset CreateNewConcreteStructuralAsset(string name)
		{
			StructuralAsset sAsset = new StructuralAsset(name + "-StructuralAsset", StructuralAssetClass.Concrete);
			//REMARK: These are hard-coded values for demonstration purposes.
			SetConcreteStructuralAssetProperties(sAsset);
			return sAsset;			
		}
		
		/// <summary>
		/// Set thermal properties on an asset typical of concrete.  Note the thermal conductivity value.
		/// </summary>
		private void SetConcreteThermalAssetProperties_StandardConductivity(ThermalAsset tAsset)
		{
			tAsset.Behavior = StructuralBehavior.Isotropic;
		 	tAsset.Compressibility= 0.5;
		 	//REMARK:  In this case, the user sets all values in display units, so we convert
			//to system units here.
			tAsset.Density = DisplayUnitsToSystem(68.1674766743637, this.ActiveUIDocument.Document.ProjectUnit.get_FormatOptions(UnitType.UT_MassDensity).Units);
		 	tAsset.ElectricalResistivity = 70629333.4429772;
		 	tAsset.Emissivity = 0.95;
		 	//REMARK:  Note: Watch out for InapplicableDataException here.
		 	//tAsset.GasViscosity=.0; //Do not set asset properties that do not apply to Concrete.
		 	//tAsset.LiquidViscosity=.0;
			tAsset.Permeability = .00001;
		 	tAsset.Porosity = 0.001;
		 	tAsset.Reflectivity = .0;
		 	tAsset.SpecificHeatOfVaporization = 0;
		 	tAsset.ThermalConductivity = DisplayUnitsToSystem(0.6043, this.ActiveUIDocument.Document.ProjectUnit.get_FormatOptions(UnitType.UT_HVAC_ThermalConductivity).Units);
		 	tAsset.TransmitsLight = false;
		 	tAsset.VaporPressure = 0;
		}
		
	
		/// <summary>
		/// Set alternate thermal properties on an asset typical of concrete.  Note the thermal conductivity value.
		/// </summary>
		private void SetConcreteThermalAssetProperties_HighConductivity(ThermalAsset tAsset)
		{
			tAsset.Behavior = StructuralBehavior.Isotropic;
		 	tAsset.Compressibility = 0.5;
		 	//REMARK:  In this case, the user sets all values in display units, so we convert
			//to system units here.
			tAsset.Density = DisplayUnitsToSystem(68.1674766743637, this.ActiveUIDocument.Document.ProjectUnit.get_FormatOptions(UnitType.UT_MassDensity).Units);
		 	tAsset.ElectricalResistivity = 70629333.4429772;
		 	tAsset.Emissivity = 0.95;
		 	//REMARK:  Note: Watch out for InapplicableDataException here.
		 	//tAsset.GasViscosity = 0.0; //Do not set asset properties that do not apply to Concrete.
			//tAsset.LiquidViscosity = 0.0;
			tAsset.Permeability = 0.00001;
		 	tAsset.Porosity = 0.001;
		 	tAsset.Reflectivity = 0.0;
		 	tAsset.SpecificHeatOfVaporization = 0.0;
		 	tAsset.ThermalConductivity = DisplayUnitsToSystem(1.2086, this.ActiveUIDocument.Document.ProjectUnit.get_FormatOptions(UnitType.UT_HVAC_ThermalConductivity).Units);
		 	tAsset.TransmitsLight = false;
		 	tAsset.VaporPressure = 0;
		}
		
		/// <summary>
		/// Set structural properties on an asset typical of concrete.  
		/// </summary>
		private void SetConcreteStructuralAssetProperties(StructuralAsset sAsset)
		{
			sAsset.Behavior= StructuralBehavior.Isotropic;
			
			
			//REMARK:  Note: Watch out for InapplicableDataException here.
			
			/* //Do not set asset properties that do not apply to Concrete.
			sAsset.ConcreteBendingReinforcement=126091321.377463;
			sAsset.ConcreteCompression=7355719.505448;
			sAsset.ConcreteShearReinforcement=126091321.377463;
			sAsset.ConcreteShearStrengthReduction=1;
			*/
			
			//REMARK:  In this case, the user sets all values in display units, so we convert
			//to system units here.
			sAsset.DampingRatio = 0.15;
			sAsset.Density = DisplayUnitsToSystem(68.1674766743637,  this.ActiveUIDocument.Document.ProjectUnit.get_FormatOptions(UnitType.UT_MassDensity).Units);
			sAsset.Lightweight = false;
			
			/*
			sAsset.MetalReductionFactor = 1.66; 
			sAsset.MetalResistanceCalculationStrength = 105076101.147886;
			sAsset.MinimumTensileStrength = 735571;
			sAsset.MinimumYieldStress = 735571;
			*/
			
			sAsset.SetPoissonRatio(0.167);
			sAsset.SetShearModulus(3037027200);
			sAsset.SubClass = "Standard";
			sAsset.SetThermalExpansionCoefficient(DisplayUnitsToSystem(.00005, this.ActiveUIDocument.Document.ProjectUnit.get_FormatOptions(UnitType.UT_ThermalExpansion).Units));
			
			/*
			structuralAsset.WoodBendingStrength = 0.5;
			structuralAsset.WoodGrade = 0.5;
			structuralAsset.WoodParallelCompressionStrength = 0.5;
			structuralAsset.WoodParallelShearStrength =0 .5;
			structuralAsset.WoodPerpendicularCompressionStrength = 0.5;
			structuralAsset.WoodPerpendicularShearStrength = 0.5;
			structuralAsset.WoodSpecies = 0.5;
			*/
			sAsset.SetYoungModulus(7086600000);
		}

		/// <summary>
		/// Return ThermalAsset data as a string.
		/// </summary>
		private string ThermalAssetSummary(ThermalAsset tAsset)
		{
			StringBuilder sBuilder = new StringBuilder();
		 	//REMARK:  We display both system and display units here.
			sBuilder.AppendLine("<h3>" + FormatUnitValue("Thermal Asset Name" , tAsset.Name) + "</h3>");
			sBuilder.AppendLine("<ul><li>" + FormatUnitValue("ThermalMaterialType" , tAsset.ThermalMaterialType) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Behavior" , tAsset.Behavior) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Compressibility" , tAsset.Compressibility) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Density", tAsset.Density, UnitType.UT_MassDensity) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("ElectricalResistivity" , tAsset.ElectricalResistivity, UnitType.UT_Electrical_Resistivity) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Emissivity" , tAsset.Emissivity) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("GasViscosity" , tAsset.GasViscosity, UnitType.UT_HVAC_Viscosity) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("LiquidViscosity" , tAsset.LiquidViscosity, UnitType.UT_Piping_Viscosity) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Permeability" , tAsset.Permeability, UnitType.UT_HVAC_Permeability) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Porosity" , tAsset.Porosity) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Reflectivity" , tAsset.Reflectivity) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Thermal Conductivity", tAsset.ThermalConductivity, UnitType.UT_HVAC_ThermalConductivity) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("SpecificHeatOfVaporization" , tAsset.SpecificHeatOfVaporization, UnitType.UT_HVAC_SpecificHeatOfVaporization) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("TransmitsLight", tAsset.TransmitsLight) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Vapor Pressure", tAsset.VaporPressure, UnitType.UT_Stress) + "</li></ul>");
			
			return sBuilder.ToString();
		}
		
		/// <summary>
		/// Return StructuralAsset data as a string.
		/// </summary>
		private string StructuralAssetSummary(StructuralAsset sAsset)
		{
			StringBuilder sBuilder = new StringBuilder();
			//REMARK:  We display both system and display units here.
			sBuilder.AppendLine("<h3>" + FormatUnitValue("Structural Asset Name", sAsset.Name)+ "</h3>");
			sBuilder.AppendLine("<ul><li>" + FormatUnitValue("StructuralAssetClass",sAsset.StructuralAssetClass) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("SubClass", sAsset.SubClass) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Behavior",sAsset.Behavior) + "</li>");
			
			if (sAsset.StructuralAssetClass == StructuralAssetClass.Concrete)
			{
				sBuilder.AppendLine("<li>" + FormatUnitValue("ConcreteCompression", sAsset.ConcreteCompression, UnitType.UT_Stress) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("ConcreteShearReinforcement", sAsset.ConcreteShearReinforcement, UnitType.UT_Stress) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("ConcreteBendingReinforcement", sAsset.ConcreteBendingReinforcement, UnitType.UT_Stress) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("ConcreteShearStrengthReduction",sAsset.ConcreteShearStrengthReduction) + "</li>");
			}
			
			sBuilder.AppendLine("<li>" + FormatUnitValue("DampingRatio", sAsset.DampingRatio) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Density", sAsset.Density, UnitType.UT_MassDensity) + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("Lightweight" , sAsset.Lightweight) + "</li>");
			
			if (sAsset.StructuralAssetClass == StructuralAssetClass.Metal)
			{
				sBuilder.AppendLine("<li>" + FormatUnitValue("MetalReductionFactor", sAsset.MetalReductionFactor) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("MetalResistanceCalculationStrength", sAsset.MetalResistanceCalculationStrength, UnitType.UT_Stress) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("MinimumTensileStrength", sAsset.MinimumTensileStrength, UnitType.UT_Stress) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("MinimumYieldStress", sAsset.MinimumYieldStress, UnitType.UT_Stress) + "</li>");
			}
			if (sAsset.Behavior == StructuralBehavior.Isotropic)			
				sBuilder.AppendLine("<li>" + FormatUnitValue("PoissonRatio", sAsset.PoissonRatio[0]) + "</li>");
			else			
				sBuilder.AppendLine("<li>" + FormatUnitValue("PoissonRatio", sAsset.PoissonRatio) + "</li>");
			
			if (sAsset.Behavior == StructuralBehavior.Isotropic)
				sBuilder.AppendLine("<li>" + FormatUnitValue("ShearModulus", sAsset.ShearModulus[0], UnitType.UT_Stress) + "</li>");
			else
				sBuilder.AppendLine("<li>" + FormatUnitValue("ShearModulus", sAsset.ShearModulus, UnitType.UT_Stress) + "</li>");
			
			if (sAsset.Behavior == StructuralBehavior.Isotropic)
				sBuilder.AppendLine("<li>" + FormatUnitValue("ThermalExpansionCoefficient", sAsset.ThermalExpansionCoefficient[0], UnitType.UT_ThermalExpansion) + "</li>");
			else
				sBuilder.AppendLine("<li>" + FormatUnitValue("ThermalExpansionCoefficient", sAsset.ThermalExpansionCoefficient, UnitType.UT_ThermalExpansion) + "</li>");

			
			if (sAsset.StructuralAssetClass == StructuralAssetClass.Wood)
			{
				sBuilder.AppendLine("<li>" + FormatUnitValue("WoodGrade", sAsset.WoodGrade) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("WoodSpecies", sAsset.WoodSpecies) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("WoodBendingStrength", sAsset.WoodBendingStrength, UnitType.UT_Stress) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("WoodParallelCompressionStrength", sAsset.WoodParallelCompressionStrength, UnitType.UT_Stress) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("WoodParallelShearStrength", sAsset.WoodParallelShearStrength, UnitType.UT_Stress) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("WoodPerpendicularCompressionStrength", sAsset.WoodPerpendicularCompressionStrength, UnitType.UT_Stress) + "</li>");
				sBuilder.AppendLine("<li>" + FormatUnitValue("WoodPerpendicularShearStrength", sAsset.WoodPerpendicularShearStrength, UnitType.UT_Stress) + "</li>");
			}
			if (sAsset.Behavior == StructuralBehavior.Isotropic)
				sBuilder.AppendLine("<li>" + FormatUnitValue("YoungModulus", sAsset.YoungModulus[0], UnitType.UT_Stress) + "</li>");
			else
				sBuilder.AppendLine("<li>" + FormatUnitValue("YoungModulus", sAsset.YoungModulus, UnitType.UT_Stress) + "</li></ul>");

			return sBuilder.ToString();
		}
	
		/// <summary>
		/// Finds a rendering asset by name, returns null if none found.
		/// </summary>
		private Asset GetRenderingAssetByName(string name)
		{
			Asset foundRenderingAsset = null;
		 	AssetSet assets = this.Application.get_Assets(Autodesk.Revit.Utility.AssetType.Appearance);
		 	IEnumerable<Asset> assetsIe = assets.Cast<Asset>();
			try 
			{
				foundRenderingAsset = assetsIe.Single(asset => asset.Name == name);
			}
			catch{}

			return foundRenderingAsset;	
		}
	}
}