﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Search for a Material of a given name, return null if none found.
		/// </summary>
		private Material GetMaterialByName(string name)
		{
			FilteredElementCollector fec = new FilteredElementCollector(this.ActiveUIDocument.Document);
			fec.OfClass(typeof(Material));
			IEnumerable<Material> materials = fec.ToElements().Cast<Material>();
			
			Material material = null;
			try 
			{
				material = materials.Single(m => m.Name == name);
			}
			catch{}
			return material;
		}
		
		
		/// <summary>
		/// Checks to see if a material of a given name exists.
		/// </summary>
		private bool DoesMaterialExist(string name)
		{
			if(GetMaterialByName(name) == null)
				return false;
			else
				return true;	
		}
		
		/// <summary>
		/// Given a material and assets, create PropertySetElements and set them to the material.
		/// </summary>
		private void GeneralizedSetMaterialProperties(Material material, StructuralAsset sAsset, ThermalAsset tAsset)
		{
			//REMARK:  In the API, assets are reallly just buckets of data with unique names. The PropertySetElement
			//absorbs the asset and is what is actually serialized in the material and ultimately, the document.
			Transaction createProperties = new Transaction(this.ActiveUIDocument.Document, "Create Properties");
			createProperties.Start();
				PropertySetElement pseStructural = PropertySetElement.Create(this.ActiveUIDocument.Document, sAsset);
				PropertySetElement pseThermal = PropertySetElement.Create(this.ActiveUIDocument.Document,tAsset);
			createProperties.Commit();

			//REMARK:  Now that the PropertySetElements are actually created and populated with data, we can
			//set them in a material.
			
			Transaction setProperties = new Transaction(this.ActiveUIDocument.Document, "Set Properties");
			setProperties.Start();			
				material.SetMaterialAspectByPropertySet(MaterialAspect.Structural, pseStructural.Id);
				material.SetMaterialAspectByPropertySet(MaterialAspect.Thermal, pseThermal.Id);
			setProperties.Commit();
		}
		
		/// <summary>
		/// Create a new Material of a given name and class
		/// </summary>
		private Material GeneralizedMaterialCreateCore(string name, string materialClass)
		{
			Transaction createMaterial = new Transaction(this.ActiveUIDocument.Document, "Create Material");
			createMaterial.Start();
				ElementId newMaterialId = Material.Create(this.ActiveUIDocument.Document, name);
			createMaterial.Commit();
			
			Material newMaterial = this.ActiveUIDocument.Document.GetElement(newMaterialId) as Material;
			
			//REMARK: This material class will initially only contain one piece of data,
			//a material class string.
			Transaction setProperties = new Transaction(this.ActiveUIDocument.Document, "Set Material class");
			setProperties.Start();
				newMaterial.MaterialClass = materialClass;
				//REMARK: I am not covering renderinging appearances in this talk.
				//Assign a default render appearance.
				//newMaterial.RenderAppearance = GetRenderingAssetByName("Concrete");
			setProperties.Commit();
			
			
			return newMaterial;	
		}
		
		/// <summary>
		/// Duplicate a Material, its Assets, and its PropertySetElements, appending a suffix string to each duplicate.
		/// </summary>
		private void GeneralizedMaterialDuplicate(Material material, out Material materialDuplicate, out PropertySetElement pseStructuralDuplicate, out PropertySetElement pseThermalDuplicate, out StructuralAsset sAssetDuplicate, out ThermalAsset tAssetDuplicate, string suffix)
		{
			Transaction duplicateMaterial = new Transaction(this.ActiveUIDocument.Document, "Duplicate Material");
			
			///REMARK:  We're just copying the core of the material here.  
			///Duplicate the actual material object
			duplicateMaterial.Start();
				materialDuplicate = material.Duplicate(material.Name + "-" + suffix);
			duplicateMaterial.Commit();
			Debug.WriteLine(materialDuplicate.MaterialClass);

			///Duplicate the assets and PropertySetElements.
			
			//REMARK:  Now, copy each PropertySetElement and Corresponding Asset for a full "Deep" copy.
			Transaction duplicateProperties = new Transaction(this.ActiveUIDocument.Document, "Duplicate Properties");
			duplicateProperties.Start();
				PropertySetElement pseStructuralOriginal= this.ActiveUIDocument.Document.GetElement(material.StructuralAssetId) as PropertySetElement;
				PropertySetElement pseThermalOriginal = this.ActiveUIDocument.Document.GetElement(material.ThermalAssetId) as PropertySetElement;
				//REMARK: New in 2013
				StructuralAsset sAssetOriginal = pseStructuralOriginal.GetStructuralAsset();
				ThermalAsset tAssetOriginal = pseThermalOriginal.GetThermalAsset();
			
				pseStructuralDuplicate = pseStructuralOriginal.Duplicate(this.ActiveUIDocument.Document, pseStructuralOriginal.Name + "-" + suffix);
				pseThermalDuplicate = pseThermalOriginal.Duplicate(this.ActiveUIDocument.Document, pseThermalOriginal.Name + "-" + suffix);
			
				sAssetDuplicate = sAssetOriginal.Copy();
				sAssetDuplicate.Name = sAssetOriginal.Name + "-StructuralAsset-" + suffix;
			
				tAssetDuplicate = tAssetOriginal.Copy();
				tAssetDuplicate.Name = tAssetOriginal.Name + "-ThermalAsset-" + suffix;
			duplicateProperties.Commit();
		}

	}
}