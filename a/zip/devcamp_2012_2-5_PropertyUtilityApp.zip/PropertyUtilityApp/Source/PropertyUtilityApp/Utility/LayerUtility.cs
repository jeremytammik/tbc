﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Get the ThermalAsset from the Material of a Layer.
		/// </summary>
		private ThermalAsset GetLayerThermalAsset(CompoundStructureLayer csl)
		{
			Material material = this.ActiveUIDocument.Document.GetElement(csl.MaterialId) as Material;
			PropertySetElement pse = this.ActiveUIDocument.Document.GetElement(material.ThermalAssetId) as PropertySetElement;
			if (pse != null)
				return pse.GetThermalAsset();
			else
				return null;
		}
		
		/// <summary>
		/// Get the StructuralAsset from the Material of a Layer.
		/// </summary>
		private StructuralAsset GetLayerStructuralAsset(CompoundStructureLayer csl)
		{
			Material material = this.ActiveUIDocument.Document.GetElement(csl.MaterialId) as Material;
			PropertySetElement pse = this.ActiveUIDocument.Document.GetElement(material.StructuralAssetId) as PropertySetElement;
			if (pse != null)
				return pse.GetStructuralAsset();
			else
				return null;
		}
		
		/// <summary>
		/// Return the thermal and structural properties of a Wall.
		/// </summary>
		private string HostObjectLayerPropertySummary(HostObject hostObject)
		{
			StringBuilder sBuilder = new StringBuilder();
			sBuilder.Append("<h2> Structural Layer Summary</h2>");
			if (hostObject is Wall)
			{
				WallType wt = (hostObject as Wall).WallType;
				CompoundStructureLayer csl = GetStructuralLayer(wt.GetCompoundStructure());
				if (csl != null)
				{
					ThermalAsset tAsset = GetLayerThermalAsset(csl);
					if (tAsset != null)
					{
						sBuilder.AppendLine(ThermalAssetSummary(tAsset));
					}
					
					StructuralAsset sAsset = GetLayerStructuralAsset(csl);
					if (sAsset != null)
					{
						sBuilder.AppendLine(StructuralAssetSummary(sAsset));
					}
				}
				
			}
			return sBuilder.ToString();
		}
		
		
		/// <summary>
		/// Find the structural layer in a compound structure;
		/// </summary>
		private CompoundStructureLayer GetStructuralLayer(CompoundStructure cs)
		{
			IEnumerable<CompoundStructureLayer> layers = cs.GetLayers();
			int index = 0;
			
			foreach (CompoundStructureLayer csl in layers)
			{
				//REMARK:  StructuralMaterialIndex is a new API property in 2013.
				if (index == cs.StructuralMaterialIndex) //Find the structural layer in the layer collection.
					return csl;
				index++;
			}
			return null;

		}
		
		/// <summary>
		/// Find insert a new CompoundStructureLayer as the structural layer in a CompoundStructure.
		/// </summary>
		private void SetStructuralLayer(CompoundStructure cs, CompoundStructureLayer cslNew)
		{
			//REMARK:  To properly set a layer in a compound strucutre, you must build a new list
			//of layers with the edited layer included, and set that list of layers to the compound structure.
			
			IEnumerable<CompoundStructureLayer> layers = cs.GetLayers();
			int index = 0;
			//Make a new list of layers.
			IList<CompoundStructureLayer> newLayers = new List<CompoundStructureLayer>();  
					
			foreach (CompoundStructureLayer csl in layers)
			{
				//REMARK:  StructuralMaterialIndex is a new API property in 2013.
				if (index == cs.StructuralMaterialIndex) //Find the structural layer in the layer collection.
					newLayers.Add(cslNew);  //Insert the new structural layer.
				else
					newLayers.Add(csl);  //Add the other original layers as is.
				
				index++;
			}
			cs.SetLayers(newLayers);  //Set the new layer list to the CompoundStructure.

		}
		
	}
	
}