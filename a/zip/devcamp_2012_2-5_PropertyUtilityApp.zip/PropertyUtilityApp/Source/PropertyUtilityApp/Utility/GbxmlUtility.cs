﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.Xml;
using System.Xml.Linq;

namespace PropertyUtilityApp
{
	 enum GbxmlElementType
	{
		Door, Window
	}
	public partial class ThisApplication
	{
	/// <summary>
	/// Get the path to the currently running revit.exe
	/// </summary>
	 private string GetProcessPath(string processName)
      {
	 	try 
	 	{
	 		Process[] processes = System.Diagnostics.Process.GetProcessesByName("Revit");
         	if ((processes == null) || (processes.Length == 0))
            	return null;
         	else
         	{
            	Process sProcess = processes[0];
            	return sProcess.MainModule.FileName;
	         }
	 	}
	 	catch
	 	{
	 		return null;
	 	}
      }

	 /// <summary>
	 /// Get the path to constructions.xml
	 /// </summary>
      private  string GetConstructionsXmlPath()
      {
         string revitPath = GetProcessPath("Revit.exe");
         if (revitPath == null)
            return "D:\\builds\\2013rtm-0\\Debugx64\\constructions.xml";
         else
         {
            return System.IO.Path.GetDirectoryName(revitPath) + "\\constructions.xml";
         }
      }
      
      
		/// <summary>
		/// Given a path to the constructions.xml gbxml thermal property source file, construct a dictionary
		/// of key-value pairs suitable for family thermal properties of doors and windows.
		/// </summary>
		private Dictionary<string, string> BuildThermalPropertyDictionary(string constructionXmlPath, GbxmlElementType elementType)
		{
			//REMARK:  If you're not familiar with the C# XDocument XML tools, I highly recommend them.
			
			//REMARK:  All of these XML names come from the GBXML schema.
			XName xId = XName.Get("id");
			XName xName = XName.Get("Name");
			XName xOpeningType = XName.Get("openingType");
			XName xWindowType = XName.Get("WindowType");
			XName xConstruction = XName.Get("Construction");
			XName xSurfaceType = XName.Get("surfaceType");
			
			//Get the XML document.
			XDocument xConstructionsXml = XDocument.Load(GetConstructionsXmlPath());  
				
			Dictionary<string, string> thermalDictionary = new Dictionary<string, string>();
			
			//Get window or door thermal property definitions from the xml, but not both.
			if (elementType == GbxmlElementType.Window)
			{
				IEnumerable<XElement> windowTypes = xConstructionsXml.Root.Elements(xWindowType);
				// Only get the "FixedSkylight" windows
				foreach (XElement xWindow in windowTypes)
				{
					string id = xWindow.Attribute(xId).Value;
					string name = xWindow.Element(xName).Value;
					string openingType = xWindow.Attribute(xOpeningType).Value;
				
					if (openingType.StartsWith("FixedSkylight"))  //Only the these specific window types.
						thermalDictionary.Add(name + " ("+id+")", id);
				
				}
			}
			else
			{
				//Only get the "NonSlidingDoor" construction elements
				IEnumerable<XElement> constructions =  xConstructionsXml.Root.Elements(xConstruction);
				foreach (XElement xeConstruction in constructions)
				{
					string id = xeConstruction.Attribute(xId).Value;
					string name = xeConstruction.Element(xName).Value;
					string surfaceType = xeConstruction.Attribute(xSurfaceType).Value;
				
					if (surfaceType == "NonSlidingDoor")  //Only get door constructions.
						thermalDictionary.Add(name + " ("+id+")", id);
				}
			}
			return thermalDictionary;
		}
	}
}