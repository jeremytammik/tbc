﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/16/2012
 * Time: 12:05 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
					
		/// <summary>
		/// return ThermalProperties object data in string form.
		/// </summary>
		private string ThermalPropertiesSummary(ThermalProperties tProperties)
		{
			StringBuilder sBuilder = new StringBuilder();
			//REMARK:  RValue is always in (m^2*K)/Watt here.
			sBuilder.AppendLine("<h2>Thermal Properties </h2>");
			sBuilder.AppendLine("<ul><li>Absorptance = " + tProperties.Absorptance + "</li>");
			sBuilder.AppendLine("<li> HeatTransferCoefficient (U) = " + tProperties.HeatTransferCoefficient + " (Watt/(m^2*K))</li>");
			sBuilder.AppendLine("<li> Roughness = " + tProperties.Roughness + "</li>");
			sBuilder.AppendLine("<li>" + FormatUnitValue("ThermalMass", tProperties.ThermalMass, UnitType.UT_HVAC_ThermalMass) + "</li>");
			sBuilder.AppendLine("<li> ThermalResistance (R) = " + tProperties.ThermalResistance + " ((m^2*K)/Watt) </li></ul>");					

			return sBuilder.ToString();
		}
		
		/// <summary>
		/// return FamilyThermalProperties object data in string form.
		/// </summary>
		private string FamilyThermalPropertySummary(FamilyThermalProperties ftProperties)
		{
			StringBuilder sBuilder = new StringBuilder();
			//REMARK:  RValue is always in (m^2*K)/Watt here.
			sBuilder.AppendLine("<h2>Family Thermal Properties</h2>");
			sBuilder.AppendLine("<ul><li>AnalyticalConstructionName = " + ftProperties.AnalyticConstructionName + "</li>");
			sBuilder.AppendLine("<li> AnalyticConstructionTypeId = " + ftProperties.AnalyticConstructionTypeId + "</li>");
			sBuilder.AppendLine("<li> HeatTransferCoefficient (U) = " + ftProperties.HeatTransferCoefficient + " (Watt/(m^2*K))</li>");
			sBuilder.AppendLine("<li> SolarHeatGainCoefficient = " + ftProperties.SolarHeatGainCoefficient + "</li>");
			sBuilder.AppendLine("<li> ThermalResistance (R) = " + ftProperties.ThermalResistance + " ((m^2*K)/Watt) </li>");
			sBuilder.AppendLine("<li> VisualLightTransmittance = " + ftProperties.VisualLightTransmittance  + "</li></ul>");

			return sBuilder.ToString();
		}
		
		/// <summary>
		/// return the ThermalProperties object from a structured assembly (Wall, Floor, Ceiling, etc...)
		/// </summary>
		private ThermalProperties GetThermalPropertiesFromHostObject(HostObject hostObject)
		{
			//REMARK:  This method is only partially implemented -- it does not support all host objects.
			
			//REMARK:  ThermalProperties class and accessors on host objects, new in 2013.
			if (hostObject is Wall)
			{
				Wall w = hostObject as Wall;
				return w.WallType.ThermalProperties;
			}
			else if  (hostObject is Floor)
			{
				Floor f = hostObject as Floor;
				return f.FloorType.ThermalProperties;
			}
			else if  (hostObject is Ceiling)
			{
				Ceiling c = hostObject as Ceiling;
				return (this.ActiveUIDocument.Document.GetElement(c.GetTypeId()) as CeilingType).ThermalProperties;	
			}
			else
				return null;				
		}

	}
	
}