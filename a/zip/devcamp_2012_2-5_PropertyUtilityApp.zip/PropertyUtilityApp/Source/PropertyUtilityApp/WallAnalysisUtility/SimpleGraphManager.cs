﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 5/1/2012
 * Time: 4:56 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Autodesk.Revit.DB;

namespace PropertyUtilityApp
{
	/// <summary>
	/// A utility class for creating line graphs
	/// </summary>
	internal class SimpleGraphManager
   	{
      /// <summary>
      /// REMARK: Initialize the class to reference a canvas and stack panel in a window.
      /// </summary>
      public SimpleGraphManager(Canvas drawingArea, StackPanel lineLabelPanel)
      {
      	 m_lineLabelPanel = lineLabelPanel;
         m_drawingArea = drawingArea;
      }
     
      /// <summary>
      /// Draw the points from one WallAdjustmentSummary in a given color.
      /// </summary>
      public void PlotPolyLine(WallAdjustmentSummary singleLayerAdjustmentSummary, SolidColorBrush color)
      {
      	 Polyline newLine = new Polyline();
         newLine.StrokeThickness = 2;
         newLine.Stroke = color;
         
         PointCollection graphPoints = new PointCollection();
       
		 int widthIndex =0;
		//REMARK:  The scaling of the data for this graph is very casual -- it is just
		//to show a general data trend.		
         foreach (double rvalue in singleLayerAdjustmentSummary.AdjustedRvalues)
         {
         	double widthValue = (singleLayerAdjustmentSummary.StartingWidth*12 + (widthIndex*singleLayerAdjustmentSummary.InchIncrement))*5;
            //REMARK:  Transform from normal X/Y coordinates to canvas-coordinates
         	graphPoints.Add(SimpleTransform(new System.Windows.Point(widthValue, rvalue*5)));
         	widthIndex++;
         }
         newLine.Points = graphPoints;
          
         m_drawingArea.Children.Add(newLine);
         //REMARK: Add a text label identifying this polyline.
         Label legend = new Label();
		 legend.Content = "(Layer " + singleLayerAdjustmentSummary.LayerIndex + "-"+singleLayerAdjustmentSummary.MaterialName + ")  ";  
         legend.Foreground = color;
         
         m_lineLabelPanel.Children.Add(legend);
      }
       
      /// <summary>
      /// Transform from normal X/Y coordinates to canvas-coordinates
      /// </summary>
      private System.Windows.Point SimpleTransform(System.Windows.Point p)
      {
         return  new System.Windows.Point(p.X, 300 - p.Y);
      }
      
      private Canvas m_drawingArea;
      private StackPanel m_lineLabelPanel;
	 }
}
