﻿
using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.Windows.Media;
using System.Windows.Media.Imaging;


namespace PropertyUtilityApp
{
	public partial class ThisApplication
	{
		/// <summary>
		/// Given a wall, find the indicies of all insulation layers, and record
		/// the changes in R-Value when adjusting each layer by one foot five times.
		/// Also record changes in R-value when adjusting all insulation layers at once.
		/// </summary>
		private IList<WallAdjustmentSummary> WallAdjustmentTrials(Wall wall, int inchIncrement)
		{
			//REMARK: Start by getting the indices of layers that contain insulation.
			IList<int> insulationIndexList = GetInsulationLayerIndices(wall);
			
			//REMARK:  The data here is complicated enough that it is worthwhile to create a new data type,
			//"WallAdjustmentSummary."
			List<WallAdjustmentSummary> walladjustmentSummaries = new List<WallAdjustmentSummary>();
			foreach(int insulationIndex in insulationIndexList)
			{
				WallAdjustmentSummary was = WallAdjustmentTrial(wall, insulationIndex, inchIncrement);
				walladjustmentSummaries.Add(was);
			}
			
			return walladjustmentSummaries;
		}
		
		/// <summary>
		/// Given a wall and layer index, increment the layer by one foot, record new R-values,
		/// and repeat five times.  Restore layers to original width when finished.
		/// </summary>
		private WallAdjustmentSummary WallAdjustmentTrial(Wall wall, int insulationIndex, int inchIncrement)
		{

				IList<CompoundStructureLayer> originalLayers= wall.WallType.GetCompoundStructure().GetLayers();
				WallAdjustmentSummary singleLayerAdjustmentSummary = new WallAdjustmentSummary();
				singleLayerAdjustmentSummary.InchIncrement = inchIncrement;
				singleLayerAdjustmentSummary.LayerIndex = insulationIndex;
				singleLayerAdjustmentSummary.MaterialName = GetLayerMaterial(wall, singleLayerAdjustmentSummary.LayerIndex).Name;
				singleLayerAdjustmentSummary.StartingRValue = GetWallRValue(wall);
				singleLayerAdjustmentSummary.StartingWidth = SystemToDisplayUnits(GetLayerWidth(wall, insulationIndex), DisplayUnitType.DUT_FRACTIONAL_INCHES);
				//REMARK: We actually do the trial adjustment and results collection here.
				for (int trialIndex =1; trialIndex !=5; trialIndex++)
				{
					IncrementLayer(wall, inchIncrement*trialIndex, insulationIndex);
					//REMARK: Get the new RValue data after a layer width has been adjusted, and append
					//it to the wall adjustment summary.
					singleLayerAdjustmentSummary.AdjustedRvalues.Add(GetWallRValue(wall));  
				}
				
				//REMARK:  Reset layers back to their original settings when done.
				//This is an important step for *any* type of trial/analysis code.
				RestoreLayers(originalLayers, wall);
				return singleLayerAdjustmentSummary;
		}
		
		/// <summary>
		/// Adds a value 'incrementValue' to the given index of a given wall
		/// </summary>
		private void IncrementLayer(Wall wall, int incrementValue, int insulationIndex)
		{
			Transaction adjustLayers = new Transaction(this.ActiveUIDocument.Document, "Adjust Layer.");
			adjustLayers.Start();
			CompoundStructure cs = wall.WallType.GetCompoundStructure();
			int layerIndex = 0;
			IList<CompoundStructureLayer> cslNew = new List<CompoundStructureLayer>();
			
			foreach (CompoundStructureLayer csl in cs.GetLayers())
			{
				if (layerIndex == insulationIndex)
				{
					//REMARK: Sanity check--Make sure that the layer is actually an insulation layer as expected.
					if (csl.Function != MaterialFunctionAssignment.Insulation)
					{
						throw new ApplicationException("Layer is not insulation layer as expected.");
					}
					double systemIncrementValue = DisplayUnitsToSystem(incrementValue, DisplayUnitType.DUT_FRACTIONAL_INCHES);
					csl.Width +=systemIncrementValue;
				}

				cslNew.Add(csl);
				layerIndex++;
			}
			cs.SetLayers(cslNew);
			wall.WallType.SetCompoundStructure(cs);
			//REMARK:  The wall type now has a new insulation layer width.
			adjustLayers.Commit();
		}
		
		/// <summary>
		/// Sets a Wall's compound structure to a given list of layers.
		/// </summary>
		private void RestoreLayers(IList<CompoundStructureLayer> originalLayers, Wall wall)
		{
			//REMARK.  We could use a transaction "Undo" to restore layers as well, but there is no guarantee
			//that in the future, the "set layers" transaction would be the last transaction in the list of transactions
			//that we would want to undo, so it is good to have a separate "reset" method.
			Transaction restoreLayers = new Transaction(this.ActiveUIDocument.Document, "Restore Layers.");
			restoreLayers.Start();
			CompoundStructure cs = wall.WallType.GetCompoundStructure();
			cs.SetLayers(originalLayers);
			wall.WallType.SetCompoundStructure(cs);
			restoreLayers.Commit();
		}
		
		/// <summary>
		/// Returns a list of layer indices in the wall that are marked as "Insulation"
		/// </summary>
		private IList<int> GetInsulationLayerIndices(Wall wall)
		{
			IList<int> indexList= new List<int>();
			CompoundStructure cs = wall.WallType.GetCompoundStructure();
			int index =0;
			foreach (CompoundStructureLayer csl in cs.GetLayers())
			{

				//The MaterialFunctionAssignment property is not new in 2013, but it is important here.
				if (csl.Function == MaterialFunctionAssignment.Insulation)
					indexList.Add(index);
					
			index++;
			}
			return indexList;
		}
		
		/// <summary>
		/// Gets the Material of a given layer index in a wall.
		/// </summary>
		private Material GetLayerMaterial(Wall wall, int layerIndex)
		{
			CompoundStructure cs = wall.WallType.GetCompoundStructure();
			return this.ActiveUIDocument.Document.GetElement(cs.GetLayers()[layerIndex].MaterialId) as Material;
		}
		
		/// <summary>
		/// Returns the calculated RValue of Wall.
		/// </summary>
		private double GetWallRValue(Wall wall)
		{
			return wall.WallType.ThermalProperties.ThermalResistance;
		}
		
		/// <summary>
		/// Returns the width of a Wall's layer at a given index.
		/// </summary>
		private double GetLayerWidth(Wall wall, int layerIndex)
		{
			return wall.WallType.GetCompoundStructure().GetLayerWidth(layerIndex);
		}
}
}