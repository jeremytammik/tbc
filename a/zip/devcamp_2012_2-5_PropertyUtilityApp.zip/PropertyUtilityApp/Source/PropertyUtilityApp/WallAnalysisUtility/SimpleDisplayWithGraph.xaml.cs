﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 5/1/2012
 * Time: 4:56 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PropertyUtilityApp
{
	/// <summary>
	/// Interaction logic for SimpleDisplayWithGraph.xaml
	/// </summary>
	internal partial class SimpleDisplayWithGraph : Window
	{
		public SimpleDisplayWithGraph()
		{
			InitializeComponent();
			m_graphManager = new SimpleGraphManager(this.m_canvas, this.m_graphStackPanel);
		}
		
		/// <summary>
		/// Set the HTML to show in the top panel.
		/// </summary>
		public string Html 
		{
			set { this.m_browser.NavigateToString (value); }
		}
		
		/// <summary>
		/// The graph manager for creating a line graph in the bottom panel.
		/// </summary>
		public SimpleGraphManager GraphManager {
			get { return m_graphManager; }
		}
		
		private SimpleGraphManager m_graphManager;
		
	
		

	}
	

}