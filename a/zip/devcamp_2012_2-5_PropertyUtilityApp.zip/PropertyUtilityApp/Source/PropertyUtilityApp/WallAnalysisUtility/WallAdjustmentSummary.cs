﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 5/2/2012
 * Time: 3:32 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Diagnostics;
using System.Text;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PropertyUtilityApp
{
	/// <summary>
	/// A simple class for holding R-values of a wall as its layer widths are adjusted.
	/// </summary>
	public class WallAdjustmentSummary
	{
		/// <summary>
		/// When computing total R-value, you must the extra resistance that a thin layer of
		/// air on the inside and outside of material also have.  Units are  m^2/(k*W).
		/// </summary>
		public static double interiorConvectionCoefficeint = 0.12;
		public static double exteriorConvectionCoefficient = 0.03;
		    
		/// <summary>
		/// The layer that is being adjusted
		/// </summary>
		public int LayerIndex 
		{
			get { return m_layerIndex; }
			set { m_layerIndex = value; }
		}
		
		/// <summary>
		/// The name of the material of the layer that is being adjusted
		/// </summary>
		public string MaterialName 
		{
			get { return m_materialName; }
			set { m_materialName = value; }
		}
		
		/// <summary>
		/// The initial width of the layer being adjusted.
		/// </summary>
		public double StartingWidth 
		{
			get { return m_startingWidth; }
			set { m_startingWidth = value; }
		}
		
		/// <summary>
		/// The trial width increment value, in inches
		/// </summary>
		public int InchIncrement 
		{
			get { return m_inchIncrement; }
			set { m_inchIncrement = value; }
		}
		
		/// <summary>
		/// The initial RValue of the wall before adjustments.
		/// </summary>
		public double StartingRValue
		{
			get { return m_startingRValue; }
			set { m_startingRValue = value; }
		}
		
		/// <summary>
		/// A list of R-values after the wall's width is adjusted n-number of times.
		/// </summary>
		public List<double> AdjustedRvalues 
		{
			get { return m_adjustedRvalues; }
		}
		
		/// <summary>
		/// Returns an RValue and an rValue with interior and exterior air convection coefficients included as a formatted string.
		/// </summary>
		public static string formattedRValue(double value)
		{
			//REMARK:  This value is a bit bulky, so be sure to trim down the decimal places and add formatting.
			string baseRValue = value.ToString("0.000");
			string baseplusConvectionCoefficients = (value + interiorConvectionCoefficeint + exteriorConvectionCoefficient).ToString("0.000");
			return baseRValue + "  (" + baseplusConvectionCoefficients + ")  m^2/(k*W)";
		}
		
		/// <summary>
		/// Returns a formatted string containing all the data in this object.
		/// </summary>
		public  string ToFormattedString(SolidColorBrush color)
		{
			//REMARK: -- There's a lot of data here, so format appropriately.
			//Used for HTML formatting of color	
			string hexColor = "#"+ String.Format("{0,2:X}", color.Color.R)   + String.Format("{0,2:X}", color.Color.G)  +  String.Format("{0,2:X}", color.Color.B);
			
			//Add main wall summary information.
			StringBuilder sb = new StringBuilder();
			sb.AppendLine("<p/>");
			sb.AppendLine("<Font color=\"" + hexColor + "\">");
			sb.Append("<h2>WallAdjustmentSummary</h2>  LayerIndex=");
			

			
			sb.Append(m_layerIndex + "<br/>");
			sb.Append(" Layer Material=" +this.MaterialName + "<br/>");
			sb.Append(" Starting R-Value=" + formattedRValue(m_startingRValue) + "<br/>");
			

			sb.Append(" Starting Width=" + (m_startingWidth) + "\"" + "<br/>");
			

			sb.AppendLine("<br/>");
			int index =1;
            //Add data for each Width-change, resulting R-Value pair.
			foreach (double adjustedRvalue in m_adjustedRvalues)
			{
				sb.Append("Width=" + ((m_startingWidth + (index*InchIncrement))) + "\"" +  ", RValue =" + formattedRValue(adjustedRvalue) + "<br/>");
				index++;
			}
			sb.AppendLine("</Font>");
			sb.Append("<p/>");
			return sb.ToString();
		}

		private int m_layerIndex;
		private double m_startingRValue;
		private double m_startingWidth;
		private int m_inchIncrement;
		private string m_materialName;
		private List<double> m_adjustedRvalues = new List<double>();
		
		
	}
}
