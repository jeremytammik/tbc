﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/17/2012
 * Time: 2:33 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace PropertyUtilityApp
{
	/// <summary>
	/// A simple window with a scrolling textbox for displaying long lists of text data.
	/// </summary>
	internal partial class SimpleDisplay : Window
	{
		public SimpleDisplay()
		{
			InitializeComponent();

		}
		
		/// <summary>
		/// Set the HTML to show in the Window.
		/// </summary>
		public string Html 
		{
			set { this.m_browser.NavigateToString (value); }
		}
	
	}
}