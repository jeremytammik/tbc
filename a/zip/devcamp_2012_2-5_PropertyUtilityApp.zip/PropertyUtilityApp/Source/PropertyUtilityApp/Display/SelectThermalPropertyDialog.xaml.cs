﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 4/17/2012
 * Time: 4:21 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace PropertyUtilityApp
{

	/// <summary>
	/// A simple dialog class that allows the user to select door or window gbxml thermal property
	/// definitions.
	/// </summary>
	internal partial class SelectThermalPropertyDialog : Window
	{
		/// <summary>
		/// Initializes the dialog to display a list of thermal property definition names
		/// and store a mapping of names to Ids.
		/// </summary>
		/// <param name="thermalPropertyDefinitions"></param>
		public SelectThermalPropertyDialog(Dictionary<string, string> thermalPropertyDefinitions)
		{
			InitializeComponent();
			//Store the name to Id Map;
			m_thermalPropertyDefinitions = thermalPropertyDefinitions;

			//Add the names to the combo box for display and selection.
			foreach (string key in m_thermalPropertyDefinitions.Keys )
			{
				cb_thermalProperties.Items.Add(key);
			}
			this.cb_thermalProperties.SelectedIndex=0;
		}
		
		public SelectThermalPropertyDialog()
		{
			InitializeComponent();
		}
		
		/// <summary>
		/// Get the selected thermal property definition name and look it up in the stored map
		/// to get the gbxml id of the property definition.
		/// </summary>
		public string selectedId
		{
			get 
			{
				if (cb_thermalProperties.SelectedItem == null)
					return null;
				return m_thermalPropertyDefinitions[cb_thermalProperties.SelectedItem as string];
			}
		}
		
		private void btn_ok_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}
		
		//The gbxml name to Id map;		
		private Dictionary<string, string> m_thermalPropertyDefinitions;
		
	
	}
}