﻿using System;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;

namespace GroupHeadersSampler
{
  [Transaction( TransactionMode.Manual )]
  public class Main : IExternalCommand
  {
    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      try
      {
        UIDocument uidoc = commandData.Application
          .ActiveUIDocument;

        Document doc = uidoc.Document;

        // Create the schedule

        Transaction tran = new Transaction( doc );
        tran.Start( "Create schedule" );

        ViewSchedule sampleSchedule
          = ViewSchedule.CreateSchedule( doc, new
            ElementId( BuiltInCategory.OST_Windows ) );

        foreach( ElementId id in
          ViewSchedule.GetAvailableParameters( doc, new
            ElementId( BuiltInCategory.OST_Windows ) ) )
        {
          try
          {
            sampleSchedule.Definition.AddField(
              new SchedulableField(
                ScheduleFieldType.Instance, id ) );
          }
          catch( Exception )
          {
          }
        }
        ScheduleDefinition sampleDefinition
          = sampleSchedule.Definition;

        // Hide two columns in the schedule

        sampleDefinition.GetField( 0 ).IsHidden = true;
        sampleDefinition.GetField( 1 ).IsHidden = true;

        // Commit the schedule. This is important so 
        // you can set the active view.

        tran.Commit();

        // Change the active view to the schedule. 
        // This is required before the GroupHeaders 
        // function will work.

        uidoc.ActiveView = sampleSchedule;

        // Group the last three headers.
        // Hidden fields are not counted in the left 
        // and right values, so make sure to account 
        // for that.

        tran.Start( "Group headers" );

        int iFieldCount = sampleDefinition
          .GetFieldCount();

        sampleSchedule.GroupHeaders( 0,
          iFieldCount - 5, 0,
          iFieldCount - 3, "Group Header" );

        tran.Commit();

        return Result.Succeeded;
      }
      catch( Exception ex )
      {
        MessageBox.Show( ex.ToString(),
          "Group Headers Sample" );

        return Result.Failed;
      }
    }
  }
}
