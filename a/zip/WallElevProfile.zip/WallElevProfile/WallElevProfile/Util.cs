#region Header
//
// Util.cs - The Building Coder Revit API utility methods
//
// Copyright (C) 2008 by Jeremy Tammik, 
// Autodesk Inc. All rights reserved.
//
#endregion // Header

#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;


using CylindricalFace = Autodesk.Revit.DB.CylindricalFace;
using Edge = Autodesk.Revit.DB.Edge;
using PlanarFace = Autodesk.Revit.DB.PlanarFace;
using Transform = Autodesk.Revit.DB.Transform;
using XYZ = Autodesk.Revit.DB.XYZ;
#endregion // Namespaces

namespace BuildingCoder
{
  class Util
  {
    #region Geometrical Comparison
    const double _eps = 1.0e-9;

    static public bool IsZero( double a )
    {
      return _eps > Math.Abs( a );
    }

    static public bool IsHorizontal( XYZ v )
    {
      return IsZero( v.Z );
    }

    static public bool IsVertical( XYZ v )
    {
      return IsZero( v.X ) && IsZero( v.Y );
    }

    static public bool IsHorizontal( Edge e )
    {
      XYZ p = e.Evaluate( 0 );
      XYZ q = e.Evaluate( 1 );
      return IsHorizontal( q - p );
    }

    static public bool IsHorizontal( PlanarFace f )
    {
      return IsVertical( f.Normal );
    }

    static public bool IsVertical( PlanarFace f )
    {
      return IsHorizontal( f.Normal );
    }

    static public bool IsVertical( CylindricalFace f )
    {
      return IsVertical( f.Axis );
    }
    #endregion // Geometrical Comparison

    #region Unit Handling
    const double _convertFootToMm = 12 * 25.4;

    /// <summary>
    /// Convert a given length in feet to millimetres.
    /// </summary>
    static public double FootToMm( double length )
    {
      return length * _convertFootToMm;
    }
    #endregion // Unit Handling

    #region Formatting
    /// <summary>
    /// Return an English plural suffix 's' or 
    /// nothing for the given number of items.
    /// </summary>
    public static string PluralSuffix( int n )
    {
      return 1 == n ? "" : "s";
    }

    public static string DotOrColon( int n )
    {
      return 1 < n ? ":" : ".";
    }

    static public string RealString( double a )
    {
      return a.ToString( "0.##" );
    }

    static public string AngleString( double angle )
    {
      return RealString( angle * 180 / Math.PI ) + " degrees";
    }

    static public string MmString( double length )
    {
      return RealString( FootToMm( length ) ) + " mm";
    }

    static public string PointString( XYZ p )
    {
      return string.Format( "({0},{1},{2})", 
        RealString( p.X ), RealString( p.Y ), 
        RealString( p.Z ) );
    }

    static public string TransformString( Transform t )
    {
      return string.Format( "({0},{1},{2},{3})", PointString( t.Origin ),
        PointString( t.BasisX ), PointString( t.BasisY ), PointString( t.BasisZ ) );
    }
    #endregion // Formatting

    const string _caption = "The Building Coder";

    static public void InfoMsg( string msg )
    {
      Debug.WriteLine( msg );

      TaskDialog.Show(_caption, msg, TaskDialogCommonButtons.Ok);
    }

    public static string ElementDescription( Element e )
    {
      // for a wall, the element name equals the 
      // wall type name, which is equivalent to the 
      // family name ...
      FamilyInstance fi = e as FamilyInstance;
      string fn = ( null == fi )
        ? string.Empty
        : fi.Symbol.Family.Name + " ";

      string cn = ( null == e.Category )
        ? e.GetType().Name
        : e.Category.Name;

      return string.Format( "{0} {1}<{2} {3}>",
        cn, fn, e.Id.ToString(), e.Name );
    }

    #region Element Selection
    public static Element SelectSingleElement( UIDocument uidoc, string description )
    {

      Reference r = uidoc.Selection.PickObject(
      ObjectType.Element, "Please select" + description);

      Element e = uidoc.Document.GetElement(r);  

      return e;
    }

    /// <summary>
    /// Retrieve all pre-selected elements of the specified type,
    /// if any elements at all have been pre-selected. If not,
    /// retiriev all elements of specified type in the database.
    /// </summary>
    /// <param name="a">Return value container</param>
    /// <param name="doc">Active document</param>
    /// <param name="t">Specific type</param>
    /// <returns>True if some elements were retrieved</returns>
    public static bool GetSelectedElementsOrAll(
      List<Element> a, 
      UIDocument uidoc, 
      Type t )
    {
      Document doc = uidoc.Document;
      Selection sel = uidoc.Selection;
      if( 0 < sel.GetElementIds().Count)
      {
        foreach (ElementId id in sel.GetElementIds())
        {
          Element e = uidoc.Document.GetElement(id);
          if( t.IsInstanceOfType( e ) )
          {
            a.Add( e );
          }
        }
        return 0 < a.Count;
      }
      else
      {
        var col = new FilteredElementCollector(doc);
        col.WherePasses(new ElementClassFilter(t));
        IList<Element> elems = col.ToElements();
        return 0 < elems.Count;
      }
    }
    #endregion // Element Selection
  }
}
