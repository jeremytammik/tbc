﻿#region Namespaces
using System;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB.Events;
#endregion

namespace RevitUiApiNews
{
  [Transaction( TransactionMode.ReadOnly )]
  public class CmdProgressWatcher : IExternalCommand
  {
    bool _watching = false;

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      Application app = uiapp.Application;

      if( _watching )
      {
        app.ProgressChanged
          -= new EventHandler<ProgressChangedEventArgs>(
            OnProgressChanged );

        Debug.Print( "\r\nProgress Watcher ended\r\n" );
      }
      else
      {
        Debug.Print( "\r\nProgress Watcher begin\r\n" );

        app.ProgressChanged
          += new EventHandler<ProgressChangedEventArgs>(
            OnProgressChanged );
      }
      return Result.Succeeded;
    }

    void OnProgressChanged(
      object sender,
      ProgressChangedEventArgs e )
    {
      double percent = 100.0 * e.Position / e.UpperRange;

      Debug.Print(
        "'{0}' stage {1} position {2} [{3}, {4}] ({5}%)",
        e.Caption, e.Stage, e.Position, e.LowerRange,
        e.UpperRange, percent.ToString( "0.##" ) );
    }
  }
}
