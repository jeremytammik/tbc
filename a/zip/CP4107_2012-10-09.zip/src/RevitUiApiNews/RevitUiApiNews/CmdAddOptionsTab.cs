﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.UI.Events;
#endregion

namespace RevitUiApiNews
{
  [Transaction( TransactionMode.ReadOnly )]
  public class CmdAddOptionsTab : IExternalCommand
  {
    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;

      uiapp.DisplayingOptionsDialog
        += new EventHandler<DisplayingOptionsDialogEventArgs>(
          OnDisplayingOptionsDialog );

      return Result.Succeeded;
    }

    void OnDisplayingOptionsDialog(
      object sender,
      DisplayingOptionsDialogEventArgs e )
    {
      try
      {
        UserControl1 c = new UserControl1(
          "Jeremy's User Control" );

        e.AddTab( "Jeremy's Custom Tab",
          new TabbedDialogExtension(
            c, c.OnOK ) );
      }
      catch( Autodesk.Revit.Exceptions
        .InternalException ex )
      {
        Debug.Assert( ex.Message.Equals( 
          "Cannot duplicate the existing resource id." ),
          "expected duplicate resource id" );
      }
    }
  }
}
