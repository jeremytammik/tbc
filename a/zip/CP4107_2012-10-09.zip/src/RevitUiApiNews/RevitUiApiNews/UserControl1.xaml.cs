﻿using System;
using System.Windows;
using System.Windows.Controls;
using Autodesk.Revit.UI;

namespace RevitUiApiNews
{
  public partial class UserControl1 : UserControl
  {
    string _name;

    public UserControl1( string name )
    {
      _name = name;

      InitializeComponent();
    }

    private void button1_Click( 
      object sender, 
      RoutedEventArgs e )
    {
      TaskDialog.Show( _name, "I was clicked..." );
    }

    public void OnOK()
    {
      TaskDialog.Show( _name, "OK" );
    }

    public void OnCancel()
    {
      TaskDialog.Show( _name, "OnCancel" );
    }

    public void OnRestoreDefaults()
    {
      TaskDialog.Show( _name, "OnRestoreDefaults" );
    }
  }
}
