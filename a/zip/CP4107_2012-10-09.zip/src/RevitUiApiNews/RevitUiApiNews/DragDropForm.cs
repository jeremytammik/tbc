﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Form = System.Windows.Forms.Form;

namespace RevitUiApiNews
{
  public partial class DragDropForm : Form
  {
    string _family_filename;

    public DragDropForm( Document fdoc )
    {
      if( null == fdoc )
      {
        throw new ArgumentNullException( "fdoc" );
      }

      if( !fdoc.IsFamilyDocument )
      {
        throw new ArgumentException( 
          "not a family", "fdoc" );
      }

      _family_filename = fdoc.PathName;

      InitializeComponent();

      // Populate list box with family type names

      foreach( FamilyType t in fdoc.FamilyManager.Types )
      {
        string s = t.Name.Trim();
        if( 0 < s.Length )
        {
          listBox1.Items.Add( s );
        }
      }

      listBox1.MouseMove += new MouseEventHandler(
        listBox1_MouseMove );
    }

    /// <summary>
    /// Initiate a drag and drop operation on 
    /// mouse move if left mouse button is pressed.
    /// This only works from a modeless form. 
    /// A modal form in a Revit add-in blocks the 
    /// Revit message queue, which disables the drop
    /// operation.
    /// </summary>
    private void listBox1_MouseMove( 
      object sender, 
      MouseEventArgs e )
    {
      if( MouseButtons.Left == MouseButtons )
      {
        string typename 
          = listBox1.SelectedItem as string;

        if( null != typename )
        {
          DragDropHandler h
            = new DragDropHandler( 
              _family_filename );

          // Tried to close form from within mouse 
          // move handler to allow successful drop 
          // from a modal form, but that does not 
          // work, of course:

          //Close();

          UIApplication.DoDragDrop( typename, h );
        }
      }
    }
  }
}
