﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Media.Imaging;
using System.Reflection;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
#endregion

namespace RevitUiApiNews
{
  class CmdData
  {
    public CmdData( 
      string name, 
      string text, 
      string tip )
    {
      Name = name;
      Text = text;
      Tip = tip;
    }
    public string Name { get; set; }
    public string Text { get; set; }
    public string Tip { get; set; }
  }

  class App : IExternalApplication
  {
    const string Caption = "Revit 2013 UI API";
    const string _class_name_prefix = "RevitUiApiNews.Cmd";

    static CmdData[] data = new CmdData[] {

      new CmdData( 
        "AddOptionsTab",
        "Add Options Tab",
        "Add a new Options tab displaying a XAML user control" ),

      new CmdData( 
        "DragDropApi",
        "Drag and Drop API",
        "Drag and drop a family type selected in a modeless form" ),

      new CmdData( 
        "PreviewControlSimple",
        "Simple Preview Control",
        "Simple PreviewControl displaying active view in a dynamic form" ),

      new CmdData( 
        "ProgressWatcher",
        "Progress Watcher",
        "List all ProgressChanged events in the Visual Studio debug output console" )

    };

    static string _namespace_prefix
      = typeof( App ).Namespace + ".";

    /// <summary>
    /// Load a new icon bitmap from embedded resources.
    /// For the BitmapImage, make sure you reference 
    /// WindowsBase and PresentationCore, and import 
    /// the System.Windows.Media.Imaging namespace. 
    /// </summary>
    BitmapImage NewBitmapImage(
      Assembly a,
      string imageName )
    {
      // to read from an external file:
      //return new BitmapImage( new Uri(
      //  Path.Combine( _imageFolder, imageName ) ) );

      Stream s = a.GetManifestResourceStream(
          _namespace_prefix + imageName );

      BitmapImage img = new BitmapImage();

      img.BeginInit();
      img.StreamSource = s;
      img.EndInit();

      return img;
    }

    public Result OnStartup( 
      UIControlledApplication a )
    {
      Assembly exe = System.Reflection.Assembly
        .GetExecutingAssembly();

      string path = exe.Location;

      bool usePulldownButton = false; // else SplitButton

      // Create ribbon panel

      RibbonPanel panel = a.CreateRibbonPanel( Caption );

      string s = "Commands";

      RibbonItemData containerData = usePulldownButton
        ? new PulldownButtonData( s, s )
        : new SplitButtonData( s, s );

      // The container is in fact either
      // a PulldownButton or a SplitButton

      RibbonItem container = panel.AddItem( 
        containerData );

      // Create buttons

      List<PushButtonData> buttonData 
        = new List<PushButtonData>( 
          data.Length );

      foreach( CmdData cd in data )
      {
        PushButtonData pbd = new PushButtonData(
          cd.Name, cd.Text, path,
          _class_name_prefix + cd.Name );

        pbd.ToolTip = cd.Tip;

        pbd.Image = NewBitmapImage( exe, 
          "smiley_16.png" );

        pbd.LargeImage = NewBitmapImage( exe, 
          "smiley_32.png" );

        //p.AddItem( pbd );

        //buttonData.Add( pbd );

        if( usePulldownButton )
        {
          (container as PulldownButton).AddPushButton( 
            pbd );
        }
        else
        {
          (container as SplitButton).AddPushButton( 
            pbd );
        }
      }

      //p.AddStackedItems( buttonData[0], 
      //  buttonData[1] );

      return Result.Succeeded;
    }

    public Result OnShutdown( 
      UIControlledApplication a )
    {
      return Result.Succeeded;
    }
  }
}
