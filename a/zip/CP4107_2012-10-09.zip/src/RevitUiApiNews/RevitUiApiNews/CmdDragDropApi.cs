﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Application = Autodesk.Revit.ApplicationServices.Application;
using Autodesk.Windows;
#endregion

namespace RevitUiApiNews
{
  [Transaction( TransactionMode.Manual )]
  public class CmdDragDropApi : IExternalCommand
  {
    /// <summary>
    /// Define the family library folder.
    /// </summary>
    const string _library_folder_name
      = "C:\\ProgramData\\Autodesk\\RVT 2013\\Libraries\\US Metric";

    /// <summary>
    /// Select a family file in the gioven folder.
    /// </summary>
    /// <param name="folder">Initial folder.</param>
    /// <param name="filename">Selected filename on success.</param>
    /// <returns>Return true if a file was successfully selected.</returns>
    static bool FileSelect(
      string folder,
      out string filename )
    {
      OpenFileDialog dlg = new OpenFileDialog();
      dlg.Title = "Select Revit Family";
      dlg.CheckFileExists = true;
      dlg.CheckPathExists = true;
      //dlg.RestoreDirectory = true;
      dlg.InitialDirectory = folder;
      dlg.Filter = ".rfa Files (*.rfa)|*.rfa";
      bool rc = ( DialogResult.OK == dlg.ShowDialog() );
      filename = dlg.FileName;
      return rc;
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      IWin32Window revit_window
        = new JtWindowHandle(
          ComponentManager.ApplicationWindow );

      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Application app = uiapp.Application;

      IDictionary<string, string> paths
        = app.GetLibraryPaths();

      string filename;

      if( FileSelect( _library_folder_name,
        out filename ) )
      {
        Document fdoc = app.OpenDocumentFile(
          filename );

        DragDropForm form = new DragDropForm( fdoc );

        // This does not work: modal form is in same 
        // thread and blocks the drop operation

        //form.ShowDialog( revit_window );

        // This works fine

        form.Show( revit_window );
      }
      return Result.Succeeded;
    }
  }
}
