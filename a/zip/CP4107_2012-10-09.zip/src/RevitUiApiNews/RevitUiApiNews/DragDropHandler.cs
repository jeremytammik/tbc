﻿using System;
using System.Diagnostics;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Form = System.Windows.Forms.Form;

namespace RevitUiApiNews
{
  /// <summary>
  /// A 'load family type' drag drop handler.
  /// </summary>
  public class DragDropHandler : IDropHandler
  {
    string _family_filename;

    public DragDropHandler(
      string family_filename )
    {
      _family_filename = family_filename;
    }

    /// <summary>
    /// On dropping a family type name onto Revit,
    /// load the one single named family symbol
    /// and prompt user for placement of it.
    /// </summary>
    public void Execute(
      UIDocument uidoc,
      object data )
    {
      string typename = data as string;

      Debug.Assert( null != typename,
        "expected a valid type name" );

      Document doc = uidoc.Document;

      using( Transaction tx = new Transaction( doc ) )
      {
        tx.Start( "Load Family Symbol" );

        FamilySymbol symbol;

        doc.LoadFamilySymbol(
          _family_filename, typename, out symbol );

        tx.Commit();

        if( null != symbol )
        {
          uidoc.PromptForFamilyInstancePlacement(
            symbol );
        }
      }
    }
  }
}
