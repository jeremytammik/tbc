﻿#define CREATE_FORM_BY_CODE

#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Windows;
using View = Autodesk.Revit.DB.View;
#endregion

namespace RevitUiApiNews
{
  [Transaction( TransactionMode.ReadOnly )]
  public class CmdPreviewControlSimple : IExternalCommand
  {
    const string _caption_prefix
      = "Simple Revit Preview - ";

    /// <summary>
    /// Create a preview control and a form to host it.
    /// </summary>
    void DisplayRevitView(
      Document doc,
      View view,
      IWin32Window owner )
    {

      using( PreviewControl pc
        = new PreviewControl( doc, view.Id ) )
      {

#if CREATE_FORM_BY_CODE

        using( System.Windows.Forms.Form form
          = new System.Windows.Forms.Form() )
        {
          ElementHost elementHost = new ElementHost();

          elementHost.Location
            = new System.Drawing.Point( 0, 0 );

          elementHost.Dock = DockStyle.Fill;
          elementHost.TabIndex = 0;
          elementHost.Parent = form;
          elementHost.Child = pc;

          form.Text = _caption_prefix + view.Name;
          form.Controls.Add( elementHost );
          form.Size = new Size( 400, 400 );
          form.ShowDialog( owner );
        }

#else // if not CREATE_FORM_BY_CODE

        Form1 form = new Form1( pc );
        form.ShowDialog( owner );

#endif // CREATE_FORM_BY_CODE

      }
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      IWin32Window revit_window
        = new JtWindowHandle(
          ComponentManager.ApplicationWindow );

      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Document doc = uidoc.Document;

      // Determine all printable views that can be
      // used to populate the preview control; not
      // used in this sample, we just display the 
      // actvie view:

      IEnumerable<View> views
        = new FilteredElementCollector( doc )
          .OfClass( typeof( View ) )
          .Cast<View>()
          .Where<View>( v => v.CanBePrinted );

      View view = doc.ActiveView;

      DisplayRevitView( doc, view, revit_window );

      return Result.Succeeded;
    }
  }
}

// C:\Program Files\Autodesk\Revit Quasar RP\Program\Samples\rac_advanced_sample_project.rvt
