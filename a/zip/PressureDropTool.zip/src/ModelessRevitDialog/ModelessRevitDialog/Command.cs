﻿#region Header
// When user selects Duct or Duct Fitting
// Pressure Drop is Displayed
//
// Copyright (C) 2009 by Joel Karr,
// CADworks Inc. All rights reserved.
// Special Thanks to Jeremy Tammik
#endregion

#region Namespaces
using System;
using System.Diagnostics;
using Autodesk.Revit;
using Autodesk.Revit.MEP;
using Autodesk.Revit.Elements;
using CmdResult
  = Autodesk.Revit.IExternalCommand.Result;
using IWin32Window
  = System.Windows.Forms.IWin32Window;
using System.Windows.Forms;
#endregion // Namespaces

namespace ModelessRevitDialog
{
  #region WindowHandle
  /// <summary>
  /// Wrapper class for converting IntPtr to IWin32Window.
  /// </summary>
  public class WindowHandle : IWin32Window
  {
    IntPtr _hwnd;

    public WindowHandle(IntPtr h)
    {
      Debug.Assert(IntPtr.Zero != h,
        "expected non-null window handle");

      _hwnd = h;
    }

    public IntPtr Handle
    {
      get
      {
        return _hwnd;
      }
    }
   }
  #endregion

  public class Command : IExternalCommand
  {
    static WindowHandle _hWndRevit = null;

    public CmdResult Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements)
    {
      #region Get Revit Window Handle
      if (null == _hWndRevit)
      {
        Process process
          = Process.GetCurrentProcess();

        IntPtr h = process.MainWindowHandle;

        _hWndRevit = new WindowHandle(h);
      }
      #endregion // Get Revit Window Handle

      Autodesk.Revit.Application app 
        = commandData.Application;

      Document doc = app.ActiveDocument;

      Data data = new Data();
      data.Selection = doc.Selection;

      using( WindowHandleForm f 
        = new WindowHandleForm( data ) )
      {
        f.Show( _hWndRevit );

        while( data.UsingWindow )
        {
          if( data.GetElements )
          {
            // Clear Selection and Pressure Drop Value:

            data.Selection.Elements.Clear();
            data.PressureDrop = 0;

            // User Selects an Element:

            data.Selection.StatusbarTip 
              = "Please select a duct fitting.";

            data.Selection.PickOne();

            SelElementSet ss = data.Selection.Elements;

            #region Process Selection for Pressure Drop

            // Check to see if selection is Duct or Fitting

            foreach (Element e in ss)
            {
              // if selection is duct get parameter of Pressure Drop
              if (e is Duct)
              {
                Duct duct = e as Duct;

                Parameter p
                  = duct.ParametersMap.get_Item( 
                    "Pressure Drop" );

                data.PressureDrop = p.AsDouble();
              }
              // if selection is fitting then must look through connectors and return
              // the highest pressure drop in this tool.  Multiple branch fittings would need to return a
              // different pressure drop value for each branch
              else if (e is FamilyInstance
                //&& e.Category.Name == "Duct Fittings"
                && e.Category.Id.Value.Equals( 
                  (int) BuiltInCategory.OST_DuctFitting ) )
              {
                FamilyInstance fitting = e as FamilyInstance;

                foreach (Connector c in 
                  fitting.MEPModel.ConnectorManager.Connectors)
                {
                  if (c.PressureDrop > data.PressureDrop)
                  {
                    data.PressureDrop = c.PressureDrop;
                  }
                }
              }
            }
            #endregion

            #region Send Information to Window Label

            // Set the recorded Pressure Drop (and Selection Name?) to Dialog

            foreach( System.Windows.Forms.Control control
              in f.Controls.Find( "lblPressure", true ) )
            {
              control.Text = Math.Round( 
                data.PressureDrop, 4 ).ToString();
            }
            #endregion
          }
        }
      }
      return CmdResult.Succeeded;
    }
  }
}
