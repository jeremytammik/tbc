﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autodesk.Revit;
using Autodesk.Revit.MEP;
namespace ModelessRevitDialog
{
  public partial class WindowHandleForm : Form
  {
    public Data CDWKSData { get; set; }

    public WindowHandleForm(Data data)
    {
      InitializeComponent();

      CDWKSData = data;
    }
  }
}
