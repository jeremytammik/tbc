﻿#region Header
// Data Storage
//
// Copyright (C) 2009 by Joel Karr,
// CADworks Inc. All rights reserved.
#endregion

#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit;
#endregion

namespace ModelessRevitDialog
{
  public class Data
  {
    public bool UsingWindow { get; set; }
    public bool GetElements { get; set; }
    public double PressureDrop { get; set; }
    public Selection Selection { get; set; }
    public Data()
    {
      UsingWindow = true;
      GetElements = true;
    }
  }
}
