//
// (C) Copyright 2003-2008 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;

using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Geometry;
using Autodesk.Revit.Symbols;
using System.Collections;

namespace Revit.Test.Samples.GenerateFloor.CS
{
    /// <summary>
    /// Implements the Revit add-in interface IExternalCommand
    /// </summary>
    public class Command2 : IExternalCommand
    {
        #region IExternalCommand Members Implementation
        /// <summary>
        /// Implement this method as an external command for Revit.
        /// </summary>
        /// <param name="commandData">An object that is passed to the external application 
        /// which contains data related to the command, 
        /// such as the application object and active view.</param>
        /// <param name="message">A message that can be set by the external application 
        /// which will be displayed if a failure or cancellation is returned by 
        /// the external command.</param>
        /// <param name="elements">A set of elements to which the external application 
        /// can add elements that are to be highlighted in case of failure or cancellation.</param>
        /// <returns>Return the status of the external command. 
        /// A result of Succeeded means that the API external method functioned as expected. 
        /// Cancelled can be used to signify that the user cancelled the external operation 
        /// at some point. Failure should be returned if the application is unable to proceed with 
        /// the operation.</returns>
        public Autodesk.Revit.IExternalCommand.Result Execute(Autodesk.Revit.ExternalCommandData commandData,
            ref string message, Autodesk.Revit.ElementSet elements)
        {
            try
            {
                if (null == commandData)
                {
                    throw new ArgumentNullException("commandData");
                }


                SelElementSet eleSet = commandData.Application.ActiveDocument.Selection.Elements;
                if (eleSet.Size != 1) 
                {
                    return IExternalCommand.Result.Failed;  
                }

                Floor floor = null;
                IEnumerator iter = eleSet.GetEnumerator();
                iter.Reset();
                while (iter.MoveNext())
                {
                    floor = iter.Current as Floor;
                }




                CurveArray profile = new CurveArray();
                EdgeArray edges = new EdgeArray();
                Options options = commandData.Application.Create.NewGeometryOptions();
                options.DetailLevel = Options.DetailLevels.Medium;

                //make sure references to geometric objects are computed.
                options.ComputeReferences = true;
                Autodesk.Revit.Geometry.Element geoElem = floor.get_Geometry(options);
                GeometryObjectArray gObjects = geoElem.Objects;
                //get all the edges in the Geometry object
                foreach (GeometryObject geo in gObjects)
                {
                    Solid solid = geo as Solid;
                    if (solid != null)
                    {
                        FaceArray faces = solid.Faces;
                        Face face = faces.get_Item(faces.Size - 1);

                        EdgeArrayArray edgeArrarr = face.EdgeLoops;
                        foreach (EdgeArray edgeArr in edgeArrarr)
                        {
                            foreach (Edge edge in edgeArr)
                            {
                                edges.Append(edge);

                                XYZArray xyzArray = edge.Tessellate();                            

                                Line line = commandData.Application.Create.NewLine(xyzArray.get_Item(0), xyzArray.get_Item(1), true);

                                profile.Append(line);
                                                                
                            }
                        }
                    }

                }


                commandData.Application.ActiveDocument.Create.NewFloor(profile, floor.FloorType, floor.Level, true);



                return IExternalCommand.Result.Succeeded;
            }
            catch (Exception e)
            {
                message = e.Message;
                return IExternalCommand.Result.Failed;
            }
        }

        #endregion IExternalCommand Members Implementation


    }



}
