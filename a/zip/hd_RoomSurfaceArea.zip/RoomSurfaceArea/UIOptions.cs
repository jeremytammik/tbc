﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;


namespace CADQ.LABS.RoomSurfaceArea
{
    public class SpatialUIOptions
    {

        public string _spatialPhase = string.Empty;

        private string SpatialPhase
        {
            get
            {
                return _spatialPhase;
            }

            set
            {
                _spatialPhase = value;
            }
        }

        //public string _strAssociatedSheet = string.Empty;

        //private string AssociatedSheet
        //{
        //    get
        //    {
        //        return _strAssociatedSheet;
        //    }

        //    set
        //    {
        //        _strAssociatedSheet = value;
        //    }
        //}

        public ElementId _idAssociatedSheet = ElementId.InvalidElementId;

        private ElementId AssociatedSheet
        {
            get
            {
                return _idAssociatedSheet;
            }

            set
            {
                _idAssociatedSheet = value;
            }
        }

    }
}
