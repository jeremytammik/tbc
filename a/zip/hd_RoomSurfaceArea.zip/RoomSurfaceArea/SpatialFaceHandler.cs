﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;

namespace CADQ.LABS.RoomSurfaceArea
{
    class SpatialFaceHandler
    {

        public List<SortedSurfaceData> GetSpatialSurfaceData(Document doc, string phaseName)
        {

            LogCreator.LogEntry(";AREATYPE;ElementId;Category;HostName;Area (m2)");
            
            UIDocument uiDoc = new UIDocument(doc);

            FamilyHandler familyHandler = new FamilyHandler();

            Dictionary<ElementId, ElementId> dctInsertByHost = new Dictionary<ElementId, ElementId>();

            if (SurfaceNetArea._docHasInPlaceHosts)
            {
                LogCreator.LogEntry("Checking In-Place familys");
                dctInsertByHost = familyHandler.GetInPlaceHostOpenings(doc);
            }

            string strRoomsWithoutBottomOrTopBound = string.Empty;

            List<RawSurfaceData> lstRawDataStructure = new List<RawSurfaceData>();

            SpatialElementBoundaryOptions sebOptions = new SpatialElementBoundaryOptions();
            sebOptions.SpatialElementBoundaryLocation = SpatialElementBoundaryLocation.Finish;

            ICollection<ElementId> collRooms = new List<ElementId>();

            Selection selPickFirst = uiDoc.Selection;
            ICollection<ElementId> collPickFirstIds = selPickFirst.GetElementIds();
            ElementId targetCatId = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Rooms).Id;

            if (collPickFirstIds.Count > 0)
            {
                foreach (ElementId idRoom in collPickFirstIds)
                {
                    ElementId pfCat = doc.GetElement(idRoom).Category.Id;

                    if (targetCatId.Equals(pfCat))
                    {
                        collRooms.Add(idRoom);
                    }
                }
            }

            else
            {
                collRooms = GetRoomsByPhase(doc, phaseName);
            }

            if (collRooms.Count.Equals(0))
            {
                return null;
            }

            SurfaceNetArea.dctCeilingsInRoom = new Dictionary<ElementId, List<ElementId>>();
            List<string> compareWallAndRoom = new List<string>();
            SolidHandlers solidHandler = new SolidHandlers();
            OpeningHandler openingHandler = new OpeningHandler();

            foreach (ElementId elemId in collRooms)
            {

                List<ElementId> lstCeilingsInRoom = new List<ElementId>();

                Element e = doc.GetElement(elemId) as Element;
                Room room = e as Room;

                if (room == null)
                {
                    continue;
                }


                Parameter excludeRoom = room.LookupParameter("ExcludeRoomSurface") as Parameter;  //would have failed already if null
                {
                    if (excludeRoom.AsInteger().Equals(1))
                    {
                        continue;
                    }
                }

                if (room.Location == null)
                {
                    LogCreator.LogEntry("Skip unplaced room:" + room.Number);
                    continue;
                }

                if (room.Area == 0)
                {
                    LogCreator.LogEntry("Skip Not Enclosed room: " + room.Number);
                    continue;
                }

                Autodesk.Revit.DB.SpatialElementGeometryCalculator calc = new Autodesk.Revit.DB.SpatialElementGeometryCalculator(doc, sebOptions);

                LogCreator.LogEntry(";"+room.Name + "__________________________________________");

                SpatialElementGeometryResults results = calc.CalculateSpatialElementGeometry(room);

                SurfaceNetArea.statusBar.Set("Processing room: " + room.Name);

                Solid roomSolid = results.GetGeometry();

                bool roomHasBottomTopFace = false;

                List<ElementType> typesInRoom = new List<ElementType>();

                

                foreach (Face face in roomSolid.Faces)
                {

                    IList<SpatialElementBoundarySubface> subfaceList = results.GetBoundaryFaceInfo(face);

                    foreach (SpatialElementBoundarySubface spatialSubFace in subfaceList)
                    {

                        if (spatialSubFace.SpatialBoundaryElement.HostElementId == ElementId.InvalidElementId)
                        {
                            LogCreator.LogEntry("Linked Room-bounding elements not supported at this time.");
                            continue;
                        }
                        
                        RawSurfaceData rawRoomSurfData = new RawSurfaceData();
                        double subfaceArea = 0;
                        double openingArea = 0;
                        double netArea = 0;

                        Element elemRoomBound = doc.GetElement(spatialSubFace.SpatialBoundaryElement.HostElementId);

                        if (elemRoomBound == null)
                        {
                            continue;
                        }

                        bool isStackedMember = false;

                        ElementType hostType = doc.GetElement(elemRoomBound.GetTypeId()) as ElementType;

                        Parameter excludeElemType = hostType.LookupParameter("ExcludeRoomSurface") as Parameter;
                        if (excludeElemType != null)
                        {
                            if (excludeElemType.AsInteger().Equals(1))
                            {
                                continue;
                            }
                        }

                        if (hostType is WallType)
                        {
                            Wall wallBound = elemRoomBound as Wall;
                            isStackedMember = wallBound.IsStackedWallMember;

                            WallType wallType = hostType as WallType;

                            if (wallType.Kind == WallKind.Curtain)
                            {
                                LogCreator.LogEntry("WallType is CurtainWall");  //leave out - curtainwalls is not painted
                                continue;
                            }

                            if (wallType.Kind == WallKind.Unknown)
                            {
                                LogCreator.LogEntry("WallType is Unknown");
                                continue;
                            }

                        }

                        if (elemRoomBound is Ceiling)
                        {
                            lstCeilingsInRoom.Add(elemRoomBound.Id);
                        }

                        if (elemRoomBound is CurtainSystem)
                        {
                            continue;
                        }

                        Parameter demolished = elemRoomBound.get_Parameter(BuiltInParameter.PHASE_DEMOLISHED) as Parameter;

                        if (demolished != null)
                        {
                            if (!demolished.AsValueString().Equals("None"))
                            {
                                LogCreator.LogEntry("Disregard demolished host " + elemRoomBound.Id);
                                continue;
                            }
                        }

                        Face subFace = spatialSubFace.GetSubface();
                        ElementId idFaceBoundMaterial = spatialSubFace.GetBoundingElementFace().MaterialElementId;

                        if (idFaceBoundMaterial != ElementId.InvalidElementId)
                        {
                            Element elemMaterial = doc.GetElement(idFaceBoundMaterial) as Element;
                            Parameter excludeMaterial = elemMaterial.LookupParameter("ExcludeRoomSurface") as Parameter;
                            if (excludeMaterial != null)
                            {
                                if (excludeMaterial.AsInteger().Equals(1))
                                {
                                    continue;
                                }
                            }
                        }


                        subfaceArea = subFace.Area;
                        LogCreator.LogEntry(";GROSS_HOSTAREA;" + spatialSubFace.SpatialBoundaryElement.HostElementId.ToString() + ";" + elemRoomBound.Category.Name + ";" + hostType.Name + ";" + (subfaceArea * 0.09290304).ToString());
                        SubfaceType subFaceType = spatialSubFace.SubfaceType;
                    

                        if (subFaceType.Equals(SubfaceType.Top) || subFaceType.Equals(SubfaceType.Bottom))
                        {
                            roomHasBottomTopFace = true;
                        }

                        HostObject hostObject = elemRoomBound as HostObject;

                        IList<ElementId> insertsThisHost = new List<ElementId>();

                        if (hostObject != null)
                        {
                            insertsThisHost = hostObject.FindInserts(true,false, true, true);
                        }

                        else if (elemRoomBound is FamilyInstance)
                        {
                            LogCreator.LogEntry("InPlace host family");
                            insertsThisHost = GetKeysFromValue(dctInsertByHost, elemRoomBound.Id); //costly but what can you doo..
                        }

                        foreach (ElementId idInsert in insertsThisHost)
                        {

                            FamilyInstance fi = doc.GetElement(idInsert) as FamilyInstance;

                            if (fi != null)
                            {
                                Element hostForInsert = fi.Host;
                                if (hostForInsert != null)
                                {
                                    if (fi.Host.Id != elemRoomBound.Id)
                                    {
                                        continue;
                                    }
                                }
                            }

                            string countOnce = room.Id.ToString() + elemRoomBound.Id.ToString() + idInsert.ToString();
                            
                            if (!compareWallAndRoom.Contains(countOnce))
                            {
                                Element elemOpening = doc.GetElement(idInsert) as Element;

                                //List<int> test = new List<int> { 457064, 457146 };

                                //if (!test.Contains(idInsert.IntegerValue))
                                //{
                                //    string s1 = "";
                                //}

                                openingArea = openingArea + openingHandler.GetOpeningArea(solidHandler, elemRoomBound, elemOpening, room, roomSolid, isStackedMember);


                                compareWallAndRoom.Add(countOnce);
                            }
                          
                        }

                        double openingAreaCheck = Util.sqFootToSquareM(openingArea);

                        netArea = Util.sqFootToSquareM(subfaceArea - openingArea);

                       

                        rawRoomSurfData.idRoomElem = room.Id;
                        rawRoomSurfData.idElemType = hostType.Id;
                        rawRoomSurfData.idFaceMaterial = idFaceBoundMaterial;
                        rawRoomSurfData.dblFaceArea = netArea;
                        rawRoomSurfData.subFaceType = spatialSubFace.SubfaceType;
                        rawRoomSurfData.idElem = elemRoomBound.Id;
                        rawRoomSurfData.faceElem = subFace;

                        lstRawDataStructure.Add(rawRoomSurfData);

                    } // end foreach subface

                } //end foreach face

                lstCeilingsInRoom.Distinct();

                SurfaceNetArea.dctCeilingsInRoom.Add(room.Id, lstCeilingsInRoom);

                if (!roomHasBottomTopFace)
                {
                    strRoomsWithoutBottomOrTopBound += room.Name + System.Environment.NewLine;
                    SurfaceNetArea.hasMissingVerticalBounds = true;
                }

            } // end foreach room


            if (strRoomsWithoutBottomOrTopBound != string.Empty)
            {
                LogCreator.LogEntry("The following rooms dont have an associated top bounding element such as a Ceiling, try adjusting the height of the room.");
                LogCreator.LogEntry(System.Environment.NewLine + strRoomsWithoutBottomOrTopBound);
            }

            List<SortedSurfaceData> finalData = SortRoomSurfDataByMaterial(lstRawDataStructure);

            return finalData;

        }

        public ICollection<ElementId> GetRoomsByPhase(Document doc, string phaseName)
        {

            FilteredElementCollector roomColl = new FilteredElementCollector(doc);
            roomColl.OfClass(typeof(Autodesk.Revit.DB.SpatialElement));

            if (phaseName.Equals("<All Phases>"))
            {
                return roomColl.ToElementIds();
            }

            else
            {
                FilteredElementCollector phaseColl = new FilteredElementCollector(doc)
                .OfClass(typeof(Phase));
                IEnumerable<Phase> phases = from Phase f in phaseColl where f.Name == phaseName select f;
                ParameterValueProvider phaseProvider = new ParameterValueProvider(new ElementId(BuiltInParameter.ROOM_PHASE));
                FilterElementIdRule phaseRule = new FilterElementIdRule(phaseProvider, new FilterNumericEquals(), phases.FirstOrDefault<Phase>().Id);
                ElementParameterFilter phaseFilter = new ElementParameterFilter(phaseRule);

                return roomColl.WherePasses(phaseFilter).ToElementIds();
            }

        }

        //private static bool IsToOrFromThisRoom(Room room, FamilyInstance fi)
        //{
        //    bool isInRoom = false;
            
        //    if (fi != null)
        //    {
        //        if (fi.ToRoom != null)
        //        {
        //            isInRoom = fi.ToRoom.Id.Equals(room.Id);
        //        }

        //        if (!isInRoom)
        //        {
        //            if (fi.FromRoom != null)
        //            {
        //                isInRoom = fi.FromRoom.Id.Equals(room.Id);
        //            }
        //        }
        //    }
        //    return isInRoom;
        //}

        private IList<ElementId> GetKeysFromValue(Dictionary<ElementId, ElementId> dict, ElementId value)
        {
            return
                (from item in dict
                 where item.Value.Equals(value)
                 select item.Key).ToList();
        }

        public bool DocHasInPlaceHostFamilys(Document doc)
        {

            FilteredElementCollector hostElems = new FilteredElementCollector(doc);
            hostElems.OfClass(typeof(FamilyInstance));
            hostElems.WherePasses(FilterHostCategories());
            hostElems.WhereElementIsNotElementType();

            ICollection<ElementId> inPlaceHosts = hostElems.ToElementIds();
            if (inPlaceHosts.Count > 0)
            {
                return true;
            }

            return false;
        }

        private ElementMulticategoryFilter FilterHostCategories()
        {
            List<BuiltInCategory> builtInHostCats = new List<BuiltInCategory>();
            builtInHostCats.Add(BuiltInCategory.OST_Walls);
            builtInHostCats.Add(BuiltInCategory.OST_Floors);
            builtInHostCats.Add(BuiltInCategory.OST_Ceilings);
            builtInHostCats.Add(BuiltInCategory.OST_Roofs);
            return new ElementMulticategoryFilter(builtInHostCats);
        }
        

        public List<SortedSurfaceData> SortRoomSurfDataByMaterial(List<RawSurfaceData> lstRawData)
        {

            var sortedRoomData = from rawData in lstRawData
                                 group rawData by new { rawData.idRoomElem, rawData.subFaceType, rawData.idFaceMaterial } into sortedData
                                 select new SortedSurfaceData()
                                 {
                                     idRoomSorted = sortedData.Key.idRoomElem,
                                     subFaceType = sortedData.Key.subFaceType,
                                     idFaceMaterial = sortedData.Key.idFaceMaterial,
                                     dblMaterialArea = sortedData.Sum(x => x.dblFaceArea),
                                 };

            return sortedRoomData.ToList();
        }

        public List<RoomDataStructure> PrepForExcel(Document doc, List<SortedSurfaceData> lstSortedData)
        {
            List<RoomDataStructure> lstRoomData = new List<RoomDataStructure>();

            List<ElementId> distinctIds = new List<ElementId>();

            foreach (SortedSurfaceData ssd0 in lstSortedData)
            {

                if (distinctIds.Contains(ssd0.idRoomSorted))
                {
                    continue;
                }

                distinctIds.Add(ssd0.idRoomSorted);

                RoomDataStructure rds = new RoomDataStructure();
                rds.idRoomElement = ssd0.idRoomSorted;
                rds.lstBottom = new List<LABBottomFace>();
                rds.lstSide = new List<LABSideFace>();
                rds.lstTop = new List<LABTopFace>();

                foreach (SortedSurfaceData ssd1 in lstSortedData)
                {

                    LABBottomFace bottomFaces = new LABBottomFace();
                    LABSideFace sideFaces = new LABSideFace();
                    LABTopFace topFaces = new LABTopFace();

                    if (rds.idRoomElement == ssd1.idRoomSorted)
                    {

                        if (ssd1.subFaceType.Equals(SubfaceType.Bottom))
                        {
                            bottomFaces.materialArea = ssd1.dblMaterialArea;
                            bottomFaces.materialId = ssd1.idFaceMaterial;
                            bottomFaces.subFaceType = ssd1.subFaceType;

                            if (ssd1.idFaceMaterial != ElementId.InvalidElementId)
                            {
                                bottomFaces.materialName = doc.GetElement(ssd1.idFaceMaterial).Name;
                            }
                            else
                            {
                                bottomFaces.materialName = "<By Category>";
                            }

                            rds.lstBottom.Add(bottomFaces);
                        }

                        if (ssd1.subFaceType.Equals(SubfaceType.Side))
                        {
                            sideFaces.materialArea = ssd1.dblMaterialArea;
                            sideFaces.materialId = ssd1.idFaceMaterial;
                            sideFaces.subFaceType = ssd1.subFaceType;

                            if (ssd1.idFaceMaterial != ElementId.InvalidElementId)
                            {
                                sideFaces.materialName = doc.GetElement(ssd1.idFaceMaterial).Name;
                            }
                            else
                            {
                                sideFaces.materialName = "<By Category>";
                            }

                            rds.lstSide.Add(sideFaces);
                        }

                        if (ssd1.subFaceType.Equals(SubfaceType.Top))
                        {
                            topFaces.materialArea = ssd1.dblMaterialArea;
                            topFaces.materialId = ssd1.idFaceMaterial;
                            topFaces.subFaceType = ssd1.subFaceType;

                            if (ssd1.idFaceMaterial != ElementId.InvalidElementId)
                            {
                                topFaces.materialName = doc.GetElement(ssd1.idFaceMaterial).Name;
                            }
                            else
                            {
                                topFaces.materialName = "<By Category>";
                            }

                            rds.lstTop.Add(topFaces);
                        }

                    }

                }

                lstRoomData.Add(rds);
            }

            return lstRoomData;
        }

    }
}
