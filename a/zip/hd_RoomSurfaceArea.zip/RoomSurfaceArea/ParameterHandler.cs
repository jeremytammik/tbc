﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using WTAPI = CADQ.LABS.Common;

namespace CADQ.LABS.RoomSurfaceArea
{
    public class ParameterHandler
    {

            private CategorySet CatSetExclude(Document doc)
            {

                CategorySet catsParam = doc.Application.Create.NewCategorySet();
                catsParam.Insert(doc.Settings.Categories.get_Item(BuiltInCategory.OST_Rooms));
                catsParam.Insert(doc.Settings.Categories.get_Item(BuiltInCategory.OST_MEPSpaces));
                catsParam.Insert(doc.Settings.Categories.get_Item(BuiltInCategory.OST_Materials));
                return catsParam;

            }

            private CategorySet CatSetProject(Document doc)
            {
                CategorySet catsParam = doc.Application.Create.NewCategorySet();
                catsParam.Insert(doc.Settings.Categories.get_Item(BuiltInCategory.OST_ProjectInformation));
                return catsParam;
            }

            public void GetParameterSetup(Autodesk.Revit.ApplicationServices.Application app, Document doc)
            {
                string progData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData).ToString();
                string devlabs = progData + "\\RVTxLab 2016\\";
                string fileName = devlabs + "setup\\RvtLabsSharedParam.txt";
                BindingMap map = doc.ParameterBindings;
                
                CategorySet spatialSurfaces = CatSetExclude(doc);
                WTAPI.SharedUtils.AttachSharedParameter(doc, fileName, "ExcludeRoomSurface", spatialSurfaces, BuiltInParameterGroup.PG_DATA, true, map);

                CategorySet spatialProject = CatSetProject(doc);
                WTAPI.SharedUtils.AttachSharedParameter(doc, fileName, "SheetViewForRoomSurface", spatialProject, BuiltInParameterGroup.PG_DATA, true, map);
            }
        
    }
}
