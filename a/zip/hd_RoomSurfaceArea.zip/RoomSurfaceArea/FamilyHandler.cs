﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;

namespace CADQ.LABS.RoomSurfaceArea
{
    class FamilyHandler
    {

        public Dictionary<ElementId, ElementId> GetInPlaceHostOpenings(Document doc)
        {

            Dictionary<ElementId, ElementId> dctOpeningAndHost = new Dictionary<ElementId, ElementId>();
            
            IList<ElementId> lstIdDoorWin = new List<ElementId>();

            FilteredElementCollector openingElems = new FilteredElementCollector(doc);
            openingElems.WherePasses(FilterDoorWindows());
            openingElems.WhereElementIsNotElementType();
            lstIdDoorWin = openingElems.ToElementIds().ToList();

            foreach (ElementId idInsert in lstIdDoorWin)
            {
                FamilyInstance fi = doc.GetElement(idInsert) as FamilyInstance;
                Element elemHost = fi.Host as Element;
                if (elemHost is FamilyInstance)  //such as an inplace wall
                {
                    dctOpeningAndHost.Add(idInsert, elemHost.Id);
                }
            }

            return dctOpeningAndHost;
        }

       

        public ICollection<ElementId> InPlaceHostFamilys(Document doc)
        {
            FilteredElementCollector hostElems = new FilteredElementCollector(doc);
            hostElems.OfClass(typeof(FamilyInstance));
            hostElems.WherePasses(FilterDoorWindows());
            hostElems.WhereElementIsNotElementType();
            List<ElementId> lstHost = hostElems.ToElementIds().ToList();

            return hostElems.ToElementIds();
        }

        private ElementMulticategoryFilter FilterDoorWindows()
        {
            List<BuiltInCategory> builtInHostCats = new List<BuiltInCategory>();
            builtInHostCats.Add(BuiltInCategory.OST_Doors);
            builtInHostCats.Add(BuiltInCategory.OST_Windows);
            return new ElementMulticategoryFilter(builtInHostCats);
        }



    }
}
