﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Collections;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data;

using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;


namespace CADQ.LABS.RoomSurfaceArea
{
    

    public class RawSurfaceData
    {
        public ElementId idRoomElem;
        public ElementId idElem;
        public ElementId idFaceMaterial;
        public Face faceElem;
        public SubfaceType subFaceType;
        public ElementId idElemType;
        public double dblFaceArea;
    }

    public class SortedSurfaceData
    {
        public ElementId idRoomSorted;
        public ElementId idFaceMaterial;
        public SubfaceType subFaceType;
        public double dblMaterialArea;
    }

    public class LABBottomFace
    {
        public double materialArea;
        public SubfaceType subFaceType;
        public ElementId materialId;
        public string materialName;
    }

    public class LABSideFace
    {
        public double materialArea;
        public SubfaceType subFaceType;
        public ElementId materialId;
        public string materialName;
    }

    public class LABTopFace
    {
        public double materialArea;
        public SubfaceType subFaceType;
        public ElementId materialId;
        public string materialName;
    }

    public class RoomDataStructure
    {
        public ElementId idRoomElement;
        public CeilingExtendedData extendedCeilingData;
        public List<LABBottomFace> lstBottom;
        public List<LABSideFace> lstSide;
        public List<LABTopFace> lstTop;
    }

    public class CeilingExtendedData
    {
        public double dblCeilingToFloorBelow;
        public double dblCeilingToFloorAbove;
        public List<double> lstCeilingsToFloorBelow;
        public List<double> lstCeilingsToFloorAbove;
        public double dblUtilitySpaceWallArea;
        public double dblUtilityVolume;
    }

    //public class OpeningData
    //{
    //    ElementId idOpening;
    //    Face openingFace;
    //}


}
