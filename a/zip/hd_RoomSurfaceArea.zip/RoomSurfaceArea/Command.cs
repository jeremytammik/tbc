﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.IO;
using xlsApp = Microsoft.Office.Interop.Excel;

using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;

namespace CADQ.LABS.RoomSurfaceArea
{
    [Transaction(TransactionMode.Manual)]
    public class SurfaceNetArea : IExternalCommand
    {

        public static StreamWriter streamLog
        {
            get;
            set;
        }

        public static Dictionary<ElementId, List<ElementId>> dctCeilingsInRoom
        {
            get;
            set;
        }

        public static List<ElementId> lstHeaderBottomMap
        {
            get;
            set;
        }

        public static List<ElementId> lstHeaderSideMap
        {
            get;
            set;
        }

        public static List<ElementId> lstHeaderTopMap
        {
            get;
            set;
        }

        public static bool hasMissingVerticalBounds
        {
            get;
            set;
        }

        public static bool _docHasInPlaceHosts
        {
            get;
            set;
        }

        public static RevitStatusBar statusBar
        {
            get;
            set;
        }

        public static SpatialUIOptions spatialOptions
        {
            get;
            set;
        }
        
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            
            UIApplication rvtUIApp = commandData.Application;
            UIDocument rvtUIDoc = rvtUIApp.ActiveUIDocument;

            Document rvtDoc = rvtUIApp.ActiveUIDocument.Document;
            Autodesk.Revit.ApplicationServices.Application rvtApp = rvtUIApp.Application;


            try
            {
                streamLog = new StreamWriter(LogCreator.fullLogPath(rvtDoc.Title));
            }

            catch
            {
                TaskDialog.Show("Logfile", "Please close the logfile first.");
                return Result.Succeeded;
            }


            try
            {

                AreaVolumeSettings volSettings =  AreaVolumeSettings.GetAreaVolumeSettings(rvtDoc);
                bool hasVolume = volSettings.ComputeVolumes;

                if (!hasVolume)
                {
                    System.Windows.Forms.MessageBox.Show("You need to enable Room volume calculations before using this function", "Room Surface");
                    streamLog.Close();
                    return Result.Succeeded;
                }

                SpatialFaceHandler faceHandler = new SpatialFaceHandler();
                ParameterHandler parameterSetup = new ParameterHandler();

                TransactionStatus transactStatus = new TransactionStatus();


                using (TransactionGroup transGroup = new TransactionGroup(rvtDoc))
                {
                    using (Transaction trans = new Transaction(rvtDoc))
                    {
                        transGroup.Start("RoomSurfaceMaterials");

                        trans.Start("ParameterSetup");
                        parameterSetup.GetParameterSetup(rvtApp, rvtDoc);

                        trans.Commit();

                        transactStatus = trans.GetStatus();

                        //initialize objects
                        _docHasInPlaceHosts = faceHandler.DocHasInPlaceHostFamilys(rvtDoc);
                        dctCeilingsInRoom = new Dictionary<ElementId, List<ElementId>>();
                        lstHeaderBottomMap = new List<ElementId>();
                        lstHeaderSideMap = new List<ElementId>();
                        lstHeaderTopMap = new List<ElementId>();
                        hasMissingVerticalBounds = false;
                        spatialOptions = new SpatialUIOptions();

                        SpatialAreaUI areaUI = new SpatialAreaUI(rvtDoc);

                        System.Windows.Forms.DialogResult dialogRes = areaUI.ShowDialog();

                        LogCreator.LogEntry(LogCreator.fullLogPath(rvtDoc.Title));

                        if (System.Windows.Forms.DialogResult.OK == dialogRes)
                        {
                            LogCreator.LogEntry("Access Revit status bar");
                            statusBar = RevitStatusBar.Create();

                            View3D view3D = GetValid3DView(rvtDoc);
                    
                            if (view3D == null)
                            {
                                LogCreator.LogEntry("No valid 3d view found");
                                TaskDialog.Show("No 3D view", "Could not find a suitable 3D view for geometry analysis.\n"
                                    + "Make sure you have a non-sectioned 3D view with both Floors and Ceilings visible.");
                                streamLog.Close();
                                return Result.Succeeded;
                            }

                            LogCreator.LogEntry("Getting room data");
                            List<SortedSurfaceData> roomCalculations = faceHandler.GetSpatialSurfaceData(rvtDoc, spatialOptions._spatialPhase);

                            if (roomCalculations == null)
                            {
                                LogCreator.LogEntry("There are no rooms in selected phase(s)");
                                streamLog.Close();
                                return Result.Succeeded;
                            }

                            LogCreator.LogEntry("Prep for Excel");
                            List<RoomDataStructure> lstRoomData = faceHandler.PrepForExcel(rvtDoc, roomCalculations);

                            LogCreator.LogEntry("Getting extended ceiling data");
                            CeilingHandler ceilingHandler = new CeilingHandler();
                            lstRoomData = ceilingHandler.GetExtendedCeilingData(rvtDoc, lstRoomData, view3D);
                            

                            LogCreator.LogEntry("Export to Excel");
                            ExcelHandler excelHandler = new ExcelHandler();

                            trans.Start("ExcelSetup");
                            excelHandler.ExportRoomsToExcel(rvtDoc, lstRoomData);
                            transactStatus = trans.Commit();

                            streamLog.Close();
                            //return Result.Succeeded;
                        }

                        else if (System.Windows.Forms.DialogResult.Cancel == dialogRes)
                        {
                            streamLog.Close();
                            return Result.Cancelled;
                        }

                        streamLog.Close();

                        transGroup.Assimilate();

                    }

                    
                }


                return Result.Succeeded;
                
            }

            catch (Exception ex)
            {
                string error = ex.Message.ToString() + "\r\n" + ex.StackTrace.ToString();
                TaskDialog.Show("Room Boundaries", error);
                LogCreator.LogEntry(error);
                streamLog.Close();
               return Result.Failed;
            }

        }

        private View3D GetValid3DView(Document doc)
        {
            FilteredElementCollector elemColl = new FilteredElementCollector(doc);
            elemColl.OfClass(typeof(View3D)).ToElements();
            List<View3D> dViews = new List<View3D>();

            Category catCeiling = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Ceilings);
            Category catFloor = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Floors);
            Category catRoof = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Roofs);

            foreach (Element e in elemColl)
            {
                View3D view = e as View3D;

                if (null == view)
                {
                    continue;
                }

                if (view.IsTemplate)
                {
                    continue;
                }

                if (view.AreModelCategoriesHidden)
                {
                    continue;
                }

                if (view.IsSectionBoxActive)
                {
                    continue;
                }

                if (view.ViewType.Equals(ViewType.ThreeD))
                {
                    dViews.Add(view);
                }

            }

            foreach (View view3D in dViews)
            {
                View3D v3D = view3D as View3D;

                if (v3D == null)
                {
                    continue;
                }

                if (v3D.GetVisibility(catCeiling) && v3D.GetVisibility(catFloor))
                {
                    return v3D;
                }
            }

            return null;
        }

    }

    [Transaction(TransactionMode.Manual)]
    public class OpenLastLogFile : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            UIApplication app = commandData.Application;
            Document rvtDoc = app.ActiveUIDocument.Document;

            string logpath = LogCreator.fullLogPath(rvtDoc);


            if (!File.Exists(logpath))
            {
                TaskDialog.Show("No logfile", "No logfile exist");
                return Result.Succeeded;
            }


            Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
            excelApp.Visible = true;
            excelApp.Workbooks.OpenText(logpath, Type.Missing, 1,
            xlsApp.XlTextParsingType.xlDelimited,
            xlsApp.XlTextQualifier.xlTextQualifierNone,
            Type.Missing, Type.Missing, true, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

            return Result.Succeeded;
        }
    }

    [Transaction(TransactionMode.Manual)]
    public class ModifyTemplate : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            UIApplication app = commandData.Application;
            Document rvtDoc = app.ActiveUIDocument.Document;

            string progData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData).ToString();
            string devlabs = progData + "\\RVTxLab 2016\\";
            string templatePath = devlabs + "setup\\RoomSurface.xltx";

            if (!File.Exists(templatePath))
            {
                TaskDialog.Show("No logfile", "No template file exist");
                return Result.Succeeded;
            }

            Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
            excelApp.Visible = true;
            excelApp.Workbooks.Open(templatePath,Editable: true);

            return Result.Succeeded;
        }
    }



}
