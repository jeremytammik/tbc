﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using xlsApp = Microsoft.Office.Interop.Excel;
using xlsColor = Microsoft.Office.Interop.Excel.ColorFormat;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB.Architecture;

namespace CADQ.LABS.RoomSurfaceArea
{
    class ExcelHandler
    {

        public void ExportRoomsToExcel(Document doc, List<RoomDataStructure> lstRoomData)
        {

            BuildHeaderMaps(lstRoomData);

            string progData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData).ToString();
            string devlabs = progData + "\\RVTxLab 2016\\";
            object excelDefaultTemplate = devlabs + "setup\\RoomSurface.xltx";

            //string projectTemplate = doc.Title;

            if (!File.Exists(excelDefaultTemplate.ToString()))
            {
                excelDefaultTemplate = Type.Missing;
            }

            xlsApp.Application excelApp = new xlsApp.Application();
            xlsApp.Workbook workbook = excelApp.Workbooks.Add(excelDefaultTemplate);
            xlsApp.Worksheet workSheet = workbook.Sheets[1];
            workSheet.Name = "Surface Materials";
            excelApp.Visible = true;

            xlsApp.Range rangeRoomNumbers = workSheet.get_Range("A7", "A1000");
            rangeRoomNumbers.NumberFormat = "@";

            xlsApp.Range rangeAllHeader = workSheet.get_Range("A1", "AZ5");
            ParameterSet projectParameters = doc.ProjectInformation.Parameters;
            SetAllHeaderInfo(rangeAllHeader, projectParameters);

            ViewSheet viewSheet = doc.GetElement(SurfaceNetArea.spatialOptions._idAssociatedSheet) as ViewSheet;

            if (viewSheet != null)
            {
                ParameterSet sheetParameters = viewSheet.Parameters;
                SetAllHeaderInfo(rangeAllHeader, sheetParameters);
                Parameter sheetForData = doc.ProjectInformation.LookupParameter("SheetViewForRoomSurface") as Parameter;
                sheetForData.Set(viewSheet.SheetNumber + " " + viewSheet.Name);
            }

            int i = 7;
            int headerPos = 1;

            workSheet.Cells[i - 1, headerPos] = "Room";

            workSheet.Cells[i, headerPos] = "Number";
            headerPos++;
            workSheet.Cells[i, headerPos] = "Name";
            headerPos++;
            //workSheet.Cells[i, headerPos] = "DesignOption";
            //headerPos++;
            workSheet.Cells[i, headerPos] = "Perimeter (mm)";
            headerPos++;
            workSheet.Cells[i, headerPos] = "Area (m2)";
            headerPos++;
            //workSheet.Cells[i, headerPos] = "Volume (m3)";
            //headerPos++;
            //workSheet.Cells[i, headerPos] = "Average Ceiling Height (Volume/Area)";
            //headerPos++;
            workSheet.Cells[i, headerPos] = "Base Finish";
            headerPos++;
            workSheet.Cells[i, headerPos] = "Floor Finish";
            headerPos++;
            workSheet.Cells[i, headerPos] = "Wall Finish";
            headerPos++;
            workSheet.Cells[i, headerPos] = "Ceiling Finish";
            headerPos++;
            workSheet.Cells[i, headerPos] = "Floor To Ceiling (mm)";
            headerPos++;
            workSheet.Cells[i, headerPos] = "Ceiling To Floor (mm)";
            headerPos++;
            workSheet.Cells[i, headerPos] = "UtilityWallArea (m2)";
            headerPos++;
            //workSheet.Cells[i, headerPos] = "Estimated UtilityVolume (m3)";
            //headerPos++;


            int typeStartIn = headerPos;
            int startInReset = headerPos;


            List<ElementId> catIds = new List<ElementId>();
            workSheet.Cells[i - 1, headerPos] = "Bottom Surface";

            foreach (ElementId idMaterial in SurfaceNetArea.lstHeaderBottomMap)
            {
                Element elemMaterial = doc.GetElement(idMaterial) as Element;
                if (elemMaterial != null)
                {
                    workSheet.Cells[i, headerPos] = elemMaterial.Name;
                }

                else
                {
                    workSheet.Cells[i, headerPos] = "<By Category>";
                }

                headerPos++;
            }

            workSheet.Cells[i - 1, headerPos] = "Side Surface";
            foreach (ElementId idMaterial in SurfaceNetArea.lstHeaderSideMap)
            {
                Element elemMaterial = doc.GetElement(idMaterial) as Element;
                if (elemMaterial != null)
                {
                    workSheet.Cells[i, headerPos] = elemMaterial.Name;
                }

                else
                {
                    workSheet.Cells[i, headerPos] = "<By Category>";
                }

                headerPos++;
            }

            workSheet.Cells[i - 1, headerPos] = "Top Surface";
            foreach (ElementId idMaterial in SurfaceNetArea.lstHeaderTopMap)
            {
                Element elemMaterial = doc.GetElement(idMaterial) as Element;
                if (elemMaterial != null)
                {
                    workSheet.Cells[i, headerPos] = elemMaterial.Name;
                }

                else
                {
                    workSheet.Cells[i, headerPos] = "<By Category>";
                }

                headerPos++;
            }


            i++;

            foreach (RoomDataStructure roomData in lstRoomData)
            {

                typeStartIn = startInReset;

                int j = 1;

                Room room = doc.GetElement(roomData.idRoomElement) as Room;

                workSheet.Cells[i, j] = room.Number;
                j++;

                if (!room.Name.Equals(room.Number)) //empty
                {
                    workSheet.Cells[i, j] = room.Name.Remove(room.Name.Count() - room.Number.Count() - 1);
                }
                
                j++;

                //DesignOption designOption = room.DesignOption;
                //string designOptionName = string.Empty;

                //if (designOption != null)
                //{
                //    designOptionName = designOption.Name;
                //}

                //workSheet.Cells[i, j] = designOptionName;
                //j++;

                workSheet.Cells[i, j] = Math.Round(room.Perimeter * 304.8, 0);
                j++;

                double roomArea = Math.Round(room.Area * 0.092903, 2);
                workSheet.Cells[i, j] = roomArea;
                j++;

                //double roomVolume = Math.Round(room.Volume * 0.0283168466, 2);
                //workSheet.Cells[i, j] = roomVolume;
                //j++;

                //double roomAverageHeight = Math.Round(roomVolume / roomArea, 3);
                //workSheet.Cells[i, j] = roomAverageHeight;
                //xlsApp.Range r1 = workSheet.Cells[i, j];
                //j++;

                Parameter baseFinish = room.get_Parameter(BuiltInParameter.ROOM_FINISH_BASE) as Parameter;
                workSheet.Cells[i, j] = baseFinish.AsString();
                j++;

                Parameter floorFinish = room.get_Parameter(BuiltInParameter.ROOM_FINISH_FLOOR) as Parameter;
                workSheet.Cells[i, j] = floorFinish.AsString();
                j++;

                Parameter wallFinish = room.get_Parameter(BuiltInParameter.ROOM_FINISH_WALL) as Parameter;
                workSheet.Cells[i, j] = wallFinish.AsString();
                j++;

                Parameter ceilingFinish = room.get_Parameter(BuiltInParameter.ROOM_FINISH_CEILING) as Parameter;
                workSheet.Cells[i, j] = ceilingFinish.AsString();
                j++;

                double lengthCheck; //no need to actually write 0 to excel

                if (roomData.extendedCeilingData != null)
                {

                    if (roomData.extendedCeilingData.lstCeilingsToFloorBelow.Count.Equals(1))
                    {
                        lengthCheck = roomData.extendedCeilingData.lstCeilingsToFloorBelow.First();

                        if (!Util.IsZero(lengthCheck))
                        {
                            workSheet.Cells[i, j] = roomData.extendedCeilingData.lstCeilingsToFloorBelow.First();
                        }
                    }

                    else if (roomData.extendedCeilingData.lstCeilingsToFloorBelow.Count() > 1)
                    {
                        string s = "";

                        foreach (double distDown in roomData.extendedCeilingData.lstCeilingsToFloorBelow)
                        {
                            if (!Util.IsZero(distDown))
                            {
                                s += (distDown).ToString() + " / ";
                            }

                        }

                        workSheet.Cells[i, j] = s.Remove(s.Count() - 3);
                    }

                }

                j++;

                if (roomData.extendedCeilingData.lstCeilingsToFloorAbove.Count.Equals(1))
                {
                    lengthCheck = roomData.extendedCeilingData.lstCeilingsToFloorAbove.First();

                    if (!Util.IsZero(lengthCheck))
                    {
                        workSheet.Cells[i, j] = roomData.extendedCeilingData.lstCeilingsToFloorAbove.First();
                    }
                }

                else if (roomData.extendedCeilingData.lstCeilingsToFloorAbove.Count() > 1)
                {
                    string s = "";

                    foreach (double distUp in roomData.extendedCeilingData.lstCeilingsToFloorAbove)
                    {
                        if (!Util.IsZero(distUp))
                        {
                            s += (distUp).ToString() + " / ";
                        }
                    }

                    workSheet.Cells[i, j] = s.Remove(s.Count() - 3);
                }

                j++;

                if (!roomData.extendedCeilingData.dblUtilitySpaceWallArea.Equals(0))
                {
                    double wallAreaAboveCeiling = Math.Round(roomData.extendedCeilingData.dblUtilitySpaceWallArea / 10.764, 1);
                    workSheet.Cells[i, j] = wallAreaAboveCeiling;
                }

                j++;

                //if (!roomData.extendedCeilingData.dblUtilityVolume.Equals(0))
                //{
                //    double volumeAboveCeiling = Math.Round(roomData.extendedCeilingData.dblUtilityVolume / 35.315, 1);
                //    workSheet.Cells[i, j] = volumeAboveCeiling;
                //}

                j = 1;


                Material faceMaterial = null;
                Parameter parmaterial = null;

                foreach (LABBottomFace floor in roomData.lstBottom)
                {

                    j = GetHeaderIndex(floor.subFaceType, floor.materialId);

                    faceMaterial = doc.GetElement(floor.materialId) as Material;
                    if (faceMaterial != null)
                    {
                        parmaterial = room.LookupParameter("Bottom_" + faceMaterial.Name) as Parameter;
                        if (parmaterial != null)
                        {
                            parmaterial.Set(floor.materialArea * 10.764);
                        }

                    }
                  
                    workSheet.Cells[i, j + typeStartIn] = floor.materialArea;
                }

                foreach (LABSideFace wall in roomData.lstSide)
                {
                    j = GetHeaderIndex(wall.subFaceType, wall.materialId);

                    faceMaterial = doc.GetElement(wall.materialId) as Material;
                    if (faceMaterial != null)
                    {
                        parmaterial = room.LookupParameter("Side_" + faceMaterial.Name) as Parameter;
                        if (parmaterial != null)
                        {
                            parmaterial.Set(wall.materialArea * 10.764);
                        }
                    }

                    workSheet.Cells[i, j + typeStartIn] = wall.materialArea;
                }

                foreach (LABTopFace ceiling in roomData.lstTop)
                {
                    j = GetHeaderIndex(ceiling.subFaceType, ceiling.materialId);

                    faceMaterial = doc.GetElement(ceiling.materialId) as Material;
                    if (faceMaterial != null)
                    {
                        parmaterial = room.LookupParameter("Top_" + faceMaterial.Name) as Parameter;
                        if (parmaterial != null)
                        {
                            parmaterial.Set(ceiling.materialArea * 10.764);
                        }
                    }

                    workSheet.Cells[i, j + typeStartIn] = ceiling.materialArea;
                }


                i++;

            }


            xlsApp.Range rangeDataHeader = workSheet.get_Range("A6", "DA7");
            rangeDataHeader.Font.Bold = true;
            
            xlsApp.Range rangeMaterialHeader = workSheet.get_Range("C7", "CA7");
            rangeMaterialHeader.Orientation = 90;
            rangeMaterialHeader.EntireColumn.AutoFit();

            xlsApp.Range rangeData = workSheet.get_Range("A8", "BA3000");
            rangeData.Columns.Sort(rangeData.Columns[1], xlsApp.XlSortOrder.xlAscending);
            

            if (SurfaceNetArea.hasMissingVerticalBounds)
            {
                TaskDialog.Show("Vertical Room boundaries", "Some rooms dont have an associated bottom and/or top bounding element such as a floor, ceiling or roof.\n" +
                "(They are listed at the end of the logfile.)");
            }

        }

        private static void SetAllHeaderInfo(xlsApp.Range rangeAllHeader, ParameterSet sheetParameters)
        {
            foreach (xlsApp.Range c in rangeAllHeader)
            {

                foreach (Parameter param in sheetParameters)
                {

                    string paramValue = string.Empty;
                    string paramName = "#" + param.Definition.Name;

                    switch (param.StorageType)
                    {
                        case StorageType.Double:
                            paramValue = param.AsValueString();
                            break;

                        case StorageType.Integer:
                            paramValue = param.AsValueString();
                            break;
                        case StorageType.String:

                            paramValue = param.AsString();
                            break;
                        default:
                            break;
                    }

                    if (paramName.Equals(c.Value2))
                    {
                        c.Value2 = paramValue;
                    }
                }

            }
        }

        private int GetHeaderIndex(SubfaceType subFaceType, ElementId materialId)
        {

            if (subFaceType.Equals(SubfaceType.Bottom))
            {
                return SurfaceNetArea.lstHeaderBottomMap.IndexOf(materialId);
            }

            if (subFaceType.Equals(SubfaceType.Side))
            {
                return SurfaceNetArea.lstHeaderBottomMap.Count() + SurfaceNetArea.lstHeaderSideMap.IndexOf(materialId);
            }

            if (subFaceType.Equals(SubfaceType.Top))
            {
                return SurfaceNetArea.lstHeaderBottomMap.Count() + SurfaceNetArea.lstHeaderSideMap.Count() + SurfaceNetArea.lstHeaderTopMap.IndexOf(materialId);
            }

            return 0;
        }

        public void DistributeHeaderId(SubfaceType subFaceType, ElementId materialId)
        {
            if (subFaceType.Equals(SubfaceType.Bottom))
            {
                SurfaceNetArea.lstHeaderBottomMap.Add(materialId);
            }

            if (subFaceType.Equals(SubfaceType.Side))
            {
                SurfaceNetArea.lstHeaderSideMap.Add(materialId);
            }

            if (subFaceType.Equals(SubfaceType.Top))
            {
                SurfaceNetArea.lstHeaderTopMap.Add(materialId);
            }
        }

        public void BuildHeaderMaps(List<RoomDataStructure> lstData)
        {
            foreach (RoomDataStructure rds in lstData)
            {
                foreach (LABBottomFace bottomFace in rds.lstBottom)
                {
                    DistributeHeaderId(bottomFace.subFaceType, bottomFace.materialId);
                }
                
                foreach (LABSideFace sideFace in rds.lstSide)
                {
                    DistributeHeaderId(sideFace.subFaceType, sideFace.materialId);
                }
                
                foreach (LABTopFace topFace in rds.lstTop)
                {
                    DistributeHeaderId(topFace.subFaceType, topFace.materialId);
                }
                
            }

            SurfaceNetArea.lstHeaderBottomMap = SurfaceNetArea.lstHeaderBottomMap.Distinct().ToList();
            SurfaceNetArea.lstHeaderSideMap = SurfaceNetArea.lstHeaderSideMap.Distinct().ToList();
            SurfaceNetArea.lstHeaderTopMap = SurfaceNetArea.lstHeaderTopMap.Distinct().ToList();

        }


    }
}
