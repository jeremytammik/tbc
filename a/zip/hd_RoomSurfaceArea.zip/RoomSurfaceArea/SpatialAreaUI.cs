﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB;

namespace CADQ.LABS.RoomSurfaceArea
{
    public partial class SpatialAreaUI : System.Windows.Forms.Form
    {


        public string spatialPhase
        {
            get;
            set;
        }

        private List<string> sheetNames
        {
            get;
            set;
        }

        private Dictionary<ElementId, string> dcSheetIdAndName
        {
            get;
            set;
        }

        public SpatialAreaUI(Document doc)
        {
            InitializeComponent();

            comboPhases.Items.Clear();
            spatialPhase = string.Empty;

            comboPhases.Items.Add("<All Phases>");

            List<string> phases =  GetPhaseNames(doc);

            foreach (string s1 in phases)
            {
                comboPhases.Items.Add(s1);
            }

            comboPhases.SelectedIndex = 0;

            //

            comboAssociatedSheet.Items.Clear();

            //sheetNames = GetSheetList(doc);
            dcSheetIdAndName = GetSheetDic(doc);

            sheetNames = dcSheetIdAndName.Values.ToList();
            sheetNames.Sort();

            comboAssociatedSheet.Items.AddRange(sheetNames.ToArray());

            Parameter sheetForRoomSurface = doc.ProjectInformation.LookupParameter("SheetViewForRoomSurface") as Parameter;
            string strSheet = string.Empty;

            if (sheetForRoomSurface != null)
            {
                strSheet = sheetForRoomSurface.AsString();
            }

            foreach (KeyValuePair<ElementId, string> pair in dcSheetIdAndName)
            {
                if (pair.Value == strSheet)
                {
                    SurfaceNetArea.spatialOptions._idAssociatedSheet = pair.Key;
                }
            }

            ViewSheet sheetView = doc.GetElement(SurfaceNetArea.spatialOptions._idAssociatedSheet) as ViewSheet;
           
            if (sheetView != null)
            {
                string itemName = sheetView.SheetNumber + " " + sheetView.Name;
                int index = comboAssociatedSheet.Items.IndexOf(itemName);
                comboAssociatedSheet.SelectedIndex = index;
            }
            
        }

        private List<string> GetPhaseNames(Document doc)
        {

            List<string> phaseNames = new List<string>();

            FilteredElementCollector phaseColl = new FilteredElementCollector(doc)
            .OfClass(typeof(Phase));

            List<ElementId> idPhases = phaseColl.ToElementIds().ToList();

            foreach (ElementId phaseId in idPhases)
            {
                Element elemPhase = doc.GetElement(phaseId) as Element;
                phaseNames.Add(elemPhase.Name);
            }

            return phaseNames;

        }

        private Dictionary<ElementId,string> GetSheetDic(Document doc)
        {

            FilteredElementCollector elemColl = new FilteredElementCollector(doc);
            elemColl.OfClass(typeof(ViewSheet));
            ICollection<ElementId> lstIdViews = elemColl.ToElementIds();

            Dictionary<ElementId, string> dcSheets = new Dictionary<ElementId, string>();

            foreach (ElementId idVs in lstIdViews)
            {
                ViewSheet vs = doc.GetElement(idVs) as ViewSheet;

                dcSheets.Add(idVs, vs.SheetNumber + " " + vs.Name);

            }

            return dcSheets;

        }




        private void comboPhases_SelectedIndexChanged(object sender, EventArgs e)
        {

            SurfaceNetArea.spatialOptions._spatialPhase = comboPhases.Text;

        }

        private void cmbAssociatedSheet_SelectedIndexChanged(object sender, EventArgs e)
        {

            foreach (KeyValuePair<ElementId, string> pair in dcSheetIdAndName)
            {
                if (pair.Value == comboAssociatedSheet.Text)
                {
                    SurfaceNetArea.spatialOptions._idAssociatedSheet = pair.Key;
                }
            }
            
        }



    }
}
