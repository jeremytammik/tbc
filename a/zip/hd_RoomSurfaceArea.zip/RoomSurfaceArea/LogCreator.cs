﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using Autodesk.Revit.DB;

namespace CADQ.LABS.RoomSurfaceArea
{

    public static class LogCreator
    {

        public static string fullLogPath(string title)
        {
            string sourceFileName = Path.GetFileNameWithoutExtension(title);
            string logfileName = "RoomSurfaceArea_" + sourceFileName + ".log";
            string tmpFiles = System.IO.Path.GetTempPath();
            return tmpFiles + logfileName;
        }

        public static string fullLogPath(Document doc)
        {
            string sourceFileName = Path.GetFileNameWithoutExtension(doc.Title);
            string logfileName = "RoomSurfaceArea_" + sourceFileName + ".log";
            string tmpFiles = System.IO.Path.GetTempPath();
            return tmpFiles + logfileName;
        }


        public static void LogEntry(string logEntry)
        {
            string timeStamp = DateTime.Now.ToString("ddMM_HHmmss.ffff");
            SurfaceNetArea.streamLog.WriteLine(timeStamp + " :< " + logEntry);
        }

    }

}
