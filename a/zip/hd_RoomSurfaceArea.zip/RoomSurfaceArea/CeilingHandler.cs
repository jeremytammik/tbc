﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB.Architecture;

namespace CADQ.LABS.RoomSurfaceArea
{
    class CeilingHandler
    {

        public List<RoomDataStructure> GetExtendedCeilingData(Document doc, List<RoomDataStructure> lstRoomData, View3D view3D)
        {

            if (view3D == null)
            {
                LogCreator.LogEntry("Can't get extended ceiling data because there's no valid 3Dview to analyze data in");
                return lstRoomData;
            }

            List<RoomDataStructure> lstRoomExtendedData = new List<RoomDataStructure>();
            List<ElementId> idDistinctCeilings = new List<ElementId>();

            foreach (RoomDataStructure rds in lstRoomData)
            {
                Room room = doc.GetElement(rds.idRoomElement) as Room;

                SurfaceNetArea.statusBar.Set("Processing extended ceilingdata for: " + room.Name);
                List<ElementId> ceilingsInRoom = new List<ElementId>();
                SurfaceNetArea.dctCeilingsInRoom.TryGetValue(room.Id, out ceilingsInRoom);

                List<CeilingExtendedData> lstCeilingsInRoomExtended = new List<CeilingExtendedData>();
                List<Solid> lstTempSolids = new List<Solid>();

                foreach (ElementId idCeiling in ceilingsInRoom)
                {

                    if (idDistinctCeilings.Contains(idCeiling))
                    {
                        continue;
                    }

                    Element elemCeiling = doc.GetElement(idCeiling) as Element;
                    Ceiling ceil = elemCeiling as Ceiling;

                    if (ceil == null)
                    {
                        continue;
                    }

                    CeilingExtendedData extendDataThisCeiling = new CeilingExtendedData();
                    extendDataThisCeiling.dblCeilingToFloorAbove = 0;

                    LogCreator.LogEntry("Get Ceiling proximity values");
                    double rawDistDown = GetCeilingProximity(doc, view3D, ceil, false);
                    double distDown = Math.Round(rawDistDown * 304.8, 0);
                    extendDataThisCeiling.dblCeilingToFloorBelow = distDown;

                    double rawDistUp = GetCeilingProximity(doc, view3D, ceil, true);
                    double distUp = Math.Round(rawDistUp * 304.8, 0);
                    extendDataThisCeiling.dblCeilingToFloorAbove = distUp;

                    if (extendDataThisCeiling.dblCeilingToFloorAbove != 0)
                    {
                        Solid solUtilitySpace = GetUtilitySolid(ceil, rawDistUp);

                        extendDataThisCeiling.dblUtilityVolume = solUtilitySpace.Volume;
                        lstTempSolids.Add(solUtilitySpace);
                    }

                    else
                    {
                        extendDataThisCeiling.dblUtilityVolume = 0;
                        extendDataThisCeiling.dblUtilitySpaceWallArea = 0;
                    }

                    lstCeilingsInRoomExtended.Add(extendDataThisCeiling);
                    idDistinctCeilings.Add(idCeiling);

                }

                double dblVerticalArea = 0;

                if (!lstTempSolids.Count().Equals(0))
                {
                    dblVerticalArea = GetSolidVerticalArea(doc, lstTempSolids);
                }

                CeilingExtendedData ceilExtendDataCombined = new CeilingExtendedData();

                List<double> utilityVolumes = new List<double>();
                //List<double> utilityAreas = new List<double>();
                List<double> ceilingsToFloorDown = new List<double>();
                List<double> ceilingsToFloorUp = new List<double>();

                foreach (CeilingExtendedData ced in lstCeilingsInRoomExtended)
                {
                    utilityVolumes.Add(ced.dblUtilityVolume);
                    //utilityAreas.Add(ced.dblUtilitySpaceWallArea);
                    ceilingsToFloorDown.Add(ced.dblCeilingToFloorBelow);
                    ceilingsToFloorUp.Add(ced.dblCeilingToFloorAbove);
                }

                ceilExtendDataCombined.dblUtilityVolume = utilityVolumes.Sum();
                ceilExtendDataCombined.dblUtilitySpaceWallArea = dblVerticalArea;
                ceilExtendDataCombined.lstCeilingsToFloorBelow = ceilingsToFloorDown.Distinct().ToList();
                ceilExtendDataCombined.lstCeilingsToFloorAbove = ceilingsToFloorUp.Distinct().ToList();

                rds.extendedCeilingData = ceilExtendDataCombined;
                lstRoomExtendedData.Add(rds);
            }

            return lstRoomExtendedData;
        }

        private double GetSolidVerticalArea(Document doc, List<Solid> tempSolids)
        {
            Solid mergedSolid = Util.UniteSolids(tempSolids);

            if (DebugHandler.EnableSolidUtilityVolumes)
            {
                ShapeCreators.CreateDirectShape(doc, mergedSolid, "UtilitySpace");
            }
           
            FaceArray faceArray = mergedSolid.Faces;

            double dblVerticalArea = 0;

            foreach (Face face in faceArray)
            {
                PlanarFace planarFace = face as PlanarFace;

                if (planarFace == null)
                {
                    continue;
                }

                if (Util.IsVertical(planarFace))
                {
                    dblVerticalArea = dblVerticalArea + planarFace.Area;
                }
            }

            return dblVerticalArea;
        }

        private Solid GetUtilitySolid(Ceiling ceiling, double dblUtilityHeight)
        {

            HostObject hostObject = ceiling as HostObject;

            Face targetFace = null;
            IList<Reference> hostTargetFaces = new List<Reference>();
            XYZ vector = new XYZ(0, 0, 1);

            hostTargetFaces = HostObjectUtils.GetTopFaces(hostObject);
            targetFace = hostObject.GetGeometryObjectFromReference(hostTargetFaces.First()) as Face;

            IList<CurveLoop> lstCurveLoops = targetFace.GetEdgesAsCurveLoops();

            CurveLoop targetLoop = null;
            double dblLongestLoopSoFar = 0;

            foreach (CurveLoop curveLoop in lstCurveLoops)
            {
                double dblLenghtThisLoop = curveLoop.GetExactLength();

                if (dblLenghtThisLoop >= dblLongestLoopSoFar)
                {
                    targetLoop = curveLoop;
                }

                dblLongestLoopSoFar = dblLenghtThisLoop;
            }

            IList<CurveLoop> lstOneLoop = new List<CurveLoop>();
            lstOneLoop.Add(targetLoop);

            Solid tempSolid = GeometryCreationUtilities.CreateExtrusionGeometry(lstOneLoop, vector, dblUtilityHeight);

            return tempSolid;

        }

        private double GetCeilingProximity(Document doc,View3D contextView, Ceiling elemCeiling,bool useVectorUp)
        {

            HostObject hostObject = elemCeiling as HostObject;
            XYZ xyzCenterFace = null;

            Face targetFace = null;
            IList<Reference> hostTargetFaces = new List<Reference>();
            XYZ vector = null;

            if(useVectorUp)
            {
                vector = new XYZ(0, 0, 1);
                hostTargetFaces = HostObjectUtils.GetTopFaces(hostObject);
                targetFace = hostObject.GetGeometryObjectFromReference(hostTargetFaces.First()) as Face;
            }

            else
            {
                vector = new XYZ(0, 0, -1);
                hostTargetFaces = HostObjectUtils.GetBottomFaces(hostObject);
                targetFace = hostObject.GetGeometryObjectFromReference(hostTargetFaces.First()) as Face;
            }


            if (targetFace != null && targetFace is PlanarFace)
            {
                BoundingBoxUV bbox = targetFace.GetBoundingBox();
                UV uvCenter = new UV((bbox.Max.U - bbox.Min.U) / 2 + bbox.Min.U, (bbox.Max.V - bbox.Min.V) / 2 + bbox.Min.V);
                Transform trans = targetFace.ComputeDerivatives(uvCenter);
                xyzCenterFace = trans.Origin;
                return GetProximityLength(doc, elemCeiling, contextView, xyzCenterFace, vector);
            }

            else
            {
                BoundingBoxXYZ bbox_xyz = elemCeiling.get_BoundingBox(null) as BoundingBoxXYZ;
                
                XYZ xyzCenter = Midpoint(bbox_xyz.Min, bbox_xyz.Max);
                XYZ xyzCenterBoxBottom = null;

                if (useVectorUp)
                {
                    xyzCenterBoxBottom = new XYZ(xyzCenter.X, xyzCenter.Y, bbox_xyz.Max.Z);
                }

                else
                {
                    xyzCenterBoxBottom = new XYZ(xyzCenter.X, xyzCenter.Y, bbox_xyz.Min.Z);
                }

                return GetProximityLength(doc, elemCeiling, contextView, xyzCenterBoxBottom, vector);
            }

        }

        private double GetProximityLength(Document hostDoc, Element ceiling, View3D view3Dlink, XYZ xyzFromPoint, XYZ vector)
        {

            double proximity = 0;

            ElementClassFilter floorFilter = new ElementClassFilter(typeof(Floor));

            ReferenceIntersector refIntersect = new ReferenceIntersector(floorFilter, FindReferenceTarget.Face, view3Dlink);
            ReferenceWithContext rwc = refIntersect.FindNearest(xyzFromPoint, vector);

            if (rwc == null)
            {
                return 0;
            }

            proximity = rwc.Proximity;

            return proximity;
        }

        static XYZ Midpoint(XYZ p, XYZ q)
        {
            return p + 0.5 * (q - p);
        }

        const double _offset = 0.1;

        public DirectShape CreateDirectShape(Document doc, Solid transientSolid,string dsName)
        {
            List<Material> lstMaterials = new FilteredElementCollector(doc)
           .OfClass(typeof(Material))
           .Cast<Material>()
           .ToList<Material>();

            ElementId idMaterial = lstMaterials.First().Id;
            
            
            FilteredElementCollector collector = new FilteredElementCollector(doc)
            .OfClass(typeof(GraphicsStyle));

            GraphicsStyle style = collector
                .Cast<GraphicsStyle>()
                .FirstOrDefault<GraphicsStyle>(gs => gs.Name.Equals("Walls"));

            ElementId graphicsStyleId = null;

            if (style != null)
            {
                graphicsStyleId = style.Id;
            }

            else
            {
                LogCreator.LogEntry("Cant create DirectShape because the Graphic Style was not found.");
                return null;
            }

            try
            {

                TessellatedShapeBuilder buildAShape = new TessellatedShapeBuilder();

                buildAShape.OpenConnectedFaceSet(true);

                FaceArray faceArray = transientSolid.Faces;

                foreach (Face face in faceArray)
                {

                    List<XYZ> triFace = new List<XYZ>(3);
                    Mesh mesh = face.Triangulate();

                    int triCount = mesh.NumTriangles;

                    for (int i = 0; i < triCount; i++)
                    {
                        triFace = new List<XYZ>();

                        for (int n = 0; n < 3; n++)
                        {
                            triFace.Add(mesh.get_Triangle(i).get_Vertex(n));
                        }

                        buildAShape.AddFace(new TessellatedFace(triFace, idMaterial));
                    }
                }


                buildAShape.CloseConnectedFaceSet();

                //bool validOptions = buildAShape.AreTargetAndFallbackCompatible(TessellatedShapeBuilderTarget.Solid, TessellatedShapeBuilderFallback.Abort);

                TessellatedShapeBuilderResult result = buildAShape.Build(TessellatedShapeBuilderTarget.Solid, TessellatedShapeBuilderFallback.Abort, graphicsStyleId);

                ElementId catId = new ElementId(BuiltInCategory.OST_GenericModel);
                DirectShape dsUtilityVolume = DirectShape.CreateElement(doc, catId, "06713861-8D80-4BCE-9B42-657695D45DC8", "");

                dsUtilityVolume.SetShape(result.GetGeometricalObjects());
                dsUtilityVolume.Name = dsName;

                return dsUtilityVolume;
            }

            catch
            {
                LogCreator.LogEntry("Cant create DirectShape because the try/catch failed.");
                return null;
            }

        }


    }
}
