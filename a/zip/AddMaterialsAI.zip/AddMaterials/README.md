AddMaterials
============

Revit add-in to add materials from a list of properties defined in Excel.

For more information, please refer to The Building Coder at

http://thebuildingcoder.typepad.com

http://thebuildingcoder.typepad.com/blog/2014/03/adding-new-materials-from-list-updated.html
