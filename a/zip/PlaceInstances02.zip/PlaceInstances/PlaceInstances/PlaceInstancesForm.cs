﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Form = System.Windows.Forms.Form;
#endregion // Namespaces

namespace PlaceInstances
{
  public partial class PlaceInstancesForm : Form
  {
    /// <summary>
    /// A regular expression to match three occurences
    /// of a real number with optional leading sign.
    /// </summary>
    const string _three_real_number_regex 
      = @"(?<X>[+-]?\d+(\.\d+)?).*(?<Y>[+-]?\d+(\.\d+)?).*(?<Z>[+-]?\d+(\.\d+)?)";

    /// <summary>
    /// The input document.
    /// </summary>
    Document _doc;

    /// <summary>
    /// The list of coordinate points read 
    /// from the selected text file.
    /// </summary>
    List<XYZ> _pts;

    /// <summary>
    /// Define initial XYZ coordinate 
    /// text file folder.
    /// </summary>
    static string _txt_folder_name 
      = Path.GetTempPath();

    public PlaceInstancesForm( Document doc )
    {
      InitializeComponent();

      _doc = doc;
      _pts = null;
    }

    private void PlaceInstancesForm_Load( 
      object sender, 
      EventArgs e )
    {
      List<Family> families = new List<Family>(
        new FilteredElementCollector( _doc )
          .OfClass( typeof( Family ) )
          .Cast<Family>()
          .Where<Family>( f => 
            f.FamilyPlacementType == 
              FamilyPlacementType.OneLevelBased ) );

      cmbFamily.DataSource = families;
      cmbFamily.DisplayMember = "Name";
    }

    private void cmbFamily_SelectedIndexChanged( 
      object sender, 
      EventArgs e )
    {
      ComboBox cb = sender as ComboBox;

      Debug.Assert( null != cb, 
        "expected a combo box" );

      Debug.Assert( cb == cmbFamily, 
        "what combo box are you, then?" );

      Family f = cb.SelectedItem as Family;

      FamilySymbolSet symbols = f.Symbols;

      // I have to convert the FamilySymbolSet to a
      // List, or the DataSource assignment will throw 
      // an exception saying "Complex DataBinding accepts
      // as a data source either an IList or an IListSource.

      List<FamilySymbol> symbols2 
        = new List<FamilySymbol>( 
          symbols.Cast <FamilySymbol>() ); 

      cmbType.DataSource = symbols2; 
      cmbType.DisplayMember = "Name";
    }

    private void btnBrowseXyz_Click( 
      object sender, 
      EventArgs e )
    {
      string filename;

      if( Util.FileSelectTxt( _txt_folder_name, 
        out filename ) )
      {
        txtFilename.Text = filename;

        _txt_folder_name = Path.GetDirectoryName( 
          filename );
      }
    }

    private void btnOk_Click( 
      object sender, 
      EventArgs e )
    {
      StreamReader reader = File.OpenText( 
        txtFilename.Text );

      string read = reader.ReadToEnd();

      string[] lines = read.Split( '\n' );

      Regex regex = new Regex( _three_real_number_regex );

      string s;

      foreach( string line in lines )
      {
        s = line.Trim();
        
        if( s.StartsWith( "#" ) )
        {
          continue;
        }
        
        Match match = regex.Match( s );

        foreach( System.Text.RegularExpressions.Group g in match.Groups )
        {
          Debug.Print( g.ToString() );
        }

        if( match.Success )
        {
          XYZ p = new XYZ( double.Parse( match.Groups["X"].ToString() ),
            double.Parse( match.Groups["Y"].ToString() ),
            double.Parse( match.Groups["Z"].ToString() ) );

          if( null == _pts )
          {
            _pts = new List<XYZ>( 1 );
          }
          _pts.Add( p );
        }
      }
    }

    //public string FamilyName
    //{
    //  get { return ( cmbFamily.SelectedItem as Family ).Name; }
    //}

    //public string TypeName
    //{
    //  get { return ( cmbType.SelectedItem as FamilySymbol ).Name; }
    //}

    /// <summary>
    /// The selected family.
    /// </summary>
    //public Family Family
    //{
    //  get { return cmbFamily.SelectedItem as Family; }
    //}

    /// <summary>
    /// The selected family symbol to be placed.
    /// </summary>
    public FamilySymbol Type
    {
      get 
      {
        return cmbType.SelectedItem as FamilySymbol; 
      }
    }

    /// <summary>
    /// The list of coordinate points read 
    /// from the selected text file.
    /// </summary>
    public IList<XYZ> Points
    {
      get 
      { 
        return _pts; 
      }
    }
  }
}
