﻿using System;
using System.Xml;
using System.Linq;
using System.Text;

namespace guidize
{
  class Guidize
  {
    public Guidize( ref JtOptions options )
    {
      if( o

      return guidize.
      string filename_stem = Path.GetFileNameWithoutExtension( filename );
      StreamWriter output = null;
      if( use_file_for_output )
      {
        string ext = "txt";
        string filename2 = Path.Combine( Path.GetDirectoryName( filename ), filename_stem + "." + ext );
        //string filename2 = Path.Combine( @"C:\docbook\repository\revit", filename_stem + "." + ext );
        output = new StreamWriter( filename2 );
        if( null == output )
        {
          System.Console.Error.WriteLine( string.Format( "unable to write to output file '{0}'", filename2 ) );
        }
      }

    }
  }
}
