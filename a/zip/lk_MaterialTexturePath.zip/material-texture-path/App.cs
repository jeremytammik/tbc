﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Media.Imaging;

using Autodesk.Revit.UI;

namespace material_texture_path
{
    public class App : IExternalApplication
    {        
        const string MAIN_CLASS = "material_texture_path.Command",
            BTN_MAIN_INTERNAL_NAME = "btnBPapp",
            PANEL_DESCRIPTION = "Materials",
            BTN_MAIN_TOOLTIP = "Changing material texture.",
            BTN_MAIN_TITLE = "Change\ntexture path";

        static Assembly LoadFromSameFolder(object sender, ResolveEventArgs args)
        {
            string folderPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string assemblyPath = Path.Combine(folderPath, new AssemblyName(args.Name).Name + ".dll");
            if (!File.Exists(assemblyPath)) return null;
            Assembly assembly = Assembly.LoadFrom(assemblyPath);
            return assembly;
        }

        public Result OnStartup(UIControlledApplication a)
        {

            AppDomain currentDomain = AppDomain.CurrentDomain;
            currentDomain.AssemblyResolve += new ResolveEventHandler(LoadFromSameFolder);
            currentDomain.ReflectionOnlyAssemblyResolve += new ResolveEventHandler(LoadFromSameFolder);

            RibbonPanel panel = a.CreateRibbonPanel(PANEL_DESCRIPTION);

            var assemblyPath = Assembly.GetExecutingAssembly().Location;
            PushButton mainButton = panel.AddItem(new PushButtonData(BTN_MAIN_INTERNAL_NAME, BTN_MAIN_TITLE,
                assemblyPath, MAIN_CLASS)) as PushButton;
            mainButton.ToolTip = BTN_MAIN_TOOLTIP;
            mainButton.LargeImage = ConvertFromImage(material_texture_path.Resources.icon32);

            return Result.Succeeded;
        }

        private BitmapSource ConvertFromImage(Bitmap image)
        {
            return System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                image.GetHbitmap(),
                IntPtr.Zero,
                System.Windows.Int32Rect.Empty,
                BitmapSizeOptions.FromEmptyOptions());
        }

        public Result OnShutdown(UIControlledApplication a)
        {
            return Result.Succeeded;
        }
    }
}