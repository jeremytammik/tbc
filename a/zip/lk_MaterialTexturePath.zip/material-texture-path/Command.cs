﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Visual;
using Autodesk.Revit.UI;

namespace material_texture_path
{
    [Transaction(TransactionMode.Manual)]
    public class Command : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;
            
            ChangeRenderingTexturePath(doc);
            
            return Result.Succeeded;
        }

        public void ChangeRenderingTexturePath(Document doc)
        { 
            // As there is only one material in the project, we can use FilteredElementCollector
            // Project file included in sample files
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            IList<Element> materials = collector.OfClass(typeof(Material)).ToElements();
            Material mat = materials.First() as Material;

            // Fixed path for new texture
            // Texture included in sample files
            string texturePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop),"new_texture.png");

            using (Transaction t = new Transaction(doc))
            {
                t.Start("Changing material texture path");

                using (AppearanceAssetEditScope editScope = new AppearanceAssetEditScope(doc))
                {
                    Asset editableAsset = editScope.Start(mat.AppearanceAssetId);
                    // Getting the correct AssetProperty
#if VERSION2018
                    
                    AssetProperty assetProperty = editableAsset["generic_diffuse"];
#elif VERSION2019
                    AssetProperty assetProperty = editableAsset.FindByName("generic_diffuse");
#endif
                    Asset connectedAsset = assetProperty.GetConnectedProperty(0) as Asset;
                    // getting the right connected Asset
                    if (connectedAsset.Name == "UnifiedBitmapSchema")
                    {
                        AssetPropertyString path = connectedAsset.FindByName(UnifiedBitmap.UnifiedbitmapBitmap) as AssetPropertyString;
                        if (path.IsValidValue(texturePath))
                            path.Value = texturePath;
                    }

                    editScope.Commit(true);
                }
                TaskDialog.Show("Material texture path", "Material texture path changed to:\n" + texturePath);

                t.Commit();
                t.Dispose();
            }
        }
    }
}
