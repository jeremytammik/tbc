﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB.Architecture;

namespace SelectionChangedExample
{
  [Autodesk.Revit.Attributes.Transaction( Autodesk.Revit.Attributes.TransactionMode.Manual )]
  [Autodesk.Revit.Attributes.Regeneration( Autodesk.Revit.Attributes.RegenerationOption.Manual )]
  [Autodesk.Revit.Attributes.Journaling( Autodesk.Revit.Attributes.JournalingMode.NoCommandData )]
  public class SelectionChangedExampleApp : IExternalApplication
  {
    private SelectionChangedWatcher selectionChangedWatcher;

    private TextBox tb;

    public Result OnShutdown( 
      UIControlledApplication a )
    {
      return Result.Succeeded;
    }

    public Result OnStartup( 
      UIControlledApplication a )
    {
      selectionChangedWatcher = new SelectionChangedWatcher( a );

      selectionChangedWatcher.SelectionChanged 
        += new EventHandler( 
          OnSelectionChanged );

      //--it does not seem to be possible to add items to context-sensitive ribbon panels.
      //--however the user can detach this panel from the main ribbon so that it is not hidden by context-sensitive panels.
      RibbonPanel rpSelectionWatcher = a.CreateRibbonPanel( "Selection Watcher" );

      var t1 = new TextBoxData( "txtInfo" );
      tb = rpSelectionWatcher.AddItem( t1 ) as TextBox;
      return Result.Succeeded;
    }


    void OnSelectionChanged( object sender, EventArgs e )
    {
      if( selectionChangedWatcher.Selection == null )
      {
        ShowInfo( "No selection" );
        return;
      }
      //--this example just reports the name of the room that is selected. Obviously any kind of element can be handled instead.
      List<Room> rooms = new List<Room>( selectionChangedWatcher.Selection.OfType<Room>() );
      if( rooms.Count == 0 )
      {
        ShowInfo( "No rooms selected" );
      }
      else if( rooms.Count == 1 )
      {
        ShowInfo( "Room " + rooms[0].Number );
      }
      else
      {
        ShowInfo( "Multiple rooms selected" );
      }
    }

    private void ShowInfo( string p )
    {
      tb.PromptText = p;
    }
  }
}
