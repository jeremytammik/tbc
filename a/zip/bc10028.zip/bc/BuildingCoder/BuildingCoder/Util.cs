#region Header
//
// Util.cs - The Building Coder Revit API utility methods
//
// Copyright (C) 2008 by Jeremy Tammik,
// Autodesk Inc. All rights reserved.
//
#endregion // Header

#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Geometry;
using RvtElement = Autodesk.Revit.Element;
#endregion // Namespaces

namespace BuildingCoder
{
  class Util
  {
    static public double Max( double[] a )
    {
      Debug.Assert( 1 == a.Rank, "expected one-dimensional array" );
      Debug.Assert( 0 == a.GetLowerBound( 0 ), "expected zero-based array" );
      Debug.Assert( 0 < a.GetUpperBound( 0 ), "expected non-empty array" );
      double max = a[0];
      for( int i = 1; i <= a.GetUpperBound( 0 ); ++i )
      {
        if( max < a[i] )
        {
          max = a[i];
        }
      }
      return max;
    }

    #region Geometrical Comparison
    const double _eps = 1.0e-9;

    static public bool IsZero( double a )
    {
      return _eps > Math.Abs( a );
    }

    static public bool IsEqual( double a, double b )
    {
      return IsZero( b - a );
    }

    static public bool IsHorizontal( XYZ v )
    {
      return IsZero( v.Z );
    }

    static public bool IsVertical( XYZ v )
    {
      return IsZero( v.X ) && IsZero( v.Y );
    }

    static public bool IsHorizontal( Edge e )
    {
      XYZ p = e.Evaluate( 0 );
      XYZ q = e.Evaluate( 1 );
      return IsHorizontal( q - p );
    }

    static public bool IsHorizontal( PlanarFace f )
    {
      return IsVertical( f.Normal );
    }

    static public bool IsVertical( PlanarFace f )
    {
      return IsHorizontal( f.Normal );
    }

    static public bool IsVertical( CylindricalFace f )
    {
      return IsVertical( f.Axis );
    }
    #endregion // Geometrical Comparison

    #region Unit Handling
    const double _convertFootToMm = 12 * 25.4;

    const double _convertFootToMeter 
      = _convertFootToMm * 0.001;

    const double _convertCubicFootToCubicMeter
      = _convertFootToMeter 
      * _convertFootToMeter 
      * _convertFootToMeter;

    /// <summary>
    /// Convert a given length in feet to millimetres.
    /// </summary>
    static public double FootToMm( double length )
    {
      return length * _convertFootToMm;
    }

    /// <summary>
    /// Convert a given length in millimetres to feet.
    /// </summary>
    static public double MmToFoot( double length )
    {
      return length / _convertFootToMm;
    }

    /// <summary>
    /// Convert a given volume in feet to cubic meters.
    /// </summary>
    static public double CubicFootToCubicMeter( double volume )
    {
      return volume * _convertCubicFootToCubicMeter;
    }
    #endregion // Unit Handling

    #region Formatting
    /// <summary>
    /// Return an English plural suffix 's' or
    /// nothing for the given number of items.
    /// </summary>
    public static string PluralSuffix( int n )
    {
      return 1 == n ? "" : "s";
    }

    /// <summary>
    /// Return an English plural suffix 'ies' or
    /// 'y' for the given number of items.
    /// </summary>
    public static string PluralSuffixY( int n )
    {
      return 1 == n ? "y" : "ies";
    }

    public static string DotOrColon( int n )
    {
      return 0 < n ? ":" : ".";
    }

    static public string RealString( double a )
    {
      return a.ToString( "0.##" );
    }

    static public string AngleString( double angle )
    {
      return RealString( angle * 180 / Math.PI ) + " degrees";
    }

    static public string MmString( double length )
    {
      return RealString( FootToMm( length ) ) + " mm";
    }

    static public string PointString( XYZ p )
    {
      return string.Format( "({0},{1},{2})",
        RealString( p.X ), RealString( p.Y ),
        RealString( p.Z ) );
    }

    static public string TransformString( Transform t )
    {
      return string.Format( "({0},{1},{2},{3})", PointString( t.Origin ),
        PointString( t.BasisX ), PointString( t.BasisY ), PointString( t.BasisZ ) );
    }

    private static string PointArrayString( XYZArray pts )
    {
      string s = string.Empty;
      foreach( XYZ p in pts )
      {
        if( 0 < s.Length )
        {
          s += ", ";
        }
        s += PointString( p );
      }
      return s;
    }

    private static string CurveString( Curve curve )
    {
      return "curve tesselation " + PointArrayString( curve.Tessellate() );
    }
    #endregion // Formatting

    const string _caption = "The Building Coder";

    static public void InfoMsg( string msg )
    {
      Debug.WriteLine( msg );
      System.Windows.Forms.MessageBox.Show( msg,
        _caption,
        System.Windows.Forms.MessageBoxButtons.OK,
        System.Windows.Forms.MessageBoxIcon.Information );
    }

    public static string ElementDescription( RvtElement e )
    {
      // for a wall, the element name equals the
      // wall type name, which is equivalent to the
      // family name ...
      FamilyInstance fi = e as FamilyInstance;
      string fn = ( null == fi )
        ? string.Empty
        : fi.Symbol.Family.Name + " ";

      string cn = ( null == e.Category )
        ? e.GetType().Name
        : e.Category.Name;

      return string.Format( "{0} {1}<{2} {3}>",
        cn, fn, e.Id.Value, e.Name );
    }

    #region Element Selection
    public static RvtElement SelectSingleElement( 
      Document doc, 
      string description )
    {
      Selection sel = doc.Selection;
      RvtElement e = null;
      sel.Elements.Clear();
      sel.StatusbarTip = "Please select " + description;
      if( sel.PickOne() )
      {
        ElementSetIterator elemSetItr
          = sel.Elements.ForwardIterator();
        elemSetItr.MoveNext();
        e = elemSetItr.Current as RvtElement;
      }
      return e;
    }

    /// <summary>
    /// Retrieve all pre-selected elements of the specified type,
    /// if any elements at all have been pre-selected. If not,
    /// retrieve all elements of specified type in the database.
    /// </summary>
    /// <param name="a">Return value container</param>
    /// <param name="doc">Active document</param>
    /// <param name="t">Specific type</param>
    /// <returns>True if some elements were retrieved</returns>
    public static bool GetSelectedElementsOrAll(
      List<RvtElement> a,
      Document doc,
      Type t )
    {
      Selection sel = doc.Selection;
      if( 0 < sel.Elements.Size )
      {
        foreach( RvtElement e in sel.Elements )
        {
          if( t.IsInstanceOfType( e ) )
          {
            a.Add( e );
          }
        }
      }
      else
      {
        doc.get_Elements( t, a );
      }
      return 0 < a.Count;
    }
    #endregion // Element Selection
  }
}
