﻿using System;
using System.IO;
using System.Reflection;
using winform = System.Windows.Forms;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI;
using adWin = Autodesk.Windows;

namespace PimpMyRevit
{
  [Regeneration( RegenerationOption.Manual )]
  public class UIApp : IExternalApplication
  {
    public Result OnStartup( UIControlledApplication a )
    {
      try
      {
        adWin.RibbonControl ribbon 
          = adWin.ComponentManager.Ribbon;

        ImageSource imgbg = new BitmapImage( 
          new Uri( Path.Combine( 
            Path.GetDirectoryName( 
              Assembly.GetExecutingAssembly().Location ), 
            "yourBackGroundPicture.jpg" ),
            UriKind.Relative ) );

        // define an image brush

        ImageBrush picBrush = new ImageBrush(); 
        picBrush.ImageSource = imgbg;
        picBrush.AlignmentX = AlignmentX.Left;
        picBrush.AlignmentY = AlignmentY.Top;
        picBrush.Stretch = Stretch.None;
        picBrush.TileMode = TileMode.FlipXY;

        // define a linear brush from top to bottom

        LinearGradientBrush gradientBrush 
          = new LinearGradientBrush(); 

        gradientBrush.StartPoint 
          = new System.Windows.Point( 0, 0 );

        gradientBrush.EndPoint 
          = new System.Windows.Point( 0, 1 );

        gradientBrush.GradientStops.Add( 
          new GradientStop( Colors.White, 0.0 ) );

        gradientBrush.GradientStops.Add( 
          new GradientStop( Colors.Blue, 1 ) );

        // change the tab header font

        ribbon.FontFamily = new System.Windows.Media
          .FontFamily( "Bauhaus 93" ); 

        ribbon.FontSize = 10;

        // iterate through the tabs and their panels

        foreach( adWin.RibbonTab tab in ribbon.Tabs )
        {
          foreach( adWin.RibbonPanel panel in tab.Panels )
          {
            panel.CustomPanelTitleBarBackground 
              = gradientBrush;

            panel.CustomPanelBackground 
              = picBrush; // use your picture

            //panel.CustomPanelBackground 
            //  = gradientBrush; // use your gradient fill
          }
        }
        adWin.ComponentManager.UIElementActivated += new 
          EventHandler<adWin.UIElementActivatedEventArgs>( 
            ComponentManager_UIElementActivated );
      }
      catch( Exception ex )
      {
        winform.MessageBox.Show( 
          ex.StackTrace + "\r\n" + ex.InnerException, 
          "Error", winform.MessageBoxButtons.OK );

        return Result.Failed;
      }
      return Result.Succeeded;
    }

    public Result OnShutdown( UIControlledApplication a )
    {
      adWin.ComponentManager.UIElementActivated 
        -= ComponentManager_UIElementActivated;

      return Result.Succeeded;
    }

    void ComponentManager_UIElementActivated( 
      object sender, 
      Autodesk.Windows.UIElementActivatedEventArgs e )
    {
      // e.UiElement.PersistId says which item has been pressed
    }

    private Autodesk.Windows.RibbonPanel 
      GetPanelFromPanel( 
        Autodesk.Revit.UI.RibbonPanel panel )
    {
      FieldInfo fi
        = panel.GetType().GetField( 
          "m_RibbonPanel",
          BindingFlags.Instance
          | BindingFlags.NonPublic );

      if( null != fi )
      {
        Autodesk.Windows.RibbonPanel p 
          = fi.GetValue( panel ) 
          as Autodesk.Windows.RibbonPanel;

        return p;
      }
      return null;
    }

    #region Ribbon Transformations
    void f()
    {
      //using adWin = Autodesk.Windows;

      adWin.RibbonControl ribbon 
        = adWin.ComponentManager.Ribbon;

      TransformGroup group = new TransformGroup();
      //group.Children.Add(new RotateTransform(-2));
      group.Children.Add( new TranslateTransform( 
        ribbon.ActualWidth * 0.25, 160 ) );

      group.Children.Add( new ScaleTransform(
        0.75, 0.75 ) );

      group.Children.Add( new SkewTransform( 
        15, -3 ) );

      ribbon.RenderTransform = group;

      adWin.ComponentManager.Ribbon.RenderTransform 
        = new System.Windows.Media.ScaleTransform( 
          0.5, 0.75 );

      adWin.ComponentManager.Ribbon.RenderTransform 
        = new System.Windows.Media.RotateTransform( 
          5 );

      adWin.ComponentManager.Ribbon.RenderTransform 
        = new System.Windows.Media.TranslateTransform( 
          100, 25 );

      adWin.ComponentManager.Ribbon.RenderTransform 
        = new System.Windows.Media.SkewTransform( 
          -15, 0 );

      System.Windows.Media.TransformGroup g 
        = new System.Windows.Media.TransformGroup();

      g.Children.Add( new ScaleTransform( 0.75, 0.75 ) );
      g.Children.Add( new SkewTransform( -25, 0 ) );
      g.Children.Add( new TranslateTransform( 50, 10 ) );

      adWin.ComponentManager.Ribbon.RenderTransform = g;

    }

    #endregion // Ribbon Transformations
  }
}

#region AutoCAD sample code
#if AutoCAD_Sample_Code
using Autodesk.Windows;
using Autodesk.AutoCAD.Runtime;
using System.Windows.Media;

namespace PimpMyAutoCAD
{
  public class UIApp : IExtensionApplication
  {
    public void Initialize()
    {
      RibbonControl ribbon = ComponentManager.Ribbon;

      ImageSource imgbg = new BitmapImage(
        new Uri( Path.Combine( Path.GetDirectoryName( 
          Assembly.GetExecutingAssembly().Location ), 
          "yourBackGroundPicture.jpg" ), 
          UriKind.Relative ) );

      // define an image brush

      ImageBrush picBrush = new ImageBrush(); 
      picBrush.ImageSource = imgbg;
      picBrush.AlignmentX = AlignmentX.Left;
      picBrush.AlignmentY = AlignmentY.Top;
      picBrush.Stretch = Stretch.None;
      picBrush.TileMode = TileMode.FlipXY;

      // define a linear brush from top to bottom

      LinearGradientBrush myLinearGradientBrush 
        = new LinearGradientBrush(); 

      myLinearGradientBrush.StartPoint 
        = new System.Windows.Point( 0, 0 );

      myLinearGradientBrush.EndPoint 
        = new System.Windows.Point( 0, 1 );

      myLinearGradientBrush.GradientStops.Add( 
        new GradientStop( Colors.White, 0.0 ) );

      myLinearGradientBrush.GradientStops.Add( 
        new GradientStop( Colors.Blue, 1 ) );

      // change the tab header font

      ribbon.FontFamily = new FontFamily( "Bauhaus 93" ); 
      ribbon.FontSize = 10;

      // now iterate through the tabs and their panels

      foreach( RibbonTab tab in ribbon.Tabs )
      {
        foreach( RibbonPanel panel in tab.Panels )
        {
          panel.CustomPanelTitleBarBackground 
            = myLinearGradientBrush;

          panel.CustomPanelBackground = picBrush;

          //panel.CustomPanelBackground 
          //  = myLinearGradientBrush; 
        }
      }
    }

    public void Initialize2()
    {
      try
      {
        TransformGroup group = new TransformGroup();

        group.Children.Add( 
          new ScaleTransform( 0.96, 1 ) );

        group.Children.Add( 
          new SkewTransform( -25, 0 ) );

        group.Children.Add( 
          new TranslateTransform( 50, 0 ) );

        ComponentManager.Ribbon.RenderTransform 
          = group;
      }
      catch
      {
      }
    }

    public void Terminate()
    {
    }
  }
}
#endif // AutoCAD_Sample_Code
#endregion // AutoCAD sample code
