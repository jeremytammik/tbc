1. Auto PDF Print from Revit 2014.vsd (pseudo logic).
2. Auto PDF Print from Revit 2014.docx (instructions for use).
3. Folders.zip (copy the Projects and AutoPDFPrint folders to the root C:).
4. AutoPDFPrint.zip (Revit 2014 add-in Application).
5. AutoPDFPrint_Bridge.zip (EXE run from Task Scheduler).