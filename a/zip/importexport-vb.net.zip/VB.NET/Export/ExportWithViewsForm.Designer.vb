﻿' 
' (C) Copyright 2003-2009 by Autodesk, Inc. 
' 
' Permission to use, copy, modify, and distribute this software in 
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and 
' restricted rights notice below appear in all supporting 
' documentation. 
' 
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF 
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE 
' UNINTERRUPTED OR ERROR FREE. 
' 
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer 
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii) 
' (Rights in Technical Data and Computer Software), as applicable. 
' 

Partial Class ExportWithViewsForm
    ''' <summary> 
    ''' Required designer variable. 
    ''' </summary> 
    Private components As System.ComponentModel.IContainer = Nothing

    ''' <summary> 
    ''' Clean up any resources being used. 
    ''' </summary> 
    ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param> 
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso (components IsNot Nothing) Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region "Windows Form Designer generated code"

    ''' <summary> 
    ''' Required method for Designer support - do not modify 
    ''' the contents of this method with the code editor. 
    ''' </summary> 
    Private Sub InitializeComponent()
        Me.textBoxSaveAs = New System.Windows.Forms.TextBox()
        Me.labelSaveAs = New System.Windows.Forms.Label()
        Me.buttonSave = New System.Windows.Forms.Button()
        Me.buttonCancel = New System.Windows.Forms.Button()
        Me.buttonOptions = New System.Windows.Forms.Button()
        Me.buttonBrowser = New System.Windows.Forms.Button()
        Me.groupBoxRange = New System.Windows.Forms.GroupBox()
        Me.buttonSelectViews = New System.Windows.Forms.Button()
        Me.radioButtonSelectView = New System.Windows.Forms.RadioButton()
        Me.radioButtonCurrentView = New System.Windows.Forms.RadioButton()
        Me.groupBoxRange.SuspendLayout()
        Me.SuspendLayout()
        ' 
        ' textBoxSaveAs 
        ' 
        Me.textBoxSaveAs.Location = New System.Drawing.Point(67, 19)
        Me.textBoxSaveAs.Name = "textBoxSaveAs"
        Me.textBoxSaveAs.Size = New System.Drawing.Size(308, 20)
        Me.textBoxSaveAs.TabIndex = 1
        ' 
        ' labelSaveAs 
        ' 
        Me.labelSaveAs.AutoSize = True
        Me.labelSaveAs.Location = New System.Drawing.Point(14, 23)
        Me.labelSaveAs.Name = "labelSaveAs"
        Me.labelSaveAs.Size = New System.Drawing.Size(50, 13)
        Me.labelSaveAs.TabIndex = 1
        Me.labelSaveAs.Text = "Save As:"
        ' 
        ' buttonSave 
        ' 
        Me.buttonSave.Location = New System.Drawing.Point(235, 141)
        Me.buttonSave.Name = "buttonSave"
        Me.buttonSave.Size = New System.Drawing.Size(75, 21)
        Me.buttonSave.TabIndex = 0
        Me.buttonSave.Text = "&Save"
        Me.buttonSave.UseVisualStyleBackColor = True
        AddHandler Me.buttonSave.Click, AddressOf Me.buttonSave_Click
        ' 
        ' buttonCancel 
        ' 
        Me.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.buttonCancel.Location = New System.Drawing.Point(320, 141)
        Me.buttonCancel.Name = "buttonCancel"
        Me.buttonCancel.Size = New System.Drawing.Size(75, 21)
        Me.buttonCancel.TabIndex = 6
        Me.buttonCancel.Text = "&Cancel"
        Me.buttonCancel.UseVisualStyleBackColor = True
        ' 
        ' buttonOptions 
        ' 
        Me.buttonOptions.Location = New System.Drawing.Point(150, 141)
        Me.buttonOptions.Name = "buttonOptions"
        Me.buttonOptions.Size = New System.Drawing.Size(75, 21)
        Me.buttonOptions.TabIndex = 5
        Me.buttonOptions.Text = "&Options..."
        Me.buttonOptions.UseVisualStyleBackColor = True
        AddHandler Me.buttonOptions.Click, AddressOf Me.buttonOptions_Click
        ' 
        ' buttonBrowser 
        ' 
        Me.buttonBrowser.Location = New System.Drawing.Point(375, 19)
        Me.buttonBrowser.Name = "buttonBrowser"
        Me.buttonBrowser.Size = New System.Drawing.Size(24, 20)
        Me.buttonBrowser.TabIndex = 2
        Me.buttonBrowser.Text = "..."
        Me.buttonBrowser.UseVisualStyleBackColor = True
        AddHandler Me.buttonBrowser.Click, AddressOf Me.buttonBrowser_Click
        ' 
        ' groupBoxRange 
        ' 
        Me.groupBoxRange.Controls.Add(Me.buttonSelectViews)
        Me.groupBoxRange.Controls.Add(Me.radioButtonSelectView)
        Me.groupBoxRange.Controls.Add(Me.radioButtonCurrentView)
        Me.groupBoxRange.Location = New System.Drawing.Point(17, 46)
        Me.groupBoxRange.Name = "groupBoxRange"
        Me.groupBoxRange.Size = New System.Drawing.Size(378, 73)
        Me.groupBoxRange.TabIndex = 4
        Me.groupBoxRange.TabStop = False
        Me.groupBoxRange.Text = "Range"
        ' 
        ' buttonSelectViews 
        ' 
        Me.buttonSelectViews.Enabled = False
        Me.buttonSelectViews.Location = New System.Drawing.Point(214, 42)
        Me.buttonSelectViews.Name = "buttonSelectViews"
        Me.buttonSelectViews.Size = New System.Drawing.Size(75, 21)
        Me.buttonSelectViews.TabIndex = 2
        Me.buttonSelectViews.Text = "Select..."
        Me.buttonSelectViews.UseVisualStyleBackColor = True
        AddHandler Me.buttonSelectViews.Click, AddressOf Me.buttonSelectViews_Click
        ' 
        ' radioButtonSelectView 
        ' 
        Me.radioButtonSelectView.AutoSize = True
        Me.radioButtonSelectView.Location = New System.Drawing.Point(9, 44)
        Me.radioButtonSelectView.Name = "radioButtonSelectView"
        Me.radioButtonSelectView.Size = New System.Drawing.Size(133, 17)
        Me.radioButtonSelectView.TabIndex = 1
        Me.radioButtonSelectView.Text = "Selected views/sheets"
        Me.radioButtonSelectView.UseVisualStyleBackColor = True
        AddHandler Me.radioButtonSelectView.CheckedChanged, AddressOf Me.radioButtonSelectView_CheckedChanged
        ' 
        ' radioButtonCurrentView 
        ' 
        Me.radioButtonCurrentView.AutoSize = True
        Me.radioButtonCurrentView.Checked = True
        Me.radioButtonCurrentView.Location = New System.Drawing.Point(9, 20)
        Me.radioButtonCurrentView.Name = "radioButtonCurrentView"
        Me.radioButtonCurrentView.Size = New System.Drawing.Size(84, 17)
        Me.radioButtonCurrentView.TabIndex = 0
        Me.radioButtonCurrentView.TabStop = True
        Me.radioButtonCurrentView.Text = "Current view"
        Me.radioButtonCurrentView.UseVisualStyleBackColor = True
        ' 
        ' ExportWithViewsForm 
        ' 
        Me.AcceptButton = Me.buttonSave
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0F, 13.0F)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.buttonCancel
        Me.ClientSize = New System.Drawing.Size(414, 169)
        Me.Controls.Add(Me.groupBoxRange)
        Me.Controls.Add(Me.buttonOptions)
        Me.Controls.Add(Me.buttonCancel)
        Me.Controls.Add(Me.buttonBrowser)
        Me.Controls.Add(Me.buttonSave)
        Me.Controls.Add(Me.labelSaveAs)
        Me.Controls.Add(Me.textBoxSaveAs)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ExportWithViewsForm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Export"
        Me.groupBoxRange.ResumeLayout(False)
        Me.groupBoxRange.PerformLayout()
        Me.ResumeLayout(False)

        Me.PerformLayout()
    End Sub

#End Region

    Private textBoxSaveAs As System.Windows.Forms.TextBox
    Private labelSaveAs As System.Windows.Forms.Label
    Private buttonSave As System.Windows.Forms.Button
    Private buttonCancel As System.Windows.Forms.Button
    Private buttonOptions As System.Windows.Forms.Button
    Private buttonBrowser As System.Windows.Forms.Button
    Private groupBoxRange As System.Windows.Forms.GroupBox
    Private buttonSelectViews As System.Windows.Forms.Button
    Private radioButtonSelectView As System.Windows.Forms.RadioButton
    Private radioButtonCurrentView As System.Windows.Forms.RadioButton
End Class