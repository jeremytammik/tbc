﻿' 
' (C) Copyright 2003-2009 by Autodesk, Inc. 
' 
' Permission to use, copy, modify, and distribute this software in 
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and 
' restricted rights notice below appear in all supporting 
' documentation. 
' 
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF 
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE 
' UNINTERRUPTED OR ERROR FREE. 
' 
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer 
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii) 
' (Rights in Technical Data and Computer Software), as applicable. 
' 

Partial Class ImportDWGForm
    ''' <summary> 
    ''' Required designer variable. 
    ''' </summary> 
    Private components As System.ComponentModel.IContainer = Nothing

    ''' <summary> 
    ''' Clean up any resources being used. 
    ''' </summary> 
    ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param> 
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso (components IsNot Nothing) Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region "Windows Form Designer generated code"

    ''' <summary> 
    ''' Required method for Designer support - do not modify 
    ''' the contents of this method with the code editor. 
    ''' </summary> 
    Private Sub InitializeComponent()
        Me.buttonCancel = New System.Windows.Forms.Button()
        Me.buttonOpen = New System.Windows.Forms.Button()
        Me.labelFileName = New System.Windows.Forms.Label()
        Me.textBoxFileSource = New System.Windows.Forms.TextBox()
        Me.buttonBrowser = New System.Windows.Forms.Button()
        Me.groupBoxPositioning = New System.Windows.Forms.GroupBox()
        Me.labelAutomaticallyPlace = New System.Windows.Forms.Label()
        Me.labelPlaceLevel = New System.Windows.Forms.Label()
        Me.radioButtonOrigin2Origin = New System.Windows.Forms.RadioButton()
        Me.radioButtonCenter2Center = New System.Windows.Forms.RadioButton()
        Me.comboBoxLevel = New System.Windows.Forms.ComboBox()
        Me.checkBoxOrient2View = New System.Windows.Forms.CheckBox()
        Me.groupBoxScaling = New System.Windows.Forms.GroupBox()
        Me.comboBoxUnits = New System.Windows.Forms.ComboBox()
        Me.textBoxScale = New System.Windows.Forms.TextBox()
        Me.labelScaleFactor = New System.Windows.Forms.Label()
        Me.labelUnits = New System.Windows.Forms.Label()
        Me.groupBoxColors = New System.Windows.Forms.GroupBox()
        Me.radioButtonInvertColor = New System.Windows.Forms.RadioButton()
        Me.radioButtonPreserve = New System.Windows.Forms.RadioButton()
        Me.radioButtonBlackWhite = New System.Windows.Forms.RadioButton()
        Me.checkBoxCurrentViewOnly = New System.Windows.Forms.CheckBox()
        Me.comboBoxLayers = New System.Windows.Forms.ComboBox()
        Me.labelLayers = New System.Windows.Forms.Label()
        Me.groupBoxPositioning.SuspendLayout()
        Me.groupBoxScaling.SuspendLayout()
        Me.groupBoxColors.SuspendLayout()
        Me.SuspendLayout()
        ' 
        ' buttonCancel 
        ' 
        Me.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.buttonCancel.Location = New System.Drawing.Point(390, 285)
        Me.buttonCancel.Name = "buttonCancel"
        Me.buttonCancel.Size = New System.Drawing.Size(75, 21)
        Me.buttonCancel.TabIndex = 8
        Me.buttonCancel.Text = "&Cancel"
        Me.buttonCancel.UseVisualStyleBackColor = True
        ' 
        ' buttonOpen 
        ' 
        Me.buttonOpen.Location = New System.Drawing.Point(303, 285)
        Me.buttonOpen.Name = "buttonOpen"
        Me.buttonOpen.Size = New System.Drawing.Size(75, 21)
        Me.buttonOpen.TabIndex = 7
        Me.buttonOpen.Text = "&Open"
        Me.buttonOpen.UseVisualStyleBackColor = True
        AddHandler Me.buttonOpen.Click, AddressOf Me.buttonOpen_Click
        ' 
        ' labelFileName 
        ' 
        Me.labelFileName.AutoSize = True
        Me.labelFileName.Location = New System.Drawing.Point(10, 15)
        Me.labelFileName.Name = "labelFileName"
        Me.labelFileName.Size = New System.Drawing.Size(61, 13)
        Me.labelFileName.TabIndex = 10
        Me.labelFileName.Text = "File source:"
        ' 
        ' textBoxFileSource 
        ' 
        Me.textBoxFileSource.Location = New System.Drawing.Point(73, 11)
        Me.textBoxFileSource.Name = "textBoxFileSource"
        Me.textBoxFileSource.Size = New System.Drawing.Size(369, 20)
        Me.textBoxFileSource.TabIndex = 1
        ' 
        ' buttonBrowser 
        ' 
        Me.buttonBrowser.Location = New System.Drawing.Point(442, 11)
        Me.buttonBrowser.Name = "buttonBrowser"
        Me.buttonBrowser.Size = New System.Drawing.Size(24, 20)
        Me.buttonBrowser.TabIndex = 0
        Me.buttonBrowser.Text = "..."
        Me.buttonBrowser.UseVisualStyleBackColor = True
        AddHandler Me.buttonBrowser.Click, AddressOf Me.buttonBrowser_Click
        ' 
        ' groupBoxPositioning 
        ' 
        Me.groupBoxPositioning.Controls.Add(Me.labelAutomaticallyPlace)
        Me.groupBoxPositioning.Controls.Add(Me.labelPlaceLevel)
        Me.groupBoxPositioning.Controls.Add(Me.radioButtonOrigin2Origin)
        Me.groupBoxPositioning.Controls.Add(Me.radioButtonCenter2Center)
        Me.groupBoxPositioning.Controls.Add(Me.comboBoxLevel)
        Me.groupBoxPositioning.Controls.Add(Me.checkBoxOrient2View)
        Me.groupBoxPositioning.Location = New System.Drawing.Point(229, 43)
        Me.groupBoxPositioning.Name = "groupBoxPositioning"
        Me.groupBoxPositioning.Size = New System.Drawing.Size(237, 157)
        Me.groupBoxPositioning.TabIndex = 5
        Me.groupBoxPositioning.TabStop = False
        Me.groupBoxPositioning.Text = "Positioning"
        ' 
        ' labelAutomaticallyPlace 
        ' 
        Me.labelAutomaticallyPlace.AutoSize = True
        Me.labelAutomaticallyPlace.Location = New System.Drawing.Point(15, 18)
        Me.labelAutomaticallyPlace.Name = "labelAutomaticallyPlace"
        Me.labelAutomaticallyPlace.Size = New System.Drawing.Size(98, 13)
        Me.labelAutomaticallyPlace.TabIndex = 0
        Me.labelAutomaticallyPlace.Text = "Automatically place"
        ' 
        ' labelPlaceLevel 
        ' 
        Me.labelPlaceLevel.AutoSize = True
        Me.labelPlaceLevel.Location = New System.Drawing.Point(14, 129)
        Me.labelPlaceLevel.Name = "labelPlaceLevel"
        Me.labelPlaceLevel.Size = New System.Drawing.Size(74, 13)
        Me.labelPlaceLevel.TabIndex = 5
        Me.labelPlaceLevel.Text = "Place at level:"
        ' 
        ' radioButtonOrigin2Origin 
        ' 
        Me.radioButtonOrigin2Origin.AutoSize = True
        Me.radioButtonOrigin2Origin.Location = New System.Drawing.Point(19, 60)
        Me.radioButtonOrigin2Origin.Name = "radioButtonOrigin2Origin"
        Me.radioButtonOrigin2Origin.Size = New System.Drawing.Size(92, 17)
        Me.radioButtonOrigin2Origin.TabIndex = 2
        Me.radioButtonOrigin2Origin.TabStop = True
        Me.radioButtonOrigin2Origin.Text = "Origin-to-origin"
        Me.radioButtonOrigin2Origin.UseVisualStyleBackColor = True
        ' 
        ' radioButtonCenter2Center 
        ' 
        Me.radioButtonCenter2Center.AutoSize = True
        Me.radioButtonCenter2Center.Checked = True
        Me.radioButtonCenter2Center.Location = New System.Drawing.Point(19, 37)
        Me.radioButtonCenter2Center.Name = "radioButtonCenter2Center"
        Me.radioButtonCenter2Center.Size = New System.Drawing.Size(101, 17)
        Me.radioButtonCenter2Center.TabIndex = 1
        Me.radioButtonCenter2Center.TabStop = True
        Me.radioButtonCenter2Center.Text = "Center-to-center"
        Me.radioButtonCenter2Center.UseVisualStyleBackColor = True
        ' 
        ' comboBoxLevel 
        ' 
        Me.comboBoxLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxLevel.FormattingEnabled = True
        Me.comboBoxLevel.Location = New System.Drawing.Point(91, 125)
        Me.comboBoxLevel.Name = "comboBoxLevel"
        Me.comboBoxLevel.Size = New System.Drawing.Size(122, 21)
        Me.comboBoxLevel.TabIndex = 4
        ' 
        ' checkBoxOrient2View 
        ' 
        Me.checkBoxOrient2View.AutoSize = True
        Me.checkBoxOrient2View.Checked = True
        Me.checkBoxOrient2View.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkBoxOrient2View.Location = New System.Drawing.Point(17, 104)
        Me.checkBoxOrient2View.Name = "checkBoxOrient2View"
        Me.checkBoxOrient2View.Size = New System.Drawing.Size(92, 17)
        Me.checkBoxOrient2View.TabIndex = 3
        Me.checkBoxOrient2View.Text = "Orient to View"
        Me.checkBoxOrient2View.UseVisualStyleBackColor = True
        ' 
        ' groupBoxScaling 
        ' 
        Me.groupBoxScaling.Controls.Add(Me.comboBoxUnits)
        Me.groupBoxScaling.Controls.Add(Me.textBoxScale)
        Me.groupBoxScaling.Controls.Add(Me.labelScaleFactor)
        Me.groupBoxScaling.Controls.Add(Me.labelUnits)
        Me.groupBoxScaling.Location = New System.Drawing.Point(10, 202)
        Me.groupBoxScaling.Name = "groupBoxScaling"
        Me.groupBoxScaling.Size = New System.Drawing.Size(456, 50)
        Me.groupBoxScaling.TabIndex = 6
        Me.groupBoxScaling.TabStop = False
        Me.groupBoxScaling.Text = "Scaling"
        ' 
        ' comboBoxUnits 
        ' 
        Me.comboBoxUnits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxUnits.FormattingEnabled = True
        Me.comboBoxUnits.Location = New System.Drawing.Point(79, 18)
        Me.comboBoxUnits.Name = "comboBoxUnits"
        Me.comboBoxUnits.Size = New System.Drawing.Size(121, 21)
        Me.comboBoxUnits.TabIndex = 0
        AddHandler Me.comboBoxUnits.SelectedIndexChanged, AddressOf Me.comboBoxUnits_SelectedIndexChanged
        ' 
        ' textBoxScale 
        ' 
        Me.textBoxScale.Enabled = False
        Me.textBoxScale.Location = New System.Drawing.Point(310, 19)
        Me.textBoxScale.Name = "textBoxScale"
        Me.textBoxScale.Size = New System.Drawing.Size(122, 20)
        Me.textBoxScale.TabIndex = 1
        Me.textBoxScale.Text = "1.000000"
        AddHandler Me.textBoxScale.KeyPress, AddressOf Me.textBoxScale_KeyPress
        AddHandler Me.textBoxScale.TextChanged, AddressOf Me.textBoxScale_TextChanged
        ' 
        ' labelScaleFactor 
        ' 
        Me.labelScaleFactor.AutoSize = True
        Me.labelScaleFactor.Location = New System.Drawing.Point(234, 22)
        Me.labelScaleFactor.Name = "labelScaleFactor"
        Me.labelScaleFactor.Size = New System.Drawing.Size(67, 13)
        Me.labelScaleFactor.TabIndex = 2
        Me.labelScaleFactor.Text = "Scale factor:"
        ' 
        ' labelUnits 
        ' 
        Me.labelUnits.AutoSize = True
        Me.labelUnits.Location = New System.Drawing.Point(7, 22)
        Me.labelUnits.Name = "labelUnits"
        Me.labelUnits.Size = New System.Drawing.Size(64, 13)
        Me.labelUnits.TabIndex = 0
        Me.labelUnits.Text = "Import units:"
        ' 
        ' groupBoxColors 
        ' 
        Me.groupBoxColors.Controls.Add(Me.radioButtonInvertColor)
        Me.groupBoxColors.Controls.Add(Me.radioButtonPreserve)
        Me.groupBoxColors.Controls.Add(Me.radioButtonBlackWhite)
        Me.groupBoxColors.Location = New System.Drawing.Point(10, 43)
        Me.groupBoxColors.Name = "groupBoxColors"
        Me.groupBoxColors.Size = New System.Drawing.Size(200, 95)
        Me.groupBoxColors.TabIndex = 2
        Me.groupBoxColors.TabStop = False
        Me.groupBoxColors.Text = "Layer/Level Colors"
        ' 
        ' radioButtonInvertColor 
        ' 
        Me.radioButtonInvertColor.AutoSize = True
        Me.radioButtonInvertColor.Checked = True
        Me.radioButtonInvertColor.Location = New System.Drawing.Point(14, 66)
        Me.radioButtonInvertColor.Name = "radioButtonInvertColor"
        Me.radioButtonInvertColor.Size = New System.Drawing.Size(83, 17)
        Me.radioButtonInvertColor.TabIndex = 2
        Me.radioButtonInvertColor.TabStop = True
        Me.radioButtonInvertColor.Text = "Invert colors"
        Me.radioButtonInvertColor.UseVisualStyleBackColor = True
        ' 
        ' radioButtonPreserve 
        ' 
        Me.radioButtonPreserve.AutoSize = True
        Me.radioButtonPreserve.Location = New System.Drawing.Point(14, 43)
        Me.radioButtonPreserve.Name = "radioButtonPreserve"
        Me.radioButtonPreserve.Size = New System.Drawing.Size(98, 17)
        Me.radioButtonPreserve.TabIndex = 1
        Me.radioButtonPreserve.Text = "Preserve colors"
        Me.radioButtonPreserve.UseVisualStyleBackColor = True
        ' 
        ' radioButtonBlackWhite 
        ' 
        Me.radioButtonBlackWhite.AutoSize = True
        Me.radioButtonBlackWhite.Location = New System.Drawing.Point(15, 20)
        Me.radioButtonBlackWhite.Name = "radioButtonBlackWhite"
        Me.radioButtonBlackWhite.Size = New System.Drawing.Size(101, 17)
        Me.radioButtonBlackWhite.TabIndex = 0
        Me.radioButtonBlackWhite.Text = "Black and white"
        Me.radioButtonBlackWhite.UseVisualStyleBackColor = True
        ' 
        ' checkBoxCurrentViewOnly 
        ' 
        Me.checkBoxCurrentViewOnly.AutoSize = True
        Me.checkBoxCurrentViewOnly.Location = New System.Drawing.Point(17, 147)
        Me.checkBoxCurrentViewOnly.Name = "checkBoxCurrentViewOnly"
        Me.checkBoxCurrentViewOnly.Size = New System.Drawing.Size(107, 17)
        Me.checkBoxCurrentViewOnly.TabIndex = 3
        Me.checkBoxCurrentViewOnly.Text = "Current view only"
        Me.checkBoxCurrentViewOnly.UseVisualStyleBackColor = True
        AddHandler Me.checkBoxCurrentViewOnly.CheckedChanged, AddressOf Me.checkBoxCurrentViewOnly_CheckedChanged
        ' 
        ' comboBoxLayers 
        ' 
        Me.comboBoxLayers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxLayers.FormattingEnabled = True
        Me.comboBoxLayers.Location = New System.Drawing.Point(88, 168)
        Me.comboBoxLayers.Name = "comboBoxLayers"
        Me.comboBoxLayers.Size = New System.Drawing.Size(122, 21)
        Me.comboBoxLayers.TabIndex = 4
        ' 
        ' labelLayers 
        ' 
        Me.labelLayers.AutoSize = True
        Me.labelLayers.Location = New System.Drawing.Point(14, 172)
        Me.labelLayers.Name = "labelLayers"
        Me.labelLayers.Size = New System.Drawing.Size(41, 13)
        Me.labelLayers.TabIndex = 5
        Me.labelLayers.Text = "Layers:"
        ' 
        ' ImportDWGForm 
        ' 
        Me.AcceptButton = Me.buttonOpen
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0F, 13.0F)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.buttonCancel
        Me.ClientSize = New System.Drawing.Size(480, 316)
        Me.Controls.Add(Me.checkBoxCurrentViewOnly)
        Me.Controls.Add(Me.groupBoxPositioning)
        Me.Controls.Add(Me.labelLayers)
        Me.Controls.Add(Me.groupBoxScaling)
        Me.Controls.Add(Me.groupBoxColors)
        Me.Controls.Add(Me.buttonBrowser)
        Me.Controls.Add(Me.comboBoxLayers)
        Me.Controls.Add(Me.buttonCancel)
        Me.Controls.Add(Me.buttonOpen)
        Me.Controls.Add(Me.labelFileName)
        Me.Controls.Add(Me.textBoxFileSource)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ImportDWGForm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Import"
        Me.groupBoxPositioning.ResumeLayout(False)
        Me.groupBoxPositioning.PerformLayout()
        Me.groupBoxScaling.ResumeLayout(False)
        Me.groupBoxScaling.PerformLayout()
        Me.groupBoxColors.ResumeLayout(False)
        Me.groupBoxColors.PerformLayout()
        Me.ResumeLayout(False)

        Me.PerformLayout()
    End Sub

#End Region

    Private buttonCancel As System.Windows.Forms.Button
    Private buttonOpen As System.Windows.Forms.Button
    Private labelFileName As System.Windows.Forms.Label
    Private textBoxFileSource As System.Windows.Forms.TextBox
    Private buttonBrowser As System.Windows.Forms.Button
    Private groupBoxPositioning As System.Windows.Forms.GroupBox
    Private radioButtonOrigin2Origin As System.Windows.Forms.RadioButton
    Private radioButtonCenter2Center As System.Windows.Forms.RadioButton
    Private checkBoxCurrentViewOnly As System.Windows.Forms.CheckBox
    Private comboBoxLevel As System.Windows.Forms.ComboBox
    Private checkBoxOrient2View As System.Windows.Forms.CheckBox
    Private groupBoxScaling As System.Windows.Forms.GroupBox
    Private textBoxScale As System.Windows.Forms.TextBox
    Private labelScaleFactor As System.Windows.Forms.Label
    Private labelUnits As System.Windows.Forms.Label
    Private groupBoxColors As System.Windows.Forms.GroupBox
    Private radioButtonInvertColor As System.Windows.Forms.RadioButton
    Private radioButtonPreserve As System.Windows.Forms.RadioButton
    Private radioButtonBlackWhite As System.Windows.Forms.RadioButton
    Private labelAutomaticallyPlace As System.Windows.Forms.Label
    Private labelPlaceLevel As System.Windows.Forms.Label
    Private comboBoxUnits As System.Windows.Forms.ComboBox
    Private comboBoxLayers As System.Windows.Forms.ComboBox
    Private labelLayers As System.Windows.Forms.Label
End Class