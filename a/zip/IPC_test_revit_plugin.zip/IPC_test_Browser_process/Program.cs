﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPC_test_browser_process
{
    static class Program
    {

        public static IntPtr revit_hwnd;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            // the Revit plugin's Window handle is passed here in the command line argument
            revit_hwnd = new IntPtr(int.Parse(args[0]));

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form_Browser());
        }
    }
}
