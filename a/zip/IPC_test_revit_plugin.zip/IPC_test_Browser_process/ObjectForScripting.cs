﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPC_test_browser_process
{
    public class ObjectForScripting
    {

        public void sendTextToRevit(string message)
        {
            Form_Browser.BrowserToRevitActions.Enqueue(message);
        }



    }
}
