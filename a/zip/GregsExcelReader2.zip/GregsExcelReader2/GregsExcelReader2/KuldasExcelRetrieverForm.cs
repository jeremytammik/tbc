﻿using Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

//using Excel;
//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;

namespace GregsExcelReader2
{
    public partial class KuldasExcelRetrieverForm : Form
    {        
        public KuldasExcelRetrieverForm()
        {
            InitializeComponent();
            //LoadSheets();  //>>>>>Automatically loads sheet per path below.  Want 'Load Sheet' Button to do this instead.
        }

        OpenFileDialog ofd = new OpenFileDialog();

        private void button1_Click(object sender, EventArgs e)  //>>>>>>SELECT FILE
        {
            ofd.Filter = "XLS (*.xlsx, *.xlsm)|*.xlsx; *xlsm";  //.....DELETE '*.xlsx' IF ONLY WANT xlsm FILES USED.
            if (ofd.ShowDialog() == DialogResult.OK);
            {
                textBox1.Text = ofd.FileName;
                //textBox1.Text = ofd.SafeFileName;
            }
        }
      
        //private void LoadSheets()
        //{

        private void button2_Click_1(object sender, EventArgs e)  //>>>>>>>>LOAD SHEET
        {                   
            string _PathFilename = textBox1.Text;    //@"C:\Users\Greg Kulda\Documents\Specifications\Revit- Specifications\GENERAL NOTES FILE (TEST).xlsm";
            using (FileStream streamIn = File.Open(_PathFilename, FileMode.Open, FileAccess.Read))
            using (IExcelDataReader execlReader = (Path.GetExtension(_PathFilename) == ".xlsm" ? ExcelReaderFactory.CreateOpenXmlReader(streamIn) : ExcelReaderFactory.CreateBinaryReader(streamIn)))

            {
                DataSet ds = new DataSet();
                ds = execlReader.AsDataSet();

                //int r = ds.Tables[0].Rows.Count;
                //int c = ds.Tables[0].Columns.Count;

                if (ds.Tables.Count < 1)
                {
                    MessageBox.Show("No sheets in workbook.");
                }               
                else
                {
                    //int x = 0, y = 0;
                    foreach (DataTable sheet in ds.Tables)
                    {
                        DataGridView dgv = excelSheetDataGridView;  //>>>>>>>>> USES EXISTING DATA GRID VIEW
                        
                        //DataGridView dgv = new DataGridView();  //>>>>>>> CREATES NEW DATA GRID VIEW
                        //dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
                        //dgv.Location = new System.Drawing.Point(0, 50);  //WAS: dgv.Location = new Point(x += 0, y += 30);
                        //dgv.Name = "dataGridView1";
                        //dgv.Size = new System.Drawing.Size(1000, 212);
                        //dgv.TabIndex = 0;
                        //dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;  //>>>Autosizes all columns to same width.

                        //dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;  //>>>Autosizes to fit all text without wrapping.
                        //dgv.Columns[0].Width = 10;  //Does not work
                        //dgv.Columns[1].Width = 30;  //Does not work


                        dgv.DataSource = sheet;


                        this.Controls.Add(dgv);
                    }
                    
                }
            }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
        }      
            
    }
}
