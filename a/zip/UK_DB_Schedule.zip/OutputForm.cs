﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UK_DB_Schedule
{
  public partial class OutputForm : Form
  {
    public OutputForm(IEnumerable a)
    {
      InitializeComponent();
      foreach (string s in a)
      {
        if (s != "")
          ReportListBox.Items.Add(s);
      }
      ReportListBox.SetSelected(0, true);
    }

    private void OutputForm_Load(object sender, EventArgs e)
    {

    }

    private void button1_Click(object sender, EventArgs e)
    {
      mSelectedPanel = (string)ReportListBox.SelectedItem;
    }

    private void ReportListBox_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
  }
}
