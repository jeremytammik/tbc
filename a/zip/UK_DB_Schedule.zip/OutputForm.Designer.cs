﻿namespace UK_DB_Schedule
{
  partial class OutputForm
  {
    public string mSelectedPanel;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.ReportListBox = new System.Windows.Forms.ListBox();
      this.button1 = new System.Windows.Forms.Button();
      this.cancel_button = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // ReportListBox
      // 
      this.ReportListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.ReportListBox.FormattingEnabled = true;
      this.ReportListBox.Location = new System.Drawing.Point(12, 12);
      this.ReportListBox.Name = "ReportListBox";
      this.ReportListBox.Size = new System.Drawing.Size(396, 186);
      this.ReportListBox.TabIndex = 0;
      this.ReportListBox.SelectedIndexChanged += new System.EventHandler(this.ReportListBox_SelectedIndexChanged);
      // 
      // button1
      // 
      this.button1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
      this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.button1.Location = new System.Drawing.Point(124, 217);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(77, 23);
      this.button1.TabIndex = 1;
      this.button1.Text = "OK";
      this.button1.UseVisualStyleBackColor = true;
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // cancel_button
      // 
      this.cancel_button.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
      this.cancel_button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cancel_button.Location = new System.Drawing.Point(221, 216);
      this.cancel_button.Name = "cancel_button";
      this.cancel_button.Size = new System.Drawing.Size(75, 23);
      this.cancel_button.TabIndex = 2;
      this.cancel_button.Text = "Cancel";
      this.cancel_button.UseVisualStyleBackColor = true;
      // 
      // OutputForm
      // 
      this.AcceptButton = this.button1;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(420, 248);
      this.Controls.Add(this.cancel_button);
      this.Controls.Add(this.button1);
      this.Controls.Add(this.ReportListBox);
      this.Name = "OutputForm";
      this.Text = "Select Panel";
      this.Load += new System.EventHandler(this.OutputForm_Load);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.ListBox ReportListBox;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button cancel_button;
  }
}