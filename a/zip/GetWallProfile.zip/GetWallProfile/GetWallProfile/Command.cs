#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB.IFC;

#endregion

namespace GetWallProfile
{
    [Transaction(TransactionMode.Manual)]
    public class Command : IExternalCommand
    {
        public Result Execute(
          ExternalCommandData commandData,
          ref string message,
          ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Application app = uiapp.Application;
            Document doc = uidoc.Document;

            Reference r = uidoc.Selection.PickObject(
              ObjectType.Element, "Select a wall");

            Element e = uidoc.Document.GetElement(r);

            Wall wall = e as Wall;

            using (Transaction tx = new Transaction(doc))
            {
                tx.Start("Wall Profile");

                // Get the exteranl wall face for the profile
                IList<Reference> sideFaces = HostObjectUtils.GetSideFaces(wall, ShellLayerType.Exterior);
                Element e2 = doc.GetElement(sideFaces[0]);
                Face face = e2.GetGeometryObjectFromReference(sideFaces[0]) as Face;

                XYZ normal = face.ComputeNormal(new UV(0, 0)); // the normal of the wall external face

                Color color = new Color(255, 0, 0); // RED

                // Get edge loops as curve loops
                IList<CurveLoop> curveLoops = face.GetEdgesAsCurveLoops();

                // ExporterIFCUtils class can be used for none IFC poupose. 
                // SortCurveLoops method sorts curve loops (edge loops) so that outer loops come first
                IList<IList<CurveLoop>> curveLoopLoop = ExporterIFCUtils.SortCurveLoops(curveLoops);

                foreach (IList<CurveLoop> curveLoops2 in curveLoopLoop)
                {
                    foreach (CurveLoop curveLoop2 in curveLoops)
                    {
                        // check if curve loop (edge loop) is counter clockwise
                        bool isCCW = curveLoop2.IsCounterclockwise(normal);

                        Transform tranlate = Transform.CreateTranslation(normal.Multiply(5));
                        CurveArray curves = doc.Application.Create.NewCurveArray();
                        foreach (Curve curve in curveLoop2)
                        {
                            curves.Append(curve.CreateTransformed(tranlate)); // Ofset the curve for visibility
                        }

                        // Create model lines for an cureve loop
                        SketchPlane sketchPlane = SketchPlane.Create(doc, doc.Application.Create.NewPlane(curves));
                        ModelCurveArray curveElements = doc.Create.NewModelCurveArray(curves, sketchPlane);

                        // if the curve loop direction is counter clockwise, change the color to RED
                        if (isCCW)
                        {
                            foreach (ModelCurve mcurve in curveElements)
                            { 
                                OverrideGraphicSettings overrides = doc.ActiveView.GetElementOverrides(mcurve.Id);
                                overrides.SetProjectionLineColor(color);
                                doc.ActiveView.SetElementOverrides(mcurve.Id, overrides);
                            }
                        }
                    }
                }
     
                tx.Commit();
            }
            return Result.Succeeded;

        }
    }
}
