﻿namespace AddMaterials.ViewModel.Enum
{
    public enum Status
    {
        Normal,

        BaseMaterialClassNotFound,

        ProjectAlreadyContainsMaterialWithTheSameName
    }
}