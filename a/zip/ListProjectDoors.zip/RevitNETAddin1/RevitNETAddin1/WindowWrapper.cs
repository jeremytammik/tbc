﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace RevitNETAddin1
{
    public class WindowWrapper : System.Windows.Forms.IWin32Window
    {
        public WindowWrapper(IntPtr RevitWindowHandle)
        {
            _hwnd = RevitWindowHandle;
        }

        public WindowWrapper()
        {
            _hwnd = GetRevitHandle();
        }

        public IntPtr GetRevitHandle()
        {
            Process process = Process.GetCurrentProcess();
            IntPtr h = process.MainWindowHandle;
            return h;
        }

        public IntPtr Handle
        {
            get { return _hwnd; }
        }

        private IntPtr _hwnd;
    }
}
