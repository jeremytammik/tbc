﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;


using Autodesk.Revit;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.ApplicationServices;
using System.Threading;
 

namespace Roof
{

    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
    [Autodesk.Revit.Attributes.Journaling(Autodesk.Revit.Attributes.JournalingMode.NoCommandData)]



    public class Program : IExternalCommand
    {



        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            // Quit if active document is null
            //if (null == commandData.Application.ActiveUIDocument.Document)
            //{
            //    message = "Active document is null.";
            //    return Result.Failed;
            //}


            //Autodesk.Revit.UI.UIApplication app = commandData.Application;
            //Document document = commandData.Application.ActiveUIDocument.Document;

            #region Dialog show

            //AccessDB ac = new AccessDB();
            //ac.CheckConnection();

            Document revitDoc = commandData.Application.Application.NewFamilyDocument(@"c:\ProgramData\Autodesk\RVT 2013\Family Templates\Chinese\公制常规模型.rft");
            //UserForm form = new UserForm(document);
            UserForm form = new UserForm(revitDoc);


            form.ShowDialog();
    
   





            #endregion





            return Autodesk.Revit.UI.Result.Succeeded;

        }






















    } //end of class    
} //end of namespace
