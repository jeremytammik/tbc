﻿Namespace ObjRel
    Partial Class Result
        ''' <summary>
        ''' Required designer variable.
        ''' </summary>
        Private components As System.ComponentModel.IContainer = Nothing

        ''' <summary>
        ''' Clean up any resources being used.
        ''' </summary>
        ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub

#Region "Windows Form Designer generated code"

        ''' <summary>
        ''' Required method for Designer support - do not modify
        ''' the contents of this method with the code editor.
        ''' </summary>
        Private Sub InitializeComponent()
            Me.treeView1 = New System.Windows.Forms.TreeView()
            Me.SuspendLayout()
            '
            'treeView1
            '
            Me.treeView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                        Or System.Windows.Forms.AnchorStyles.Left) _
                        Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.treeView1.Location = New System.Drawing.Point(12, 12)
            Me.treeView1.Name = "treeView1"
            Me.treeView1.Size = New System.Drawing.Size(514, 290)
            Me.treeView1.TabIndex = 0
            '
            'Result
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(538, 314)
            Me.Controls.Add(Me.treeView1)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "Result"
            Me.Text = "Parent-Child Relationships"
            Me.ResumeLayout(False)

        End Sub

#End Region

        Private treeView1 As System.Windows.Forms.TreeView
    End Class
End Namespace
