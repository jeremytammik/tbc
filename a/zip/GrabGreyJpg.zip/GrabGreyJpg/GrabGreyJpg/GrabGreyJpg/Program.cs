﻿#region Header
// Grab greyscale image from Internet webcam.
//
// Copyright (C) 2010 by Jeremy Tammik, Autodesk Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this software
// for any purpose and without fee is hereby granted, provided
// that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
#endregion // Header

#region Namespaces
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Net;
using System.IO;
using System.Windows;
using System.Windows.Media; // WindowsBase
using System.Windows.Media.Imaging; // PresentationCore
#endregion // Namespaces

namespace GrabGreyJpg
{
  /// <summary>
  /// Grab greyscale image from Internet webcam.
  /// By Jeremy Tammik, http://thebuildingcoder.typepad.com.
  /// </summary>
  class Program
  {
    const string _url = 
      "http://www.ggb.ch/webcam.php?e_1__getimage=1";

    static BitmapSource ConvertBitmapToBitmapSource( 
      Bitmap bmp )
    {
      return System.Windows.Interop.Imaging
        .CreateBitmapSourceFromHBitmap( 
          bmp.GetHbitmap(), 
          IntPtr.Zero, 
          Int32Rect.Empty, 
          BitmapSizeOptions.FromEmptyOptions() );
    }

    static void Main( string[] args )
    {
      using( WebClient client = new WebClient() )
      {
        byte[] data = client.DownloadData( _url );

        using( Image img = Image.FromStream( 
          new MemoryStream( data ) ) )
        {
          string filename = "a.jpg";
          img.Save( filename, ImageFormat.Jpeg );

          // test display original:

          Process.Start( filename );

          // scale down to half size in each direction:

          int w = img.Width >> 1; 
          int h = img.Height >> 1;

          Bitmap bitmap = new Bitmap( 
            img.GetThumbnailImage( w, h, null, 
              IntPtr.Zero ) );

          FormatConvertedBitmap grey 
            = new FormatConvertedBitmap();

          grey.BeginInit();

          grey.Source 
            = ConvertBitmapToBitmapSource( bitmap );

          grey.DestinationFormat 
            = PixelFormats.Gray32Float;

          grey.EndInit();

          JpegBitmapEncoder encoder 
            = new JpegBitmapEncoder();

          encoder.Frames.Add( 
            BitmapFrame.Create( grey ) );

          encoder.QualityLevel = 25;

          string filename2 = "a2.jpg";

          FileStream file = new FileStream( 
            filename2, FileMode.Create, 
            FileAccess.Write );

          encoder.Save( file );
          file.Close();

          // test display greyscale:

          Process.Start( filename2 ); 
        }
      }
    }
  }
}
