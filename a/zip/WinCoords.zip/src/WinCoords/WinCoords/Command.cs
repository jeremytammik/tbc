#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion

namespace WinCoords
{
  [Transaction( TransactionMode.ReadOnly )]
  public class Command : IExternalCommand
  {
    /// <summary>
    /// Return a string for a real number 
    /// formatted to two decimal places.
    /// </summary>
    static string RealString( double a )
    {
      return a.ToString( "0.##" );
    }

    /// <summary>
    /// Return a string for a XYZ point
    /// or vector with its coordinates 
    /// formatted to two decimal places.
    /// </summary>
    static string PointString( XYZ p )
    {
      return string.Format( "({0},{1},{2})",
        RealString( p.X ),
        RealString( p.Y ),
        RealString( p.Z ) );
    }

    /// <summary>
    /// Return a string representing the 
    /// given Rectangle instance size, in
    /// the order left+top, right+bottom.
    /// Windows coordinates reverse the Y 
    /// direction!
    /// </summary>
    static string RectangleString( Rectangle r )
    {
      return string.Format( "({0},{1})-({2},{3})",
        r.Left, r.Top, r.Right, r.Bottom );
    }
    
    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Document doc = uidoc.Document;
      View view = doc.ActiveView;
      UIView uiview = null;
      IList<UIView> uiviews = uidoc.GetOpenUIViews();

      foreach( UIView uv in uiviews )
      {
        if( uv.ViewId.Equals( view.Id ) )
        {
          uiview = uv;
          break;
        }
      }

      Rectangle rect = uiview.GetWindowRectangle();
      IList<XYZ> corners = uiview.GetZoomCorners();
      XYZ p = corners[0];
      XYZ q = corners[1];

      string msg = string.Format( 
        "UIView Windows rectangle: {0}; "
        + "zoom corners: {1}-{2}; "
        + "click Close to zoom in by 10%.", 
        RectangleString( rect ), 
        PointString( p ), PointString( q ) );

      TaskDialog.Show( "WinCoords", msg );

      // Calculate new zoom corners to 
      // zoom in by 10%, i.e. the two corners
      // end up at 0.45 of their previous
      // distance to the centre point.

      XYZ v = q - p;
      XYZ center = p + 0.5 * v;
      v *= 0.45;
      p = center - v;
      q = center + v;

      uiview.ZoomAndCenterRectangle( p, q );

      return Result.Succeeded;
    }
  }
}
