﻿using System;
using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Geometry;

public class RevitCommand : IExternalCommand
{
  void f(
    Application app,
    Document doc )
  {
    XYZ p = XYZ.Zero;
    XYZ norm = XYZ.BasisZ;
    double startAngle = 0;
    double endAngle = 2 * Math.PI;
    double radius = 1.23;

    Plane plane = new Plane( norm, p );

    Arc arc = app.Create.NewArc(
      plane, radius, startAngle, endAngle );

    DetailArc detailArc
      = doc.Create.NewDetailCurve(
        doc.ActiveView, arc ) as DetailArc;
  }

  public IExternalCommand.Result Execute(
    ExternalCommandData commandData,
    ref string messages,
    ElementSet elements )
  {
    Application app = commandData.Application;
    Document doc = app.ActiveDocument;

    // Create an arc on the plane whose 
    // center is at the plane origin:

    XYZ end0 = new XYZ( 0, 0, 1 );
    XYZ end1 = new XYZ( 1, 3, 2 );
    XYZ norm;
    
    if( end0.X == end1.X )
    {
      norm = XYZ.BasisZ;
    }
    else if ( end0.Y == end1.Y )
    {
      norm = XYZ.BasisZ;
    }
    else
    {
      norm = XYZ.BasisZ;
    }

    double startAngle = 0;
    double endAngle = 2 * Math.PI;
    double radius = 5;

    Plane objPlane 
      = app.Create.NewPlane( norm, XYZ.Zero );

    // ViewPlan of "Level 2"
    
    ViewPlan vp2 = null;

    ElementIterator ei 
      = doc.get_Elements( typeof( ViewPlan ) );

    while( ei.MoveNext() )
    {
      ViewPlan vp = ei.Current as ViewPlan;

      if( vp.GenLevel.Name.Equals( "Level 2" ) )
      {
        vp2 = vp;
        break;
      }
    }

    if( null == vp2 )
    {
      vp2 = doc.ActiveView as ViewPlan;
    }

    if( null != vp2 )
    {
      // draw the circle:

      Arc arc = app.Create.NewArc( objPlane,
        radius, startAngle, endAngle );

      DetailArc detailArc
        = doc.Create.NewDetailCurve(
          vp2, arc ) as DetailArc;
    }
    return (null == vp2)
      ? IExternalCommand.Result.Failed
      : IExternalCommand.Result.Succeeded;
  }
}
