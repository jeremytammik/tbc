Place �LRUG_01_Basic� folder in
C:\Program Files\Autodesk\Revit Architecture2011\Program\VstaMacros\AppHookup\

NOTE
Code structure is kept to the bare minimum for simplicity, so ->
1 : Little or no error-checking provided
2 : Object-oriented technology is ignored -> users should investigate Classes and encapsulation
3 : Examples highlight re-usability of code -> cut and paste to bootstrap projects