﻿
namespace OpenRevitOleStorage
{
 /// <summary>An enumerate to list Revit Product Type. </summary>
 public enum ProductType
 {
  Architecture,
  Structure,
  MEP,
  Unknown
 }
}
