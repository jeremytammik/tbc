﻿
namespace OpenRevitOleStorage
{
 /// <summary>An enumerate to list Revit Platform Type. </summary>
 public enum PlatformType
 {
  x86,
  x64,
  Unknown
 }
}
