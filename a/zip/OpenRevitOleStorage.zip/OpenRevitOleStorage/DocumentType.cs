﻿

namespace OpenRevitOleStorage
{
 /// <summary>Types of Revit documents.</summary>
 public enum DocumentType
 {
  Project,
  Family,
  ProjectTemplate,
  FamilyTemplate,
  Unknown
 }
}
