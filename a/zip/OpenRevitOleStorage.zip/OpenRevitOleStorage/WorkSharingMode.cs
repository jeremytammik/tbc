﻿
namespace OpenRevitOleStorage
{
 
 public enum WorkSharingMode
 {
  NotEnabled,
  Local,
  Central,
  Unknown
 }

}
