﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Collections;
using System.Diagnostics;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB.Structure;
using System.Security.Util;
using System.IO;
using Autodesk.Revit.DB.Events;
using System.Reflection;
using System.Globalization;
using System.Resources;
using Autodesk.Revit.DB.Architecture;


namespace DataToBim
{
  class DataToTopography
  {
    public readonly int NumberOfFailedPoints;
    public readonly TopographySurface Topography;
    public DataToTopography( Document document, List<List<XYZ>> contours, double interpolationLength = 10, double proximityTolerance = 5 )
    {
      Dictionary<string, XYZ> dict = new Dictionary<string, XYZ>();
      int counter = 0;
      foreach( List<XYZ> cntr in contours )
      {
        ProcessPolygon processedContour = new ProcessPolygon( cntr );
        processedContour.LoadEdgeLengths();
        processedContour.RemoveClosePoints( proximityTolerance );
        processedContour.Interpolate( interpolationLength );
        processedContour.LoadEdgeLengths();
        foreach( XYZ item in processedContour.ProcessedPolygon )
        {
          string key = item.X.ToString() + item.Y.ToString();
          try
          {
            dict.Add( key, item );
          }
          catch( Exception )
          {
            //MessageBox.Show(er.Message);
            counter++;
          }
        }
      }
      this.NumberOfFailedPoints = counter;
      List<XYZ> pnts = new List<XYZ>();
      foreach( var item in dict.Keys )
      {
        XYZ pn;
        if( dict.TryGetValue( item, out pn ) )
        {
          pnts.Add( pn );
        }
      }
      Transaction createTopography = new Transaction( document, "Create Topography" );
      createTopography.Start();
      this.Topography = TopographySurface.Create( document, pnts );
      createTopography.Commit();
    }
  }

}
