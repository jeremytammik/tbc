#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB.Architecture;
#endregion

namespace DataToBim
{
  /// <summary>
  /// Failures preprocessor to swallow warnings
  /// </summary>
  public class WarningSwallower : IFailuresPreprocessor
  {
    public FailureProcessingResult PreprocessFailures( 
      FailuresAccessor a )
    {
      // Inside event handler, get all warnings

      IList<FailureMessageAccessor> failures 
        = a.GetFailureMessages();

      foreach( FailureMessageAccessor f in failures )
      {
        a.DeleteAllWarnings();
      }
      return FailureProcessingResult.Continue;
    }
  }

  [Transaction( TransactionMode.Manual )]
  public class Command : IExternalCommand
  {
    /// <summary>
    /// Directory path for input text files
    /// </summary>
    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      try
      {
        UIApplication uiapp = commandData.Application;
        Document doc = uiapp.ActiveUIDocument.Document;
        // Change the Paths
        List<Building> buildings = EnvironmentalComponents.LoadBuildings(  );
        List<Contour> allContours = EnvironmentalComponents.LoadContours( );

        #region Set up timer
        Stopwatch timer = Stopwatch.StartNew();
        timer.Reset();
        StringBuilder report = new StringBuilder();
        #endregion

        #region Get Topography
        timer.Start();
        List<List<XYZ>> contours = new List<List<XYZ>>();
        foreach( Contour cntr in allContours )
        {
          contours.Add( cntr.vertices );
        }
        DataToTopography getTopo = new DataToTopography( doc, contours, 10, 5 );
        TopographySurface topoSurface = getTopo.Topography;
        timer.Stop();
        report.AppendLine( "Topography Information:" );
        report.AppendLine( timer.Elapsed.TotalSeconds.ToString() + " seconds to process the contour lines and get the points." );
        report.AppendLine( topoSurface.GetPoints().Count.ToString() + " points exist in the topography." );
        report.AppendLine( getTopo.NumberOfFailedPoints.ToString() + " points were located on the top of each other." );
        #endregion

        #region Get buildings
        timer.Reset();
        timer.Start();
        DataToBuilding getBldgs = new DataToBuilding( doc, buildings, getTopo.Topography.Id);
        timer.Stop();
        report.AppendLine( "" );
        report.AppendLine( "Building & building pad generation information:" );
        report.AppendLine( timer.Elapsed.TotalSeconds.ToString() + " seconds to create the building." );
        report.AppendLine( getBldgs.FailedAttemptsToCreateBuildings.ToString() + " times failed to generate buildings." );
        #endregion

        #region Create report
        TaskDialog.Show( "Report of process", report.ToString() );
        #endregion
      }
      catch( Exception exception )
      {
        message = exception.Message;
        return Result.Failed;
      }
      return Result.Succeeded;
    }
  }
}
