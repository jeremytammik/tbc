﻿/*
 * Revit Macro created by SharpDevelop
 * User: mycynes
 * Date: 11/29/2012
 * Time: 9:53 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace UiClose
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.UI.Macros.AddInId("FBDC2696-DFA7-4746-99AD-F2E99CEF2106")]
	public partial class ThisApplication
	{
		private void Module_Startup(object sender, EventArgs e)
		{
			m_CloseHelper = new UiCloseHelper(this, @"C:\\uiClose\\_placeholder_.rvt");
		}

		private void Module_Shutdown(object sender, EventArgs e)
		{

		}
		public void CloseActiveDocDemo()
		{
			Autodesk.Revit.UI.UIDocument doc = this.ActiveUIDocument;
			CloseHelper.CloseAndSave(doc);
		}
		#region Revit Macros generated code
		private void InternalStartup()
		{
			this.Startup += new System.EventHandler(Module_Startup);
			this.Shutdown += new System.EventHandler(Module_Shutdown);
		}
		public UiCloseHelper CloseHelper
		{
			get {return m_CloseHelper;}
		}
		private UiCloseHelper m_CloseHelper;
		#endregion
	}
}