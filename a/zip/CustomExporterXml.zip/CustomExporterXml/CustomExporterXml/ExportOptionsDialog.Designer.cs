﻿namespace CustomExporterXml
{
   partial class ExportOptionsDialog
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.txtOutputPath = new System.Windows.Forms.TextBox();
         this.btnBrowse = new System.Windows.Forms.Button();
         this.label1 = new System.Windows.Forms.Label();
         this.chkInstances = new System.Windows.Forms.CheckBox();
         this.chkLinks = new System.Windows.Forms.CheckBox();
         this.chkFaces = new System.Windows.Forms.CheckBox();
         this.chkMaterial = new System.Windows.Forms.CheckBox();
         this.chkMeshes = new System.Windows.Forms.CheckBox();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.btnSelectNone = new System.Windows.Forms.Button();
         this.btnSelectAll = new System.Windows.Forms.Button();
         this.chkApplyTransforms = new System.Windows.Forms.CheckBox();
         this.btnOK = new System.Windows.Forms.Button();
         this.btnCancel = new System.Windows.Forms.Button();
         this.label2 = new System.Windows.Forms.Label();
         this.lstViews = new System.Windows.Forms.CheckedListBox();
         this.btnAllViews = new System.Windows.Forms.Button();
         this.btnNoViews = new System.Windows.Forms.Button();
         this.groupBox1.SuspendLayout();
         this.SuspendLayout();
         // 
         // txtOutputPath
         // 
         this.txtOutputPath.Location = new System.Drawing.Point(12, 34);
         this.txtOutputPath.Name = "txtOutputPath";
         this.txtOutputPath.Size = new System.Drawing.Size(444, 20);
         this.txtOutputPath.TabIndex = 0;
         // 
         // btnBrowse
         // 
         this.btnBrowse.Location = new System.Drawing.Point(467, 32);
         this.btnBrowse.Name = "btnBrowse";
         this.btnBrowse.Size = new System.Drawing.Size(83, 24);
         this.btnBrowse.TabIndex = 1;
         this.btnBrowse.Text = "browse...";
         this.btnBrowse.UseVisualStyleBackColor = true;
         this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Location = new System.Drawing.Point(9, 18);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(66, 13);
         this.label1.TabIndex = 2;
         this.label1.Text = "Output path:";
         // 
         // chkInstances
         // 
         this.chkInstances.AutoSize = true;
         this.chkInstances.Location = new System.Drawing.Point(6, 46);
         this.chkInstances.Name = "chkInstances";
         this.chkInstances.Size = new System.Drawing.Size(72, 17);
         this.chkInstances.TabIndex = 3;
         this.chkInstances.Text = "Instances";
         this.chkInstances.UseVisualStyleBackColor = true;
         // 
         // chkLinks
         // 
         this.chkLinks.AutoSize = true;
         this.chkLinks.Location = new System.Drawing.Point(6, 24);
         this.chkLinks.Name = "chkLinks";
         this.chkLinks.Size = new System.Drawing.Size(51, 17);
         this.chkLinks.TabIndex = 3;
         this.chkLinks.Text = "Links";
         this.chkLinks.UseVisualStyleBackColor = true;
         // 
         // chkFaces
         // 
         this.chkFaces.AutoSize = true;
         this.chkFaces.Location = new System.Drawing.Point(6, 68);
         this.chkFaces.Name = "chkFaces";
         this.chkFaces.Size = new System.Drawing.Size(55, 17);
         this.chkFaces.TabIndex = 3;
         this.chkFaces.Text = "Faces";
         this.chkFaces.UseVisualStyleBackColor = true;
         // 
         // chkMaterial
         // 
         this.chkMaterial.AutoSize = true;
         this.chkMaterial.Location = new System.Drawing.Point(6, 114);
         this.chkMaterial.Name = "chkMaterial";
         this.chkMaterial.Size = new System.Drawing.Size(96, 17);
         this.chkMaterial.TabIndex = 3;
         this.chkMaterial.Text = "Material assets";
         this.chkMaterial.UseVisualStyleBackColor = true;
         // 
         // chkMeshes
         // 
         this.chkMeshes.AutoSize = true;
         this.chkMeshes.Location = new System.Drawing.Point(6, 90);
         this.chkMeshes.Name = "chkMeshes";
         this.chkMeshes.Size = new System.Drawing.Size(63, 17);
         this.chkMeshes.TabIndex = 3;
         this.chkMeshes.Text = "Meshes";
         this.chkMeshes.UseVisualStyleBackColor = true;
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.btnSelectNone);
         this.groupBox1.Controls.Add(this.btnSelectAll);
         this.groupBox1.Controls.Add(this.chkMeshes);
         this.groupBox1.Controls.Add(this.chkApplyTransforms);
         this.groupBox1.Controls.Add(this.chkMaterial);
         this.groupBox1.Controls.Add(this.chkFaces);
         this.groupBox1.Controls.Add(this.chkLinks);
         this.groupBox1.Controls.Add(this.chkInstances);
         this.groupBox1.Location = new System.Drawing.Point(302, 69);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(154, 223);
         this.groupBox1.TabIndex = 4;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Include in the output";
         // 
         // btnSelectNone
         // 
         this.btnSelectNone.Location = new System.Drawing.Point(85, 187);
         this.btnSelectNone.Name = "btnSelectNone";
         this.btnSelectNone.Size = new System.Drawing.Size(62, 23);
         this.btnSelectNone.TabIndex = 5;
         this.btnSelectNone.Text = "none";
         this.btnSelectNone.UseVisualStyleBackColor = true;
         this.btnSelectNone.Click += new System.EventHandler(this.btnSelectNone_Click);
         // 
         // btnSelectAll
         // 
         this.btnSelectAll.Location = new System.Drawing.Point(8, 187);
         this.btnSelectAll.Name = "btnSelectAll";
         this.btnSelectAll.Size = new System.Drawing.Size(63, 23);
         this.btnSelectAll.TabIndex = 4;
         this.btnSelectAll.Text = "all";
         this.btnSelectAll.UseVisualStyleBackColor = true;
         this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click);
         // 
         // chkApplyTransforms
         // 
         this.chkApplyTransforms.AutoSize = true;
         this.chkApplyTransforms.Location = new System.Drawing.Point(6, 137);
         this.chkApplyTransforms.Name = "chkApplyTransforms";
         this.chkApplyTransforms.Size = new System.Drawing.Size(124, 17);
         this.chkApplyTransforms.TabIndex = 6;
         this.chkApplyTransforms.Text = "Point transformations";
         this.chkApplyTransforms.UseVisualStyleBackColor = true;
         // 
         // btnOK
         // 
         this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
         this.btnOK.Location = new System.Drawing.Point(468, 77);
         this.btnOK.Name = "btnOK";
         this.btnOK.Size = new System.Drawing.Size(82, 24);
         this.btnOK.TabIndex = 7;
         this.btnOK.Text = "Export";
         this.btnOK.UseVisualStyleBackColor = true;
         this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
         // 
         // btnCancel
         // 
         this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
         this.btnCancel.Location = new System.Drawing.Point(468, 107);
         this.btnCancel.Name = "btnCancel";
         this.btnCancel.Size = new System.Drawing.Size(82, 24);
         this.btnCancel.TabIndex = 8;
         this.btnCancel.Text = "Close";
         this.btnCancel.UseVisualStyleBackColor = true;
         // 
         // label2
         // 
         this.label2.AutoSize = true;
         this.label2.Location = new System.Drawing.Point(11, 69);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(82, 13);
         this.label2.TabIndex = 7;
         this.label2.Text = "Views to export:";
         // 
         // lstViews
         // 
         this.lstViews.CheckOnClick = true;
         this.lstViews.Location = new System.Drawing.Point(12, 88);
         this.lstViews.Name = "lstViews";
         this.lstViews.Size = new System.Drawing.Size(274, 169);
         this.lstViews.TabIndex = 2;
         // 
         // btnAllViews
         // 
         this.btnAllViews.Location = new System.Drawing.Point(12, 267);
         this.btnAllViews.Name = "btnAllViews";
         this.btnAllViews.Size = new System.Drawing.Size(125, 24);
         this.btnAllViews.TabIndex = 9;
         this.btnAllViews.Text = "Select all";
         this.btnAllViews.UseVisualStyleBackColor = true;
         this.btnAllViews.Click += new System.EventHandler(this.btnAllViews_Click);
         // 
         // btnNoViews
         // 
         this.btnNoViews.Location = new System.Drawing.Point(161, 267);
         this.btnNoViews.Name = "btnNoViews";
         this.btnNoViews.Size = new System.Drawing.Size(125, 24);
         this.btnNoViews.TabIndex = 10;
         this.btnNoViews.Text = "Select none";
         this.btnNoViews.UseVisualStyleBackColor = true;
         this.btnNoViews.Click += new System.EventHandler(this.btnNoViews_Click);
         // 
         // ExportOptionsDialog
         // 
         this.AcceptButton = this.btnOK;
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.CancelButton = this.btnCancel;
         this.ClientSize = new System.Drawing.Size(562, 304);
         this.ControlBox = false;
         this.Controls.Add(this.btnNoViews);
         this.Controls.Add(this.btnAllViews);
         this.Controls.Add(this.lstViews);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.btnCancel);
         this.Controls.Add(this.btnOK);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.btnBrowse);
         this.Controls.Add(this.txtOutputPath);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "ExportOptionsDialog";
         this.Text = "Export Views to XML";
         this.groupBox1.ResumeLayout(false);
         this.groupBox1.PerformLayout();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.TextBox txtOutputPath;
      private System.Windows.Forms.Button btnBrowse;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.CheckBox chkInstances;
      private System.Windows.Forms.CheckBox chkLinks;
      private System.Windows.Forms.CheckBox chkFaces;
      private System.Windows.Forms.CheckBox chkMaterial;
      private System.Windows.Forms.CheckBox chkMeshes;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.Button btnOK;
      private System.Windows.Forms.Button btnCancel;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Button btnSelectNone;
      private System.Windows.Forms.Button btnSelectAll;
      private System.Windows.Forms.CheckBox chkApplyTransforms;
      private System.Windows.Forms.CheckedListBox lstViews;
      private System.Windows.Forms.Button btnAllViews;
      private System.Windows.Forms.Button btnNoViews;
   }
}