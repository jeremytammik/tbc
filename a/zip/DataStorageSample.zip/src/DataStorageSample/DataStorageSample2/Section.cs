﻿using Autodesk.Revit.DB;

namespace DataStorageSample2
{
  public class Section
  {
    public string Name { get; set; }
    public XYZ BoundingBoxMin { get; set; }
    public XYZ BoundingBoxMax { get; set; }
    public View View { get; set; }
  }
}
