Imports Autodesk.Revit
Imports CmdResult = Autodesk.Revit.IExternalApplication.Result

Public Class App
    Implements IExternalApplication

    Public Function OnShutdown(ByVal app As ControlledApplication) _
    As CmdResult Implements IExternalApplication.OnShutdown
        MsgBox("OnShutdown()")
        Return IExternalApplication.Result.Succeeded
    End Function

    Public Function OnStartup(ByVal app As ControlledApplication) _
    As CmdResult Implements IExternalApplication.OnStartup
        MsgBox("OnStartup()")
        Return IExternalApplication.Result.Succeeded
    End Function
End Class
