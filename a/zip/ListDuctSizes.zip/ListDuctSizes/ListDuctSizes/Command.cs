#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.UI;
#endregion

namespace ListDuctSizes
{
  [Transaction( TransactionMode.ReadOnly )]
  public class Command : IExternalCommand
  {
    /// <summary>
    /// List all duct sizes, thus proving that the duct 
    /// size settings available in the Revit UI through 
    /// Manage > MEP Settings > Mechanical Settings > 
    /// Duct Settings > Round/Oval/Rectangular are 
    /// indeed available via the API.
    /// </summary>
    void ListDuctSizes( Document doc )
    {
      DuctSizeSettings settings 
        = DuctSizeSettings.GetDuctSizeSettings( doc );

      foreach( KeyValuePair<DuctShape, DuctSizes> pair 
        in settings )
      {
        Debug.Print( pair.Key.ToString() );

        foreach( MEPSize size in pair.Value )
        {
          string value = FormatUtils.Format( doc, 
            UnitType.UT_HVAC_DuctSize, 
            size.NominalDiameter );

          Debug.Print( 
            "  {0}: used in size lists/sizing: {1}/{2}",
            value,
            size.UsedInSizeLists.ToString(),
            size.UsedInSizing.ToString() );
        }
      }
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Document doc = uidoc.Document;

      ListDuctSizes( doc );

      return Result.Succeeded;
    }
  }
}
