using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using IVC.NotifyBox.Controls;
using IVC.NotifyBox.ViewModel.Enums;

namespace YetAnotherBaloons
{
    [Transaction(TransactionMode.Manual)]
    public class StartWarningBaloonCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            NotifyBox.Show("Warning", "Warning! Something is not perfect :)", NotificationIcon.Warning, NotificationDuration.Medium);
            return Result.Succeeded;
        }
    }
}