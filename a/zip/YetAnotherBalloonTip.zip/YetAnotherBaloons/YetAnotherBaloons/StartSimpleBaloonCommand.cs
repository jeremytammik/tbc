using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using IVC.NotifyBox.Controls;
using IVC.NotifyBox.ViewModel.Enums;

namespace YetAnotherBaloons
{
    [Transaction(TransactionMode.Manual)]
    public class StartSimpleBaloonCommand : IExternalCommand
    {
        public Result Execute(
          ExternalCommandData commandData,
          ref string message,
          ElementSet elements)
        {
            NotifyBox.Show("Hello", "Hello from Investicionnaya Venchurnaya Companiya ;-)", NotificationDuration.Short);
            return Result.Succeeded;
        }
    }
}
