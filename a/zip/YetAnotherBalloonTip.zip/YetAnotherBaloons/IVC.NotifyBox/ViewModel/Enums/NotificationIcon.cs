namespace IVC.NotifyBox.ViewModel.Enums
{
    public enum NotificationIcon
    {
        None,

        Warning
    }
}