﻿namespace IVC.NotifyBox.ViewModel.Enums
{
    public enum NotificationDuration
    {
        VeryShort,

        Short,

        Medium,

        Long,

        VeryLong,

        ExtraLong
    }
}