﻿Imports Autodesk.Revit

Public Class App
    Implements IExternalApplication

    Public Function OnShutdown(ByVal application As ControlledApplication) _
    As IExternalApplication.Result _
    Implements IExternalApplication.OnShutdown
        Return IExternalApplication.Result.Succeeded
    End Function

    Public Function OnStartup(ByVal application As ControlledApplication) _
    As IExternalApplication.Result _
    Implements IExternalApplication.OnStartup
        System.Windows.Forms.MessageBox.Show( _
          "OnStartUp says Hello from Jeremy", _
          "OnStartUp VB")
    End Function

End Class
