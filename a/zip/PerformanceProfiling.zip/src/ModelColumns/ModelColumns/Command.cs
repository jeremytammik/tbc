﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Creation = Autodesk.Revit.Creation;

namespace hsbSoft.Revit
{
  [Transaction( TransactionMode.Automatic )]
  [Regeneration( RegenerationOption.Manual )]
  public class Command : IExternalCommand
  {
    private Document m_document;
    private Creation.Document m_createDoc;

    public Result Execute( 
      ExternalCommandData commandData, 
      ref string message, 
      ElementSet elements )
    {
      Result result = Result.Failed;
      try
      {
        m_document = commandData.Application.ActiveUIDocument.Document;
        m_createDoc = m_document.Create;

        // Keep track of the total time used:

        PerfTimer ptTotalTime = new PerfTimer( "TOTAL TIME" );
        using( ptTotalTime )
        {
          ModelColumns();
          using( PerfTimer pt = new PerfTimer( "Document.Regenerate" ) )
          {
            m_document.Regenerate();
          }
        }

        // Report all resulting time delays in a text file:

        ptTotalTime.Report();
        result = Result.Succeeded;
      }
      catch( System.Exception e )
      {
        message = e.Message;
        result = Result.Failed;
      }
      return result;
    }

    private void ModelColumns()
    {
      IList<Level> levels = GetLevels();
      if( levels.Count < 2 )
        return;

      FamilySymbol columnType = GetColumnType();
      if( columnType == null )
        return;

      ModelColumn column = new ModelColumn( m_createDoc, m_document );

      // Create 600 new columns for group 1

      ElementSet elementsForGroup1 = new ElementSet();
      for( int i = 0; i < 600; i++ )
      {
        XYZ startPoint = new XYZ( 0, i, 0 );
        XYZ endPoint = new XYZ( 0, i, 13 );

        FamilyInstance fi = column.DrawIt( startPoint, endPoint, 
          columnType, levels[0], levels[1], Math.PI * 1.25 );

        elementsForGroup1.Insert( fi );
      }

      // Create 600 new columns for group 2

      ElementSet elementsForGroup2 = new ElementSet();
      for( int i = 0; i < 600; i++ )
      {
        XYZ startPoint = new XYZ( i, 0, 0 );
        XYZ endPoint = new XYZ( i, 0, 13 );
        FamilyInstance fi = column.DrawIt( startPoint, endPoint, 
          columnType, levels[0], levels[1], Math.PI * 0.35 );

        elementsForGroup2.Insert( fi );
      }
      using( PerfTimer pt = new PerfTimer( "Creation.Document.NewGroup" ) )
      {
        m_createDoc.NewGroup( elementsForGroup1 );
        m_createDoc.NewGroup( elementsForGroup2 );
      }
    }

    FamilySymbol GetColumnType()
    {
      FilteredElementCollector columnTypes 
        = new FilteredElementCollector( m_document );

      columnTypes.OfCategory( 
        BuiltInCategory.OST_StructuralColumns );

      columnTypes.OfClass( typeof( FamilySymbol ) );
      return columnTypes.FirstElement() as FamilySymbol;
    }

    IList<Level> GetLevels()
    {
      FilteredElementCollector a 
        = new FilteredElementCollector( m_document );

      a.OfCategory( BuiltInCategory.OST_Levels );
      a.OfClass( typeof( Level ) );
      return a.ToElements().Cast<Level>().ToList<Level>();
    }
  }
}
