﻿using System;
using System.Collections.Generic;

#region Revit Header
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Creation = Autodesk.Revit.Creation;
#endregion

namespace hsbSoft.Revit
{
  public class ModelColumn
  {
    Creation.Document _createDoc;
    Document _document;

    public ModelColumn( Creation.Document createDoc, Document document )
    {
      _createDoc = createDoc;
      _document = document;
    }

    /// <summary>
    /// Create a column of the specified type between the given levels and start and end points.
    /// </summary>
    /// <param name="startPoint">start point</param>
    /// <param name="endPoint">end point</param>
    /// <param name="columnType">column family symbol</param>
    /// <param name="baseLevel">base level</param>
    /// <param name="topLevel">top level</param>
    /// <param name="dRotationAngle">rotation angle</param>
    /// <returns></returns>
    public FamilyInstance DrawIt(
      XYZ startPoint,
      XYZ endPoint,
      FamilySymbol columnType,
      Level baseLevel,
      Level topLevel,
      double dRotationAngle )
    {
      StructuralType structuralType = StructuralType.Column;
      FamilyInstance column;
      using( PerfTimer pt = new PerfTimer( "NewFamilyInstance" ) )
      {
        column = _createDoc.NewFamilyInstance( startPoint,
          columnType, baseLevel, structuralType );
      }
      using( PerfTimer pt = new PerfTimer( "Document.Regenerate" ) )
      {
        _document.Regenerate();
      }
      //sets baselevel & toplevel of the column
      if( null != column )
      {
        Parameter baseLevelParameter = column.get_Parameter(
          BuiltInParameter.FAMILY_BASE_LEVEL_PARAM );

        Parameter topLevelParameter = column.get_Parameter(
          BuiltInParameter.FAMILY_TOP_LEVEL_PARAM );

        Parameter topOffsetParameter = column.get_Parameter(
          BuiltInParameter.FAMILY_TOP_LEVEL_OFFSET_PARAM );

        Parameter baseOffsetParameter = column.get_Parameter(
          BuiltInParameter.FAMILY_BASE_LEVEL_OFFSET_PARAM );

        if( null != baseLevelParameter )
        {
          ElementId baseLevelId;
          baseLevelId = baseLevel.Id;
          ParameterSet( baseLevelParameter, baseLevelId );
        }

        if( null != topLevelParameter )
        {
          ElementId topLevelId;
          topLevelId = topLevel.Id;
          ParameterSet( topLevelParameter, topLevelId );
        }

        if( null != topOffsetParameter )
        {
          double dtopOffset = endPoint.Z - topLevel.Elevation;
          ParameterSet( topOffsetParameter, dtopOffset );
        }

        if( null != baseOffsetParameter )
        {
          double dBaseOffSet = startPoint.Z;
          ParameterSet( baseOffsetParameter, dBaseOffSet );
        }

        Parameter paramColumnBottom = column.get_Parameter(
          BuiltInParameter
          .STRUCTURAL_ANALYTICAL_PROJECT_MEMBER_PLANE_COLUMN_BOTTOM );

        if( paramColumnBottom != null )
        {
          ElementId id = new ElementId( -4 );
          ParameterSet( paramColumnBottom, id );
        }

        Parameter paramColumnTop = column.get_Parameter(
          BuiltInParameter
          .STRUCTURAL_ANALYTICAL_PROJECT_MEMBER_PLANE_COLUMN_TOP );

        if( paramColumnTop != null )
        {
          ElementId id = new ElementId( -2 );
          ParameterSet( paramColumnTop, id );
        }

        Rotate( column, dRotationAngle );
      }
      return column;
    }

    /// <summary>
    /// Rotate a column
    /// </summary>
    /// <param name="element">column</param>
    /// <param name="dAngle">angle</param>
    /// <returns></returns>
    bool Rotate( Element element, double dAngle )
    {
      bool rotated = false;

      // Rotate the element via its location curve:

      LocationPoint pointLocation = element.Location as LocationPoint;
      if( null != pointLocation )
      {
        XYZ aa = pointLocation.Point;
        XYZ cc = new XYZ( aa.X, aa.Y, aa.Z + 10 );
        Line axis = _document.Application.Create.NewLineBound( aa, cc );

        using( PerfTimer profiler
          = new PerfTimer( "Document.Rotate" ) )
        {
          rotated = _document.Rotate(
            element, axis, dAngle );
        }
        // rotated = pointLocation.Rotate(axis, dAngle);
      }
      return rotated;
    }

    /// <summary>
    /// Set a parameter value
    /// </summary>
    /// <param name="value">value</param>
    /// <param name="parameter">parameter</param>
    /// <returns></returns>
    bool ParameterSet( Parameter parameter, object value )
    {
      bool bResult = false;

      // To review performance

      using( PerfTimer pt = new PerfTimer( "Parameter.Set" ) )
      {
        Type type = value.GetType();
        if( type == typeof( int ) )
          bResult = parameter.Set( ( int ) value );
        else if( type == typeof( double ) )
          bResult = parameter.Set( ( double ) value );
        else if( type == typeof( string ) )
          bResult = parameter.Set( ( string ) value );
        else if( type == typeof( ElementId ) )
          bResult = parameter.Set( ( ElementId ) value );
      }
      return bResult;
    }
  }
}
