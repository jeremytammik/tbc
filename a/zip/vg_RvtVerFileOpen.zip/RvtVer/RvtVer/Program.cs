﻿using System;
using System.Windows.Forms;

namespace RvtVer
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            if (args.Length > 0)
            {
                //get the revit file
                Application.Run(new frmMain(args[0]));
            }
            Environment.Exit(0);


        }
    }
}
