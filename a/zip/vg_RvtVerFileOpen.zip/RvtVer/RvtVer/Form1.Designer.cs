﻿namespace RvtVer
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.lblRevitFile = new System.Windows.Forms.Label();
            this.lblRevitVersion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblRevitFile
            // 
            this.lblRevitFile.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblRevitFile.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevitFile.Location = new System.Drawing.Point(0, 0);
            this.lblRevitFile.Margin = new System.Windows.Forms.Padding(4);
            this.lblRevitFile.Name = "lblRevitFile";
            this.lblRevitFile.Size = new System.Drawing.Size(396, 47);
            this.lblRevitFile.TabIndex = 0;
            this.lblRevitFile.Text = "Opening...";
            this.lblRevitFile.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRevitVersion
            // 
            this.lblRevitVersion.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblRevitVersion.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevitVersion.Location = new System.Drawing.Point(0, 47);
            this.lblRevitVersion.Margin = new System.Windows.Forms.Padding(4);
            this.lblRevitVersion.Name = "lblRevitVersion";
            this.lblRevitVersion.Size = new System.Drawing.Size(396, 23);
            this.lblRevitVersion.TabIndex = 2;
            this.lblRevitVersion.Text = "With Revit...";
            this.lblRevitVersion.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 90);
            this.ControlBox = false;
            this.Controls.Add(this.lblRevitVersion);
            this.Controls.Add(this.lblRevitFile);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Revit File Opener";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.frmMain_Shown);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblRevitFile;
        private System.Windows.Forms.Label lblRevitVersion;
    }
}

