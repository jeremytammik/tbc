﻿namespace RvtVer
{
    enum Action
    {
        Prepend,
        Append,
        Clear
    };
}
