// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

//
// use the Project > Properties > Common Properties > References
// instead of #using statements to control additional features
// like setting 'Copy Local' to false.
//
//#using <System.Windows.Forms.dll>
//#using <RevitAPI.dll>
