﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAM_Model_Viewer_Utilities
{
    public static class IPCUtilities
    {

    }
}
