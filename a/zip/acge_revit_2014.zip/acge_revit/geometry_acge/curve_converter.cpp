#include "stdafx.h"
#include "curve_converter.h"

using namespace System;

namespace RvtDB = Autodesk::Revit::DB;
namespace RvtCrt = Autodesk::Revit::Creation;

namespace Geometry { 
  namespace AcGe {

  std::unique_ptr<AcGeCurve3d> Converter::createAcGeCurve(RvtDB::Curve^ curve)
  {
    RvtDB::Line^ line = dynamic_cast<RvtDB::Line^>(curve);
    if (line != nullptr)
      return createAcGeLinear(line);
    /*else if (curve is RvtDB::Arc)
      return createAcGeLinear((RvtDB::Arc)curve);*/

    throw gcnew NotImplementedException();
  }

  RvtDB::Curve^ Converter::createRevitCurve(RvtCrt::Application^ app, const AcGeCurve3d* curve)
  {
    if (curve->isKindOf(::AcGe::kLinearEnt3d))
      return createRevitLine(app, static_cast<const AcGeLinearEnt3d*>(curve));

    throw gcnew NotImplementedException();
  }

  std::unique_ptr<AcGeLinearEnt3d> Converter::createAcGeLinear(RvtDB::Line^ line)
  {
    if (line == nullptr)
      throw gcnew ArgumentNullException();

    auto firstPt  = createAcGePoint(line->EndPoint[0]);
    auto secondPt = createAcGePoint(line->EndPoint[1]);

    // Creates a new AcGeLine3d if the input line is unbound, otherwise an AcGeLineSeg3d.
    std::unique_ptr<AcGeLinearEnt3d> linear;

    if (line->IsBound)
      linear.reset(new AcGeLineSeg3d(*firstPt, *secondPt));
    else
      linear.reset(new AcGeLine3d(*firstPt, *secondPt));

    return linear;
  }

  RvtDB::Line^ Converter::createRevitLine(RvtCrt::Application^ app, const AcGeLinearEnt3d* curve)
  {
    if (curve->isKindOf(::AcGe::kLine3d))
    {
      const AcGeLine3d* line = static_cast<const AcGeLine3d*>(curve);
      // Unbounded line
      const AcGePoint3d& pt = line->pointOnLine();
      const AcGeVector3d& direction = line->direction();

      //RvtDB::Line^ rvtLine = app->NewLineUnbound(createRevitXYZ(&pt), createRevitXYZ(&direction)); // 2013
      RvtDB::Line^ rvtLine = RvtDB::Line::CreateUnbound(createRevitXYZ(&pt), createRevitXYZ(&direction)); // 2014
      return rvtLine;
    }
    else if (curve->isKindOf(::AcGe::kLineSeg3d))
    {
      const AcGeLineSeg3d* line = static_cast<const AcGeLineSeg3d*>(curve);
      // Unbounded line
      const AcGePoint3d& startPt = line->startPoint();
      const AcGePoint3d& endPt  = line->endPoint();

      //RvtDB::Line^ rvtLine = app->NewLineBound(createRevitXYZ(&startPt), createRevitXYZ(&endPt)); // 2013
      RvtDB::Line^ rvtLine = RvtDB::Line::CreateBound(createRevitXYZ(&startPt), createRevitXYZ(&endPt)); // 2014
      return rvtLine;
    }

    //@todo AcGeRay3d
    throw gcnew NotImplementedException();
  }


  /* std::unique_ptr<AcGeCircArc3d> createAcGeArc(RvtDB::Arc^ curve)
  {

  }*/

  std::unique_ptr<AcGePoint3d> Converter::createAcGePoint(Autodesk::Revit::DB::XYZ^ xyz)
  {
    std::unique_ptr<AcGePoint3d> pt(new AcGePoint3d(xyz->X, xyz->Y, xyz->Z));
    return pt;
  }

  RvtDB::XYZ^ Converter::createRevitXYZ(const AcGePoint3d* pt)
  {
    return gcnew RvtDB::XYZ(pt->x, pt->y, pt->z);
  }

  std::unique_ptr<AcGeVector3d> Converter::createAcGeVector(Autodesk::Revit::DB::XYZ^ xyz)
  {
    std::unique_ptr<AcGeVector3d> vec(new AcGeVector3d(xyz->X, xyz->Y, xyz->Z));
    return vec;
  }

  RvtDB::XYZ^ Converter::createRevitXYZ(const AcGeVector3d* vec)
  {
    RvtDB::XYZ^ rvtVec = gcnew RvtDB::XYZ(vec->x, vec->y, vec->z);
    return rvtVec->Normalize();
  }

  std::unique_ptr<AcGePlane> Converter::createAcGePlane(Autodesk::Revit::DB::Plane^ plane)
  {
    auto origin = createAcGePoint(plane->Origin);
    auto normal = createAcGeVector(plane->Normal);

    return std::unique_ptr<AcGePlane>(new AcGePlane(*origin, *normal));
  }

  Autodesk::Revit::DB::Plane^ Converter::createRevitPlane(const AcGePlane* plane)
  {
    RvtDB::XYZ^ origin = createRevitXYZ(&plane->pointOnPlane());
    RvtDB::XYZ^ normal = createRevitXYZ(&plane->pointOnPlane());

    return gcnew RvtDB::Plane(normal, origin);
  }

  RvtDB::GeometryObject^ Helper::orthoProjectIntoPlane(RvtDB::Curve^ curve, RvtDB::Plane^ plane, RvtCrt::Application^ app)
  {
    // Create a temporary AcGeCurve and AcGePlane
    auto geCurvePtr = Converter::createAcGeCurve(curve);
    auto gePlanePtr = Converter::createAcGePlane(plane);

    // Use the temporary AcGe objects to do the projection operation
    const std::unique_ptr<AcGeEntity3d> projectedCurvePtr(geCurvePtr->orthoProject(*gePlanePtr));

    // Create a new Revit Curve or XYZ from the AcGe curve that resulted from the projection operation
    if (projectedCurvePtr->isKindOf(::AcGe::kCurve3d))
    {
      const AcGeCurve3d* geEnt = static_cast<const AcGeCurve3d*>(projectedCurvePtr.get());
      RvtDB::Curve^ rvtObj = Converter::createRevitCurve(app, geEnt);
      return rvtObj;
    }
    else if (projectedCurvePtr->isKindOf(::AcGe::kPointEnt3d))
    {
      const AcGePointEnt3d* geEnt = static_cast<const AcGePointEnt3d*>(projectedCurvePtr.get());
      RvtDB::XYZ^ rvtObj = Converter::createRevitXYZ(&geEnt->point3d());
      RvtDB::Point^ p = app->NewPoint(rvtObj);
      return p; // crash here -- jeremy
    }
    throw gcnew NotImplementedException(); 
  }

  RvtDB::GeometryObject^ Helper::projectIntoPlane(RvtDB::Curve^ curve, RvtDB::Plane^ plane, RvtCrt::Application^ app)
  {
    // Create a temporary AcGeCurve and AcGePlane
    auto geCurvePtr = Converter::createAcGeCurve(curve);
    auto gePlanePtr = Converter::createAcGePlane(plane);

    // Use the temporary AcGe objects to do the projection operation
    const std::unique_ptr<AcGeEntity3d> projectedCurvePtr(geCurvePtr->project(*gePlanePtr, gePlanePtr->normal()));

    // Create a new Revit Curve or XYZ from the AcGe curve that resulted from the projection operation
    if (projectedCurvePtr->isKindOf(::AcGe::kCurve3d))
    {
      const AcGeCurve3d* geEnt = static_cast<const AcGeCurve3d*>(projectedCurvePtr.get());
      RvtDB::Curve^ rvtObj = Converter::createRevitCurve(app, geEnt);
      return rvtObj;
    }
    else if (projectedCurvePtr->isKindOf(::AcGe::kPointEnt3d))
    {
      const AcGePointEnt3d* geEnt = static_cast<const AcGePointEnt3d*>(projectedCurvePtr.get());
      RvtDB::XYZ^ rvtObj = Converter::createRevitXYZ(&geEnt->point3d());
      return app->NewPoint(rvtObj);
    }
    throw gcnew NotImplementedException(); 
  }
  }
}
