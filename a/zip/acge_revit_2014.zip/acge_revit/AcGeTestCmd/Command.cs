#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion

namespace AcGeTestCmd
{
  [Transaction( TransactionMode.ReadOnly )]
  public class Command : IExternalCommand
  {
    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Application app = uiapp.Application;
      Document doc = uidoc.Document;

      Autodesk.Revit.Creation.Application creator = app.Create;

      // Plane with normal in z-direction

      Plane plane = new Plane( -XYZ.BasisZ, XYZ.Zero );

      // Line in Z direction

      XYZ lineStartPt = new XYZ( 0, 0, 10 );
      XYZ lineEndPt = new XYZ( 0, 0, 100 );
      Line lineInZ = Line.CreateBound( 
        lineStartPt, lineEndPt );

      GeometryObject projection = Geometry.AcGe.Helper
        .orthoProjectIntoPlane( lineInZ, plane, 
          creator );

      if( projection is Point )
      {
        XYZ pt = ( (Point) projection ).Coord;
      }

      // Line diagonal

      lineStartPt = new XYZ( 0, 0, 0 );
      lineEndPt = new XYZ( 100, 0, 100 );
      Line lineDiagonal = Line.CreateBound( 
        lineStartPt, lineEndPt );
      double lineLen = lineDiagonal.Length;

      projection = Geometry.AcGe.Helper
        .orthoProjectIntoPlane( lineDiagonal, 
          plane, creator );

      if( projection is Line )
      {
        Line l = (Line) projection;
        XYZ pt1 = l.GetEndPoint( 0 );
        XYZ pt2 = l.GetEndPoint( 1 );
        lineLen = l.Length;
      }

      projection = Geometry.AcGe.Helper
        .projectIntoPlane( lineDiagonal, 
          plane, creator );

      if( projection is Line )
      {
        Line l = (Line) projection;
        XYZ pt1 = l.GetEndPoint( 0 );
        XYZ pt2 = l.GetEndPoint( 1 );
        lineLen = l.Length;
      }
      return Result.Succeeded;
    }
  }
}
