﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Adam Nagy 2012 - ADN/Developer Technical Services
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using System.Configuration;
using System.ComponentModel;
using System.Collections.Generic;
using System.ServiceModel.Configuration;

using AdnRvtCloudConsole.AdnViewerSrv;
using AdnMeshDataUtils;
using Newtonsoft.Json;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;

namespace AdnRvtCloudConsole
{
  /////////////////////////////////////////////////////////////////////////////
  // CloudConsole Control class
  //
  /////////////////////////////////////////////////////////////////////////////
  public partial class CloudConsoleCtrl : UserControl
  {
    public class MyExternalEventHandler : IExternalEventHandler
    {
      CloudConsoleCtrl _ctrl;

      public MyExternalEventHandler(CloudConsoleCtrl ctrl)
      {
        _ctrl = ctrl;
      }

      public void Execute(UIApplication app)
      {
        string filename = System.IO.Path.GetTempFileName();

        AdnRvtMeshDataProvider meshData = new AdnRvtMeshDataProvider();

        Document doc = app.ActiveUIDocument.Document;

        if (!meshData.MeshModel(doc, filename, true))
        {
          _ctrl._progressBar.LabelText = "Meshing failed...";
          _ctrl._progressBar.Value = 0;

          return;
        }

        AdnDbModelData modelData = new AdnDbModelData(
            Guid.NewGuid().ToString(),
            doc.Title.Replace(".rvt", ""),
            3, // Model doc type id
            meshData.FacetCount,
            meshData.VertexCount);

        _ctrl.Cursor = Cursors.WaitCursor;

        _ctrl._bUpload.Enabled = false;

        UploadArgs uploadArgs = new UploadArgs(
            modelData,
            meshData);

        Thread thread = new Thread(() => _ctrl.DoUpload(uploadArgs));

        thread.Start();
      }

      //public void Execute(UIApplication app)
      //{
      //  AdnRevitMeshData meshData =
      //      new AdnRevitMeshData();

      //  Document doc = app.ActiveUIDocument.Document;

      //  string filename = System.IO.Path.GetTempFileName();

      //  _ctrl._currentArgs.FullFileName = filename;

      //  _ctrl._currentArgs.ModelData = new AdnDbModelData(
      //      Guid.NewGuid().ToString(),   //doc.InternalName,
      //      doc.Title,
      //      2); // doc type number

      //  bool res = meshData.SaveToFile(
      //      doc,
      //      filename,
      //      true);

      //  /*
      //    if (doc != InvApp.ActiveDocument)
      //        doc.Close(true);
      //  */
      //  if (res != true)
      //  {
      //    _ctrl._progressBar.LabelText = "Upload failed...";
      //    _ctrl._progressBar.Value = 0;
      //  }

      //  _ctrl.Cursor = Cursors.WaitCursor;

      //  _ctrl._bUpload.Enabled = false;

      //  Thread thread = new Thread(new ThreadStart(_ctrl.doUpload));

      //  thread.Start();
      //}



      public string GetName()
      {
        return "MyCommand";
      }
    }

    private ExternalEvent _myEvent;
    private MyExternalEventHandler _myHandler;

    string _hostAddress = "23.23.212.64:80";
    //string _hostAddress = "localhost:80";

    IAdnViewerConsoleSrv _serviceClient;

    public LabeledProgressBar _progressBar;

    ContextMenu _ctxMenuOptions;

    ContextMenu _ctxMenuTreeNode;

    /////////////////////////////////////////////////////////////////////////////
    // Constructor
    //
    /////////////////////////////////////////////////////////////////////////////
    public CloudConsoleCtrl()
    {
      InitializeComponent();

      _ctxMenuTreeNode = new ContextMenu();

      _ctxMenuTreeNode.MenuItems.Add("Delete selection").Click +=
                  new EventHandler(DeleteModels_Click);

      _progressBar = new LabeledProgressBar(0);

      _progressBar.Style = ProgressBarStyle.Continuous;

      _progressBar.Dock = DockStyle.Fill;

      _progressBar.Value = 0;
      _progressBar.Minimum = 0;
      _progressBar.Maximum = 1000;

      _panelProgress.Controls.Add(_progressBar);

      _tvModels.ImageList = imageList1;

      _tvModels.NodeMouseClick +=
          new TreeNodeMouseClickEventHandler(TreeNode_Click);

      _myHandler = new MyExternalEventHandler(this);
      _myEvent = ExternalEvent.Create(_myHandler);

      SetDefaultModel();

      BeginRefreshCloudModels();
    }

    /////////////////////////////////////////////////////////////////////////////
    // Connects to WCF service and initializes client
    //
    /////////////////////////////////////////////////////////////////////////////
    private void GetWcfClient()
    {
      if (_serviceClient != null)
        return;

      try
      {
        FileInfo fi = new FileInfo(
            System.Reflection.Assembly.GetExecutingAssembly().Location);

        string configPath = fi.DirectoryName + "\\" + "addin.config";

        Configuration config =
            ConfigurationManager.OpenMappedExeConfiguration(
                new ExeConfigurationFileMap { ExeConfigFilename = configPath },
                ConfigurationUserLevel.None);

        ConfigurationChannelFactory<IAdnViewerConsoleSrv> channelFactory =
            new ConfigurationChannelFactory<IAdnViewerConsoleSrv>(
                "WCFClientEndpoint",
                config,
                null);

        _serviceClient = channelFactory.CreateChannel();
      }
      catch (Exception ex)
      {
        _serviceClient = null;
      }
    }

    public void SetDefaultModel()
    {
      /*
        Inventor.Application InvApp = AdnInventorUtilities.InvApplication;

        if (InvApp.ActiveDocument == null)
            return;

        if (InvApp.ActiveDocument.DocumentType != DocumentTypeEnum.kAssemblyDocumentObject &&
            InvApp.ActiveDocument.DocumentType != DocumentTypeEnum.kPartDocumentObject)
            return;

        if (InvApp.ActiveDocument.FullFileName == "")
            return;

        _tbFilename.Text = InvApp.ActiveDocument.FullFileName;
       * */
    }

    /////////////////////////////////////////////////////////////////////////////
    // Refresh cloud models in browser (asychronous call)
    //
    /////////////////////////////////////////////////////////////////////////////
    public void BeginRefreshCloudModels()
    {
      _tvModels.Nodes.Clear();

      TreeNode root = _tvModels.Nodes.Add("_cloudModelsKey", "Cloud Models", 0, 0);

      try
      {
        GetWcfClient();

        HttpWebRequest request = WebRequest.Create(
            "http://" + _hostAddress + "/AdnViewerSrv/rest/GetDbModelData")
                as HttpWebRequest;

        request.BeginGetResponse(
            new AsyncCallback(GetDbModelDataAsyncInfoResponder),
            request);
      }
      catch (Exception ex)
      {

      }
    }

    private void EndRefreshCloudModels(AdnDbModelData[] modelData)
    {
      TreeNode root = _tvModels.Nodes[0];

      foreach (AdnDbModelData data in modelData)
      {
        TreeNode node = root.Nodes.Add(
            data.ModelName,
            data.ModelName,
            data.DocType + 2, 
            data.DocType + 2);

        node.Tag = data;
      }

      root.Expand();
    }

    private delegate void RefreshCloudModelsDelegate(AdnDbModelData[] modelData);

    private void GetDbModelDataAsyncInfoResponder(IAsyncResult result)
    {
      try
      {
        using (HttpWebResponse response =
            (result.AsyncState as HttpWebRequest).EndGetResponse(result)
                as HttpWebResponse)
        {
          if (result.IsCompleted)
          {
            StreamReader reader = new StreamReader(response.GetResponseStream());

            string jsonMsg = reader.ReadToEnd();

            var modelData = JsonConvert.DeserializeObject<List<AdnDbModelData>>(jsonMsg);

            this.Invoke(
                new RefreshCloudModelsDelegate(EndRefreshCloudModels),
                new object[] { modelData.ToArray() });
          }
        }
      }
      catch (Exception ex)
      {

      }
    }

    /////////////////////////////////////////////////////////////////////////////
    // Performs upload to server
    //
    /////////////////////////////////////////////////////////////////////////////
    private string GetFormattedSize(double bytes)
    {
      double mbSize = bytes / 1048576.0;

      if (mbSize > 1.0)
        return mbSize.ToString("F2") + " Mb";

      double kbSize = bytes / 1024.0;

      if (kbSize > 1.0)
        return kbSize.ToString("F2") + " Kb";

      return bytes.ToString() + " Bytes";
    }

    class UploadArgs : IDisposable
    {
      public UploadArgs(
          AdnDbModelData modelData,
          AdnRvtMeshDataProvider meshData)
      {
        ModelData = modelData;
        MeshData = meshData;

        Stream = meshData.MeshToStream(true);
      }

      public AdnDbModelData ModelData
      {
        get;
        protected set;
      }

      public AdnRvtMeshDataProvider MeshData
      {
        get;
        protected set;
      }

      public Stream Stream
      {
        get;
        protected set;
      }

      public void Dispose()
      {
        if (Stream != null)
        {
          Stream.Close();
          Stream.Dispose();
          Stream = null;
        }
      }
    };

    private void DoUpload(UploadArgs args)
    {
      try
      {
        using (ProgressStream uploadStream = new ProgressStream(args.Stream))
        {
          uploadStream.ProgressChanged += ProgressChanged;

          AdnViewerSrv.AdnRemoteModelInfo rfi =
              new AdnViewerSrv.AdnRemoteModelInfo(
                  args.Stream.Length,
                  args.ModelData,
                  uploadStream);

          _serviceClient.AddDbModel(rfi);
        }

        this.Invoke(
            new UploadResultDelegate(UploadResult),
                new object[] { true, args });
      }
      catch (Exception ex)
      {
        this.Invoke(
        new UploadResultDelegate(UploadResult),
            new object[] { false, args });
      }

      try
      {
        //Upload metadata
        foreach (AdnMetaData metaData in args.MeshData.MetaDataList)
        {
          Stream stream = AdnGZipUtils.ConvertToJsonStream(
              metaData,
              true);

          _serviceClient.AddMetaData(
              new AdnViewerSrv.AdnRemoteDataInfo(
                  metaData.Id,
                  stream.Length,
                  stream));
        }
      }
      catch (Exception ex)
      {

      }
    }

    private delegate void UploadResultDelegate(bool succeeded, UploadArgs args);

    private void UploadResult(bool succeeded, UploadArgs args)
    {
      Cursor = Cursors.Default;

      _bUpload.Enabled = true;

      if (succeeded)
      {
        long len = args.Stream.Length;

        _progressBar.LabelText = "Upload successful [" + GetFormattedSize(len) + "] ...";

        _tbFilename.Text = "";

        Refresh();

        BeginRefreshCloudModels();
      }
      else
      {
        _progressBar.LabelText = "Upload failed...";
        _progressBar.Value = 0;
      }

      args.Dispose();
    }

    private void bUpload_Click(object sender, EventArgs e)
    {
      _myEvent.Raise();
    }

    private delegate void ProgressChangedDelegate(int value);

    void ProgressChanged(
        object sender,
        ProgressStream.ProgressChangedEventArgs e)
    {
      if (e.Length != 0)
      {
        int value = (int)((double)e.BytesRead * 1000.0 / (double)e.Length);

        this.Invoke(
            new ProgressChangedDelegate(UpdateProgress),
                new object[] { value });
      }
    }

    void UpdateProgress(int value)
    {
      _progressBar.Value = value;
      _progressBar.Refresh();
    }

    /////////////////////////////////////////////////////////////////////////////
    // Right-Click menu event handler
    //
    /////////////////////////////////////////////////////////////////////////////
    private void Mouse_Click(object sender, MouseEventArgs e)
    {
      if (e.Button == System.Windows.Forms.MouseButtons.Right)
      {
        try
        {
          _ctxMenuOptions = new ContextMenu();

          _ctxMenuOptions.MenuItems.Add("Refresh Cloud Models").Click +=
              new EventHandler(RefreshCloudModels_Click);

          _ctxMenuOptions.Show(
              _panelTop1,
              _panelTop1.PointToClient(Cursor.Position));
        }
        catch
        {

        }
      }
    }

    /////////////////////////////////////////////////////////////////////////////
    // Refresh cloud models click handler
    //
    /////////////////////////////////////////////////////////////////////////////
    void RefreshCloudModels_Click(object sender, EventArgs e)
    {
      _progressBar.Value = 0;

      _progressBar.LabelText = "";

      _progressBar.Refresh();

      BeginRefreshCloudModels();
    }

    /////////////////////////////////////////////////////////////////////////////
    // Treenode right-click handler
    //
    /////////////////////////////////////////////////////////////////////////////
    private void TreeNode_Click(object sender, TreeNodeMouseClickEventArgs e)
    {
      if (e.Button == MouseButtons.Right)
      {
        if (!_tvModels.IsNodeSelected(e.Node))
        {
          _tvModels.ClearSelection();
          _tvModels.SetSelected(e.Node, true, false);
        }

        if (e.Node.Tag is AdnDbModelData)
        {
          _ctxMenuTreeNode.Show(_tvModels, e.Location);
        }
      }
    }

    /////////////////////////////////////////////////////////////////////////////
    // Delete selected cloud models in browser (asychronous call)
    //
    /////////////////////////////////////////////////////////////////////////////
    void DeleteModels_Click(object sender, EventArgs e)
    {
      foreach (TreeNode node in _tvModels.SelectedNodes)
      {
        if (node.Tag != null)
        {
          AdnDbModelData data = node.Tag as AdnDbModelData;

          _serviceClient.BeginDeleteDbModel(
              data.ModelId,
              DeleteDbModelAsyncInfoResponder,
              node);
        }
      }
    }

    private void EndDeleteModel(TreeNode node)
    {
      node.Remove();
    }

    private delegate void DeleteDbModelDelegate(TreeNode node);

    private void DeleteDbModelAsyncInfoResponder(IAsyncResult result)
    {
      try
      {
        _serviceClient.EndDeleteDbModel(result);

        if (result.IsCompleted)
        {
          TreeNode node = result.AsyncState as TreeNode;

          this.Invoke(
              new DeleteDbModelDelegate(EndDeleteModel),
              new object[] { node });
        }
      }
      catch (Exception ex)
      {

      }
    }

    private void _bBrowse_Click(object sender, EventArgs e)
    {

    }
  }
}
