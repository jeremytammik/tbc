#pragma once

//#include <windows.h>

using namespace System;
using namespace System::Windows::Forms;

namespace Fresh2
{
    [Autodesk::Revit::Attributes::TransactionAttribute(Autodesk::Revit::Attributes::TransactionMode::Manual)]
    public ref class CommandTest : public Autodesk::Revit::UI::IExternalCommand
    {
    public:
        virtual Autodesk::Revit::UI::Result Execute( Autodesk::Revit::UI::ExternalCommandData^ pCommandData,
            String^% strMessage,
            Autodesk::Revit::DB::ElementSet^ pElements );
    };
}