// Fresh1.cpp : main project file.

#include "stdafx.h"
#include "Fresh2.h"

using namespace Fresh2;
using namespace Autodesk::Revit;
using namespace Autodesk::Revit::DB;
using namespace System::Windows::Forms;


Autodesk::Revit::UI::Result CommandTest::Execute( Autodesk::Revit::UI::ExternalCommandData^ pCommandData,
    String^% strMessage,
    Autodesk::Revit::DB::ElementSet^ pElements )
{
    UI::UIApplication ^pApplication = pCommandData->Application;
	Autodesk::Revit::DB::Transaction ^transaction = gcnew Autodesk::Revit::DB::Transaction(pApplication->ActiveUIDocument->Document);    
    transaction->Start("Test Transaction");

	//-------------------------------------------------
	//Autodesk::Revit::DB::Element ^pElement;
	Autodesk::Revit::DB::Element ^pElementOne;
	Autodesk::Revit::DB::Element ^pElementTwo;
	Autodesk::Revit::DB::ElementId ^pElementId;
	Autodesk::Revit::DB::FamilyInstance ^pFInst ;
	System::Collections::Generic::List<Autodesk::Revit::DB::ElementId^> ^list_Beams = gcnew System::Collections::Generic::List<Autodesk::Revit::DB::ElementId^>() ;
	System::Collections::Generic::ICollection<Autodesk::Revit::DB::ElementId^> ^the_list_of_the_joined = nullptr ;
	
	String ^report = "No elements are joined" ;

	//Quick:
	int beam_one_id = 266881 ;
	int beam_two_id = 267040 ;

	if(pElementId)
		delete pElementId ;
	pElementId = gcnew Autodesk::Revit::DB::ElementId(beam_one_id) ;
	pElementOne = pApplication->ActiveUIDocument->Document->GetElement(pElementId);
	
	the_list_of_the_joined = JoinGeometryUtils::GetJoinedElements(pApplication->ActiveUIDocument->Document, pElementOne);   //<-- Unfortunately here we got nothing
							
	if (the_list_of_the_joined->Count > 0)
	{
		report = "\n\nElements joined with "+pElementOne->Id->IntegerValue+": " ;
		Autodesk::Revit::DB::Element ^pJoinedElement;
		Collections::IEnumerator ^joinedIter = the_list_of_the_joined->GetEnumerator() ;
		while(joinedIter->MoveNext())
		{
			pJoinedElement = dynamic_cast<Autodesk::Revit::DB::Element^> (joinedIter->Current);
			if(pJoinedElement)
				report += pJoinedElement->Id->IntegerValue+", ";
		}
		report += "\n" ;
	}
	
	//Are elements joined:
	if(pElementId)
		delete pElementId ;
	pElementId = gcnew Autodesk::Revit::DB::ElementId(beam_two_id) ;
	pElementTwo = pApplication->ActiveUIDocument->Document->GetElement(pElementId);
	if(pElementTwo)
		pFInst =  dynamic_cast <Autodesk::Revit::DB::FamilyInstance^> (pElementTwo) ;

	if(JoinGeometryUtils::AreElementsJoined(pApplication->ActiveUIDocument->Document, pElementOne, pElementTwo))
		report = "Elements are joined!" ;
	
	try
	{		
		JoinGeometryUtils::UnjoinGeometry(pApplication->ActiveUIDocument->Document, pElementOne, pElementTwo) ;
	}	
	catch (Exception ^e)
	{
		report = "Exception after UnjoinGeometry method:\n"+e->Message ;
	}

	MessageBox::Show(report) ;
    //-------------------------------------------------
	transaction->Commit() ;
    return Autodesk::Revit::UI::Result::Succeeded;
}