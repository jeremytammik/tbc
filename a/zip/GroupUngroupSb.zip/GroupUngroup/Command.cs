//
// (C) Copyright 2003-2010 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//


using System;
using System.Collections.Generic;
using System.Text;

using Autodesk.Revit;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.ApplicationServices;

using System.Linq;

namespace Revit.SDK.Samples.HelloRevit.CS
{
 
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
    [Autodesk.Revit.Attributes.Journaling(Autodesk.Revit.Attributes.JournalingMode.NoCommandData)]
    public class Command : IExternalCommand
    {
        
        public Autodesk.Revit.UI.Result Execute(ExternalCommandData commandData,
            ref string message, Autodesk.Revit.DB.ElementSet elements)
        {

          UIDocument uiDoc = commandData.Application.ActiveUIDocument;

          // Prompt user to select existing group
          Group grpExisting = uiDoc.Document.GetElement(uiDoc.Selection.PickObject(Autodesk.Revit.UI.Selection.ObjectType.Element, "Select an existing group")) as Group;
          String name = grpExisting.Name;

          Transaction ungrpTrans = new Transaction(commandData.Application.ActiveUIDocument.Document);
          ungrpTrans.Start("Ungroup and delete");
          // Ungroup the group
          ElementSet grpElements = grpExisting.Ungroup();
          ElementSet newgrpElements = new ElementSet();

          // Ignore the first element of the group
          int counter = 0;
          foreach (Element ele in grpElements)
          {
            if (counter != 0)
            {
              newgrpElements.Insert(ele);
            }
            else
            {
              // Delete the first element in the group
              uiDoc.Document.Delete(ele);
            }
            counter++;
          }
          ungrpTrans.Commit();

          Transaction grpTrans = new Transaction(commandData.Application.ActiveUIDocument.Document);
          grpTrans.Start("Group");

          // Create new group with new set of elements
          Group grpNew = commandData.Application.ActiveUIDocument.Document.Create.NewGroup(newgrpElements);
          
          // Access the name of the previous group type and change the new group type to previous group type
          // This will retain the previous group configuration though
          FilteredElementCollector coll = new FilteredElementCollector(commandData.Application.ActiveUIDocument.Document);
          coll.OfClass(typeof(GroupType));
          IEnumerable<GroupType> grpTypes = from GroupType f in coll where f.Name == name select f;
          grpNew.GroupType = grpTypes.First<GroupType>();
          grpTrans.Commit();
 
          return Autodesk.Revit.UI.Result.Succeeded;

        }        
    }
}
