﻿using System;
using System.IO;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners;

internal class Logging
{
  protected static void CreateLoggingConfiguration() //or possibly a slightly tidier constructor
  {
    var configBuilder = new ConfigurationSourceBuilder();
    String tempPath = Path.GetTempPath();

    configBuilder.ConfigureLogging()
        .WithOptions
        .DoNotRevertImpersonation()
        .LogToCategoryNamed( "Info" )
        .SendTo.RollingFile( "General Log File" )
        .WhenRollFileExists( RollFileExistsBehavior.Overwrite )
        .RollEvery( RollInterval.Day )
        .FormatWith( new FormatterBuilder()
                        .TextFormatterNamed( "Text Formatter" )
                        .UsingTemplate( "Timestamp: {timestamp(local)} Message: {message} Category: {category}" ) )
        .WithFooter( "" )
        .WithHeader( "" )
        .ToFile( tempPath + "\\MyRevitApi.log" );


    var configSource = new DictionaryConfigurationSource();
    configBuilder.UpdateConfigurationWithReplace( configSource );
    EnterpriseLibraryContainer.Current = EnterpriseLibraryContainer.CreateDefaultContainer( configSource );
  }
}
