﻿namespace InterfaceStudy {
    partial class DialogTest {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.buttonWindow = new System.Windows.Forms.Button();
            this.buttonSingle = new System.Windows.Forms.Button();
            this.SelectType = new System.Windows.Forms.GroupBox();
            this.radioButtonWindows = new System.Windows.Forms.RadioButton();
            this.radioButtonDoors = new System.Windows.Forms.RadioButton();
            this.checkBoxAutoClose = new System.Windows.Forms.CheckBox();
            this.SelectType.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonWindow
            // 
            this.buttonWindow.Location = new System.Drawing.Point(128, 124);
            this.buttonWindow.Name = "buttonWindow";
            this.buttonWindow.Size = new System.Drawing.Size(104, 28);
            this.buttonWindow.TabIndex = 0;
            this.buttonWindow.Text = "Select Window";
            this.buttonWindow.UseVisualStyleBackColor = true;
            this.buttonWindow.Click += new System.EventHandler(this.buttonWindow_Click);
            // 
            // buttonSingle
            // 
            this.buttonSingle.Location = new System.Drawing.Point(15, 124);
            this.buttonSingle.Name = "buttonSingle";
            this.buttonSingle.Size = new System.Drawing.Size(104, 28);
            this.buttonSingle.TabIndex = 1;
            this.buttonSingle.Text = "Select Single";
            this.buttonSingle.UseVisualStyleBackColor = true;
            this.buttonSingle.Click += new System.EventHandler(this.buttonSingle_Click);
            // 
            // SelectType
            // 
            this.SelectType.Controls.Add(this.radioButtonWindows);
            this.SelectType.Controls.Add(this.radioButtonDoors);
            this.SelectType.Location = new System.Drawing.Point(15, 18);
            this.SelectType.Name = "SelectType";
            this.SelectType.Size = new System.Drawing.Size(217, 53);
            this.SelectType.TabIndex = 2;
            this.SelectType.TabStop = false;
            this.SelectType.Text = "Select Type";
            // 
            // radioButtonWindows
            // 
            this.radioButtonWindows.AutoSize = true;
            this.radioButtonWindows.Location = new System.Drawing.Point(113, 21);
            this.radioButtonWindows.Name = "radioButtonWindows";
            this.radioButtonWindows.Size = new System.Drawing.Size(69, 17);
            this.radioButtonWindows.TabIndex = 1;
            this.radioButtonWindows.TabStop = true;
            this.radioButtonWindows.Text = "Windows";
            this.radioButtonWindows.UseVisualStyleBackColor = true;
            this.radioButtonWindows.CheckedChanged += new System.EventHandler(this.radioButtonWindows_CheckedChanged);
            // 
            // radioButtonDoors
            // 
            this.radioButtonDoors.AutoSize = true;
            this.radioButtonDoors.Location = new System.Drawing.Point(22, 21);
            this.radioButtonDoors.Name = "radioButtonDoors";
            this.radioButtonDoors.Size = new System.Drawing.Size(53, 17);
            this.radioButtonDoors.TabIndex = 0;
            this.radioButtonDoors.TabStop = true;
            this.radioButtonDoors.Text = "Doors";
            this.radioButtonDoors.UseVisualStyleBackColor = true;
            this.radioButtonDoors.CheckedChanged += new System.EventHandler(this.radioButtonDoors_CheckedChanged);
            // 
            // checkBoxAutoClose
            // 
            this.checkBoxAutoClose.AutoSize = true;
            this.checkBoxAutoClose.Location = new System.Drawing.Point(15, 91);
            this.checkBoxAutoClose.Name = "checkBoxAutoClose";
            this.checkBoxAutoClose.Size = new System.Drawing.Size(171, 17);
            this.checkBoxAutoClose.TabIndex = 3;
            this.checkBoxAutoClose.Text = "Automatically Close Dialog Box";
            this.checkBoxAutoClose.UseVisualStyleBackColor = true;
            // 
            // DialogTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(252, 164);
            this.Controls.Add(this.checkBoxAutoClose);
            this.Controls.Add(this.SelectType);
            this.Controls.Add(this.buttonSingle);
            this.Controls.Add(this.buttonWindow);
            this.Name = "DialogTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DialogTest";
            this.SelectType.ResumeLayout(false);
            this.SelectType.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonWindow;
        private System.Windows.Forms.Button buttonSingle;
        private System.Windows.Forms.GroupBox SelectType;
        private System.Windows.Forms.RadioButton radioButtonWindows;
        private System.Windows.Forms.RadioButton radioButtonDoors;
        private System.Windows.Forms.CheckBox checkBoxAutoClose;
    }
}