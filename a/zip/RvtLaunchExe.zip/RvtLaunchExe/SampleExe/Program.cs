﻿using System;
using System.Windows.Forms;

namespace SampleExe
{
  class Program
  {
    static void Main( string[] args )
    {
      MessageBox.Show( "Hello Shalini.", 
        "Sample Executable" );
    }
  }
}
