﻿
using System;

namespace Case14975586.CustomProperties
{

    public partial class CtrlRevitCustomProperties : System.Windows.Forms.UserControl
    {

        public CtrlRevitCustomProperties() { InitializeComponent(); }

    }

}
