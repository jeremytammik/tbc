﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using System.Windows.Input;
using System.Windows.Interop;


namespace Case14975586.CustomProperties
{
   public class RevitCustomPropertiesHost : WindowsFormsHost, IKeyboardInputSink
   {
      [DllImport("user32.dll")]
      static extern bool IsDialogMessage(IntPtr hDlg, [In] ref Message lpMsg);

      bool IKeyboardInputSink.TranslateAccelerator(ref MSG msg, ModifierKeys modifiers)
      {
         if (base.TranslateAcceleratorCore(ref msg, modifiers))
            return true; // defer to base

#if (Revit2018 || Revit2019)
         // Give embedded controls chance to translate, to avoid keys such as delete etc.
         // being translated by Revit main UI before the contols get their chance. 
         Message m = Message.Create(msg.hwnd, msg.message, msg.wParam, msg.lParam);
         return IsDialogMessage(Handle, ref m);
#else
         // In newer Revit will take care of the translation for winform controls
         // embedded in a Dockable pane by default, however, the presence of the code above would
         // still work in that scenerio, it would just do it 1 step before the revit code would. 
         return false;
#endif
      }
   }
}
