﻿
using System;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace Case14975586.CustomProperties
{

    [Transaction(TransactionMode.Manual)]
    public class CmdCustomProperties : IExternalCommand
    {

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                AppExternal.Instance.ShowCustomPropertiesPalette();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return Result.Succeeded;
        }

    }

}
