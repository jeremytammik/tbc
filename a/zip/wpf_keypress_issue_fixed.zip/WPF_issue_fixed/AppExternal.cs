﻿
using System;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Events;
using Case14975586.CustomProperties;

namespace Case14975586
{

    public class AppExternal : IExternalApplication
    {

        internal static AppExternal Instance;
        private UIControlledApplication _uiApp;
        private static bool _isDockPanelInitialized;
        private static readonly DockablePaneId DockablePaneId = new DockablePaneId(new Guid("42056326-68FE-4E18-B4B9-54C4C5064CB7"));

        public Result OnStartup(UIControlledApplication application)
        {
            Instance = this;
            _uiApp = application;

            BuildMenu(application);
            RegisterDockablePane(application);

            return Result.Succeeded;
        }
        public Result OnShutdown(UIControlledApplication application) { return Result.Succeeded; }

        private void BuildMenu(UIControlledApplication app)
        {
            var executingAssemblyPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            var ribbonPanel = app.GetRibbonPanels().Find(t => t.Name == "WPF_issue") ?? app.CreateRibbonPanel("WPF_issue");
            ribbonPanel.AddItem(new PushButtonData("WPF_issue", "WPF_issue", executingAssemblyPath, typeof(CmdCustomProperties).FullName));
        }

        private void RegisterDockablePane(UIControlledApplication application)
        {
            application.RegisterDockablePane(DockablePaneId, " VCF Properties", new CustomPropertiesDockPanel());
            application.DockableFrameVisibilityChanged += Application_DockableFrameVisibilityChanged;
            application.ViewActivated += Application_ViewActivated;
        }

        /// <summary>
        /// Immediately hides the DockPanel after it's registered and shown.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Application_DockableFrameVisibilityChanged(object sender, DockableFrameVisibilityChangedEventArgs e)
        {
            if (!e.DockableFrameShown || e.PaneId != DockablePaneId || _isDockPanelInitialized)
                return;
            try
            {
                var dockablePane = _uiApp.GetDockablePane(DockablePaneId);
                dockablePane?.Hide();
            }
            catch (Exception ex) { }
        }

        /// <summary>
        /// Immediately hides the DockPanel after it's registered and shown.
        /// We have to hide it here, because Application_DockableFrameVisibilityChanged() is not raised on startup if the palette was docked in the last session.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Application_ViewActivated(object sender, ViewActivatedEventArgs e)
        {
            if (_isDockPanelInitialized)
                return;
            try
            {
                var dockablePane = _uiApp.GetDockablePane(DockablePaneId);
                dockablePane?.Hide();
            }
            catch (Exception ex) { }
        }

        public void ShowCustomPropertiesPalette()
        {
            // We should register the panel here, but the GetDockablePane() method throws an exception in that case.
            _uiApp.GetDockablePane(DockablePaneId)?.Show();
            _isDockPanelInitialized = true;
        }

    }

}
