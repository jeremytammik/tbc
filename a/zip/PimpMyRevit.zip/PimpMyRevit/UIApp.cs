﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using winform = System.Windows.Forms;
using System.Reflection;
using System.IO;

using System.Windows.Media;
using System.Windows.Media.Imaging;

using Autodesk;
using Autodesk.Revit;
using Autodesk.Revit.UI;
using adWin = Autodesk.Windows;

namespace PimpMyRevit
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Automatic)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Automatic)]
    public class UIApp : IExternalApplication
    {
        public Autodesk.Revit.UI.Result OnStartup(UIControlledApplication application)
        {
            try
            {
                adWin.RibbonControl ribbon = adWin.ComponentManager.Ribbon;

                ImageSource imgbg = new BitmapImage(
                      new Uri(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "yourBackGroundPicture.jpg"), UriKind.Relative)
                );

                ImageBrush picBrush = new ImageBrush(); // define an image brush
                picBrush.ImageSource = imgbg;
                picBrush.AlignmentX = AlignmentX.Left;
                picBrush.AlignmentY = AlignmentY.Top;
                picBrush.Stretch = Stretch.None;
                picBrush.TileMode = TileMode.FlipXY;


                LinearGradientBrush myLinearGradientBrush = new LinearGradientBrush(); // define a linear brush from top to bottom
                myLinearGradientBrush.StartPoint = new System.Windows.Point(0, 0);
                myLinearGradientBrush.EndPoint = new System.Windows.Point(0, 1);
                myLinearGradientBrush.GradientStops.Add(new GradientStop(Colors.White, 0.0));
                myLinearGradientBrush.GradientStops.Add(new GradientStop(Colors.Blue, 1));

                ribbon.FontFamily = new System.Windows.Media.FontFamily("Bauhaus 93"); // change the tab header font
                ribbon.FontSize = 10;

                // now iterate through the tabs and their panels

                foreach (adWin.RibbonTab tab in ribbon.Tabs)
                {
                    foreach (adWin.RibbonPanel panel in tab.Panels)
                    {
                        panel.CustomPanelTitleBarBackground = myLinearGradientBrush;

                        panel.CustomPanelBackground = picBrush; // use your picture
                        //panel.CustomPanelBackground = myLinearGradientBrush; // use your gradient fill
                    }
                }

            }
            catch (Exception ex)
            {
                winform.MessageBox.Show(ex.StackTrace + "\r\n" + ex.InnerException, "Error", winform.MessageBoxButtons.OK);
                return Autodesk.Revit.UI.Result.Failed;
            }
            return Autodesk.Revit.UI.Result.Succeeded;
        }
        public Autodesk.Revit.UI.Result OnShutdown(UIControlledApplication application)
        {
            adWin.ComponentManager.UIElementActivated -= ComponentManager_UIElementActivated;
            return Autodesk.Revit.UI.Result.Succeeded;
        }

        void ComponentManager_UIElementActivated(object sender, Autodesk.Windows.UIElementActivatedEventArgs e)
        {
            // e.UiElement.PersistId says which item has been pressed
        }
    }
}
