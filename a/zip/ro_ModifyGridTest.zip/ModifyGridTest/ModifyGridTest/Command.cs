#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion

namespace ModifyGridTest
{
    [Transaction(TransactionMode.Manual)]
    public class Command : IExternalCommand
    {
        public Result Execute(
          ExternalCommandData commandData,
          ref string message,
          ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Application app = uiapp.Application;
            Document doc = uidoc.Document;

            Selection sel = uidoc.Selection;

            Reference elemRef = sel.PickObject(ObjectType.Element, "Pick a grid");

            Element elem = doc.GetElement(elemRef);

            Grid grid = elem as Grid;

            IList<Curve> gridCurves = grid.GetCurvesInView(DatumExtentType.Model, doc.ActiveView);

            using (Transaction tx = new Transaction(doc))
            {
                tx.Start("Transaction Modify Grid");

                foreach (Curve c in gridCurves)
                {
                    XYZ start = c.GetEndPoint(0);
                    XYZ end = c.GetEndPoint(1);

                    XYZ newStart = new XYZ(start.X, start.Y+10, start.Z);
                    XYZ newEnd = new XYZ(end.X, end.Y - 10, end.Z);

                    Line newLine = Line.CreateBound(newStart, newEnd);

                    grid.SetCurveInView(DatumExtentType.Model, doc.ActiveView, newLine);
                }

                tx.Commit();
            }

            return Result.Succeeded;
        }
    }
}
