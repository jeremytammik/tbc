﻿using System;
using System.Diagnostics;
//using WinForms = System.Windows.Forms;
using Autodesk.Revit;
using Autodesk.Revit.Events;

namespace AutoExecuteOnOpen
{
  public class App : IExternalApplication
  {
    public IExternalApplication.Result OnStartup(
      ControlledApplication a )
    {
      a.DocumentCreated 
        += new EventHandler<DocumentCreatedEventArgs>( 
          a_DocumentCreated );

      a.DocumentOpened 
        += new EventHandler<DocumentOpenedEventArgs>( 
          a_DocumentOpened );

      return IExternalApplication.Result.Succeeded;
    }

    public IExternalApplication.Result OnShutdown(
      ControlledApplication a )
    {
      a.DocumentCreated
        -= new EventHandler<DocumentCreatedEventArgs>(
          a_DocumentCreated );

      a.DocumentOpened
        -= new EventHandler<DocumentOpenedEventArgs>(
          a_DocumentOpened );

      return IExternalApplication.Result.Succeeded;
    }

    //const string _caption = "AutoExecuteOnOpen";

    void a_DocumentCreated( 
      object sender, 
      DocumentCreatedEventArgs e )
    {
      //WinForms.MessageBox.Show( "DocumentCreated", _caption ); // no input accepted to click OK when driven from journal file in Visual Studio debugger
      Debug.Print( "DocumentCreated" );
    }

    void a_DocumentOpened( 
      object sender, 
      DocumentOpenedEventArgs e )
    {
      //WinForms.MessageBox.Show( "DocumentOpened", _caption ); // no input accepted to click OK when driven from journal file in Visual Studio debugger
      Debug.Print( "DocumentOpened" );

      #region Access to Other Documents
      Document doc = e.Document;
      Application app = doc.Application;
      DocumentSet docs = app.Documents;
      int n = docs.Size;
      Debug.Print( "Application has {0} document{1} open.",
        n, (1==n ? "" : "s") );
      #endregion
    }
  }
}
