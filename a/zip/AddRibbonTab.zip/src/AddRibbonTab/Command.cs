﻿using System.Diagnostics;
using Autodesk.Revit;

namespace AddRibbonTab
{
  class Command : IExternalCommand
  {
    IExternalCommand.Result IExternalCommand.Execute( 
      ExternalCommandData commandData, 
      ref string message, 
      ElementSet elements )
    {
      Debug.Print(
        "AddRibbonTab.Command.Execute method invoked." );

      System.Windows.Forms.MessageBox.Show( 
        "Hello", ToString() );

      return IExternalCommand.Result.Failed;
    }
  }
}
