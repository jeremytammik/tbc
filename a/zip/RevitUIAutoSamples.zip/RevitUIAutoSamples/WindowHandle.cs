﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RevitUIAutoSamples
{
    public class WindowHandle : System.Windows.Forms.IWin32Window
    {
        IntPtr _hwnd;

        public WindowHandle(IntPtr h)
        {
            _hwnd = h;
        }

        public IntPtr Handle
        {
            get
            {
                return _hwnd;
            }
        }
    }
}