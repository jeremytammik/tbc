﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.UI.Selection;

namespace RevitAddin1.PipeSlope
{
    [Transaction(TransactionMode.Manual)]
    class CmdSlopeBranchAtKnownDirection : IExternalCommand
    {
        public static FailureDefinitionId m_idWarning;
        public static FailureDefinition m_fdWarning;
        public Result Execute(
          ExternalCommandData commandData,
          ref string message,
          ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Application app = uiapp.Application;
            Document doc = uidoc.Document;

            // select a pipe
            ISelectionFilter selFilter = new PipeSelectionFilter();

            Reference mainPipeRef = uidoc.Selection.PickObject(Autodesk.Revit.UI.Selection.ObjectType.Element, selFilter, "Pick a main");
            Pipe mainPipe = (Pipe)doc.GetElement(mainPipeRef.ElementId);
            PipeHelper mainHelper = new PipeHelper(mainPipe);

            Reference branchPipeRef = uidoc.Selection.PickObject(Autodesk.Revit.UI.Selection.ObjectType.Element, selFilter, "Pick a branch");
            Pipe branchPipe = (Pipe)doc.GetElement(branchPipeRef.ElementId);
            PipeHelper branchHelper = new PipeHelper(branchPipe);


            // this assumes there is some slope to the orginal branch
            double a, b, c, d, e;
            a = mainHelper.Line3D.OriginalVector.X;
            b = mainHelper.Line3D.OriginalVector.Y;
            c = mainHelper.Line3D.OriginalVector.Z;
            d = branchHelper.Line3D.OriginalVector.X;
            e = branchHelper.Line3D.OriginalVector.Y;

            double costheta = Math.Cos(FindBranchVector.DegreeToRadian(45));

            double A, B, C, D;
            A = c * c - costheta * costheta * (a * a + b * b + c * c);
            B = 2 * (a * d * c + b * e * c);
            C = 2 * a * d * b * e + a * a * d * d + b * b * e * e - costheta * costheta * (a * a * d * d + a * a * e * e + b * b * d * d + b * b * e * e + c * c * d * d + c * c * e * e);
            D = B * B - 4 * A * C;


            double f1, f2;
            FindBranchVector.ResultType result =FindBranchVector.ResultType.Unsolved;

            if (D == 0)
            {
                result = FindBranchVector.ResultType.Single;
                f1 = f2 = -B / (2 * A);
            }
            if (D < 0)
            {
                result = FindBranchVector.ResultType.Imaginary;
                f1 = f2 = double.NaN;
            }
            else
            {
                result = FindBranchVector.ResultType.Unique;
                f1 = (-B - Math.Sqrt(D)) / (2 * A);
                f2 = (-B + Math.Sqrt(D)) / (2 * A);
            }

            double f = f1;
            if (f2 > f1)
                f = f2;

            // this gives where on the main the branch needs to connect
          Point3D intersect=  mainHelper.Line3D.Intersect(branchHelper.Line3D);

          Point3D farPoint = branchHelper.Line3D.StartPoint;
          double testDistStart = Point3dUtils.DistanceBetween(intersect, branchHelper.Line3D.StartPoint);
          double testDistEnd = Point3dUtils.DistanceBetween(intersect, branchHelper.Line3D.EndPoint);
          if (testDistEnd > testDistStart)
              farPoint = branchHelper.Line3D.EndPoint;

          Vector3D newVec = new Vector3D(branchHelper.Line3D.OriginalVector.X, branchHelper.Line3D.OriginalVector.Y, f);

          Line3D newLine = new Line3D(intersect, newVec);
          Point3D newEnd = newLine.GetPointFromXY(farPoint.X, farPoint.Y);

          XYZ startXYZ = new XYZ(intersect.X, intersect.Y, intersect.Z);
          XYZ endXYZ = new XYZ(newEnd.X, newEnd.Y, newEnd.Z);





////            double f = FindBranchVector.FindVectorZComponent(mainHelper, branchHelper);
//            double d1, d2;
//        //   MyGeometry.FindBranchVector.ResultType result= FindBranchVector.FindBComponent(mainHelper, f, out d1, out d2);


//            Vector3D testVector1, testVector2;
//            testVector1 = testVector2 = new Vector3D();

//            double e1, e2;
//            if (result == MyGeometry.FindBranchVector.ResultType.Unique)
//            {
//                e1 = Math.Sqrt(1 - Math.Pow(d1, 2) - Math.Pow(f, 2));
//                e2 = Math.Sqrt(1 - Math.Pow(d2, 2) - Math.Pow(f, 2));


//                testVector1 = new Vector3D(d1, e1, f);
//                testVector2 = new Vector3D(d2, e2, f);


//                // it is possible that the resulting value don't actually work 
//                // since the U.x term is squared in the quadratic form of the formula 
//                // need to also test negative Vy values
//                if (Vector3D.DotProduct(-mainHelper.Line3D.DirectionUnitVector, testVector1) < 0)
//                {
//                    testVector1 = new Vector3D(-d1, e1, f);
//                    testVector2 = new Vector3D(-d2, e2, f);
//                }
//            }
//            if (result == MyGeometry.FindBranchVector.ResultType.Imaginary)
//            {
//                //// the above failed, so swap to solve for X instead of Y
//                //Vector3D tmpVec = new Vector3D(mainLine.DirectionUnitVector.Y, mainLine.DirectionUnitVector.X, mainLine.DirectionUnitVector.Z);
//                //result = MyGeometry.FindBranchVector.FindVectorComponentUsingQuadratic(Vz, 45, tmpVec, out Vx1, out Vx2);

//                //Vy1 = Math.Sqrt(1 - Math.Pow(Vx1, 2) - Math.Pow(Vz, 2));
//                //Vy2 = Math.Sqrt(1 - Math.Pow(Vx2, 2) - Math.Pow(Vz, 2));


//                //testVector1 = new Vector3D(Vx1, Vy1, Vz);
//                //testVector2 = new Vector3D(Vx2, Vy2, Vz);

//                //// it is possible that the resulting value don't actually work 
//                //// since the U.x term is squared in the quadratic form of the formula 
//                //// need to also test negative Vy values
//                //if (Vector3D.DotProduct(mainLine.DirectionUnitVector, testVector1) < 0)
//                //{
//                //    testVector1 = new Vector3D(Vx1, -Vy1, Vz);
//                //    testVector2 = new Vector3D(Vx2, -Vy2, Vz);
//                //}
//            }


//            Point3D testPoint1 = mainHelper.Line3D.StartPoint + testVector1;
//            Point3D testPoint2 = mainHelper.Line3D.StartPoint + testVector2;

//            Vector3D branchVector = new Vector3D();
//            if (Point3dUtils.DistanceBetween(testPoint1, branchHelper.Line3D.StartPoint) <
//                Point3dUtils.DistanceBetween(testPoint2, branchHelper.Line3D.StartPoint))
//            {
//                branchVector = testVector1;
//            }
//            else
//            {
//                branchVector = testVector2;
//            }


        //    XYZ branchXYZ = new XYZ(branchVector.X, branchVector.Y, branchVector.Z);

            XYZ startPoint = ((LocationCurve)branchPipe.Location).Curve.get_EndPoint(0);
            XYZ endPoint = ((LocationCurve)branchPipe.Location).Curve.get_EndPoint(1);
            Line newPipeLine = app.Create.NewLineBound(startXYZ, endXYZ);

            Transaction tx = new Transaction(doc);
            tx.SetName("Modify Pipe");
            tx.Start();
            ((LocationCurve)branchPipe.Location).Curve = newPipeLine;

            tx.Commit();

            return Result.Succeeded;
        }

        private double GetXYIntersectPoint(PipeHelper a, PipeHelper b)
        {
            return 0;
        }

    }
}