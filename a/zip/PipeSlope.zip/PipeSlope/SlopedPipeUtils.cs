﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.DB;

namespace RevitAddin1.PipeSlope
{
    class SlopedPipeUtils
    {
        public enum ConnectorLocation { Top, Bottom };
        public static XYZ GetConnectionPoint(Pipe pipe, out Connector connectedTo, ConnectorLocation connectorLocation)
        {
            Connector thisConnector = GetConnector(connectorLocation, pipe);

            connectedTo = GetConnectedTo(thisConnector);

            return thisConnector.Origin;
        }

        public static Connector GetConnector(ConnectorLocation connectorLocation, Pipe pipe)
        {
            Connector thisConnector = null;
            foreach (Connector c in pipe.ConnectorManager.Connectors)
            {
                if (thisConnector == null)
                {
                    thisConnector = c;
                }
                if (connectorLocation == ConnectorLocation.Top)
                {
                    if (thisConnector.Origin.Z < c.Origin.Z)
                    {
                        thisConnector = c;
                    }
                }
                else if (connectorLocation == ConnectorLocation.Bottom)
                {
                    if (thisConnector.Origin.Z > c.Origin.Z)
                    {
                        thisConnector = c;
                    }
                }
            }
            return thisConnector;
        }


        public static Connector GetConnectedTo(Connector thisConnector)
        {
            Connector connectedTo = null;

            if (thisConnector.IsConnected)
            {
                foreach (Connector c in thisConnector.AllRefs)
                {
                    if (thisConnector.Owner.Id.Compare(c.Owner.Id) != 0)
                    {
                        System.Diagnostics.Debug.WriteLine(string.Format("Connectors: {0} {1}", thisConnector.Owner.Id.IntegerValue, c.Owner.Id.IntegerValue));
                        connectedTo = c;
                        break;
                    }
                }
            }

            return connectedTo;
        }
    }
}
