﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.UI;
using System.Windows.Media.Imaging;
using System.Resources;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;



namespace RevitAddin1.PipeSlope
{
    class UiCreator
    {
        const string tabName = "Pipe Slope Tools";
        const string panelName = "Home";
        static string AddInPath = typeof(UiCreator).Assembly.Location;

        public static void CreateUI(UIControlledApplication a)
        {

            a.CreateRibbonTab(tabName);
            RibbonPanel panel = a.CreateRibbonPanel(tabName, panelName);

            RibbonItem ri = panel.AddItem(new PushButtonData("Slope1", "Route From Sloping Main to Riser with 1/8\" per foot", AddInPath, typeof(CmdSlopedMainToRiserWithSlopedBranch).FullName));
            ri.ToolTip = "Some tool tip text\nhere for you to get some info.";
            ri.LongDescription = "This is where the very\nlong\nlong\nlong... description goes";

            ContextualHelp ch = new ContextualHelp(ContextualHelpType.ContextId, "THIS_IS_THE_CONTEXT_ID");
            ri.SetContextualHelp(ch);
          
          //   System.Windows.Media.ImageSourceConverter c = new System.Windows.Media.ImageSourceConverter();
             //ri.ToolTipImage = (System.Windows.Media.ImageSource)c.ConvertFrom(Resource2.asdfasdf);


            Bitmap bmp = Resources.DSC_0149;

            MemoryStream ms = new MemoryStream();
            bmp.Save(ms, ImageFormat.Png);

            BitmapImage b = new BitmapImage();
            b.BeginInit();
            b.StreamSource = ms;
            b.EndInit();

            ri.ToolTipImage = b;


            panel.AddItem(new PushButtonData("Slope2", "Test Route Pipe", AddInPath, typeof(CmdTestRoutePipe).FullName));
            panel.AddItem(new PushButtonData("Slope3", "Slope Branch at Known Direction", AddInPath, typeof(CmdSlopeBranchAtKnownDirection).FullName));

           
        }
    }
}
