﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB.Plumbing;

namespace RevitAddin1.PipeSlope
{
    [Transaction(TransactionMode.Manual)]
    class CmdTestRoutePipe : IExternalCommand
    {


        public Result Execute(
          ExternalCommandData commandData,
          ref string message,
          ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Application app = uiapp.Application;
            Document doc = uidoc.Document;

            Reference fittingRef = uidoc.Selection.PickObject(Autodesk.Revit.UI.Selection.ObjectType.Element, "Pick a fitting");
            FamilyInstance selectedInstance = (FamilyInstance)doc.GetElement(fittingRef.ElementId);

            Transaction tx = new Transaction(doc);
            tx.SetName("Make Pipe");
            tx.Start();

            // find the pipe connected to the selected fitting.
            PipeType pipeType = null;
            ElementId levelId = ElementId.InvalidElementId;

            foreach (Connector c in selectedInstance.MEPModel.ConnectorManager.Connectors)
            {
                if (!c.IsConnected)
                    continue;

                Connector pipeConnector = SlopedPipeUtils.GetConnectedTo(c);
                Pipe p = (Pipe)pipeConnector.Owner;
                pipeType = p.PipeType;
                levelId=p.ReferenceLevel.Id;
            }

            // make sure there was a pipe/type found
            if (pipeType == null)
            {
                tx.RollBack();
                return Result.Failed;
            }

            //route a pipe from the other connectors.
            foreach (Connector c in selectedInstance.MEPModel.ConnectorManager.Connectors)
            {
                if (c.IsConnected)
                    continue;

                XYZ direction = c.CoordinateSystem.BasisZ;
                XYZ endpoint = c.Origin + 10 * (direction);

               Pipe ph= Pipe.CreatePlaceholder(doc, pipeType.Id, levelId, c.Origin, endpoint);
               foreach (Connector phc in ph.ConnectorManager.Connectors)
               {
                   if (phc.CoordinateSystem.Origin.IsAlmostEqualTo(c.Origin))
                   {
                       phc.ConnectTo(c);
                   }
               }
                //doc.Create.NewPipe(endpoint, c, pipeType);
            }

            tx.Commit();

            return Result.Succeeded;
        }
    }
}
