﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.DB;
using RevitAddin1.MyGeometry;
using System.Windows.Media.Media3D;

namespace RevitAddin1.PipeSlope
{
    class PipeHelper
    {
        ElementId _levelId;

        public ElementId LevelId
        {
            get { return _levelId; }
        }

        PipeType _pipeType;

        public PipeType PipeType
        {
            get { return _pipeType; }
        }
        
        public ElementId PipeTypeId
        {
            get { return _pipeType.Id; }
        }

        double _pipeSize;

        public double PipeSize
        {
            get { return _pipeSize; }
        }

        Connector _connectedToAtTop;

        public Connector ConnectedToAtTop
        {
            get { return _connectedToAtTop; }
        }
        Connector _connectedToAtBottom;

        public Connector ConnectedToAtBottom
        {
            get { return _connectedToAtBottom; }
        }

        XYZ _topXYZ;


        public XYZ XYZTop
        {
            get { return _topXYZ; }
        }
        XYZ _bottomXYZ;

        public XYZ XYZBottom
        {
            get { return _bottomXYZ; }
        }

        private XYZ _unitVectorLowToHigh;

        public XYZ UnitVectorLowToHigh
        {
            get { return _unitVectorLowToHigh; }
        }






 

        private Line3D _line3D;

        internal Line3D Line3D
        {
            get { return _line3D; }
        }

        private ElementId _systemTypeId;

        public ElementId SystemTypeId
        {
            get { return _systemTypeId; }
        }

        private PipingSystem _pipingSystem;

        public PipingSystem PipingSystem
        {
            get { return _pipingSystem; }
        }

        public PipeHelper(Pipe p)
        {
            _levelId = p.ReferenceLevel.Id;
            _pipeType = p.PipeType;
            _pipeSize = p.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble();
            _topXYZ = SlopedPipeUtils.GetConnectionPoint(p, out _connectedToAtTop, SlopedPipeUtils.ConnectorLocation.Top);
            _bottomXYZ = SlopedPipeUtils.GetConnectionPoint(p, out _connectedToAtBottom, SlopedPipeUtils.ConnectorLocation.Bottom);
            _line3D = GetLineFromPipe(p);
            _unitVectorLowToHigh = new XYZ(_line3D.DirectionUnitVector.X, _line3D.DirectionUnitVector.Y, _line3D.DirectionUnitVector.Z);
            _systemTypeId = p.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId();

            foreach (Connector con in p.ConnectorManager.Connectors)
            {
                _pipingSystem = (PipingSystem)con.MEPSystem;
                break;
            }
        }

        public static Line3D GetLineFromPipe(Pipe pipe)
        {
            LocationCurve lc = (LocationCurve)pipe.Location;
            Line l = (Line)lc.Curve;
            IList<XYZ> points = l.Tessellate();

            Point3D pt0 = new Point3D(points[0].X, points[0].Y, points[0].Z);
            Point3D pt1 = new Point3D(points[1].X, points[1].Y, points[1].Z);

            // return the line so that the first point is lower
            if (pt0.Z < pt1.Z)
            {
                return new Line3D(pt0, pt1);
            }
            return new Line3D(pt1, pt0);

        }
    }
}
