﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.UI.Selection;
using RevitAddin1.MyGeometry;
using System.Windows.Media.Media3D;

namespace RevitAddin1.PipeSlope
{
    
    // the purpose of this function is to route a sloping branch pipe between a sloping main and a vertical riser
    [Transaction(TransactionMode.Manual)]
    public class CmdSlopedMainToRiserWithSlopedBranch : IExternalCommand
    {

        public static FailureDefinitionId m_idWarning;
        public static FailureDefinition m_fdWarning;
        public Result Execute(
          ExternalCommandData commandData,
          ref string message,
          ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Application app = uiapp.Application;
            Document doc = uidoc.Document;

            // select a pipe
            ISelectionFilter selFilter = new PipeSelectionFilter();

            Reference mainPipeRef = uidoc.Selection.PickObject(Autodesk.Revit.UI.Selection.ObjectType.Element, selFilter, "Pick a main");
            Pipe mainPipe = (Pipe)doc.GetElement(mainPipeRef.ElementId);
            PipeHelper mainHelper = new PipeHelper(mainPipe);

            Reference riserPipeRef = uidoc.Selection.PickObject(Autodesk.Revit.UI.Selection.ObjectType.Element, selFilter, "Pick a riser");
            Pipe riserPipe = (Pipe)doc.GetElement(riserPipeRef.ElementId);
            Line3D riserLine = PipeHelper.GetLineFromPipe(riserPipe);
            Point3D riserLocation = riserLine.StartPoint;

            Vector3D branchVector = FindBranchVector(mainHelper.Line3D, riserLocation);

            // we now know which vector to use.. we need to find where riser location intersects the plane defined by branchVector and MainPipeLine 
            Point3D riserIntersectPoint = FindIntersectPoint(mainHelper.Line3D, branchVector, riserLocation);

            // now, find the inersection on the main of the branch line
            Line3D branchTestLine = new Line3D(riserIntersectPoint, -branchVector);
            Point3D intersectPointOnMain = branchTestLine.Intersect(mainHelper.Line3D);

            Transaction tx = new Transaction(doc);
            tx.SetName("Make Pipe");
            tx.Start();

            XYZ pointOnMain = new XYZ(intersectPointOnMain.X, intersectPointOnMain.Y, intersectPointOnMain.Z);
            XYZ pointAtRiser = new XYZ(riserIntersectPoint.X, riserIntersectPoint.Y, riserIntersectPoint.Z);


            Pipe newLateralPipe = Pipe.CreatePlaceholder(doc, mainHelper.PipeTypeId, mainHelper.LevelId, pointOnMain, pointAtRiser);
            Parameter lateralPipeTypeParam = newLateralPipe.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM);
            lateralPipeTypeParam.Set(mainHelper.SystemTypeId);

            Parameter newPipeSize = newLateralPipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM);
            Parameter riserPipeSize = riserPipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM);
            newPipeSize.Set(riserPipeSize.AsDouble());

            CreateElbow(newLateralPipe, riserPipe, doc, pointAtRiser);

            doc.Delete(mainPipe);
            tx.Commit();


            CreateTee(mainHelper, newLateralPipe, doc, pointOnMain);

            return Result.Succeeded;

        }



        private Point3D FindIntersectPoint(Line3D mainLine, Vector3D branchVector, Point3D riserLocation)
        {
            // we now know which vector to use.. we need to find where riser location intersects the plane defined by branchVector and MainPipeLine 
            double A, B, C, D;
            PlaneUtils.GetCoefficients(mainLine, branchVector, out A, out B, out C, out D);
            double Z = PlaneUtils.GetIntersectionZ(riserLocation.X, riserLocation.Y, A, B, C, D);
            return new Point3D(riserLocation.X, riserLocation.Y, Z);
        }

        public static string TransNameConvertPlaceholder = "akl;jsdfjkl asdf";

        private static void CreateTee(PipeHelper mainHelper, Pipe branchLateralPipe, Document doc, XYZ pointOnMain)
        {
            // find what the 'top' of the main pipe is connected to.  if not connected to anything, get the origin of the top connector
            // create a new pipe from the 'top connector'/point in the down direction
            // get the connector at the bottom of this new pipe.

            Transaction transMakeMainPlaceholder = new Transaction(doc);
            transMakeMainPlaceholder.SetName("Make Main Placeholder Pipe");
            transMakeMainPlaceholder.Start();


            Pipe placeholderMainPipe = Pipe.CreatePlaceholder(doc, mainHelper.PipeTypeId, mainHelper.LevelId, mainHelper.XYZBottom, mainHelper.XYZTop);

            PlumbingUtils.ConnectPipePlaceholdersAtTee(doc, placeholderMainPipe.Id, branchLateralPipe.Id);
            transMakeMainPlaceholder.Commit();

            Transaction transSetMainSystem = new Transaction(doc);
            transSetMainSystem.SetName("Set Main System");
            transSetMainSystem.Start();
            Parameter mainPipeSystemTypeParam = placeholderMainPipe.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM);
            mainPipeSystemTypeParam.Set(mainHelper.SystemTypeId);
            transSetMainSystem.Commit();


            Transaction transSetMainSize = new Transaction(doc);
            transSetMainSize.SetName("Set Main Size");
            transSetMainSize.Start();
            Parameter mainPipeSystemSizeParam = placeholderMainPipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM);
            mainPipeSystemSizeParam.Set(mainHelper.PipeSize);
            transSetMainSize.Commit();


            
            Transaction transConvertPlaceholder = new Transaction(doc, TransNameConvertPlaceholder);

            // tried using failure handling, but found it wasn't necessary.
            // leaving this in for now for reference if happen to need it later.
            //FailureHandlingOptions options = transConvertPlaceholder.GetFailureHandlingOptions();
            // FailurePreproccessor preproccessor = new FailurePreproccessor();
            // options.SetFailuresPreprocessor(preproccessor);
            //  transConvertPlaceholder.SetFailureHandlingOptions(options);
            transConvertPlaceholder.Start();
            
            ICollection<ElementId> idsToConvert = new List<ElementId>();
            idsToConvert.Add(placeholderMainPipe.Id);
            idsToConvert.Add(branchLateralPipe.Id);
            ICollection<ElementId> newIds = PlumbingUtils.ConvertPipePlaceholders(doc, idsToConvert);

            foreach (ElementId newId in newIds)
            {
                Element element = doc.GetElement(newId);

                if (element.Category.Id.IntegerValue == (int)BuiltInCategory.OST_PipeCurves)
                {
                    Pipe newPipe = (Pipe)element;
                    foreach (Connector connector in newPipe.ConnectorManager.Connectors)
                    {
                        if (connector.Origin.IsAlmostEqualTo(mainHelper.XYZTop))
                        {
                            if (mainHelper.ConnectedToAtTop != null)
                            {
                                connector.ConnectTo(mainHelper.ConnectedToAtTop);
                            }
                        }

                        if (connector.Origin.IsAlmostEqualTo(mainHelper.XYZBottom))
                        {
                            if (mainHelper.ConnectedToAtBottom != null)
                            {
                                connector.ConnectTo(mainHelper.ConnectedToAtBottom);
                            }
                        }
                    }
                }
            }
            transConvertPlaceholder.Commit();
        }

        private static void CreateElbow(Pipe newPipe, Pipe riserPipe, Document doc, XYZ pointAtRiser)
        {
            // need an elbow between the bottom of the riser and the point at riser

            // find the connector on the new pipe nearest the riser
            Connector connectorOnNewPipeNearestTheRiser = null;

            foreach (Connector c in newPipe.ConnectorManager.Connectors)
            {
                if (c.Origin.DistanceTo(pointAtRiser) < 0.001)
                {
                    connectorOnNewPipeNearestTheRiser = c;
                }
            }


            // find the bottom connector on the riser
            Connector connectorAtBottomOfRiser = null;

            foreach (Connector c in riserPipe.ConnectorManager.Connectors)
            {
                if (connectorAtBottomOfRiser == null)
                    connectorAtBottomOfRiser = c;
                if (c.Origin.Z < connectorAtBottomOfRiser.Origin.Z)
                    connectorAtBottomOfRiser = c;
            }

            if (connectorAtBottomOfRiser != null && connectorOnNewPipeNearestTheRiser != null)
            {
                doc.Create.NewElbowFitting(connectorAtBottomOfRiser, connectorOnNewPipeNearestTheRiser);
            }

        }

        private static Vector3D FindBranchVector(Line3D mainLine, Point3D riserLocation)
        {

            double Vz = 0.125 / 12.0;  // should give user list of slopes

            double Vx1, Vx2;
            double Vy1, Vy2;
            Vx1 = Vx2 = double.NaN;

            // find the 'y' components of the vector with a known slope, angle, and unit vector for the main.
            MyGeometry.FindBranchVector.ResultType result = MyGeometry.FindBranchVector.FindVectorComponentUsingQuadratic(Vz, 45, mainLine.DirectionUnitVector, out Vy1, out Vy2);

            Vector3D testVector1, testVector2;
            testVector1 = testVector2 = new Vector3D();

            if (result == MyGeometry.FindBranchVector.ResultType.Unique)
            {
                Vx1 = Math.Sqrt(1 - Math.Pow(Vy1, 2) - Math.Pow(Vz, 2));
                Vx2 = Math.Sqrt(1 - Math.Pow(Vy2, 2) - Math.Pow(Vz, 2));


                testVector1 = new Vector3D(Vx1, Vy1, Vz);
                testVector2 = new Vector3D(Vx2, Vy2, Vz);


                // it is possible that the resulting value don't actually work 
                // since the U.x term is squared in the quadratic form of the formula 
                // need to also test negative Vy values
                if (Vector3D.DotProduct(mainLine.DirectionUnitVector, testVector1) < 0)
                {
                    testVector1 = new Vector3D(-Vx1, Vy1, Vz);
                    testVector2 = new Vector3D(-Vx2, Vy2, Vz);
                }
            }
            if (result == MyGeometry.FindBranchVector.ResultType.Imaginary)
            {
                // the above failed, so swap to solve for X instead of Y
                Vector3D tmpVec = new Vector3D(mainLine.DirectionUnitVector.Y, mainLine.DirectionUnitVector.X, mainLine.DirectionUnitVector.Z);
                result = MyGeometry.FindBranchVector.FindVectorComponentUsingQuadratic(Vz, 45, tmpVec, out Vx1, out Vx2);

                Vy1 = Math.Sqrt(1 - Math.Pow(Vx1, 2) - Math.Pow(Vz, 2));
                Vy2 = Math.Sqrt(1 - Math.Pow(Vx2, 2) - Math.Pow(Vz, 2));


                testVector1 = new Vector3D(Vx1, Vy1, Vz);
                testVector2 = new Vector3D(Vx2, Vy2, Vz);

                // it is possible that the resulting value don't actually work 
                // since the U.x term is squared in the quadratic form of the formula 
                // need to also test negative Vy values
                if (Vector3D.DotProduct(mainLine.DirectionUnitVector, testVector1) < 0)
                {
                    testVector1 = new Vector3D(Vx1, -Vy1, Vz);
                    testVector2 = new Vector3D(Vx2, -Vy2, Vz);
                }
            }

            // check which vector added to the starting point gets
            // us closer to the riser
            Point3D testPoint1 = mainLine.StartPoint + testVector1;
            Point3D testPoint2 = mainLine.StartPoint + testVector2;

            Vector3D branchVector = new Vector3D();
            if (Point3dUtils.DistanceBetween(testPoint1, riserLocation) <
                Point3dUtils.DistanceBetween(testPoint2, riserLocation))
            {
                branchVector = testVector1;
            }
            else
            {
                branchVector = testVector2;
            }
            return branchVector;
        }





    }



    public class PipeSelectionFilter : ISelectionFilter
    {
        public bool AllowElement(Element element)
        {
            if (element.Category.Id.IntegerValue == (int)BuiltInCategory.OST_PipeCurves)// element.Category.id)//(int)BuiltInCategory.OST_Conduit == owner.Category.Id.IntegerValue
            {
                return true;
            }
            return false;
        }

        public bool AllowReference(Reference refer, XYZ point)
        {
            return false;
        }
    }





    public class FailurePreproccessor : IFailuresPreprocessor
    {
        /// <summary>
        /// This method is called when there have been failures found at the end of a transaction and Revit is about to start processing them. 
        /// </summary>
        /// <param name="failuresAccessor">The Interface class that provides access to the failure information. </param>
        /// <returns></returns>
        public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
        {
            IList<FailureMessageAccessor> fmas = failuresAccessor.GetFailureMessages();
            if (fmas.Count == 0)
            {
                return FailureProcessingResult.Continue;
            }

            String transactionName = failuresAccessor.GetTransactionName();
            if (transactionName.Equals(CmdSlopedMainToRiserWithSlopedBranch.TransNameConvertPlaceholder))
            {
                foreach (FailureMessageAccessor fma in fmas)
                {
                    FailureDefinitionId failId = fma.GetFailureDefinitionId();
                    //  if(failId == BuiltInFailures.PipingFailures.
                    failuresAccessor.DeleteWarning(fma);
                }

                return FailureProcessingResult.ProceedWithCommit;
            }

            else
            {
                return FailureProcessingResult.Continue;
            }
        }
    }
}