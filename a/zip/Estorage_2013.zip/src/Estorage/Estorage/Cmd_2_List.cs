﻿#region Header
//
// (C) Copyright 2011-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
#endregion // Header

#region Namespaces
using System;
using System.Diagnostics;
using System.Collections.Generic;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.UI;
#endregion // Namespaces

namespace Estorage
{
  [Transaction( TransactionMode.ReadOnly )]
  public class Cmd_2_List : IExternalCommand
  {
    /// <summary>
    ///  If a schema is in memory from a previous 
    ///  document that is now closed, Schema.ListSchemas
    ///  will still return it.  Therefore, this method 
    ///  will tell if if no schemas are present at all
    ///  in the current document or any previous ones.
    ///  If it returns true, you need to verify whether
    ///  any elements in the active document actually 
    ///  use it using StorageExistsSlow.
    /// </summary>
    public static bool StorageExistsQuick()
    {
      // Todo: retrieve a list of schemata by calling
      // the static ListSchemas method on the Schema
      // class

      IList<Schema> schemas = Schema.ListSchemas();

      // If the list retrieved is null or has zero
      // entries, no estorage exists at all

      return null != schemas && 0 < schemas.Count;
    }

    /// <summary>
    /// Iterarate through all elements in a document 
    /// and check to see if they contain any entities 
    /// of any schema in the current Revit session 
    /// (see StorageExistsQuick).
    /// </summary>
    public static bool StorageExistSlow( Document doc )
    {
      // Todo: retrieve a list of schemata by calling
      // the static ListSchemas method on the Schema
      // class

      IList<Schema> schemas = Schema.ListSchemas();

      FilteredElementCollector elements
        = Util.GetAllElements( doc );

      foreach( Schema schema in schemas )
      {
        foreach( Element e in elements )
        {
          Entity entity = e.GetEntity( schema );

          // No need to check for null... if the
          // element has no data for this schema, 
          // the returned entity with be valid
          // but with a null schema and IsValid
          // returns false.

          if( entity.IsValid() )
          {
            return true;
          }
        }
      }
      return false;
    }

    /// <summary>
    /// List all schemas in Revit memory across all documents.
    /// </summary>
    void ListSchemata()
    {
      // Todo: retrieve a list of schemata by calling
      // the static ListSchemas method on the Schema
      // class

      IList<Schema> schemas = Schema.ListSchemas();

      string content = string.Empty;

      int n;

      foreach( Schema s in schemas )
      {
        // Todo: retrieve a list of all fields defined
        // by the schema 's' by calling its ListFields
        // method

        IList<Field> fields = s.ListFields();

        n = fields.Count;

        content += string.Format(
          "{0}  Schema '{1}' has {2} field{3}:",
          ( 0 < content.Length ? "\r\n\r\n" : "" ),
          s.SchemaName, n, Util.PluralSuffix( n ) );

        foreach( Field f in fields )
        {
          content += string.Format(
            "\r\n    Field '{0}' has value type {1}"
            + " and unit type {2}", f.FieldName,
            f.ValueType, f.UnitType );
        }
      }

      n = schemas.Count;

      Util.InfoMessage( string.Format(
        "{0} schema{1} defined{2}",
        n, Util.PluralSuffix( n ),
        Util.DotOrColon( n ) ),
        content );
    }

    /// <summary>
    /// List availability of schema data 
    /// in each of the given documents.
    /// </summary>
    void ListEstorage( DocumentSet docs )
    {
      int n = docs.Size;

      string s = string.Empty;

      foreach( Document doc in docs )
      {
        s += string.Format(
          "\r\n  '{0}' contains {1}extensible storage data.",
          doc.Title,
          ( StorageExistSlow( doc ) ? "" : "no " ) );
      }
      Util.InfoMessage( string.Format(
        "{0} document{1}{2}",
        n, Util.PluralSuffix( n ),
        Util.DotOrColon( n ) ),
        s );
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      // Determine whether any schema data is 
      // available in each of the current documents

      if( !StorageExistsQuick() )
      {
        Util.InfoMessage( "None of the open documents "
          + "contains any extensible storage data." );
      }
      else
      {
        // List all schemata in memory across all documents

        ListSchemata();

        // Check for schema data in each of the current documents

        UIApplication uiapp = commandData.Application;
        Application app = uiapp.Application;

        ListEstorage( app.Documents );
      }
      return Result.Succeeded;
    }
  }
}
