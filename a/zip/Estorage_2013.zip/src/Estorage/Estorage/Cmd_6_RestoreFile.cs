﻿#region Header
//
// (C) Copyright 2011-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
#endregion // Header

#region Namespaces
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Application = Autodesk.Revit.ApplicationServices.Application;
#endregion // Namespaces

namespace Estorage
{
  #region Restore file
  /// <summary>
  /// External Revit command to retrieve EstoreFile 
  /// data from a selected element and recreate 
  /// the external file from it.
  /// </summary>
  [Transaction( TransactionMode.ReadOnly )]
  public class Cmd_6_RestoreFile : IExternalCommand
  {
    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Application app = uiapp.Application;
      Document doc = uidoc.Document;

      if( null == doc )
      {
        message = "Please run this command in an active Revit document.";
        return Result.Failed;
      }

      // Todo: Retrieve the schema identified by
      // the Cmd_5_StoreFile.SchemaGuid using the
      // static Lookup method on the Schema class

      Schema schema = Schema.Lookup( Cmd_5_StoreFile.SchemaGuid );

      if( null == schema )
      {
        message = "The EstoreFile schema is not registered.";
        return Result.Failed;
      }

      Element e = null;

      try
      {
        Selection sel = uidoc.Selection;

        Reference r = sel.PickObject(
          ObjectType.Element,
          "Please pick an element to restore the file from: " );

        e = doc.GetElement( r.ElementId );
      }
      catch( OperationCanceledException )
      {
        return Result.Cancelled;
      }

      // Todo: Retrieve the schema entity from
      // the selected Revit element 'e'

      Entity ent = e.GetEntity( schema );

      if( null == ent || !ent.IsValid() )
      {
        message = "No EstoreFile data found on selected element.";
        return Result.Failed;
      }

      string filename = ent.Get<string>( 
        schema.GetField( "Filename" ) );

      // Todo: Retrieve the schema "Folder" field from 
      // the schema entity 'ent' and extract the original
      // file path from it using the templated Get
      // method with a string field type

      string folder = ent.Get<string>( 
        schema.GetField( "Folder" ) );

      // Todo: Retrieve the schema "Data" field from 
      // the schema entity and extract the file data 
      // from it using the templated Get method with 
      // an IList<byte> field type, using ToArray to
      // convert it from Ilist to a byte array

      byte[] data = ent.Get<IList<byte>>( 
        schema.GetField( "Data" ) ).ToArray();

      // Here is the code to save the file data back 
      // to the original filename and location without 
      // any user interaction:
      //
      //string filepath = Path.Combine(
      //  ent.Get<string>( schema.GetField( "Folder" ) ),
      //  ent.Get<string>( schema.GetField( "Filename" ) ) );
      //
      //File.WriteAllBytes( filepath, data );

      // Ask the user where to store the 
      // retrieved file information

      SaveFileDialog dlg = new SaveFileDialog();
      dlg.Title = "Restore File from Revit Extensible Storage";
      dlg.AddExtension = false;
      dlg.FileName = filename;

      if( Directory.Exists( folder ) )
      {
        dlg.InitialDirectory = folder;
      }

      if( DialogResult.OK == dlg.ShowDialog() )
      {
        File.WriteAllBytes( dlg.FileName, data );

        return Result.Succeeded;
      }
      else
      {
        return Result.Cancelled;
      }
    }
  }
  #endregion // Restore file
}

// todo at some point later, but not part of the 
// estorage exercises: list all stored files, allow 
// navigation to each element containing EstoreFile 
// data
