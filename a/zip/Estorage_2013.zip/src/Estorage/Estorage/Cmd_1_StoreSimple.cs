﻿#region Header
//
// (C) Copyright 2011-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
#endregion // Header

#region Namespaces
using System;
using System.Diagnostics;
using System.Collections.Generic;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion // Namespaces

namespace Estorage
{
  [Transaction( TransactionMode.Manual )]
  public class Cmd_1_StoreSimple : IExternalCommand
  {
    static readonly Guid SchemaGuid
      = new Guid( "aeffa5b8-f840-41f3-9d40-6f1e9b3ae0b5" );

    /// <summary>
    /// Create an extensible storage schema, 
    /// attach it to a wall, populate it with data, 
    /// and retrieve the data back from the wall.
    /// </summary>
    void StoreDataInWall(
      Wall wall,
      XYZ dataToStore )
    {
      // Todo: Check whether schema already exists 
      // using the static Lookup method on the
      // Schema class.

      Schema schema = Schema.Lookup( SchemaGuid );

      if( null == schema )
      {
        // Todo: Create a new schema 
        // builder for our schema GUID

        SchemaBuilder schemaBuilder
          = new SchemaBuilder( SchemaGuid );

        // Allow anyone to read the object

        schemaBuilder.SetReadAccessLevel(
          AccessLevel.Public );

        // Restrict writing to this vendor only

        schemaBuilder.SetWriteAccessLevel(
          AccessLevel.Vendor );

        // Required because of restricted write access

        schemaBuilder.SetVendorId( "TBC_" );

        // Todo: Use the AddSimpleField method on the
        // schema builder to create a field named 
        // "WireSpliceLocation" to store an XYZ 
        // data item

        FieldBuilder fieldBuilder = schemaBuilder
          .AddSimpleField( "WireSpliceLocation",
          typeof( XYZ ) );

        fieldBuilder.SetUnitType( UnitType.UT_Length );

        fieldBuilder.SetDocumentation( "A stored "
          + "location value representing a wiring "
          + "splice in a wall." );

        schemaBuilder.SetSchemaName( "WireSpliceLocation" );

        // Todo: Register the schema by calling 
        // the schema builder Finish method

        schema = schemaBuilder.Finish();
      }

      // Todo: Create a new entity (object) 
      // for this schema (class)

      Entity ent = new Entity( schema );

      // Todo: retrieve the field named 
      // "WireSpliceLocation" from the schema

      Field fieldSpliceLocation = schema.GetField(
        "WireSpliceLocation" );

      // Todo: Set the value for this entity.
      // For floating-point values, the unit type must
      // be specified. Here we use (decimal) feet, to 
      // avoid the need to convert from the Revit 
      // database values to some other unit.

      ent.Set<XYZ>( fieldSpliceLocation, dataToStore,
        DisplayUnitType.DUT_DECIMAL_FEET );

      // Todo: Store the entity 'ent' 
      // on the wall element

      wall.SetEntity( ent );

      // Todo: Read back the data from the wall
      // into the retrieved entity 'ent_retrieved'

      Entity ent_retrieved = wall.GetEntity( schema );

      // Todo: Extract the XYZ data from 
      // the retrieved entity 'ent_retrieved'

      XYZ data_retrieved = ent_retrieved.Get<XYZ>(
        schema.GetField( "WireSpliceLocation" ),
        DisplayUnitType.DUT_DECIMAL_FEET );
    }

    /// <summary>
    /// Selection filter allowing only wall elements.
    /// </summary>
    class WallFaceSelectionFilter : ISelectionFilter
    {
      public bool AllowElement( Element e )
      {
        return e is Wall;
      }

      public bool AllowReference( Reference r, XYZ p )
      {
        //return r.GeometryObject is Face; // 2012

        return r.ElementReferenceType == // 2013
          ElementReferenceType.REFERENCE_TYPE_SURFACE; 
      }
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Document doc = uidoc.Document;

      try
      {
        // Pick an element and define the XYZ 
        // data to store at the same time

        Reference r = uidoc.Selection.PickObject(
          ObjectType.Face,
          new WallFaceSelectionFilter(),
          "Please pick a wall at a point on one of its faces" );

        Wall wall = doc.GetElement( r.ElementId ) as Wall;
        XYZ dataToStore = r.GlobalPoint;

        Transaction t = new Transaction( doc );

        t.Start( "Create Extensible Storage Schema"
          + " and Store Data" );

        // Store the data, and also 
        // demonstrate reading it back

        StoreDataInWall( wall, dataToStore );

        t.Commit();

        return Result.Succeeded;
      }
      catch( Exception ex )
      {
        message = ex.Message;
        return Result.Failed;
      }
    }
  }
}
