﻿#region Header
//
// (C) Copyright 2011-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
#endregion // Header

#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Media.Imaging;
using System.Reflection;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
#endregion

namespace Estorage
{
  class App : IExternalApplication
  {
    const string _name = "Estorage";

    const string _text = "Revit Extensible Storage Samples";

    //static string _namespace_prefix
    //  = typeof( App ).Namespace + ".";

    static string _cmdClassNamePrefix 
      = typeof( App ).FullName.Replace(
        "App", "Cmd_" );

    static string[] text = new string[] {
        "About...",
        "Store Simple",
        "List",
        "Store Map",
        "Delete",
        "Store File",
        "Restore File",
        "DataStorage"
      };

    static string[] classNameStem = new string[] {
        "0_About",
        "1_StoreSimple",
        "2_List",
        "3_StoreMap",
        "4_Delete",
        "5_StoreFile",
        "6_RestoreFile",
        "7_DataStorage"
      };

    /// <summary>
    /// Create a ribbon panel for the estorage sample 
    /// application. Present a column of two buttons: 
    /// a pulldown button for the sample commands, 
    /// and a separate button for the about command.
    /// </summary>
    void AddRibbonPanel(
      UIControlledApplication a )
    {
      string path = Assembly.GetExecutingAssembly().Location;

      RibbonPanel panel = a.CreateRibbonPanel(
        "Estorage" );

      // Create button for the about command

      PushButtonData d0 = new PushButtonData(
        classNameStem[0], text[0], path,
        _cmdClassNamePrefix + classNameStem[0] );

      d0.ToolTip = "About the Extensible Storage sample.";

      // Create pulldown button for sample commands

      PulldownButtonData d1 = new PulldownButtonData(
        "Samples", "Samples" );

      d1.ToolTip = "Extensible Storage Commands";

      IList<RibbonItem> ribbonItems = panel.AddStackedItems(
        d0, d1 );

      // Add sub-items to the pulldown button

      int n = classNameStem.Length;

      Debug.Assert( text.Length == n,
        "expected equal number of text and class name entries" );

      PulldownButton pulldown;
      PushButton pb;

      for( int i = 1; i < n; ++i )
      {
        pulldown = ribbonItems[1] as PulldownButton;

        PushButtonData pbd = new PushButtonData(
          text[i], text[i], path,
          _cmdClassNamePrefix + classNameStem[i] );

        pb = pulldown.AddPushButton( pbd );

        pb.ToolTip = text[i];
      }
    }

    public Result OnStartup( UIControlledApplication a )
    {
      AddRibbonPanel( a );
      return Result.Succeeded;
    }

    public Result OnShutdown( UIControlledApplication a )
    {
      return Result.Succeeded;
    }
  }
}

// C:\Program Files\Autodesk\Revit Architecture 2012\Program\Samples\rac_basic_sample_project.rvt
