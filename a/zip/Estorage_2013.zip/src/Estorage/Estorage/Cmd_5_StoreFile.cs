﻿#region Header
//
// (C) Copyright 2011-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
#endregion // Header

#region Namespaces
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Application = Autodesk.Revit.ApplicationServices.Application;
#endregion // Namespaces

namespace Estorage
{
  #region Store file
  /// <summary>
  /// External Revit command to store the data of an
  /// arbitrary selected external file into Revit 
  /// extensible storage on a selected element.
  /// The data stored includes filename, original 
  /// folder name, and the file data itself.
  /// </summary>
  [Transaction( TransactionMode.Manual )]
  public class Cmd_5_StoreFile : IExternalCommand
  {
    public static readonly Guid SchemaGuid 
      = new Guid( "431224e5-db13-4cf2-9e14-56d2e92889eb" );

    public static Schema GetSchema()
    {
      Schema schema = Schema.Lookup( SchemaGuid );

      if( null == schema )
      {
        SchemaBuilder schemaBuilder
          = new SchemaBuilder( SchemaGuid );

        schemaBuilder.SetSchemaName( "EstoreFile" );

        // Allow anyone to read and write the object

        schemaBuilder.SetReadAccessLevel(
          AccessLevel.Public );

        schemaBuilder.SetWriteAccessLevel(
          AccessLevel.Public );

        // Create fields

        // Todo: create a simple field named
        // "Filename" of type string

        FieldBuilder fieldBuilder = schemaBuilder
          .AddSimpleField( "Filename", typeof( string ) );

        fieldBuilder.SetDocumentation( "File name" );

        // Todo: create a simple field named
        // "Folder" of type string

        fieldBuilder = schemaBuilder.AddSimpleField(
          "Folder", typeof( string ) );

        fieldBuilder.SetDocumentation( "Original file folder path" );

        // Todo: create a field named "Data"
        // containing an array of bytes

        fieldBuilder = schemaBuilder.AddArrayField(
          "Data", typeof( byte ) );

        fieldBuilder.SetDocumentation( "Stored file data" );

        // Register the schema

        schema = schemaBuilder.Finish();
      }
      return schema;
    }

    /// <summary>
    /// Store the given file data on the selected element.
    /// </summary>
    static bool EstoreFile( string filename, Element e )
    {
      Document doc = e.Document;

      bool rc = doc.IsModifiable;

      if( rc )
      {
        Schema schema = GetSchema();

        // Prepare the data to store

        byte[] data = File.ReadAllBytes( filename );

        string folder = Path.GetDirectoryName( filename );

        filename = Path.GetFileName( filename );

        // Create an entity (object) for this schema (class)

        Entity entity = new Entity( schema );

        // Set the values for this entity

        entity.Set<string>( 
          schema.GetField( "Filename" ), 
          filename );

        // Todo: Retrieve the "Folder" field on the
        // entity and save the file folder path to it

        entity.Set<string>( 
          schema.GetField( "Folder" ), 
          folder );

        // Todo: Retrieve the "Data" field
        // and save the file data to it using the 
        // templated Entity.Set method using a
        // field type of IList<byte>

        entity.Set<IList<byte>>( 
          schema.GetField( "Data" ), 
          data );

        // Store the entity on the element

        e.SetEntity( entity );
      }
      return rc;
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Application app = uiapp.Application;
      Document doc = uidoc.Document;

      if( null == doc )
      {
        message = "Please run this command in an active Revit document.";
        return Result.Failed;
      }

      OpenFileDialog dlg = new OpenFileDialog();
      dlg.Title = "Store File Data in Revit Extensible Storage";
      dlg.CheckFileExists = true;
      if( DialogResult.OK != dlg.ShowDialog() )
      {
        return Result.Cancelled;
      }

      Element e = null;

      try
      {
        Selection sel = uidoc.Selection;

        Reference r = sel.PickObject(
          ObjectType.Element,
          "Please pick an element to store the file on: " );

        e = doc.GetElement( r.ElementId );
      }
      catch( OperationCanceledException )
      {
        return Result.Cancelled;
      }

      Transaction t = new Transaction( doc );

      t.Start( "Estore File" );

      EstoreFile( dlg.FileName, e );

      t.Commit();

      return Result.Succeeded;
    }
  }
  #endregion // Store file
}

// todo at some point later, but not part of the 
// estorage exercises: list all stored files, allow 
// navigation to each element containing EstoreFile 
// data
