﻿#region Header
//
// (C) Copyright 2011-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
#endregion // Header

#region Namespaces
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Windows.Forms;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion // Namespaces

namespace Estorage
{
  /// <summary>
  /// Delete all estorage created by any application 
  /// in all active documents.
  /// This command will also report if there is no 
  /// storage in the active document to delete.
  /// The document must be saved after the storage 
  /// is deleted to commit the deletion.
  /// </summary>
  [Transaction( TransactionMode.Manual )]
  public class Cmd_4_Delete : IExternalCommand
  {
    const string _title = "Delete Extensible Storage";

    bool Question( string message )
    {
      TaskDialog a = new TaskDialog( _title );
      a.MainInstruction = message;
      a.MainIcon = TaskDialogIcon.TaskDialogIconWarning;
      a.CommonButtons = TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No;
      a.DefaultButton = TaskDialogResult.No;
      return TaskDialogResult.Yes == a.Show();
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      IList<Schema> schemas = Schema.ListSchemas();

      if( null == schemas || 0 == schemas.Count )
      {
        TaskDialog.Show( _title,
          "None of the loaded documents contain"
          + " any extensible storage data." );
      }
      else
      {
        bool go = Question( 
          "Are you sure you wish to delete all"
          + " extensible storage in all documents?" );

        if( go )
        {
          // Normally, the usual write access controls apply 
          // to prevent deletion of Entities that you don't 
          // have write permissions for. However, the user 
          // may choose to override the controls. Set this 
          // flag to true only if the user gave explicit
          // permission to destroy the Schema.

          bool overrideWriteAccessWithUserPermission 
            = Question( "Also delete Entities that you"
              + " have no write permission to?" );

          foreach( Schema schema in schemas )
          {
            // Note: this deletes storage of this 
            // schema in *all* open documents.

            // Todo: for the given schema 'schema',
            // erase all its entities and data by
            // calling the appropriate static method
            // on the Schema class, passing in the
            // Boolean variable with the user choice 
            // whether to also delete data that would
            // otherwise not be accessible.

            Schema.EraseSchemaAndAllEntities( schema, 
              overrideWriteAccessWithUserPermission );
          }
        }
        message = "All extensible storage data was deleted.";
      }
      return Result.Succeeded;
    }
  }
}
