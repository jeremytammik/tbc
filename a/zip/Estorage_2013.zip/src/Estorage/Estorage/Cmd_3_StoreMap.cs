﻿#region Header
//
// (C) Copyright 2011-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
#endregion // Header

#region Namespaces
using System;
using System.Diagnostics;
using System.Collections.Generic;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion // Namespaces

namespace Estorage
{
  [Transaction( TransactionMode.Manual )]
  public class Cmd_3_StoreMap : IExternalCommand
  {
    static readonly Guid SchemaGuid
      = new Guid( "e32b67e8-4f57-48e0-ae54-d4c74bbc1b3c" );

    /// <summary>
    /// Create an extensible storage schema specifying 
    /// a dictionary mapping keys to values, both using 
    /// strings,  populate it with data, attach it to the 
    /// given element, and retrieve the data back again.
    /// </summary>
    void StoreStringMapInElement( Element e )
    {
      Schema schema = Schema.Lookup( SchemaGuid );

      if( null == schema )
      {
        SchemaBuilder schemaBuilder 
          = new SchemaBuilder( SchemaGuid );

        // Todo: Allow anyone to read or write the 
        // schema data by setting the access level 
        // to 'public' using the schema builder 
        // SetReadAccessLevel and 
        // SetWriteAccessLevel methods

        schemaBuilder.SetReadAccessLevel(
          AccessLevel.Public );

        schemaBuilder.SetWriteAccessLevel(
          AccessLevel.Public );

        // Todo: Create a field named "StringMap"
        // to store a string map using the schema 
        // builder AddMapField method and 
        // typeof( string ) for both the 
        // key and value data type

        FieldBuilder fieldBuilder
          = schemaBuilder.AddMapField( "StringMap",
            typeof( string ), typeof( string ) );

        fieldBuilder.SetDocumentation(
          "An estorage sample string map." );

        schemaBuilder.SetSchemaName(
          "EstorageStringMap" );

        // Register the schema

        schema = schemaBuilder.Finish();
      }

      // Create an entity (object) for this schema (class)

      Entity entity = new Entity( schema );

      // Get the field from the schema

      Field field = schema.GetField( "StringMap" );

      // Define the value for this schema entity

      IDictionary<string, string> stringMap
        = new Dictionary<string, string>();

      stringMap.Add( "key1", "value1" );
      stringMap.Add( "key2", "value2" );

      // Todo: set the value of the "StringMap" field 
      // on the schema entity to the 'stringMap' value.
      // This requires use of the templated 
      // Entity.Set method with a field type of 
      // IDictionary<string, string>

      entity.Set<IDictionary<string, string>>(
        field, stringMap );

      // Store the entity on the element

      e.SetEntity( entity );

      // Read back the data from the wall

      Entity ent_retrieved = e.GetEntity( schema );

      // Todo: retrieve the stored string map data and
      // store it in 'map_retrieved' using the templated
      // Entity.Get method with a field type of 
      // IDictionary<string, string>

      IDictionary<string, string> map_retrieved
        = ent_retrieved.Get<IDictionary<string, string>>(
            schema.GetField( "StringMap" ) );
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Document doc = uidoc.Document;

      try
      {
        // Pick an element

        Reference r = uidoc.Selection.PickObject(
          ObjectType.Element,
          "Please pick an element" );

        Element e = doc.GetElement( r.ElementId );

        Transaction t = new Transaction( doc );

        t.Start( "Create Extensible Storage Schema"
          + " and Store Complex Data" );

        // Store data on selected element

        StoreStringMapInElement( e );

        t.Commit();

        return Result.Succeeded;
      }
      catch( Exception ex )
      {
        message = ex.Message;
        return Result.Failed;
      }
    }
  }
}
