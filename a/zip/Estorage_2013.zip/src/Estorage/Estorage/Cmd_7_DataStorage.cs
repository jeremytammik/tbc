﻿#region Header
//
// (C) Copyright 2011-2012 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
#endregion // Header

#region Namespaces
using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;
using Autodesk.Revit.UI;
//using Autodesk.Revit.UI.Selection;
//using Application = Autodesk.Revit.ApplicationServices.Application;
#endregion // Namespaces

namespace Estorage
{
  static class FooSchema
  {
    static readonly Guid _guid = new Guid( 
      "1e802ce2-a6ff-48bf-bae7-c06e97aba2ee" );

    public static Schema GetSchema()
    {
      // Look  for existing schema

      Schema schema = Schema.Lookup( _guid );

      if( null == schema )
      {
        SchemaBuilder schemaBuilder 
          = new SchemaBuilder( _guid );

        schemaBuilder.SetSchemaName( 
          "Foo" );

        schemaBuilder.AddSimpleField( 
          "Bar", typeof( int ) );

        schema = schemaBuilder.Finish();
      }
      return schema;
    }
  }

  /// <summary>
  /// External Revit command to retrieve EstoreFile 
  /// data from a selected element and recreate 
  /// the external file from it.
  /// </summary>
  [Transaction( TransactionMode.Manual )]
  public class Cmd_7_DataStorage : IExternalCommand
  {
    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Document doc = uidoc.Document;

      if( null == doc )
      {
        message = "Please run this command in an active Revit document.";
        return Result.Failed;
      }

      // Create and populate data storage

      using( Transaction t = new Transaction( doc ) )
      {
        t.Start( "Create DataStorage Element" );

        // Create data storage in new document

        DataStorage dataStorage
          = DataStorage.Create( doc );

        // Create entity to store data

        Entity entity = new Entity(
          FooSchema.GetSchema() );

        entity.Set( "Bar", 42 );

        // Set entity to the data storage element

        dataStorage.SetEntity( entity );

        t.Commit();
      }

      // Retrieve data storage

      FilteredElementCollector a =
        new FilteredElementCollector( doc )
          .OfClass( typeof( DataStorage ) );

      Entity ent = null;

      foreach( DataStorage dataStorage in a )
      {
        ent = dataStorage.GetEntity( 
          FooSchema.GetSchema() );

        // If a DataStorage contains 
        // setting entity, we found it

        if( ent.IsValid() ) break;
      }
      return Result.Succeeded;
    }
  }
}
