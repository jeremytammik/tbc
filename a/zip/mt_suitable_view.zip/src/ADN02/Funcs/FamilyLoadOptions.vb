﻿#Region "Imported Namespaces"
Imports System.Collections.Generic
Imports System.Diagnostics
Imports Autodesk.Revit
Imports Autodesk.Revit.ApplicationServices
Imports Autodesk.Revit.Attributes
Imports Autodesk.Revit.UI.Selection
#End Region

Public Class FamilyLoadOptions
  Implements DB.IFamilyLoadOptions

#Region "IFamilyLoadOptions Interface methods"
  Public Function OnFamilyFound( _
    ByVal familyInUse As Boolean,
    ByRef overwriteParameterValues As Boolean) _
  As Boolean Implements DB.IFamilyLoadOptions.OnFamilyFound

    overwriteParameterValues = True
    Return True
  End Function

  Public Function OnSharedFamilyFound( _
    ByVal sharedFamily As DB.Family,
    ByVal familyInUse As Boolean,
    ByRef source As DB.FamilySource, _
    ByRef overwriteParameterValues As Boolean) _
  As Boolean Implements DB.IFamilyLoadOptions.OnSharedFamilyFound

    overwriteParameterValues = True
    Return True
  End Function
#End Region

End Class
