﻿namespace DataStorageSample2
{
    public class MyProjectSettings
    {
        public int Parameter1 { get; set; }
        public string Parameter2 { get; set; }
    }
}