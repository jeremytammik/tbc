﻿namespace DrivingRevitViaUIAutomation
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_openFile = new System.Windows.Forms.Button();
            this.button_closeFileSave = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button_closeFileSaveNot = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.button_readTabs = new System.Windows.Forms.Button();
            this.button_ok = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_openFile
            // 
            this.button_openFile.Location = new System.Drawing.Point(413, 19);
            this.button_openFile.Name = "button_openFile";
            this.button_openFile.Size = new System.Drawing.Size(75, 23);
            this.button_openFile.TabIndex = 0;
            this.button_openFile.Text = "Open";
            this.button_openFile.UseVisualStyleBackColor = true;
            this.button_openFile.Click += new System.EventHandler(this.button_openFile_Click);
            // 
            // button_closeFileSave
            // 
            this.button_closeFileSave.Location = new System.Drawing.Point(250, 49);
            this.button_closeFileSave.Name = "button_closeFileSave";
            this.button_closeFileSave.Size = new System.Drawing.Size(238, 23);
            this.button_closeFileSave.TabIndex = 1;
            this.button_closeFileSave.Text = "Close active doc with saving";
            this.button_closeFileSave.UseVisualStyleBackColor = true;
            this.button_closeFileSave.Click += new System.EventHandler(this.button_closeFile_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.button_openFile);
            this.groupBox1.Controls.Add(this.button_closeFileSaveNot);
            this.groupBox1.Controls.Add(this.button_closeFileSave);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(496, 79);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Files";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 21);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(401, 20);
            this.textBox1.TabIndex = 2;
            // 
            // button_closeFileSaveNot
            // 
            this.button_closeFileSaveNot.Location = new System.Drawing.Point(6, 49);
            this.button_closeFileSaveNot.Name = "button_closeFileSaveNot";
            this.button_closeFileSaveNot.Size = new System.Drawing.Size(238, 23);
            this.button_closeFileSaveNot.TabIndex = 1;
            this.button_closeFileSaveNot.Text = "Close active doc without saving";
            this.button_closeFileSaveNot.UseVisualStyleBackColor = true;
            this.button_closeFileSaveNot.Click += new System.EventHandler(this.button_closeFileSaveNot_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.treeView1);
            this.groupBox2.Controls.Add(this.button_readTabs);
            this.groupBox2.Location = new System.Drawing.Point(12, 97);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(496, 287);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tabs";
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(19, 48);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(469, 233);
            this.treeView1.TabIndex = 5;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // button_readTabs
            // 
            this.button_readTabs.Location = new System.Drawing.Point(19, 19);
            this.button_readTabs.Name = "button_readTabs";
            this.button_readTabs.Size = new System.Drawing.Size(469, 23);
            this.button_readTabs.TabIndex = 4;
            this.button_readTabs.Text = "Fill List: Read Headers, caching RibbonBar Headers, then select TreeNode";
            this.button_readTabs.UseVisualStyleBackColor = true;
            this.button_readTabs.Click += new System.EventHandler(this.button_readTabs_Click);
            // 
            // button_ok
            // 
            this.button_ok.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button_ok.Location = new System.Drawing.Point(434, 391);
            this.button_ok.Name = "button_ok";
            this.button_ok.Size = new System.Drawing.Size(75, 23);
            this.button_ok.TabIndex = 5;
            this.button_ok.Text = "OK";
            this.button_ok.UseVisualStyleBackColor = true;
            this.button_ok.Click += new System.EventHandler(this.button_ok_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.button_ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 424);
            this.Controls.Add(this.button_ok);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_openFile;
        private System.Windows.Forms.Button button_closeFileSave;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_readTabs;
        private System.Windows.Forms.Button button_ok;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button_closeFileSaveNot;
    }
}

