//
// CmdRelationshipInverter.cs 
//
// Determine door and window to wall relationships,
// i.e. hosted --> host, and invert it to obtain
// a map host --> list of hosted elements.
//
// Copyright (C) 2008 by Jeremy Tammik, 
// Autodesk Inc. All rights reserved.
//

using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit;
using Autodesk.Revit.Elements;
using Autodesk.Revit.Parameters;
using CmdResult
  = Autodesk.Revit.IExternalCommand.Result;

namespace BuildingCoder
{
  public class CmdRelationshipInverter 
    : IExternalCommand
  {
    private Document m_doc;

    /// <summary>
    /// Return an English plural suffix 's' or 
    /// nothing for the given number of items.
    /// </summary>
    public static string PluralSuffix( int n )
    {
      return 1 == n ? "" : "s";
    }

    public static string DotOrColon( int n )
    {
      return 1 < n ? ":" : ".";
    }

    string ElementDescription( Element e )
    {
      // for a wall, the element name equals the 
      // wall type name, which is equivalent to the 
      // family name ...
      FamilyInstance fi = e as FamilyInstance;
      string fn = string.Empty;

      if( null != fi )
      { fn = fi.Symbol.Family.Name + " ";  }

      return string.Format( "{0} {1}<{2} {3}>",
        e.Category.Name, fn,
        e.Id.Value.ToString(), e.Name );
    }

    string ElementDescription( ElementId id )
    {
      Element e = m_doc.get_Element( ref id );
      return ElementDescription( e );
    }

    /// <summary>
    /// From a list of openings, determine 
    /// the wall hoisting each and return a mapping 
    /// of element ids from host to all hosted.
    /// </summary>
    /// <param name="elements">Hosted elements</param>
    /// <returns>Map of element ids from host to 
    /// hosted</returns>
    private Dictionary<ElementId, List<ElementId>>
      getElementIds( List<Element> elements )
    {
      Dictionary<ElementId, List<ElementId>> dict =
        new Dictionary<ElementId, List<ElementId>>();

      string fmt = "{0} is hosted by {1}";

      foreach( FamilyInstance fi in elements )
      {
        ElementId id = fi.Id;
        ElementId idHost = fi.Host.Id;

        Debug.WriteLine( string.Format( fmt,
          ElementDescription( fi ),
          ElementDescription( idHost ) ) );

        if( !dict.ContainsKey( idHost ) )
        {  dict.Add( idHost, new List<ElementId>() );  }

        dict[idHost].Add( id );
      }
      
      return dict;
    }

    private void dumpHostedElements(
      Dictionary<ElementId, List<ElementId>> ids )
    {
      foreach( ElementId idHost in ids.Keys )
      {
        string s = string.Empty;

        foreach( ElementId id in ids[idHost] )
        {
          if( 0 < s.Length )
          { s += ", "; }

          s += ElementDescription( id );
        }

        int n = ids[idHost].Count;

        Debug.WriteLine(string.Format(
          "{0} hosts {1} opening{2}: {3}",
          ElementDescription( idHost ),
          n, PluralSuffix( n ), s ) );
      }
    }

    public CmdResult Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      Application app = commandData.Application;
      m_doc = app.ActiveDocument;

      // f5 = f1 && f4 
      //    = f1 && (f2 || f3) 
      //    = family instance and (door or window)
      Autodesk.Revit.Creation.Filter cf 
        = app.Create.Filter;

      Filter f1 = cf.NewTypeFilter( 
        typeof( FamilyInstance ) );
      
      Filter f2 = cf.NewCategoryFilter( 
        BuiltInCategory.OST_Doors );
      Filter f3 = cf.NewCategoryFilter( 
        BuiltInCategory.OST_Windows );
      
      Filter f4 = cf.NewLogicOrFilter( f2, f3 );
      Filter f5 = cf.NewLogicAndFilter( f1, f4 );
      
      List<Element> openings = new List<Element>();
      int n = m_doc.get_Elements( f5, openings );
      
      // map with key = host element id and
      // value = list of hosted element ids:
      Dictionary<ElementId, List<ElementId>> ids = 
        getElementIds( openings );

      dumpHostedElements( ids );
      m_doc = null;

      return CmdResult.Succeeded;
    }
  }
}
