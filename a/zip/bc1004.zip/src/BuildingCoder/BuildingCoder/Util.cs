using System.Diagnostics;
using Autodesk.Revit.Geometry;

namespace BuildingCoder
{
  class Util
  {
    static public string RealString( double a )
    {
      return a.ToString( "0.##" );
    }

    static public string PointString( XYZ p )
    {
      return string.Format( "({0},{1},{2})", 
        RealString( p.X ), RealString( p.Y ), 
        RealString( p.Z ) );
    }

    const string _caption = "The Building Coder";

    static public void InfoMsg( string msg )
    {
      Debug.WriteLine( msg );
      System.Windows.Forms.MessageBox.Show( msg, 
        _caption, 
        System.Windows.Forms.MessageBoxButtons.OK, 
        System.Windows.Forms.MessageBoxIcon.Information );
    }
  }
}
