#region Namespaces
using System;
using System.Linq;
using System.Collections.Generic;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion

namespace GroupUngroup
{
  [Transaction( TransactionMode.Manual )]
  public class Command : IExternalCommand
  {
    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Application app = uiapp.Application;
      Document doc = uidoc.Document;

      // Prompt user to select existing group

      Group grpExisting = doc.GetElement( 
        uidoc.Selection.PickObject( ObjectType.Element, 
          "Select an existing group" ) ) as Group;

      string name = grpExisting.Name;

      Transaction ungrpTrans = new Transaction( doc );
      ungrpTrans.Start( "Ungroup and delete" );

      // Ungroup the group

      ElementSet grpElements = grpExisting.Ungroup();
      
      ElementSet newgrpElements = new ElementSet();

      // Ignore the first element of the group
      
      int counter = 0;

      foreach( Element e in grpElements )
      {
        if( 0 == counter )
        {
          // Delete the first group element

          doc.Delete( e );
        }
        else
        {
          newgrpElements.Insert( e );
        }
        ++counter;
      }
      ungrpTrans.Commit();

      Transaction grpTrans = new Transaction( doc );
      grpTrans.Start( "Group" );

      // Create new group with new set of elements

      Group grpNew = doc.Create.NewGroup( 
        newgrpElements );

      // Access the name of the previous group type 
      // and change the new group type to previous 
      // group type to retain the previous group 
      // configuration

      FilteredElementCollector coll 
        = new FilteredElementCollector( doc )
          .OfClass( typeof( GroupType ) );

      IEnumerable<GroupType> grpTypes 
        = from GroupType f in coll 
          where f.Name == name select f;

      grpNew.GroupType = grpTypes.First<GroupType>();

      grpTrans.Commit();

      return Result.Succeeded;
    }
  }
}
