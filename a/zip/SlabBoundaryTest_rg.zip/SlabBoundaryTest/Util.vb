﻿#Region "Namespaces"
Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.Linq
Imports System.Reflection
Imports WinForms = System.Windows.Forms
Imports Autodesk.Revit.ApplicationServices
Imports Autodesk.Revit.Attributes
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.UI.Selection
#End Region

Public Class Util
    Public Sub ShowBasicElementInfo(ByRef m_rvtDoc As Document, ByVal elem As Element)

        ''  let's see what kind of element we got. 
        Dim s As String = "You picked:" + vbCr
        s = s + "  Class name = " + elem.GetType.Name + vbCr
        s = s + "  Category = " + elem.Category.Name + vbCr
        s = s + "  Element id = " + elem.Id.ToString + vbCr + vbCr

        ''  and check its type info. 
        Dim elemTypeId As ElementId = elem.GetTypeId
        Dim elemType As ElementType = TryCast(m_rvtDoc.GetElement(elemTypeId), ElementType)
        s = s + "Its ElementType:" + vbCr
        s = s + "  Class name = " + elemType.GetType.Name + vbCr
        s = s + "  Category = " + elemType.Category.Name + vbCr
        s = s + "  Element type id = " + elemType.Id.ToString + vbCr

        ''  show what we got. 
        TaskDialog.Show("Basic Element Info", s)

    End Sub


#Region "Geometrical Comparison"
    Const _eps As Double = 0.000000001

    Public Shared ReadOnly Property Eps() As Double
        Get
            Return _eps
        End Get
    End Property

    Public Shared ReadOnly Property MinLineLength() As Double
        Get
            Return _eps
        End Get
    End Property

    Public Shared ReadOnly Property TolPointOnPlane() As Double
        Get
            Return _eps
        End Get
    End Property

    Public Shared Function IsZero(a As Double, tolerance As Double) As Boolean
        Return tolerance > Math.Abs(a)
    End Function

    Public Shared Function IsZero(a As Double) As Boolean
        Return IsZero(a, _eps)
    End Function

    Public Shared Function IsEqual(a As Double, b As Double) As Boolean
        Return IsZero(b - a)
    End Function

    Public Shared Function Compare(a As Double, b As Double) As Integer
        Return If(IsEqual(a, b), 0, (If(a < b, -1, 1)))
    End Function


    Public Shared Function Compare(p As XYZ, q As XYZ) As Integer
        Dim d As Integer = Compare(p.X, q.X)

        If 0 = d Then
            d = Compare(p.Y, q.Y)

            If 0 = d Then
                d = Compare(p.Z, q.Z)
            End If
        End If
        Return d
    End Function

    Public Shared Function IsEqual(p As XYZ, q As XYZ) As Boolean
        Return 0 = Compare(p, q)
    End Function

    ''' <summary>
    ''' Return true if the vectors v and w 
    ''' are non-zero and perpendicular.
    ''' </summary>
    Private Function IsPerpendicular(v As XYZ, w As XYZ) As Boolean
        Dim a As Double = v.GetLength()
        Dim b As Double = v.GetLength()
        Dim c As Double = Math.Abs(v.DotProduct(w))
        Return _eps < a AndAlso _eps < b AndAlso _eps > c
        ' c * c < _eps * a * b
    End Function

    Public Shared Function IsParallel(p As XYZ, q As XYZ) As Boolean
        Return p.CrossProduct(q).IsZeroLength()
    End Function

    Public Shared Function IsHorizontal(v As XYZ) As Boolean
        Return IsZero(v.Z)
    End Function

    Public Shared Function IsVertical(v As XYZ) As Boolean
        Return IsZero(v.X) AndAlso IsZero(v.Y)
    End Function

    Public Shared Function IsVertical(v As XYZ, tolerance As Double) As Boolean
        Return IsZero(v.X, tolerance) AndAlso IsZero(v.Y, tolerance)
    End Function

    Public Shared Function IsHorizontal(e As Edge) As Boolean
        Dim p As XYZ = e.Evaluate(0)
        Dim q As XYZ = e.Evaluate(1)
        Return IsHorizontal(q - p)
    End Function

    Public Shared Function IsHorizontal(f As PlanarFace) As Boolean
        Return IsVertical(f.Normal)
    End Function

    Public Shared Function IsVertical(f As PlanarFace) As Boolean
        Return IsHorizontal(f.Normal)
    End Function

    Public Shared Function IsVertical(f As CylindricalFace) As Boolean
        Return IsVertical(f.Axis)
    End Function


    ''' <summary>
    ''' Minimum slope for a vector to be considered
    ''' to be pointing upwards. Slope is simply the
    ''' relationship between the vertical and
    ''' horizontal components.
    ''' </summary>
    Const _minimumSlope As Double = 0.3

    ''' <summary>
    ''' Return true if the Z coordinate of the
    ''' given vector is positive and the slope
    ''' is larger than the minimum limit.
    ''' </summary>
    Public Shared Function PointsUpwards(v As XYZ) As Boolean
        Dim horizontalLength As Double = v.X * v.X + v.Y * v.Y
        Dim verticalLength As Double = v.Z * v.Z

        Return 0 < v.Z AndAlso _minimumSlope < verticalLength / horizontalLength

        'return _eps < v.Normalize().Z;
        'return _eps < v.Normalize().Z && IsVertical( v.Normalize(), tolerance );
    End Function

    Public Shared Function PointsDownwards(v As XYZ) As Boolean
        Dim horizontalLength As Double = v.X * v.X + v.Y * v.Y
        Dim verticalLength As Double = v.Z * v.Z

        Return 0 > v.Z AndAlso _minimumSlope < verticalLength / horizontalLength

        'return _eps < v.Normalize().Z;
        'return _eps < v.Normalize().Z && IsVertical( v.Normalize(), tolerance );
    End Function

    ''' <summary>
    ''' Return true if the given bounding box bb
    ''' contains the given point p in its interior.
    ''' </summary>
    Public Function BoundingBoxXyzContains(bb As BoundingBoxXYZ, p As XYZ) As Boolean
        Return 0 < Compare(bb.Min, p) AndAlso 0 < Compare(p, bb.Max)
    End Function

#End Region

#Region "Flatten, i.e. project from 3D to 2D by dropping the Z coordinate"
    ''' <summary>
    ''' Eliminate the Z coordinate.
    ''' </summary>
    Public Shared Function Flatten(point As XYZ) As UV
        Return New UV(point.X, point.Y)
    End Function

    Public Shared Function Flatten2(point As XYZ) As XYZ
        Return New XYZ(point.X, point.Y, 0)
    End Function

    ''' <summary>
    ''' Eliminate the Z coordinate.
    ''' </summary>
    Public Shared Function Flatten(polygon As List(Of XYZ)) As List(Of UV)
        Dim z As Double = polygon(0).Z
        Dim a As New List(Of UV)(polygon.Count)
        For Each p As XYZ In polygon
            Debug.Assert(Util.IsEqual(p.Z, z), "expected horizontal polygon")
            a.Add(Flatten(p))
        Next
        Return a
    End Function

    Public Shared Function Flatten2(polygon As List(Of XYZ)) As List(Of XYZ)
        Dim z As Double = polygon(0).Z
        Dim a As New List(Of XYZ)(polygon.Count)
        For Each p As XYZ In polygon
            a.Add(Flatten2(p))
        Next
        Return a
    End Function

    ''' <summary>
    ''' Eliminate the Z coordinate.
    ''' </summary>
    Public Shared Function Flatten(polygons As List(Of List(Of XYZ))) As List(Of List(Of UV))
        Dim z As Double = polygons(0)(0).Z
        Dim a As New List(Of List(Of UV))(polygons.Count)
        For Each polygon As List(Of XYZ) In polygons
            Debug.Assert(Util.IsEqual(polygon(0).Z, z), "expected horizontal polygons")
            a.Add(Flatten(polygon))
        Next
        Return a
    End Function

    Public Shared Function Flatten2(polygons As List(Of List(Of XYZ))) As List(Of List(Of XYZ))
        Dim z As Double = polygons(0)(0).Z
        Dim a As New List(Of List(Of XYZ))(polygons.Count)
        For Each polygon As List(Of XYZ) In polygons
            a.Add(Flatten2(polygon))
        Next
        Return a
    End Function

#End Region

#Region "Geometrical XYZ Calculation"
    ''' <summary>
    ''' Return the midpoint between two points.
    ''' </summary>
    Public Shared Function Midpoint(p As XYZ, q As XYZ) As XYZ
        Return p + 0.5 * (q - p)
    End Function

    ''' <summary>
    ''' Return the midpoint of a Line.
    ''' </summary>
    Public Shared Function Midpoint(line As Line) As XYZ
        Return Midpoint(line.GetEndPoint(0), line.GetEndPoint(1))
    End Function

    ''' <summary>
    ''' Return the normal of a Line in the XY plane.
    ''' </summary>
    Public Shared Function Normal(line As Line) As XYZ
        Dim p As XYZ = line.GetEndPoint(0)
        Dim q As XYZ = line.GetEndPoint(1)
        Dim v As XYZ = q - p

        'Debug.Assert( IsZero( v.Z ),
        '  "expected horizontal line" );

        Return v.CrossProduct(XYZ.BasisZ).Normalize()
    End Function


    Public Shared Function DividePoints(A As XYZ, B As XYZ, length As Double, increment As Double) As List(Of XYZ)
        Dim retval As New List(Of XYZ)
        retval.Add(A)
        retval.Add(B)

        'retval.Add(Midpoint(A, B))

        '((Xa - Xb) / L) * Ld
        Dim newLength As Double = increment
        For i As Integer = 1 To CInt(length / increment) - 1
            Dim Xn As Double = A.X + (((B.X - A.X) / length) * newLength)
            Dim Yn As Double = A.Y + (((B.Y - A.Y) / length) * newLength)
            Dim Zn As Double = A.Z + (((B.Z - A.Z) / length) * newLength)

            Dim pt As New XYZ(Xn, Yn, Zn)
            retval.Add(pt)
            newLength = newLength + increment
        Next

        Return retval
    End Function

    Public Shared Function IsTopFace(f As Face) As Boolean
        Dim b As BoundingBoxUV = f.GetBoundingBox()
        Dim p As UV = b.Min
        Dim q As UV = b.Max
        Dim midpoint As UV = p + 0.5 * (q - p)
        Dim normal As XYZ = f.ComputeNormal(midpoint)
        Return Util.PointsUpwards(normal)
    End Function

    Public Shared Function IsBottomFace(f As Face) As Boolean
        Dim b As BoundingBoxUV = f.GetBoundingBox()
        Dim p As UV = b.Min
        Dim q As UV = b.Max
        Dim midpoint As UV = p + 0.5 * (q - p)
        Dim normal As XYZ = f.ComputeNormal(midpoint)
        Return Util.PointsDownwards(normal)
    End Function

    ''' <summary>
    ''' Return the four XYZ corners of the given 
    ''' bounding box in the XY plane at the minimum 
    ''' Z elevation in the order lower left, lower 
    ''' right, upper right, upper left:
    ''' </summary>
    'Public Shared Function GetCorners(b As BoundingBoxXYZ) As XYZ()
    '    Dim z As Double = AddressOf b.Min.Z

    '    Return New XYZ() {New XYZ(AddressOf b.Min.X, AddressOf b.Min.Y, z), New XYZ(AddressOf b.Max.X, AddressOf b.Min.Y, z), New XYZ(AddressOf b.Max.X, AddressOf b.Max.Y, z), New XYZ(AddressOf b.Min.X, AddressOf b.Max.Y, z)}
    'End Function

    ''' <summary>
    ''' Offset the generated boundary polygon loop
    ''' model lines downwards to separate them from
    ''' the slab edge.
    ''' </summary>
    Const _offset As Double = 0.1

    ''' <summary>
    ''' Determine the boundary polygons of the lowest
    ''' horizontal planar face of the given solid.
    ''' </summary>
    ''' <param name="polygons">Return polygonal boundary
    ''' loops of lowest horizontal face, i.e. profile of
    ''' circumference and holes</param>
    ''' <param name="solid">Input solid</param>
    ''' <returns>False if no horizontal planar face was
    ''' found, else true</returns>
    Private Shared Function GetBoundary(polygons As List(Of List(Of XYZ)), solid As Solid) As Boolean
        Dim lowest As PlanarFace = Nothing
        Dim faces As FaceArray = solid.Faces
        For Each f As Face In faces
            Dim pf As PlanarFace = TryCast(f, PlanarFace)
            'If pf IsNot Nothing AndAlso Util.IsHorizontal(pf) Then
            If pf IsNot Nothing AndAlso IsBottomFace(f) = True Then
                If (lowest Is Nothing) OrElse (pf.Origin.Z < lowest.Origin.Z) Then
                    lowest = pf

                    Dim p As XYZ, q As XYZ = XYZ.Zero
                    Dim first As Boolean
                    Dim i As Integer, n As Integer
                    Dim loops As EdgeArrayArray = lowest.EdgeLoops
                    For Each [loop] As EdgeArray In loops
                        Dim vertices As New List(Of XYZ)()
                        first = True
                        For Each e As Edge In [loop]
                            Dim points As IList(Of XYZ) = e.Tessellate()
                            p = points(0)
                            If Not first Then
                                Debug.Assert(p.IsAlmostEqualTo(q), "expected subsequent start point" & " to equal previous end point")
                            End If
                            n = points.Count
                            q = points(n - 1)
                            For i = 0 To n - 2
                                Dim v As XYZ = points(i)
                                v -= _offset * XYZ.BasisZ
                                vertices.Add(v)
                            Next
                        Next
                        q -= _offset * XYZ.BasisZ
                        Debug.Assert(q.IsAlmostEqualTo(vertices(0)), "expected last end point to equal" & " first start point")
                        polygons.Add(vertices)
                    Next

                End If
            End If
        Next
        'If lowest IsNot Nothing Then
        '    Dim p As XYZ, q As XYZ = XYZ.Zero
        '    Dim first As Boolean
        '    Dim i As Integer, n As Integer
        '    Dim loops As EdgeArrayArray = lowest.EdgeLoops
        '    For Each [loop] As EdgeArray In loops
        '        Dim vertices As New List(Of XYZ)()
        '        first = True
        '        For Each e As Edge In [loop]
        '            Dim points As IList(Of XYZ) = e.Tessellate()
        '            p = points(0)
        '            If Not first Then
        '                Debug.Assert(p.IsAlmostEqualTo(q), "expected subsequent start point" & " to equal previous end point")
        '            End If
        '            n = points.Count
        '            q = points(n - 1)
        '            For i = 0 To n - 2
        '                Dim v As XYZ = points(i)
        '                v -= _offset * XYZ.BasisZ
        '                vertices.Add(v)
        '            Next
        '        Next
        '        q -= _offset * XYZ.BasisZ
        '        Debug.Assert(q.IsAlmostEqualTo(vertices(0)), "expected last end point to equal" & " first start point")
        '        polygons.Add(vertices)
        '    Next
        'End If
        Return lowest IsNot Nothing
    End Function

    Private Shared Function GetBoundary2(polygons As List(Of List(Of XYZ)), solid As Solid) As Boolean
        Dim lowest As Face = Nothing
        Dim faces As FaceArray = solid.Faces
        For Each f As Face In faces

            'If pf IsNot Nothing AndAlso Util.IsHorizontal(pf) Then
            If f IsNot Nothing AndAlso IsBottomFace(f) = True Then

                lowest = f

                Dim p As XYZ, q As XYZ = XYZ.Zero
                Dim first As Boolean
                Dim i As Integer, n As Integer
                Dim loops As EdgeArrayArray = lowest.EdgeLoops
                For Each [loop] As EdgeArray In loops
                    Dim vertices As New List(Of XYZ)()
                    first = True
                    For Each e As Edge In [loop]
                        Dim points As IList(Of XYZ) = e.Tessellate()
                        p = points(0)
                        If Not first Then
                            Debug.Assert(p.IsAlmostEqualTo(q), "expected subsequent start point" & " to equal previous end point")
                        End If
                        n = points.Count
                        q = points(n - 1)
                        For i = 0 To n - 2
                            Dim v As XYZ = points(i)
                            v -= _offset * XYZ.BasisZ
                            vertices.Add(v)
                        Next
                    Next
                    q -= _offset * XYZ.BasisZ
                    Debug.Assert(q.IsAlmostEqualTo(vertices(0)), "expected last end point to equal" & " first start point")
                    polygons.Add(vertices)
                Next

            End If


        Next

        Return lowest IsNot Nothing
    End Function

    ''' <summary>
    ''' Return all floor slab boundary loop polygons
    ''' for the given floors, offset downwards from the
    ''' bottom floor faces by a certain amount.
    ''' </summary>
    Public Shared Function GetBoundaryPolygons(elems As List(Of Element), opt As Options) As List(Of List(Of XYZ))
        Dim polygons As New List(Of List(Of XYZ))()

        For Each e As Element In elems
            Dim geo As GeometryElement = e.Geometry(opt)

            'GeometryObjectArray objects = geo.Objects; // 2012
            'foreach( GeometryObject obj in objects ) // 2012

            For Each obj As GeometryObject In geo
                ' 2013
                Dim solid As Solid = TryCast(obj, Solid)
                If solid IsNot Nothing Then
                    'GetBoundary(polygons, solid)
                    GetBoundary2(polygons, solid)
                End If
            Next
        Next
        Return polygons
    End Function

#End Region


#Region "Formatting"
    ''' <summary>
    ''' Return an English plural suffix for the given
    ''' number of items, i.e. 's' for zero or more
    ''' than one, and nothing for exactly one.
    ''' </summary>
    Public Shared Function PluralSuffix(n As Integer) As String
        Return If(1 = n, "", "s")
    End Function

    ''' <summary>
    ''' Return an English plural suffix 'ies' or
    ''' 'y' for the given number of items.
    ''' </summary>
    Public Shared Function PluralSuffixY(n As Integer) As String
        Return If(1 = n, "y", "ies")
    End Function


    ''' <summary>
    ''' Return a string for a real number
    ''' formatted to two decimal places.
    ''' </summary>
    Public Shared Function RealString(a As Double) As String
        Return a.ToString("0.##")
    End Function


    ''' <summary>
    ''' Return a string for a UV point
    ''' or vector with its coordinates
    ''' formatted to two decimal places.
    ''' </summary>
    Public Shared Function PointString(p As UV) As String
        Return String.Format("({0},{1})", RealString(p.U), RealString(p.V))
    End Function

    ''' <summary>
    ''' Return a string for an XYZ point
    ''' or vector with its coordinates
    ''' formatted to two decimal places.
    ''' </summary>
    Public Shared Function PointString(p As XYZ) As String
        Return String.Format("({0},{1},{2})", RealString(p.X), RealString(p.Y), RealString(p.Z))
    End Function

#End Region
End Class
