﻿#Region "Imported Namespaces"
Imports System
Imports System.Collections.Generic
Imports Autodesk.Revit.ApplicationServices
Imports Autodesk.Revit.Attributes
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.UI.Selection
#End Region


<Transaction(TransactionMode.Manual)>
Public Class cmdSlabBoundary
    Implements IExternalCommand

    Dim uiapp As UIApplication
    Dim uidoc As UIDocument
    Dim app As Autodesk.Revit.ApplicationServices.Application
    Dim doc As Document
    Dim sel As Selection

    Dim clsUtil As New Util
    Dim fh As New FailureHandler()

    Dim m_Element As Element


    Public Function Execute(commandData As ExternalCommandData, ByRef message As String, elements As ElementSet) As Result Implements IExternalCommand.Execute
        uiapp = commandData.Application
        uidoc = uiapp.ActiveUIDocument
        app = uiapp.Application
        doc = uidoc.Document
        sel = uidoc.Selection

        'so I want to pick an element.  in my final app it could be a floor, roof, pad
        Dim elemFilter As New ElemPickFilter()
        Dim refElement As Reference = uidoc.Selection.PickObject(ObjectType.Element, elemFilter, "Select an object")
        m_Element = doc.GetElement(refElement)

        'so we should have the elment not I want to draw the boundary loop.   
        'this is so I can visually debug why pointinpoly might not be working.  
        'i suspect the polygon is the issue.
        Dim elems As New List(Of Element)()
        elems.Add(m_Element)

        Dim opt As Options = app.Create.NewGeometryOptions()
        Dim polygons As List(Of List(Of XYZ)) = Util.GetBoundaryPolygons(elems, opt)
        'Dim polygons As List(Of List(Of XYZ)) = GetFloorBoundaryPolygons(elems, opt)

        'it doesn't like drawing the boundary for slabs with sloped curved edges so try a flattened XYZ
        'Dim flat_polygons As List(Of List(Of UV)) = Util.Flatten(polygons)
        Dim flat_polygons As List(Of List(Of XYZ)) = Util.Flatten2(polygons)

        Dim creator As New Creator(doc)

        Using t As New Transaction(doc)
            t.Start("Draw Slab Boundaries")
            creator.DrawPolygons(flat_polygons)
            t.Commit()
        End Using

    End Function


End Class
