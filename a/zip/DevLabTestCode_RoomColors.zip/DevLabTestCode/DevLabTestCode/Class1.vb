﻿
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.DB
Imports Autodesk.Revit
Imports Autodesk.Revit.DB.Architecture
Imports Autodesk.Revit.Utility

<Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)> _
<Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)> _
Public Class DevLab
    Implements IExternalCommand

    Public Function Execute(ByVal commandData As Autodesk.Revit.UI.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.DB.ElementSet) As Autodesk.Revit.UI.Result Implements Autodesk.Revit.UI.IExternalCommand.Execute
        Dim oDoc As UIDocument = commandData.Application.ActiveUIDocument
        Dim transaction As DB.Transaction = New DB.Transaction(oDoc.Document, "New")
        Dim oview As ViewPlan = Nothing
        Try
            transaction.Start()

            ' oDoc.Application.ActiveUIDocument.Document.Create.NewAreaViewPlan()

            oview = oDoc.Document.Create.NewAreaViewPlan(oDoc.Document.ActiveView.Name, oDoc.Document.ActiveView.Level, AreaElemType.GrossArea)

            transaction.Commit()
            Return Result.Succeeded
        Catch ex As Exception
            transaction.RollBack()
            Return Result.Failed
        End Try
    End Function
End Class

