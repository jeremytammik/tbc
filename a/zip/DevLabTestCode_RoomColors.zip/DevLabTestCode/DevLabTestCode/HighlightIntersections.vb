﻿'
' (C) Copyright 2003-2007 by Autodesk, Inc.
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted,
' provided that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports System.Text

Imports Autodesk.Revit.ApplicationServices
Imports Autodesk.Revit.Attributes
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.DB.Analysis
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.UI.Selection

Namespace Revit.Test.CSTemplate
    <Regeneration(RegenerationOption.Manual)> _
    <Transaction(TransactionMode.Manual)> _
    Public Class RestoreViewCommand
        Implements IExternalCommand
#Region "IExternalCommand Members"

        Public Function Execute1(ByVal commandData As Autodesk.Revit.UI.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.DB.ElementSet) As Autodesk.Revit.UI.Result Implements Autodesk.Revit.UI.IExternalCommand.Execute

            'End Function
            'Public Function Execute(ByVal commandData As ExternalCommandData, ByRef message As String, ByVal elements As ElementSet) As Result
            Dim doc As Document = commandData.Application.ActiveUIDocument.Document
            Dim t As New Transaction(doc, "Restore View")
            t.Start()
            Dim view As View = doc.ActiveView

            Dim sfm As SpatialFieldManager = SpatialFieldManager.GetSpatialFieldManager(View)
            If sfm IsNot Nothing Then
                sfm.Clear()
            End If

            Dim categories As Categories = doc.Settings.Categories

            HighlightIntersectionsCommand.SetCategoryVisible(categories, BuiltInCategory.OST_Walls, view)
            HighlightIntersectionsCommand.SetCategoryVisible(categories, BuiltInCategory.OST_Columns, view)
            HighlightIntersectionsCommand.SetCategoryVisible(categories, BuiltInCategory.OST_StructuralColumns, view)

            t.Commit()

            Return Result.Succeeded
        End Function

#End Region
    End Class

    ''' <summary>
    ''' get element's id and type information and its supported information.
    ''' </summary>
    <Regeneration(RegenerationOption.Manual)> _
    <Transaction(TransactionMode.Manual)> _
    Public Class HighlightIntersectionsCommand
        Implements IExternalCommand

        Public Function Execute1(ByVal commandData As Autodesk.Revit.UI.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.DB.ElementSet) As Autodesk.Revit.UI.Result Implements Autodesk.Revit.UI.IExternalCommand.Execute

            'End Function
            'Public Function Execute(ByVal revit As ExternalCommandData, ByRef message As String, ByVal elements As ElementSet) As Result
            m_uiApp = commandData.Application
            m_app = m_uiApp.Application
            m_uiDoc = m_uiApp.ActiveUIDocument
            m_doc = m_uiDoc.Document

            'TaskDialog.Show("Test application", "Revit version: " + m_app.VersionBuild);

            'm_writer = new StreamWriter( @"C:\CSTemplate.txt" );

            HighlightIntersections(commandData.Application.ActiveUIDocument.Document)

            'm_writer.Close();

            Return Result.Succeeded
        End Function

        ''' <summary>
        ''' A data structure containing the details of each intersecting wall/column pair.
        ''' </summary>
        Private Structure Intersection
            Public Wall As Element
            Public Column As Element
            Public Solid As Solid
        End Structure

        ''' <summary>
        ''' A collection of all intersections.
        ''' </summary>
        Private m_allIntersections As List(Of Intersection)

        ''' <summary>
        ''' Finds and posts information on wall/column intersections.
        ''' </summary>
        ''' <param name="doc">The document.</param>
        Public Sub FindIntersectionVolumes(ByVal doc As Document)
            ' Find all Wall elements.
            Dim collector As New FilteredElementCollector(doc)
            collector.OfClass(GetType(FamilyInstance))
            m_allIntersections = New List(Of Intersection)()

            Dim categories As New List(Of BuiltInCategory)()
            categories.Add(BuiltInCategory.OST_Columns)
            categories.Add(BuiltInCategory.OST_StructuralColumns)
            Dim categoryFilter As New ElementMulticategoryFilter(categories)
            collector.WherePasses(categoryFilter)

            For Each famInst As FamilyInstance In collector.OfType(Of FamilyInstance)()
                Dim walllIntersectionCollector As New FilteredElementCollector(doc)
                walllIntersectionCollector.OfClass(GetType(Wall))

                ' Columns may be one of two different categories

                Dim geomElem As GeometryElement = famInst.GetOriginalGeometry(New Options()).GetTransformed(famInst.GetTransform())

                Dim columnSolid As Solid = GetGeometry(geomElem)

                ' Apply intersection filter to find matches
                Dim intersectsFilter As New ElementIntersectsSolidFilter(columnSolid)
                walllIntersectionCollector.WherePasses(intersectsFilter)

                For Each element As Element In walllIntersectionCollector
                    ' Store information on intersection
                    Dim intersection As Intersection
                    intersection.Wall = TryCast(element, Wall)
                    intersection.Column = famInst

                    Dim wallGeometry As GeometryElement = element.Geometry(New Options())
                    Dim wallSolid As Solid = GetGeometry(wallGeometry)

                    ' Intersect the solid geometry of the two elements
                    intersection.Solid = BooleanOperationsUtils.ExecuteBooleanOperation(wallSolid, columnSolid, BooleanOperationsType.Intersect)

                    m_allIntersections.Add(intersection)
                Next
            Next

            Dim td As New TaskDialog("Intersection info")
            td.MainInstruction = "Intersections found: " & m_allIntersections.Count
            Dim builder As New StringBuilder()
            For Each intersection As Intersection In m_allIntersections
                builder.AppendLine([String].Format("{0} x {1}: volume {2} faces {3}", intersection.Wall.Name, intersection.Column.Name, intersection.Solid.Volume, intersection.Solid.Faces.Size))
            Next
            td.MainContent = builder.ToString()

            td.Show()
        End Sub

        ''' <summary>
        ''' Return the solid geometry of an element.  
        ''' </summary>
        ''' <remarks>Makes an assumption that each element consists of only one 
        ''' positive-volume solid, and returns the first one it finds.</remarks>
        Public Function GetGeometry(ByVal geomElem As GeometryElement) As Solid
            For Each geomObj As GeometryObject In geomElem.Objects
                ' Walls and some columns will have a solid directly in its geometry
                If TypeOf geomObj Is Solid Then
                    Dim solid As Solid = DirectCast(geomObj, Solid)
                    If solid.Volume > 0 Then
                        Return solid
                    End If
                End If

                ' Some columns will have a instance pointing to symbol geometry
                If TypeOf geomObj Is GeometryInstance Then
                    Dim geomInst As GeometryInstance = DirectCast(geomObj, GeometryInstance)
                    ' Instance geometry is obtained so that the intersection works as
                    ' expected without requiring transformation
                    Dim instElem As GeometryElement = geomInst.GetInstanceGeometry()

                    For Each instObj As GeometryObject In instElem.Objects
                        If TypeOf instObj Is Solid Then
                            Dim solid As Solid = DirectCast(instObj, Solid)
                            If solid.Volume > 0 Then
                                Return solid
                            End If
                        End If
                    Next
                End If
            Next
            Return Nothing
        End Function

        Public Sub HighlightIntersections(ByVal doc As Document)
            FindIntersectionVolumes(doc)

            Dim t As New Transaction(doc, "Hide categories")
            t.Start()
            Dim view As View = doc.ActiveView

            Dim categories As Categories = doc.Settings.Categories

            SetCategoryInvisible(categories, BuiltInCategory.OST_Walls, view)
            SetCategoryInvisible(categories, BuiltInCategory.OST_Columns, view)
            SetCategoryInvisible(categories, BuiltInCategory.OST_StructuralColumns, view)

            t.Commit()

            Dim value As Double = 1.0
            For Each intersection As Intersection In m_allIntersections
                PaintSolid(doc, intersection.Solid, value)
                value += 1
            Next
        End Sub

        Public Sub RestoreViewAfterHighlight(ByVal doc As Document)
            Dim t As New Transaction(doc, "Show categories")
            t.Start()
            Dim view As View = doc.ActiveView

            Dim categories As Categories = doc.Settings.Categories

            SetCategoryVisible(categories, BuiltInCategory.OST_Walls, view)
            SetCategoryVisible(categories, BuiltInCategory.OST_Columns, view)
            SetCategoryVisible(categories, BuiltInCategory.OST_StructuralColumns, view)

            t.Commit()

            Dim sfm As SpatialFieldManager = SpatialFieldManager.GetSpatialFieldManager(doc.ActiveView)
            If sfm IsNot Nothing Then
                sfm.Clear()
            End If
        End Sub

        Private schemaId As Integer = -1

        Private Sub PaintSolid(ByVal doc As Document, ByVal s As Solid, ByVal value As Double)
            Dim app As Application = doc.Application

            Dim view As View = doc.ActiveView

            If view.AnalysisDisplayStyleId = ElementId.InvalidElementId Then
                CreateAVFDisplayStyle(doc, view)
            End If

            Dim sfm As SpatialFieldManager = SpatialFieldManager.GetSpatialFieldManager(view)
            If sfm Is Nothing Then
                sfm = SpatialFieldManager.CreateSpatialFieldManager(view, 1)
            End If

            If schemaId <> -1 Then
                Dim results As IList(Of Integer) = sfm.GetRegisteredResults()

                If Not results.Contains(schemaId) Then
                    schemaId = -1
                End If
            End If

            If schemaId = -1 Then
                Dim resultSchema1 As New AnalysisResultSchema("PaintedSolid", "Description")
                schemaId = sfm.RegisterResult(resultSchema1)
            End If

            Dim faces As FaceArray = s.Faces
            Dim trf As Transform = Transform.Identity

            For Each face As Face In faces
                Dim idx As Integer = sfm.AddSpatialFieldPrimitive(face, trf)

                Dim uvPts As IList(Of UV) = New List(Of UV)()
                Dim doubleList As New List(Of Double)()
                Dim valList As IList(Of ValueAtPoint) = New List(Of ValueAtPoint)()
                Dim bb As BoundingBoxUV = face.GetBoundingBox()
                uvPts.Add(bb.Min)
                doubleList.Add(value)
                valList.Add(New ValueAtPoint(doubleList))
                Dim pnts As New FieldDomainPointsByUV(uvPts)
                Dim vals As New FieldValues(valList)

                sfm.UpdateSpatialFieldPrimitive(idx, pnts, vals, schemaId)
            Next
        End Sub

        Private Sub CreateAVFDisplayStyle(ByVal doc As Document, ByVal view As View)
            Dim t As New Transaction(doc, "Create AVF style")
            t.Start()
            Dim coloredSurfaceSettings As New AnalysisDisplayColoredSurfaceSettings()
            coloredSurfaceSettings.ShowGridLines = True
            Dim colorSettings As New AnalysisDisplayColorSettings()
            Dim legendSettings As New AnalysisDisplayLegendSettings()
            legendSettings.ShowLegend = False
            Dim analysisDisplayStyle__1 As AnalysisDisplayStyle = AnalysisDisplayStyle.CreateAnalysisDisplayStyle(doc, "Paint Solid", coloredSurfaceSettings, colorSettings, legendSettings)

            view.AnalysisDisplayStyleId = analysisDisplayStyle__1.Id
            t.Commit()
        End Sub

        Public Shared Sub SetCategoryInvisible(ByVal categories As Categories, ByVal bic As BuiltInCategory, ByVal view As View)
            SetCategoryVisibility(categories, bic, view, False)
        End Sub

        Public Shared Sub SetCategoryVisible(ByVal categories As Categories, ByVal bic As BuiltInCategory, ByVal view As View)
            SetCategoryVisibility(categories, bic, view, True)
        End Sub

        Private Shared Sub SetCategoryVisibility(ByVal categories As Categories, ByVal bic As BuiltInCategory, ByVal view As View, ByVal visible As Boolean)
            Dim category As Category = categories.Item(bic)
            category.Visible(view) = visible
        End Sub

        Private m_uiApp As Autodesk.Revit.UI.UIApplication
        Private m_uiDoc As Autodesk.Revit.UI.UIDocument
        Private m_app As Application
        Private m_doc As Autodesk.Revit.DB.Document

        'private TextWriter m_writer;



    End Class
End Namespace