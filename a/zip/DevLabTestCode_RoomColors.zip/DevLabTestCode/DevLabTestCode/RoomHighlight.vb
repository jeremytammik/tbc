﻿'
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports System.Text

Imports Autodesk.Revit.ApplicationServices
Imports Autodesk.Revit.Attributes
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.DB.Analysis
Imports Autodesk.Revit.UI
Imports Autodesk.Revit.UI.Selection
Imports Autodesk.Revit


<Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)> _
<Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)> _
Public Class RoomHighlight
    Implements IExternalCommand
    Private schemaId As Integer = -1

    Public Function Execute(ByVal commandData As Autodesk.Revit.UI.ExternalCommandData, ByRef message As String, ByVal elements As Autodesk.Revit.DB.ElementSet) As Autodesk.Revit.UI.Result Implements Autodesk.Revit.UI.IExternalCommand.Execute
        Dim oDoc As UIDocument = commandData.Application.ActiveUIDocument
        Dim transaction As DB.Transaction = New DB.Transaction(oDoc.Document, "New")
        Dim oview As ViewPlan = Nothing
        Try
            '  transaction.Start()
            Dim collectorTmp As DB.FilteredElementCollector = Nothing  '= New DB.FilteredElementCollector(app.ActiveUIDocument.Document)
            ' collectorTmp = New DB.FilteredElementCollector(oDoc.Document, oDoc.ActiveView.Id)
            collectorTmp = New DB.FilteredElementCollector(oDoc.Document) ', oDoc.ActiveView.Id)
            collectorTmp.WhereElementIsNotElementType.ToElements()
            collectorTmp.OfCategory(BuiltInCategory.OST_Rooms)


            Dim value As Double = 1.0
            For Each oRoom As Architecture.Room In collectorTmp
                Dim wallGeometry As GeometryElement = oRoom.ClosedShell() '(New Options())
                Dim wallSolid As Solid = GetGeometry(wallGeometry)
                PaintSolid(oDoc.Document, wallSolid, value)
                value = value + 1
            Next

            transaction.Start()
            Dim categories As Categories = oDoc.Document.Settings.Categories
            SetCategoryInvisible(categories, BuiltInCategory.OST_Walls, oDoc.ActiveView)

            transaction.Commit()
            Return Result.Succeeded
        Catch ex As Exception
            ' transaction.RollBack()
            Return Result.Failed
        End Try
    End Function

    Public Shared Sub SetCategoryInvisible(ByVal categories As Categories, ByVal bic As BuiltInCategory, ByVal view As View)
        SetCategoryVisibility(categories, bic, view, False)
    End Sub

    Private Shared Sub SetCategoryVisibility(ByVal categories As Categories, ByVal bic As BuiltInCategory, ByVal view As View, ByVal visible As Boolean)
        Dim category As Category = categories.Item(bic)
        category.Visible(view) = visible
    End Sub

    Public Function GetGeometry(ByVal geomElem As GeometryElement) As Solid
        For Each geomObj As GeometryObject In geomElem.Objects
            ' Walls and some columns will have a solid directly in its geometry
            If TypeOf geomObj Is Solid Then
                Dim solid As Solid = DirectCast(geomObj, Solid)
                If solid.Volume > 0 Then
                    Return solid
                End If
            End If

            ' Some columns will have a instance pointing to symbol geometry
            If TypeOf geomObj Is GeometryInstance Then
                Dim geomInst As GeometryInstance = DirectCast(geomObj, GeometryInstance)
                ' Instance geometry is obtained so that the intersection works as
                ' expected without requiring transformation
                Dim instElem As GeometryElement = geomInst.GetInstanceGeometry()

                For Each instObj As GeometryObject In instElem.Objects
                    If TypeOf instObj Is Solid Then
                        Dim solid As Solid = DirectCast(instObj, Solid)
                        If solid.Volume > 0 Then
                            Return solid
                        End If
                    End If
                Next
            End If
        Next
        Return Nothing
    End Function

    Private Sub PaintSolid(ByVal doc As Document, ByVal s As Solid, ByVal value As Double)
        Dim app As Application = doc.Application

        Dim view As View = doc.ActiveView

        If view.AnalysisDisplayStyleId = ElementId.InvalidElementId Then
            CreateAVFDisplayStyle(doc, view)
        End If

        Dim sfm As SpatialFieldManager = SpatialFieldManager.GetSpatialFieldManager(view)
        If sfm Is Nothing Then
            sfm = SpatialFieldManager.CreateSpatialFieldManager(view, 1)
        End If

        If schemaId <> -1 Then
            Dim results As IList(Of Integer) = sfm.GetRegisteredResults()

            If Not results.Contains(schemaId) Then
                schemaId = -1
            End If
        End If

        If schemaId = -1 Then
            Dim resultSchema1 As New AnalysisResultSchema("PaintedSolid", "Description")
            schemaId = sfm.RegisterResult(resultSchema1)
        End If

        Dim faces As FaceArray = s.Faces
        Dim trf As Transform = Transform.Identity

        For Each face As Face In faces
            Dim idx As Integer = sfm.AddSpatialFieldPrimitive(face, trf)

            Dim uvPts As IList(Of UV) = New List(Of UV)()
            Dim doubleList As New List(Of Double)()
            Dim valList As IList(Of ValueAtPoint) = New List(Of ValueAtPoint)()
            Dim bb As BoundingBoxUV = face.GetBoundingBox()
            uvPts.Add(bb.Min)
            doubleList.Add(value)
            valList.Add(New ValueAtPoint(doubleList))
            Dim pnts As New FieldDomainPointsByUV(uvPts)
            Dim vals As New FieldValues(valList)

            sfm.UpdateSpatialFieldPrimitive(idx, pnts, vals, schemaId)
        Next
    End Sub

    Private Sub CreateAVFDisplayStyle(ByVal doc As Document, ByVal view As View)
        Dim t As New Transaction(doc, "Create AVF style")
        t.Start()
        Dim coloredSurfaceSettings As New AnalysisDisplayColoredSurfaceSettings()
        coloredSurfaceSettings.ShowGridLines = True
        Dim colorSettings As New AnalysisDisplayColorSettings()
        Dim legendSettings As New AnalysisDisplayLegendSettings()
        legendSettings.ShowLegend = False
        Dim analysisDisplayStyle__1 As AnalysisDisplayStyle = AnalysisDisplayStyle.CreateAnalysisDisplayStyle(doc, "Paint Solid", coloredSurfaceSettings, colorSettings, legendSettings)

        view.AnalysisDisplayStyleId = analysisDisplayStyle__1.Id
        t.Commit()
    End Sub
End Class
