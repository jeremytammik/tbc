﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Threading;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace ExternalEventTests
{
    class FlipHandHandler : IExternalEventHandler
    {
        ViewModel vm;
        Action<object> setStatus;

        public FlipHandHandler(ViewModel vm, Action<object> setStatus)
        {
            this.vm = vm;
            this.setStatus = setStatus;
        }

        public void Execute(UIApplication app)
        {
            var doc = app.ActiveUIDocument.Document;

            var doorset = vm.door == null ?
                new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_Doors)
                .ToElements() : null;

            setStatus(doorset.Count);
#if ONE_TX
            using (Transaction tx = new Transaction(app.ActiveUIDocument.Document))
            {
                tx.Start("FlipHandHandlerExecute");

                if (vm.door == null)
                    for (int i = 0; i < doorset.Count; i++)
                    {
                        //vm.Status = i.ToString();
                        setStatus(GetName() + i);
                        try
                        {
                            (doorset[i] as FamilyInstance).flipHand();
                        }
                        catch (Exception e)
                        {
                            //Debug.Assert(false, e.ToString());
                            //vm.Status = e.Message; 
                        }
                    }
                else vm.door.flipHand();

                tx.Commit();
            }
#else
            if (vm.door == null)
                for (int i = 0; i < doorset.Count; i++)
                {
                    //vm.Status = i.ToString();
                    setStatus(GetName() + i);
                    try
                    {
                        flipHand(doorset[i] as FamilyInstance, doc);
                    }
                    catch (Exception e)
                    {
                        //Debug.Assert(false, e.ToString());
                        //vm.Status = e.Message; 
                    }
                }
            else flipHand(vm.door, doc);
#endif
            if (vm.door != null)
                vm.Status = GetName();
        }

        void flipHand(FamilyInstance door, Document doc)
        {
            using (Transaction tx = new Transaction(doc))
            {
                tx.Start("FlipHandHandlerExecute");

                door.flipHand();

                tx.Commit();
            }
        }

        public string GetName()
        {
            return "FlipFacingHandler";
        }
    }
}
