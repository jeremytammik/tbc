﻿using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace ExternalEventTests
{
    class FlipFacingHandler : IExternalEventHandler
    {
        ViewModel vm;

        public FlipFacingHandler(ViewModel vm)
        {
            this.vm = vm;
        }

        public void Execute(UIApplication app)
        {
            var doc = app.ActiveUIDocument.Document;

            var doorset = vm.door == null ?
                new FilteredElementCollector(doc, doc.ActiveView.Id)
                .OfCategory(BuiltInCategory.OST_Doors)
                .ToElements() : null;

            using (Transaction tx = new Transaction(doc))
            {
                tx.Start("FlipFacingHandlerExecute");

                if (vm.door == null)
                    for (int i = 0; i < doorset.Count; i++)
                    {
                        (doorset[i] as FamilyInstance).flipFacing();
                        vm.Status = GetName() + i;
                        vm.doEvents();
                    }
                else vm.door.flipFacing();

                tx.Commit();
            }

            vm.Status = vm.door == null ? doorset.Count.ToString() : GetName();
        }

        public string GetName()
        {
            return "FlipFacingHandler";
        }
    }
}
