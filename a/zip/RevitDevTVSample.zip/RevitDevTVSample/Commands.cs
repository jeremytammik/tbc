﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.Attributes;

namespace RevitDevTVSample
{
    [Transaction(TransactionMode.Automatic)]
    [Regeneration(RegenerationOption.Manual)]
    public class Commands : IExternalCommand
    {
        public Result Execute(
            ExternalCommandData commandData,
            ref string message,
            Autodesk.Revit.DB.ElementSet elements)
        {
            //Part 1
            System.Windows.Forms.MessageBox.Show("Hello Revit");

            //Part 2
            UIApplication uiApp = commandData.Application;
            UIDocument uiDoc = uiApp.ActiveUIDocument;

            Selection sel = uiDoc.Selection;

            foreach (Element ele in sel.Elements)
            {
                String eleInfo = String.Format(
                    "Name: {0}\nCategory: {1}",
                    ele.Name, ele.Category.Name);

                System.Windows.Forms.MessageBox.Show(eleInfo);
            }

            //Part 3
            Document doc = uiDoc.Document;
            FilteredElementCollector doors = new FilteredElementCollector(doc);
            doors.OfClass(typeof(FamilyInstance));
            doors.OfCategory(BuiltInCategory.OST_Doors);
            foreach (FamilyInstance door in doors)
            {
                StringBuilder doorInfo = new StringBuilder();
                doorInfo.AppendFormat("Name: {0}", door.Name);

                //Part 4
                foreach (Parameter param in door.Parameters)
                {
                    doorInfo.AppendFormat("\nParameter: {0} - Value: ", param.Definition.Name);

                    if (param.AsValueString() != null)
                        doorInfo.Append(param.AsValueString());
                    else
                        switch (param.StorageType)
                        {
                            case StorageType.String:
                                doorInfo.Append(param.AsString());
                                break;
                            default:
                                doorInfo.Append("Homework");
                                break;
                        }
                }

                System.Windows.Forms.MessageBox.Show(doorInfo.ToString());
            }

            return Result.Succeeded;
        }
    }
}
