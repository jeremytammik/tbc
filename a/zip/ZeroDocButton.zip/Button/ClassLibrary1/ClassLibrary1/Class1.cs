﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes; // specify this if you want to save typing for attributes. e.g.
using System.Windows.Media.Imaging;

namespace ClassLibrary1
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class Class1: IExternalApplication
    {

        //String m_assembly = @"C:\Temp\Button\ClassLibrary1\ClassLibrary2\bin\Debug\ClassLibrary2.dll";
        static string m_assembly = System.Reflection.Assembly.GetExecutingAssembly().Location;

        #region IExternalApplication Members

        public Result OnShutdown(UIControlledApplication application)
        {
            return Result.Succeeded;
        }

        public Result OnStartup(UIControlledApplication application)
        {
            RibbonPanel panel = application.CreateRibbonPanel("Ribbon Sampler");
            AddPushButton(panel);
            
            return Result.Succeeded;
        }

        public void AddPushButton(RibbonPanel panel)
        {
                        
            PushButtonData pushButtonDataHello = new PushButtonData("PushButtonHello", "Hello World", m_assembly, "ClassLibrary1.HelloWorld");
            pushButtonDataHello.AvailabilityClassName = "ClassLibrary1.ButtonAvailability";

            //' add a button to the panel 
            PushButton pushButtonHello = panel.AddItem(pushButtonDataHello) as PushButton;

            pushButtonHello.ToolTip = "simple push button";

        }      
        #endregion
    }

    public class ButtonAvailability: IExternalCommandAvailability
    {
        #region IExternalCommandAvailability Members

        public bool IsCommandAvailable(UIApplication applicationData, CategorySet selectedCategories)
        {
           return true;
        }

        #endregion
    }

    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class HelloWorld : IExternalCommand
    {

        #region IExternalCommand Members

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            TaskDialog.Show("Welcome", "Hi there!!");

            return Result.Succeeded;
        }

        #endregion
    }
}
