﻿#region Namespaces
using System;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion

namespace ImpInstGeo
{
  [Transaction( TransactionMode.ReadOnly )]
  public class Command : IExternalCommand
  {
    /// <summary>
    /// Return an English plural suffix for the given 
    /// number of items, i.e. 's' for zero or more 
    /// than one, and nothing for exactly one.
    /// </summary>
    static string PluralSuffix( int n )
    {
      return 1 == n ? "" : "s";
    }

    /// <summary>
    /// Retrieve a single pre-selected element, if one exists.
    /// Otherwise prompt the user to select an element.
    /// </summary>
    static Result GetSingleSelectedElement(
      UIDocument uidoc,
      out Element e )
    {
      e = null;

      Selection sel = uidoc.Selection;

      // Check for a single pre-selected element

      SelElementSet set = sel.Elements;

      if( 1 == set.Size )
      {
        foreach( Element e2 in set )
        {
          e = e2;
        }
      }

      if( null == e )
      {
        // Prompt user to select an element

        if( ViewType.Internal == uidoc.ActiveView.ViewType )
        {
          TaskDialog.Show( "Error",
            "Cannot pick an element in this view: "
            + uidoc.ActiveView.Name );

          return Result.Failed;
        }

        try
        {
          Reference r = sel.PickObject(
            ObjectType.Element,
            "Please pick an element" );

          e = uidoc.Document.get_Element( 
            r.ElementId );
        }
        catch( OperationCanceledException )
        {
          return Result.Cancelled;
        }
      }
      return Result.Succeeded;
    }

    public Result Execute(
      ExternalCommandData commandData,
      ref string message,
      ElementSet elements )
    {
      UIApplication uiapp = commandData.Application;
      UIDocument uidoc = uiapp.ActiveUIDocument;
      Application app = uiapp.Application;
      Document doc = uidoc.Document;

      Element e;

      Result r = GetSingleSelectedElement( uidoc, out e );

      if( Result.Succeeded == r )
      {
        int curveCounter = 0;
        int polylineCounter = 0;

        GeometryElement geoElement 
          = e.get_Geometry( new Options() );

        foreach( GeometryObject geoObject 
          in geoElement.Objects )
        {
          GeometryInstance instance 
            = geoObject as GeometryInstance;

          if( null != instance )
          {
            foreach( GeometryObject instObj 
              in instance.SymbolGeometry.Objects )
            {
              if( instObj is Curve )
              {
                ++curveCounter;
              }
              else if( instObj is PolyLine )
              {
                ++polylineCounter;
              }
            }
          }
        }
        TaskDialog.Show( "GeometryInstance Symbol Geometry",
          string.Format( "{0} curve{1} and {2} polyline{3}",
            curveCounter, PluralSuffix( curveCounter ),
            polylineCounter, PluralSuffix( polylineCounter ) ) );
      }
      return r;
    }
  }
}
