﻿#region Namespaces
using System;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
#endregion

namespace SetoutPoints
{
  class App : IExternalApplication
  {
    const string Caption = "Setout Points";
    const string _cmd1 = "Mark Concrete Corners";
    const string _cmd2 = "Renumber";
    const string _class_name_prefix = "SetoutPoints.Cmd";

    public Result OnStartup( 
      UIControlledApplication a )
    {
      string path = System.Reflection.Assembly
        .GetExecutingAssembly().Location;

      // Create ribbon panel

      RibbonPanel p = a.CreateRibbonPanel( Caption );

      // Create buttons

      PushButtonData d = new PushButtonData( 
        _cmd1, _cmd1, path, 
        _class_name_prefix + "GeomVertices" );

      d.ToolTip = "Place a setout point marker "
        + "on every concrete corner.";

      p.AddItem( d );

      d = new PushButtonData( _cmd2, _cmd2, path, 
        _class_name_prefix + _cmd2 );

      d.ToolTip = "Renumber major setout points";

      p.AddItem( d );


      return Result.Succeeded;
    }

    public Result OnShutdown( 
      UIControlledApplication a )
    {
      return Result.Succeeded;
    }
  }
}
