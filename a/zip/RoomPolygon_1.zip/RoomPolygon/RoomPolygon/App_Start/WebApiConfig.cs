﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace RoomPolygon
{
  public static class WebApiConfig
  {
    public static void Register( HttpConfiguration config )
    {
      config.Routes.MapHttpRoute(
          name: "DefaultApi",
          routeTemplate: "api/{controller}/{id}",
          defaults: new { id = RouteParameter.Optional },
          constraints: new { id = "[0-9a-z]+" } // jeremy, cf. http://www.asp.net/web-api/overview/web-api-routing-and-actions/routing-and-action-selection
      );
    }
  }
}
