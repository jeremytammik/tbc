﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Http;

namespace RoomPolygon.Controllers
{
  public class RoomController : ApiController
  {
    //// GET: /Room/
    //public ActionResult Index()
    //{
    //    return View();
    //}

    // GET api/room
    public IEnumerable<string> Get()
    {
      return new string[] { "value1", "value2" };
    }

    // removed by jeremy:

    // GET api/room/5
    //public string Get( int id )
    //{
    //  return "value";
    //}

    // added by jeremy:

    public string Get( string id )
    {
      return string.Format(
        "The room containing the input location "
        + "'{0}' is still being determined...", 
        id );
    }

    // POST api/room
    public void Post( [FromBody]string value )
    {
    }

    // PUT api/room/5
    public void Put( int id, [FromBody]string value )
    {
    }

    // DELETE api/room/5
    public void Delete( int id )
    {
    }
  }
}
