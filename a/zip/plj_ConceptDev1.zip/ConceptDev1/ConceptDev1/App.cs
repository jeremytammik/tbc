///<header>
/// DISCALIMER:
/// This add-in developed on a concept level as part of the research for my MSc thesis
/// Its main purpose is to support the conclusions of a interoperability method analysis
/// The functionality is limited to a few variables in SBi213/Be10-EAM exchange requirements
/// 
/// Correct/valid output data is not guaranteed
/// ...
/// December 2014
/// Peter Lind Johansen
/// stud.building informatics
/// Aalborg University
///</header>

#region Namespaces
using System;
using System.Collections.Generic;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
#endregion

namespace ConceptDev1
{
    class App : IExternalApplication
    {
        public Result OnStartup(UIControlledApplication a)
        {
            return Result.Succeeded;
        }

        public Result OnShutdown(UIControlledApplication a)
        {
            return Result.Succeeded;
        }
    }
}
