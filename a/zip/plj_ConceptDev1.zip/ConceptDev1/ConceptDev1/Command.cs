///<header>
/// DISCALIMER:
/// This add-in developed on a concept level as part of the research for my MSc thesis
/// Its main purpose is to support the conclusions of a interoperability method analysis
/// The functionality is limited to a few variables in SBi213/Be10-EAM exchange requirements
/// 
/// Correct/valid output data is not guaranteed
/// ...
/// December 2014
/// Peter Lind Johansen
/// stud.building informatics
/// Aalborg University
///</header>

#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Linq;
using WinForms = System.Windows.Forms;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Text;
using System.IO;

using X = Microsoft.Office.Interop.Excel;
#endregion

namespace ConceptDev1
{
    /// <summary>
    /// collects the Be10-EAM relevant window information:
    /// Area, Orientation, VerticalTilt
    /// and exports it to Excel
    /// </summary>
    [Transaction(TransactionMode.Manual)]
    public class Command : IExternalCommand
    {

        // set member variables
        // allthough they aren't actually used ...
        Application m_app;
        Document m_doc;
        // ...
                
        public Result Execute(
          ExternalCommandData commandData,
          ref string message,
          ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Application app = uiapp.Application;
            Document doc = uidoc.Document;
            m_app = uiapp.Application;
            m_doc = uidoc.Document;

            // call methods between here ...

            

            // ... and here

            // get link instances
            FilteredElementCollector linkcollector = new FilteredElementCollector(doc);
            linkcollector.OfClass(typeof(RevitLinkInstance));
            

            // Someone should stop this thing if no link instance is present/loaded
            
            Stopwatch sw = Stopwatch.StartNew();

            X.Application excel = new X.Application();
            if (null == excel)
            {
                Utils.ErrorMsg(
                    "Failed to start MS Excel");

                return Result.Failed;
            }
            excel.Visible = true;

            X.Workbook workbook = excel.Workbooks.Add(
                Missing.Value);

            

            int linksCount = 0;
            int instNum = 0;
            foreach (Element elem in linkcollector)
            {
                
                RevitLinkInstance linkInst = elem as RevitLinkInstance;
                Document linkedDoc = linkInst.GetLinkDocument();
                
                string linkName = linkedDoc.Title;

                X.Worksheet worksheet;

                worksheet = excel.Worksheets.Add(
                    Missing.Value, Missing.Value,
                    Missing.Value, Missing.Value)
                    as X.Worksheet;

                worksheet.Name = linkName;

                
                worksheet.Cells[2, 1] = "FamilyType";
                worksheet.Cells[2, 4] = "ID";
                worksheet.Cells[2, 5] = "Areal";
                worksheet.Cells[2, 6] = "Orientering";
                worksheet.Cells[2, 7] = "H�ldning";

                FilteredElementCollector wincollector = new FilteredElementCollector(linkedDoc);
                wincollector.OfCategory(BuiltInCategory.OST_Windows);
                wincollector.OfClass(typeof(FamilyInstance));

                
                int row = 3;
                int instNumLink = 0;
                foreach (FamilyInstance expInst in wincollector)
                {
                    worksheet.Cells[row, 1] = expInst.Name;
                    worksheet.Cells[row, 4] = expInst.Id;

                    Parameter paramArea = expInst.get_Parameter(BuiltInParameter.HOST_AREA_COMPUTED);
                    double metricArea = Utils.areaMultiplier * paramArea.AsDouble();
                    decimal areaDecimal = (decimal)metricArea;
                    areaDecimal = decimal.Round(areaDecimal, 2);                    
                    worksheet.Cells[row, 5] = areaDecimal;

                    // msdn ref Atan2: 
                    // http://msdn.microsoft.com/en-us/library/vstudio/system.math.atan2(v=vs.100).aspx
                    // msdn ref Abs: 
                    // http://msdn.microsoft.com/en-us/library/vstudio/a4ke8e73(v=vs.100).aspx

                    XYZ facing = expInst.FacingOrientation;
                    // Be10 coord system is CW with Y-axis = 0 deg
                    // 'typical' atan is then reversed to x / y
                    double radians = Math.Atan2(facing.X, facing.Y);
                    double orientDeg = radians * (180 / Math.PI);
                    if (orientDeg < 0)
                    {
                        orientDeg += 360;
                    }
                    // msdn ref Math.Round: 
                    // http://msdn.microsoft.com/en-us/library/vstudio/System.Math.Round(v=vs.100).aspx
                    worksheet.Cells[row, 6] = Math.Round(orientDeg, 2);

                    double radianZ = Math.Atan(facing.Z);
                    double tiltAngle = radianZ * (180 / Math.PI);
                    // adjust to Be10
                    tiltAngle += 90;

                    worksheet.Cells[row, 7] = Math.Round(tiltAngle, 2);                    

                    instNum++;
                    row++;
                    instNumLink++;
                }
                
                linksCount++;
                worksheet.Cells[1, 1] = instNumLink;
                worksheet.Cells[1, 2] = "instances from link: " + linkedDoc.Title;
                
            }

            sw.Stop();

            string exportMsg = "Total Windows Instances exported: " + instNum +
                "\n From " + linksCount + " Linked Documents" +
                " in " + sw.Elapsed.TotalSeconds + " seconds"; 

            TaskDialog.Show("Export", exportMsg);

            // the end
            return Result.Succeeded;
        }
        
    }
}
