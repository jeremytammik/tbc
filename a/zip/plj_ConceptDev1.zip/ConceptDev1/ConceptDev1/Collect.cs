﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Linq;
using WinForms = System.Windows.Forms;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System.Text;
using System.IO;

using X = Microsoft.Office.Interop.Excel;
#endregion

namespace ConceptDev1
{
    public class Collect
    {
        // Get link information
        // help ref: http://help.autodesk.com/view/RVT/2015/ENU/?guid=GUID-0DFBA9EA-0E7B-49D4-9576-6D0528FC0D3C
        // ...
        public static GetAllRevitLinkInstances(Document doc)
        {
            
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            collector.OfClass(typeof(RevitLinkInstance));
            foreach (Element elem in collector)
            {
                RevitLinkInstance link = elem as RevitLinkInstance;
                Document linkDoc = link.GetLinkDocument();
            }
            return doc;
        }

        /// <summary>
        /// collects link instances 
        /// </summary>
        /// <param name="document"></param>
        /// <returns></returns>
        public Document CollectLinkInstances(Document document)
        {
            FilteredElementCollector collector = new FilteredElementCollector(document);
            collector.OfClass(typeof(RevitLinkInstance));

            foreach (Element elem in collector)
            {
                RevitLinkInstance linkInst = elem as RevitLinkInstance;
                Document linkDoc = linkInst.GetLinkDocument();
                return linkDoc;
            }
            return document;
        }
        public static FilteredElementCollector CollectOfType(
            Document doc,
            Type type,
            BuiltInCategory biCat)
        {
            FilteredElementCollector collector = new FilteredElementCollector(doc);

            collector.OfCategory(biCat);
            collector.OfClass(type);

            return collector;
        }


        //public static FilteredElementCollector CollectElementsOfType(
        //    Document doc,
        //    Type elemType,
        //    BuiltInCategory biCat)
        //{
        //    FilteredElementCollector collector = new FilteredElementCollector(doc);

        //    collector.OfCategory(biCat);
        //    collector.OfClass(elemType);

        //    return collector;
        //}

    }
}
