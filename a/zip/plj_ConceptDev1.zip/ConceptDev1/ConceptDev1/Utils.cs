﻿#region Namespaces
using System.Diagnostics;
using Autodesk.Revit.UI;


#endregion

namespace ConceptDev1
{
    static class Utils
    {
        public const string Caption = "Be10ConceptDev";

        // square feet to square meters
        public const double areaMultiplier = 0.09290304;

        /// <summary>
        /// TaskDialog for error message
        /// </summary>
        public static void ErrorMsg(string msg)
        {
            Debug.WriteLine(msg);

            TaskDialog dialog = new TaskDialog(Caption);
            dialog.MainIcon = TaskDialogIcon.TaskDialogIconWarning;
            dialog.MainInstruction = msg;
            dialog.Show();
        }

    }
}
