﻿Imports System.Windows.Forms

Public Class ProgressDlg
    Delegate Sub taskFunction(ByVal progressNotifier As ProgressDlg)

    Property Fun As taskFunction = Nothing
    Property CancelTask As Boolean = False

    Private Sub ProgressDlg_Load(sender As Object, e As EventArgs) Handles Me.Load
        Me.lPercentage.Text = "0%"

        'Enable the Cancel button while 
        Me.btnCancel.Enabled = True

        'Start the timer
        Timer1.Start()
    End Sub
    Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        'Cancel the asynchronous operation.
        'Me.bgWorker.CancelAsync()
        Me.CancelTask = True

        'Disable the Cancel button.
        Me.btnCancel.Enabled = False
    End Sub

    Public Sub Increment(ByVal vintProgressPercentage As Integer)
        If 0 <= vintProgressPercentage AndAlso vintProgressPercentage <= 100 Then
            Me.progressBar.Value = vintProgressPercentage
            Me.lPercentage.Text = String.Format("{0}%", vintProgressPercentage)
        End If
        Application.DoEvents()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Timer1.Stop()
        Try
            If Me.Fun IsNot Nothing Then Me.Invoke(Fun, Me)
            If Me.CancelTask Then
                ' The user canceled the operation.
                Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Else
                'The operation completed normally.
                Me.DialogResult = System.Windows.Forms.DialogResult.Yes
            End If
        Catch ex As Exception
            'There was an error during the operation.
            Me.DialogResult = System.Windows.Forms.DialogResult.No
            MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Me.Increment(100)
        Me.Close()
    End Sub
End Class