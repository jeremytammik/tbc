﻿Imports Autodesk.Revit.UI
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.DB.Architecture
Imports Autodesk.Revit.DB.Mechanical

Public Class Form1
    Property RvtApp As UIApplication
    '' declare a kind of delegate with the signature you want
    'Private Delegate Sub processingFunDelegate(ByVal bgWorker As System.ComponentModel.BackgroundWorker)

    Private Sub bgWorker_DoWork(sender As Object, e As ComponentModel.DoWorkEventArgs) Handles bgWorker.DoWork
        Dim worker As System.ComponentModel.BackgroundWorker = CType(sender, System.ComponentModel.BackgroundWorker)
        Dim app As UIApplication = DirectCast(e.Argument, UIApplication)
        Dim doc As Document = app.ActiveUIDocument.Document
        'Dim doc As Document = constData.theRvtAPP.ActiveUIDocument.Document
        processingFun(worker, doc)
        'Dim del As processingFunDelegate = AddressOf constData.processingFun
        'Me.Invoke(del, worker)
        e.Result = True
    End Sub

    Private Sub bgWorker_ProgressChanged(sender As Object, e As ComponentModel.ProgressChangedEventArgs) Handles bgWorker.ProgressChanged
        Me.progressBar.Value = e.ProgressPercentage
    End Sub

    Private Sub bgWorker_RunWorkerCompleted(sender As Object, e As ComponentModel.RunWorkerCompletedEventArgs) Handles bgWorker.RunWorkerCompleted
        Me.progressBar.Value = 100
        btnOK.Enabled = True
    End Sub

    Private Sub processingFun(ByVal bgWorker As System.ComponentModel.BackgroundWorker, ByVal doc As Document)
        'get all Rooms and Spaces elements from active document.
        Dim spatialElements As New List(Of Element)
        Dim collector As New FilteredElementCollector(doc)
        Dim roomSpaceFilter As New LogicalOrFilter(New RoomFilter(), New SpaceFilter())
        spatialElements.AddRange(collector.WherePasses(roomSpaceFilter).ToElements())

        If spatialElements.Count > 0 Then
            Dim iIdx As Integer = 0
            For Each element As Element In spatialElements
                'Get room geometry & boundaries          
                If element IsNot Nothing AndAlso _
                   TypeOf element Is SpatialElement Then
                    Try
                        Dim space As SpatialElement = DirectCast(element, SpatialElement)
                        Dim strName As String = space.Name

                        ' computing area or spatial geometry raise a system AccessViolationException !!!
                        Dim dArea As Double = space.Area
                        Dim calculator As New SpatialElementGeometryCalculator(doc)
                        Dim results As SpatialElementGeometryResults = calculator.CalculateSpatialElementGeometry(space)
                        ' ------------------------------------------------------------------------------------------------

                    Catch ex As Exception
                    End Try
                End If
                If bgWorker IsNot Nothing Then bgWorker.ReportProgress(CInt(iIdx / spatialElements.Count * 100))
                iIdx += 1
            Next
        End If
    End Sub

    Private Sub btnWork_Click(sender As Object, e As EventArgs) Handles btnWork.Click
        If bgWorker.IsBusy <> True Then
            ' Start the asynchronous operation.
            bgWorker.RunWorkerAsync(Me.RvtApp)
            btnOK.Enabled = False
        End If
        'processingFun(Nothing, RvtApp.ActiveUIDocument.Document)
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub
End Class