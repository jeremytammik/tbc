﻿Imports Autodesk.Revit.UI
Imports Autodesk.Revit.DB
Imports Autodesk.Revit.DB.Architecture
Imports Autodesk.Revit.DB.Mechanical


<Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)> _
<Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)> _
<Autodesk.Revit.Attributes.Journaling(Autodesk.Revit.Attributes.JournalingMode.NoCommandData)>
Public Class Command
    Implements IExternalCommand

    Public Function Execute(ByVal commandData As Autodesk.Revit.UI.ExternalCommandData,
                            ByRef message As String, ByVal elements As Autodesk.Revit.DB.ElementSet) As Autodesk.Revit.UI.Result Implements Autodesk.Revit.UI.IExternalCommand.Execute
        Dim ret As Result = Result.Succeeded
        Dim dlgProgress As New ProgressDlg
        Try
            constData.theRvtAPP = commandData.Application
            Dim transaction As New Transaction(constData.theRvtAPP.ActiveUIDocument.Document, "BackgroundWorker Command")
            If transaction.Start() = TransactionStatus.Started Then
                'Dim form As New Form1
                'form.RvtApp = commandData.Application
                'form.ShowDialog()
                dlgProgress.Fun = AddressOf processingFun
                dlgProgress.ShowDialog()
                transaction.Commit()
            End If
        Catch ex As Exception
            ret = Autodesk.Revit.UI.Result.Failed
        End Try
        dlgProgress.Increment(100)
        dlgProgress.Close()
        Return ret
    End Function


End Class


Public Module constData
    Public Sub processingFun(ByVal bgWorker As System.ComponentModel.BackgroundWorker)
        'get all Rooms and Spaces elements from active document.
        Dim doc As Document = constData.theRvtAPP.ActiveUIDocument.Document
        Dim spatialElements As New List(Of Element)
        Dim collector As New FilteredElementCollector(doc)
        Dim roomSpaceFilter As New LogicalOrFilter(New RoomFilter(), New SpaceFilter())
        spatialElements.AddRange(collector.WherePasses(roomSpaceFilter).ToElements())

        If spatialElements.Count > 0 Then
            Dim iIdx As Integer = 0
            For Each element As Element In spatialElements
                'Get room geometry & boundaries          
                If element IsNot Nothing AndAlso _
                   TypeOf element Is SpatialElement Then
                    Try
                        Dim space As SpatialElement = DirectCast(element, SpatialElement)
                        Dim strName As String = space.Name

                        ' computing area or spatial geometry raise a system AccessViolationException !!!
                        Dim dArea As Double = space.Area
                        Dim calculator As New SpatialElementGeometryCalculator(doc)
                        Dim results As SpatialElementGeometryResults = calculator.CalculateSpatialElementGeometry(space)
                        ' ------------------------------------------------------------------------------------------------

                    Catch ex As Exception
                    End Try
                End If
                If bgWorker IsNot Nothing Then bgWorker.ReportProgress(CInt(iIdx / spatialElements.Count * 100))
                iIdx += 1
            Next
        End If
    End Sub

    Public theRvtAPP As Autodesk.Revit.UI.UIApplication
    Public Sub processingFun(ByVal dlgProgress As ProgressDlg)
        'get all Rooms and Spaces elements from active document.
        Dim spatialElements As New List(Of Element)
        Dim collector As New FilteredElementCollector(constData.theRvtAPP.ActiveUIDocument.Document)
        Dim roomSpaceFilter As New LogicalOrFilter(New RoomFilter(), New SpaceFilter())
        spatialElements.AddRange(collector.WherePasses(roomSpaceFilter).ToElements())

        If spatialElements.Count > 0 Then
            Dim iIdx As Integer = 1
            For Each element As Element In spatialElements
                'Get room geometry & boundaries          
                If element IsNot Nothing AndAlso _
                   TypeOf element Is SpatialElement Then
                    Try
                        Dim space As SpatialElement = DirectCast(element, SpatialElement)
                        Dim strName As String = space.Name
                        If dlgProgress IsNot Nothing Then dlgProgress.Increment(CInt(iIdx / spatialElements.Count * 100))

                        ' computing area or spatial geometry raise a system AccessViolationException !!!
                        Dim dArea As Double = space.Area
                        Dim calculator As New SpatialElementGeometryCalculator(constData.theRvtAPP.ActiveUIDocument.Document)
                        Dim results As SpatialElementGeometryResults = calculator.CalculateSpatialElementGeometry(space)
                        ' ------------------------------------------------------------------------------------------------
                        ' do same timeconsuming calculation
                        Dim i As Integer = 0
                        While i < 1000000
                            Dim dd = Math.Pow(10, i)
                            i += 1
                        End While

                        If dlgProgress IsNot Nothing AndAlso dlgProgress.CancelTask Then Return

                    Catch ex As Exception
                    End Try
                End If
                iIdx += 1
            Next
        End If
    End Sub
End Module
