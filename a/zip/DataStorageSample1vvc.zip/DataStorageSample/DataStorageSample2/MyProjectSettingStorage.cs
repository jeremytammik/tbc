using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;

namespace DataStorageSample2
{
    class MyProjectSettingStorage
    {
        readonly Guid settingDsId = new Guid("{A71F620F-BD0D-46DD-AECD-AFDEF0DFFD74}");

        public MyProjectSettings ReadSettings(Document document)
        {
            var settingDs = GetSettingsDataStorage(document);

            if (settingDs == null) return null;

            var settingsEntity = settingDs.GetEntity(MyProjectSettingsSchema.GetSchema());
            if (!settingsEntity.IsValid())
                return null;

            MyProjectSettings settings = 
                new MyProjectSettings();


            settings.Parameter1 = settingsEntity.Get<int>("Parameter1");
            settings.Parameter2 = settingsEntity.Get<string>("Parameter2");

            return settings;
        }

        public void WriteSettings(Document document, MyProjectSettings settings)
        {
            var settingDs = GetSettingsDataStorage(document);

            if (settingDs == null)
                settingDs = DataStorage.Create(document);

            Entity settingsEntity = 
                new Entity(MyProjectSettingsSchema.GetSchema());

            settingsEntity.Set("Parameter1", settings.Parameter1);
            settingsEntity.Set("Parameter2", settings.Parameter2);

            //identify settings data storage
            Entity idEntity = new Entity(DataStorageUniqueIdSchema.GetSchema());
            idEntity.Set("Id", settingDsId);

            settingDs.SetEntity(idEntity);
            settingDs.SetEntity(settingsEntity);
        }

        private DataStorage GetSettingsDataStorage(Document document)
        {
            //Retrieve all data storages from project
            FilteredElementCollector collector =
                new FilteredElementCollector(document);

            var dataStorages =
                collector.OfClass(typeof(DataStorage));

            //find setting data storage
            foreach (DataStorage dataStorage in dataStorages)
            {
                Entity settingIdEntity =
                    dataStorage.GetEntity(DataStorageUniqueIdSchema.GetSchema());
                if (!settingIdEntity.IsValid()) continue;

                var id = settingIdEntity.Get<Guid>("Id");
                if (!id.Equals(settingDsId)) continue;

                return dataStorage;
            }

            return null;
        }

    }
}