using System;
using System.Text;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace DataStorageSample2
{
    [Transaction(TransactionMode.Manual)]
    public class ReadWriteSettingsCommand : IExternalCommand
    {
        #region Implementation of IExternalCommand

        public Result Execute(ExternalCommandData commandData, 
                              ref string message, 
                              ElementSet elements)
        {
            Document document =
                commandData.Application.ActiveUIDocument.Document;

            MyProjectSettings settings = new MyProjectSettings();

            settings.Parameter1 = new Random().Next();
            settings.Parameter2 = document.PathName;

            MyProjectSettingStorage settingStorage = new MyProjectSettingStorage();

            using (Transaction t = new Transaction(document, "Write settings"))
            {
                t.Start();
                settingStorage.WriteSettings(document, settings);
                t.Commit();
            }

            MyProjectSettings readedSettings =
                settingStorage.ReadSettings(document);

            if (readedSettings == null)
            {
                message = "Could not get settings";
                return Result.Failed;
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Parameter1: {0}\r\n", readedSettings.Parameter1);
            sb.AppendFormat("Parameter2: {0}\r\n", readedSettings.Parameter2);

            TaskDialog.Show("Settings",
                            sb.ToString());

            return Result.Succeeded;
        }

        #endregion
    }
}