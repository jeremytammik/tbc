// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

// std
#include <memory>

// AcGe
#include <gecurv3d.h>
#include <gegblge.h>
#include <gelent3d.h>
#include <geline3d.h>
#include <gelnsg3d.h>
#include <gepnt3d.h>
#include <geplane.h>



