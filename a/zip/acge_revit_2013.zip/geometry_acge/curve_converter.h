#ifndef SOF_RVT_GEOMETRY_ACGE_CURVE_CONVERTER_H
#define SOF_RVT_GEOMETRY_ACGE_CURVE_CONVERTER_H


// AcGe
#include <gecurv3d.h>
#include <gegblge.h>
#include <gelent3d.h>
#include <geline3d.h>
#include <gelnsg3d.h>
#include <gepnt3d.h>
#include <geplane.h>


namespace Geometry { namespace AcGe {

	public ref class Converter abstract sealed
	{
   public:
      static std::unique_ptr<AcGeCurve3d> createAcGeCurve(Autodesk::Revit::DB::Curve^ curve);

      static Autodesk::Revit::DB::Curve^ createRevitCurve(Autodesk::Revit::Creation::Application^ app, const AcGeCurve3d* curve);

      static std::unique_ptr<AcGePoint3d> createAcGePoint(Autodesk::Revit::DB::XYZ^ xyz);

      static Autodesk::Revit::DB::XYZ^ createRevitXYZ(const AcGePoint3d* pt);

      static std::unique_ptr<AcGeVector3d> createAcGeVector(Autodesk::Revit::DB::XYZ^ xyz);

      static Autodesk::Revit::DB::XYZ^ createRevitXYZ(const AcGeVector3d* vec);

      static std::unique_ptr<AcGePlane> createAcGePlane(Autodesk::Revit::DB::Plane^ plane);

      static Autodesk::Revit::DB::Plane^ createRevitPlane(const AcGePlane* plane);

   private:
      static std::unique_ptr<AcGeLinearEnt3d> createAcGeLinear(Autodesk::Revit::DB::Line^ curve);

      static Autodesk::Revit::DB::Line^ createRevitLine(Autodesk::Revit::Creation::Application^ app, const AcGeLinearEnt3d* curve);

      //static std::unique_ptr<AcGeCircArc3d> createAcGeArc(Autodesk::Revit::DB::Arc^ curve);
	};



   public ref class Helper abstract sealed
   {
   public:
      static Autodesk::Revit::DB::GeometryObject^ orthoProjectIntoPlane(Autodesk::Revit::DB::Curve^ curve, Autodesk::Revit::DB::Plane^ plane, Autodesk::Revit::Creation::Application^ app);
      static Autodesk::Revit::DB::GeometryObject^ projectIntoPlane(Autodesk::Revit::DB::Curve^ curve, Autodesk::Revit::DB::Plane^ plane, Autodesk::Revit::Creation::Application^ app);
   };

}
}

#endif
