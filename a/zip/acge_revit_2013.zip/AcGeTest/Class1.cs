﻿using System;

using RvtDB = Autodesk.Revit.DB;
using RvtUI = Autodesk.Revit.UI;

namespace AcGeTest
{
   public class ExternalApplication : RvtUI.IExternalApplication
   {
      /** @todo Could we use Tao.Platform.Windows.Kernel.SetDllDirectory? */
      //[DllImport("kernel32.dll", EntryPoint = "SetDllDirectory", SetLastError = true)]
      //[return: MarshalAs(UnmanagedType.Bool)]
      //public extern static bool SetDllDirectory(string lpPathName);

      //[DllImport("kernel32.dll")]
      //private static extern IntPtr LoadLibraryEx(string lpFileName, IntPtr hFile, uint dwFlags);
      //public static IntPtr LoadLibrary(string lpFileName)
      //{
      //   System.IntPtr handle = LoadLibraryEx(lpFileName, IntPtr.Zero, 0);
      //   return handle;
      //}


      //private List<AssemblyResolver> m_assemblyResolvers = new List<AssemblyResolver>();

      // IExternalApplication implementations
      public RvtUI.Result OnStartup(RvtUI.UIControlledApplication application)
      {
         Autodesk.Revit.Creation.Application creator = application.ControlledApplication.Create;

         // Plane with normal in z-direction
         RvtDB.Plane plane = new RvtDB.Plane(-RvtDB.XYZ.BasisZ, RvtDB.XYZ.Zero);

         // Line in z-direction
         RvtDB.XYZ lineStartPt = new RvtDB.XYZ(0, 0, 10);
         RvtDB.XYZ lineEndPt = new RvtDB.XYZ(0, 0, 100);
         RvtDB.Line lineInZ = creator.NewLineBound(lineStartPt, lineEndPt);

         RvtDB.GeometryObject projection = Geometry.AcGe.Helper.orthoProjectIntoPlane(lineInZ, plane, creator);
         if (projection is RvtDB.Point)
         {
            RvtDB.XYZ pt = ((RvtDB.Point)projection).Coord;
         }

         // Line diagonal
         lineStartPt = new RvtDB.XYZ(0, 0, 0);
         lineEndPt = new RvtDB.XYZ(100, 0, 100);
         RvtDB.Line lineDiagonal = creator.NewLineBound(lineStartPt, lineEndPt);
         double lineLen = lineDiagonal.Length;

         projection = Geometry.AcGe.Helper.orthoProjectIntoPlane(lineDiagonal, plane, creator);
         if (projection is RvtDB.Line)
         {
            RvtDB.Line l = (RvtDB.Line)projection;
            RvtDB.XYZ pt1 = l.get_EndPoint(0);
            RvtDB.XYZ pt2 = l.get_EndPoint(1);
            lineLen = l.Length;
         }

         projection = Geometry.AcGe.Helper.projectIntoPlane(lineDiagonal, plane, creator);
         if (projection is RvtDB.Line)
         {
            RvtDB.Line l = (RvtDB.Line)projection;
            RvtDB.XYZ pt1 = l.get_EndPoint(0);
            RvtDB.XYZ pt2 = l.get_EndPoint(1);
            lineLen = l.Length;
         }

         return RvtUI.Result.Succeeded;
      }

      public RvtUI.Result OnShutdown(RvtUI.UIControlledApplication application)
      {
         return RvtUI.Result.Succeeded;
      }
   }
}
