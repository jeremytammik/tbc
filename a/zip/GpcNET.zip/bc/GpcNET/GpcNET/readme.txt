This sample shows how to use the GPC polygon library. You can find further information about it on the net:

http://www.softpedia.com/get/Programming/Components-Libraries/General-Polygon-Clipper.shtml

This library is only free to use for non-commercial use. Please contact the vendor if you are thinking of using it in a commercial product.

1) In the Visual Studio project, adjust the "Properties > Build > Output Path" to point to the Revit.exe folder, e.g. "C:\Program Files\Revit Architecture 2009\Program".
2) Compile the project.
3) Copy the gpc.dll file from the project folder to the Revit.exe folder.
4) Adjust your Revit.ini file, for instance using the text in the sample Revit.ini file provided.
