//
//	requires: ghosts.js
//

//
//	Tree class
//

function LayerTree () {

	//if m_bImg is set to true you must fill .src fields during LayerTree initialization
	this.m_bImg				= false;
	this.m_imgOpen			= new Image();
	this.m_imgClose			= new Image();
	this.m_imgChildShow		= new Image();
	this.m_imgChildHide		= new Image();

	this.m_vItems 	= new Array();
	this.m_nItems	= 0;

	this.addItem	= LayerTree_addItem;
	this.addChild	= LayerTree_addChild;
	this.roll		= LayerTree_roll;
	this.rollChild	= LayerTree_rollChild;
}

//
//	Tree item class
//
function LayerItem ( sName, nLevel, bChild ) {
	this.m_ghost	= new Ghost( sName, 1 );
	this.m_sName	= sName;
	this.m_nLevel	= nLevel;
	this.m_bChild	= bChild;
	this.m_bOpen	= true;
}

//
//	Implementation
//
function LayerTree_addItem ( sName, nLevel, bOpen ) {
	var item = new LayerItem ( sName, nLevel, false );
	item.m_bOpen = bOpen;
	item.m_ghost.m_bVisibility = bOpen;
	this.m_vItems[ this.m_nItems ] = item;
	this.m_nItems ++;
}

function LayerTree_addChild ( sName, bOpen ) {
	var nPrevLevel = this.m_vItems[ this.m_nItems-1 ].m_nLevel;
	var item = new LayerItem ( sName, nPrevLevel, true );
	item.m_bOpen = bOpen;
	item.m_ghost.m_bVisibility = bOpen;
	this.m_vItems[ this.m_nItems ] = item;
	this.m_nItems ++;
}

function LayerTree_roll ( nIdx ) {
	var item = this.m_vItems[nIdx];
	var nLevel = item.m_nLevel;
	var bOpen = !item.m_bOpen;
	item.m_bOpen = bOpen;
	if( this.m_bImg ) {
		if( bOpen ) {
			eval( "document.Img" + item.m_sName + ".src = this.m_imgOpen.src;" );
		} else {
			eval( "document.Img" + item.m_sName + ".src = this.m_imgClose.src;" );
		}
	}
	
	++nIdx;
	while( nIdx < this.m_nItems && this.m_vItems[nIdx].m_bChild ) {
		++nIdx;
	}
	while( nIdx < this.m_nItems ) {
		item = this.m_vItems[nIdx];
		if( item.m_nLevel > nLevel ) {
			var bShowThis;
			if( item.m_bChild ) {
				if( bOpen ) {
					bShowThis = item.m_bOpen;
				} else {
					bShowThis = false;
				}
			} else {	//not child
				item.m_bOpen = bOpen;
				bShowThis = bOpen;
			}
			item.m_ghost.show( bShowThis );
			++nIdx;
		} else {
			break;
		}
	}
}

function LayerTree_rollChild ( nIdx, nChild ) {
	var item = this.m_vItems[nIdx];
	
	++nIdx;
	item = this.m_vItems[nIdx];
	while( nIdx < this.m_nItems && item.m_bChild ) {
		item.m_bOpen = !item.m_bOpen
		item.m_ghost.show( item.m_bOpen );

		if( this.m_bImg ) {
			if( item.m_bOpen ) {
				eval( "document.Img" + item.m_sName + ".src = this.m_imgChildShow.src;" );
			} else {
				eval( "document.Img" + item.m_sName + ".src = this.m_imgChildHide.src;" );
			}
		}

		++nIdx;
		item = this.m_vItems[nIdx];
	}
}

