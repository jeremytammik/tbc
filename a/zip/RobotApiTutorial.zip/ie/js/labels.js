////////////////////
// browser version
var nBrowser = 0;
if( document.layers ) {
	nBrowser = 1;	//Netscape
} else if( document.all ) {
	nBrowser = 2;	//IE >= 4
	if( navigator.userAgent.indexOf('MSIE 5') > 0 ) {
		nBrowser = 3;	//IE 5
	}
}

// state if page has finished loading
var bScriptLoaded = false;
function PageLoaded () {
	if( bScriptLoaded && nBrowser > 0 && ( nBrowser != 2 || document.FormLoaded ))
		return true;
	else
		return false;
}

// show label
function ShowLabel ( sTitle, sText ) {
	if( PageLoaded() ) {
		if( nBrowser == 1 ) {
			gLabel.m_ghost.show( true );
			gLabel.setContent( sTitle, sText );
		} else {
			gLabel.setContent( sTitle, sText );
			gLabel.m_ghost.show( true );
		}
	}
}

// hide label
function HideLabel () {
	if( PageLoaded() ) {
		gLabel.m_ghost.show( false );
		gLabel.setContent( "", "" )
	}
}

////////////////////
//class Ghost

function Ghost ( sDivName, nShowMode ) {
	this.m_sDivName		= sDivName;
	this.m_sDivRef		= ( nBrowser == 1 ? "document." + sDivName : sDivName + ".style" );
	this.m_bVisible		= false;
	this.m_nX			= 0;
	this.m_nY			= 0;

	//0 - show/hide
	//1 - show/hide with page content move (style="position:block")
	//    ( currently supported only by IE )
	this.m_nShowMode	= ( nShowMode ? nShowMode : 0 );	


	this.setContent		= Ghost_setContent;
	this.show			= Ghost_show;	
	this.moveTo			= Ghost_moveTo;
	this.getHeight		= Ghost_getHeight;
	this.getWidth		= Ghost_getWidth;
}

function Ghost_setContent ( sContent ) {
	if ( nBrowser == 1 ) {
		var layer;
		eval( "layer = " + this.m_sDivRef + ".document" );
        layer.write( sContent );
		layer.close();
	} else if( nBrowser > 1 ) {
		document.all[ this.m_sDivName ].innerHTML = sContent;
	}
}

function Ghost_show ( bShow ) {
	var sShow;
	if( nBrowser == 1 ) {
		sShow = bShow ? "show" : "hide";
		this.m_bVisible = bShow;
		this.moveTo( this.m_nX, this.m_nY );
		eval( this.m_sDivRef + ".visibility = \"" + sShow + "\"" );
	} else if( nBrowser > 1 ) {
		this.m_bVisible = bShow;
		if( this.m_nShowMode == 0 ) {
			this.moveTo( this.m_nX, this.m_nY );
			eval( this.m_sDivRef + ".visibility = \"" + (bShow ? "visible" : "hidden") + "\"" );
		} else {
			document.all[this.m_sDivName].style.display = (bShow ? "block" : "none");
		}
	}
}

function Ghost_moveTo( nX, nY ) {
	if( nBrowser > 0 ) {
		this.m_nX = nX;
		this.m_nY = nY;
		if( !this.m_bVisible ) {
			nX = nY = 0;
		}
		eval( this.m_sDivRef + ".left = " + nX );
		eval( this.m_sDivRef + ".top = " + nY );
	}
}

function Ghost_getWidth () {
	var nWidth = 0;
	if( nBrowser == 1 ) {
		eval( "nWidth = " + this.m_sDivRef + ".clip.width" );
	} else if( nBrowser > 1 ) {
		nWidth = 0;
	}
	return nWidth;
}

function Ghost_getHeight () {
	var nHeight = 0;
	if( nBrowser == 1 ) {
		eval( "nHeight = " + this.m_sDivRef + ".clip.height" );
	} else if( nBrowser > 1 ) {
		nHeight = 0;
	}
	return nHeight;
}


////////////////////
//class Label

function Label ( sDivName ) {
	this.m_ghost		= new Ghost ( sDivName );
	
	this.setContent		= Label_setContent;
}

function Label_setContent ( sTitle, sText ) {
	var sContent = "<TABLE border=0 cellpadding=0 cellspacing=0 >"
		+ "<TR>"
		+ "<TD>"
		+ "<TABLE width=\"100%\" border=1 cellpadding=0 cellspacing=0 >"
			+ "<TR><TD>"
			+ "<TABLE width=\"100%\" border=0 cellpadding=4 cellspacing=0 >"
			+ ( sTitle != "" ? "<TR><TD class=\"LabelTitle\">" + sTitle + "</TD></TR>" : "" )
			+ ( sText != "" ? "<TR><TD class=\"LabelText\">" + sText + "</TD></TR>" : "" )
			+ "</TABLE>"
			+ "</TD></TR>"
		+ "</TABLE>"
		+ "</TD>"
		+ "</TR>"
		+ "</TABLE>";
	this.m_ghost.setContent( sContent );
}

////////////////////

var gLabel = new Label( "ForumLabel" );

// Moves the Label
function MouseMove ( e ) {
	if( nBrowser > 0 ) {
		var fX, fY;
		if( nBrowser == 1 ) {
			fX = e.pageX;
			fY = e.pageY;
		} else if( nBrowser == 2 ) {
			fX = event.x;
			fY = event.y;
		} else {
			fX = event.x + document.body.scrollLeft;
			fY = event.y + document.body.scrollTop;
		}
		gLabel.m_ghost.moveTo( fX + 12, fY + 10 );
	}
}

document.onmousemove = MouseMove;
if( nBrowser == 1 ) {
	document.captureEvents(Event.MOUSEMOVE);
}

bScriptLoaded = true;


