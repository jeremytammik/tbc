

var oTree = new LayerTree();
oTree.m_imgOpen.src			= "../img/n_off.gif";
oTree.m_imgClose.src		= "../img/n_on.gif";
oTree.m_imgChildShow.src	= "../img/vb_off.gif";
oTree.m_imgChildHide.src	= "../img/vb_on.gif";
oTree.m_bImg = true;

oTree.addItem("Item0",0,true);
oTree.addChild("Item1",true);
oTree.addItem("Item2",0,true);
oTree.addChild("Item3",true);
oTree.addItem("Item4",0,true);
oTree.addChild("Item5",true);
oTree.addItem("Item6",0,true);
oTree.addChild("Item7",true);
oTree.addItem("Item8",0,true);
oTree.addChild("Item9",true);
oTree.addItem("Item10",0,true);
oTree.addChild("Item11",true);
oTree.addItem("Item12",0,true);
oTree.addChild("Item13",true);
oTree.addItem("Item14",0,true);
oTree.addChild("Item15",true);
oTree.addItem("Item16",0,true);
oTree.addChild("Item17",true);
oTree.addItem("Item18",0,true);
oTree.addChild("Item19",true);
oTree.addItem("Item20",0,true);
oTree.addChild("Item21",true);
