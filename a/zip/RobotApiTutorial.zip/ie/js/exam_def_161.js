

var oTree = new LayerTree();
oTree.m_imgOpen.src			= "../img/n_off.gif";
oTree.m_imgClose.src		= "../img/n_on.gif";
oTree.m_imgChildShow.src	= "../img/vb_off.gif";
oTree.m_imgChildHide.src	= "../img/vb_on.gif";
oTree.m_bImg = true;

oTree.addItem("Item0",0,true);
oTree.addChild("Item1",true);
oTree.addItem("Item2",0,true);
oTree.addChild("Item3",true);
oTree.addItem("Item4",0,true);
oTree.addChild("Item5",true);
oTree.addItem("Item6",0,true);
oTree.addChild("Item7",true);
oTree.addItem("Item8",0,true);
oTree.addChild("Item9",true);
oTree.addItem("Item10",0,true);
oTree.addChild("Item11",true);
oTree.addItem("Item12",0,true);
oTree.addChild("Item13",true);
oTree.addItem("Item14",0,true);
oTree.addChild("Item15",true);
oTree.addItem("Item16",0,true);
oTree.addChild("Item17",true);
oTree.addItem("Item18",1,true);
oTree.addChild("Item19",true);
oTree.addItem("Item20",1,true);
oTree.addChild("Item21",true);
oTree.addItem("Item22",0,true);
oTree.addChild("Item23",true);
oTree.addItem("Item24",0,true);
oTree.addChild("Item25",true);
oTree.addItem("Item26",0,true);
oTree.addChild("Item27",true);
oTree.addItem("Item28",0,true);
oTree.addChild("Item29",true);
oTree.addItem("Item30",0,true);
oTree.addChild("Item31",true);
oTree.addItem("Item32",0,true);
oTree.addChild("Item33",true);
oTree.addItem("Item34",0,true);
oTree.addChild("Item35",true);
oTree.addItem("Item36",0,true);
oTree.addChild("Item37",true);
oTree.addItem("Item38",0,true);
oTree.addChild("Item39",true);
oTree.addItem("Item40",0,true);
oTree.addChild("Item41",true);
oTree.addItem("Item42",0,true);
oTree.addChild("Item43",true);
oTree.addItem("Item44",0,true);
oTree.addChild("Item45",true);
oTree.addItem("Item46",0,true);
oTree.addChild("Item47",true);
oTree.addItem("Item48",0,true);
oTree.addChild("Item49",true);
oTree.addItem("Item50",0,true);
oTree.addChild("Item51",true);
oTree.addItem("Item52",0,true);
oTree.addChild("Item53",true);
oTree.addItem("Item54",0,true);
oTree.addChild("Item55",true);
oTree.addItem("Item56",0,true);
oTree.addChild("Item57",true);
oTree.addItem("Item58",0,true);
oTree.addChild("Item59",true);
oTree.addItem("Item60",0,true);
oTree.addChild("Item61",true);
oTree.addItem("Item62",0,true);
oTree.addChild("Item63",true);
oTree.addItem("Item64",0,true);
oTree.addChild("Item65",true);
oTree.addItem("Item66",0,true);
oTree.addChild("Item67",true);
oTree.addItem("Item68",0,true);
oTree.addChild("Item69",true);
oTree.addItem("Item70",0,true);
oTree.addChild("Item71",true);
oTree.addItem("Item72",0,true);
oTree.addChild("Item73",true);
oTree.addItem("Item74",0,true);
oTree.addChild("Item75",true);
