﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.IO;
using Autodesk.Revit.DB;
#endregion

namespace CustomExporterObj
{
  class ExportContextObj : IExportContext
  {
    Document _doc = null;

    IJtFaceEmitter _emitter;

    bool isCancelled = false;

    Stack<ElementId> elementStack 
      = new Stack<ElementId>();

    Stack<Transform> _transformationStack 
      = new Stack<Transform>();

    //ElementId currentMaterialId 
    //  = ElementId.InvalidElementId;

    //StreamWriter streamWriter = null;

    //Dictionary<uint, ElementId> polymeshToMaterialId 
    //  = new Dictionary<uint, ElementId>();

    //uint CurrentPolymeshIndex { get; set; }

    ElementId CurrentElementId
    {
      get
      {
        return ( elementStack.Count > 0 ) 
          ? elementStack.Peek() 
          : ElementId.InvalidElementId;
      }
    }

    Element CurrentElement
    {
      get
      {
        return _doc.GetElement( 
          CurrentElementId );
      }
    }

    Transform CurrentTransform
    {
      get
      {
        return _transformationStack.Peek();
      }
    }

    public ExportContextObj( 
      Document document, 
      IJtFaceEmitter emitter )
    {
      _doc = document;
      _emitter = emitter;
      _transformationStack.Push( Transform.Identity );
    }

    public bool Start()
    {
      Debug.Print( "Start" );
      //CurrentPolymeshIndex = 0;
      //polymeshToMaterialId.Clear();
      return true;
    }

    public void Finish()
    {
    }

    public void OnPolymesh( PolymeshTopology node )
    {
      //CurrentPolymeshIndex++;

      //WriteXmlGeometryBegin();
      //WriteXmlGeometrySourcePositions( polymesh );
      //WriteXmlGeometrySourceNormals( polymesh );
      //if( polymesh.NumberOfUVs > 0 )
      //  WriteXmlGeometrySourceMap( polymesh );

      //WriteXmlGeometryVertices();

      //if( polymesh.NumberOfUVs > 0 )
      //  WriteXmlGeometryTrianglesWithMap( polymesh );
      //else
      //  WriteXmlGeometryTrianglesWithoutMap( polymesh );

      //WriteXmlGeometryEnd();

      //polymeshToMaterialId.Add( CurrentPolymeshIndex, 
      //  currentMaterialId );

      int nPts = node.NumberOfPoints;
      int nFacets = node.NumberOfFacets;

      DistributionOfNormals distrib
        = node.DistributionOfNormals;

      Debug.Print( string.Format(
        "Polymesh {0} vertices {1} facets",
        nPts, nFacets ) );

      int iFacet = 0;
      int iPoint = 0;

      IList<XYZ> vertices = node.GetPoints();
      IList<XYZ> normals = node.GetNormals();
      XYZ normal;

      foreach( PolymeshFacet triangle in node.GetFacets() )
      {
        // Just grab one normal per facet; ignore the 
        // three normals per point if they differ.

        if( DistributionOfNormals.OnePerFace == distrib )
        {
          normal = node.GetNormal( 0 );
        }
        else if( DistributionOfNormals.OnEachFacet
          == distrib )
        {
          normal = node.GetNormal( iFacet++ );
        }
        else
        {
          Debug.Assert( DistributionOfNormals
            .AtEachPoint == distrib, "what else?" );

          normal = normals[triangle.V1]
            + normals[triangle.V2]
            + normals[triangle.V3];

          normal /= 3.0;
        }

        _emitter.StoreTriangle( vertices[triangle.V1], 
          vertices[triangle.V2], vertices[triangle.V3] );
      }
    }

    public void OnMaterial( MaterialNode node )
    {
      // OnMaterial method can be invoked for every single 
      // out-coming mesh even when the material has not 
      // actually changed. Thus it is usually beneficial 
      // to store the current material and only get its 
      // attributes when the material actually changes.

      //currentMaterialId = node.MaterialId;

      Color c = node.Color;
      double t = node.Transparency;

      string s = string.Format( "({0},{1},{2})",
        c.Red, c.Green, c.Blue );

      Debug.Print( "Colour " + s + ", transparency "
        + t.ToString( "0.##" ) );

      int transparency = (int) ( t * 100 + 0.4999 );

      _emitter.StoreColorTransparency( c, transparency );
    }

    public bool IsCanceled()
    {
      // This method is invoked many 
      // times during the export process.

      return isCancelled;
    }

    public void OnDaylightPortal( 
      DaylightPortalNode node )
    {
    }

    public void OnRPC( RPCNode node )
    {
    }

    public RenderNodeAction OnViewBegin( 
      ViewNode node )
    {
      View3D view = _doc.GetElement( node.ViewId )
        as View3D;

      Debug.Assert( null != view,
        "expected valid 3D view" );

      Debug.Print( "ViewBegin " + view.Name );

      return RenderNodeAction.Proceed;
    }

    public void OnViewEnd( ElementId elementId )
    {
      // Note: This method is invoked even 
      // for a view that was skipped.

      Debug.Print( "ViewEnd" );
    }

    public RenderNodeAction OnElementBegin( 
      ElementId elementId )
    {
      elementStack.Push( elementId );

      return RenderNodeAction.Proceed;
    }

    public void OnElementEnd( ElementId elementId )
    {
      // Note: this method is invoked even 
      // for elements that were skipped.

      elementStack.Pop();
    }

    public RenderNodeAction OnFaceBegin( 
      FaceNode node )
    {
      // This method is invoked only if the 
      // custom exporter was set to include faces.

      return RenderNodeAction.Proceed;
    }

    public void OnFaceEnd( FaceNode node )
    {
      // This method is invoked only if the 
      // custom exporter was set to include faces.
      // Note: This method is invoked even 
      // for faces that were skipped.
    }

    public RenderNodeAction OnInstanceBegin( 
      InstanceNode node )
    {
      // This method marks the start of 
      // processing a family instance.

      ElementId id = node.GetSymbolId();

      Element e = _doc.GetElement( id );
      FamilySymbol symbol = e as FamilySymbol;

      Debug.Assert( null != symbol,
        "expected valid family symbol" );

      Debug.Print( "InstanceBegin "
        + symbol.Category.Name + " : "
        + symbol.Family.Name + " : "
        + symbol.Name );

      _transformationStack.Push( CurrentTransform
        .Multiply( node.GetTransform() ) );

      // We can either skip this instance 
      // or proceed with rendering it.

      return RenderNodeAction.Proceed;
    }

    public void OnInstanceEnd( InstanceNode node )
    {
      // Note: This method is invoked even 
      // for instances that were skipped.

      Debug.Print( "InstanceEnd" );

      _transformationStack.Pop();
    }

    public RenderNodeAction OnLinkBegin( 
      LinkNode node )
    {
      _transformationStack.Push( CurrentTransform
        .Multiply( node.GetTransform() ) );

      return RenderNodeAction.Proceed;
    }

    public void OnLinkEnd( LinkNode node )
    {
      // Note: This method is invoked even 
      // for instances that were skipped.

      _transformationStack.Pop();
    }

    public void OnLight( LightNode node )
    {
    }

    #region Collada output methods
#if COLLADA
    private string GetCurrentElementName()
    {
      Element element = CurrentElement;
      if( element != null )
        return element.Name;

      return ""; //default name
    }

    private string GetMaterialName( ElementId materialId )
    {
      Material material = _doc.GetElement( materialId ) as Material;
      if( material != null )
        return material.Name;

      return ""; // default material name
    }

    private bool IsMaterialValid( ElementId materialId )
    {
      Material material = _doc.GetElement( materialId ) 
        as Material;

      return null != material;
    }

    private void WriteXmlGeometryBegin()
    {
      streamWriter.Write( "<geometry id=\"geom-" + CurrentPolymeshIndex + "\" name=\"" + GetCurrentElementName() + "\">\n" );
      streamWriter.Write( "<mesh>\n" );
    }

    private void WriteXmlGeometryEnd()
    {
      streamWriter.Write( "</mesh>\n" );
      streamWriter.Write( "</geometry>\n" );
    }

    private void WriteXmlGeometrySourcePositions( PolymeshTopology polymesh )
    {
      streamWriter.Write( "<source id=\"geom-" + CurrentPolymeshIndex + "-positions" + "\">\n" );
      streamWriter.Write( "<float_array id=\"geom-" + CurrentPolymeshIndex + "-positions" + "-array" + "\" count=\"" + ( polymesh.NumberOfPoints * 3 ) + "\">\n" );

      XYZ point;
      Transform currentTransform = CurrentTransform;

      for( int iPoint = 0; iPoint < polymesh.NumberOfPoints; ++iPoint )
      {
        point = polymesh.GetPoint( iPoint );
        point = currentTransform.OfPoint( point );
        streamWriter.Write( "{0:0.0000} {1:0.0000} {2:0.0000}\n", point.X, point.Y, point.Z );
      }

      streamWriter.Write( "</float_array>\n" );
      streamWriter.Write( "<technique_common>\n" );
      streamWriter.Write( "<accessor source=\"#geom-" + CurrentPolymeshIndex + "-positions" + "-array\"" + " count=\"" + polymesh.NumberOfPoints + "\" stride=\"3\">\n" );
      streamWriter.Write( "<param name=\"X\" type=\"float\"/>\n" );
      streamWriter.Write( "<param name=\"Y\" type=\"float\"/>\n" );
      streamWriter.Write( "<param name=\"Z\" type=\"float\"/>\n" );
      streamWriter.Write( "</accessor>\n" );
      streamWriter.Write( "</technique_common>\n" );
      streamWriter.Write( "</source>\n" );
    }

    private void WriteXmlGeometrySourceNormals( PolymeshTopology polymesh )
    {
      int nNormals = 0;

      switch( polymesh.DistributionOfNormals )
      {
        case DistributionOfNormals.AtEachPoint:
          nNormals = polymesh.NumberOfPoints;
          break;
        case DistributionOfNormals.OnePerFace:
          nNormals = 1;
          break;
        case DistributionOfNormals.OnEachFacet:
          //TODO : DistributionOfNormals.OnEachFacet
          nNormals = 1;
          break;
      }

      streamWriter.Write( "<source id=\"geom-" + CurrentPolymeshIndex + "-normals" + "\">\n" );
      streamWriter.Write( "<float_array id=\"geom-" + CurrentPolymeshIndex + "-normals" + "-array" + "\" count=\"" + ( nNormals * 3 ) + "\">\n" );

      XYZ point;
      Transform currentTransform = CurrentTransform;

      for( int iNormal = 0; iNormal < nNormals; ++iNormal )
      {
        point = polymesh.GetNormal( iNormal );
        point = currentTransform.OfVector( point );
        streamWriter.Write( "{0:0.0000} {1:0.0000} {2:0.0000}\n", point.X, point.Y, point.Z );
      }

      streamWriter.Write( "</float_array>\n" );
      streamWriter.Write( "<technique_common>\n" );
      streamWriter.Write( "<accessor source=\"#geom-" + CurrentPolymeshIndex + "-normals" + "-array\"" + " count=\"" + nNormals + "\" stride=\"3\">\n" );
      streamWriter.Write( "<param name=\"X\" type=\"float\"/>\n" );
      streamWriter.Write( "<param name=\"Y\" type=\"float\"/>\n" );
      streamWriter.Write( "<param name=\"Z\" type=\"float\"/>\n" );
      streamWriter.Write( "</accessor>\n" );
      streamWriter.Write( "</technique_common>\n" );
      streamWriter.Write( "</source>\n" );
    }

    private void WriteXmlGeometrySourceMap( PolymeshTopology polymesh )
    {
      streamWriter.Write( "<source id=\"geom-" + CurrentPolymeshIndex + "-map" + "\">\n" );
      streamWriter.Write( "<float_array id=\"geom-" + CurrentPolymeshIndex + "-map" + "-array" + "\" count=\"" + ( polymesh.NumberOfUVs * 2 ) + "\">\n" );

      UV uv;

      for( int iUv = 0; iUv < polymesh.NumberOfUVs; ++iUv )
      {
        uv = polymesh.GetUV( iUv );
        streamWriter.Write( "{0:0.0000} {1:0.0000}\n", uv.U, uv.V );
      }

      streamWriter.Write( "</float_array>\n" );
      streamWriter.Write( "<technique_common>\n" );
      streamWriter.Write( "<accessor source=\"#geom-" + CurrentPolymeshIndex + "-map" + "-array\"" + " count=\"" + polymesh.NumberOfPoints + "\" stride=\"2\">\n" );
      streamWriter.Write( "<param name=\"S\" type=\"float\"/>\n" );
      streamWriter.Write( "<param name=\"T\" type=\"float\"/>\n" );
      streamWriter.Write( "</accessor>\n" );
      streamWriter.Write( "</technique_common>\n" );
      streamWriter.Write( "</source>\n" );
    }

    private void WriteXmlGeometryVertices()
    {
      streamWriter.Write( "<vertices id=\"geom-" + CurrentPolymeshIndex + "-vertices" + "\">\n" );
      streamWriter.Write( "<input semantic=\"POSITION\" source=\"#geom-" + CurrentPolymeshIndex + "-positions" + "\"/>\n" );
      streamWriter.Write( "</vertices>\n" );
    }

    private void WriteXmlGeometryTrianglesWithoutMap( PolymeshTopology polymesh )
    {
      streamWriter.Write( "<triangles count=\"" + polymesh.NumberOfFacets + "\"" );
      if( IsMaterialValid( currentMaterialId ) )
        streamWriter.Write( " material=\"material-" + currentMaterialId.ToString() + "\"" );
      streamWriter.Write( ">\n" );
      streamWriter.Write( "<input offset=\"0\" semantic=\"VERTEX\" source=\"#geom-" + CurrentPolymeshIndex + "-vertices" + "\"/>\n" );
      streamWriter.Write( "<input offset=\"1\" semantic=\"NORMAL\" source=\"#geom-" + CurrentPolymeshIndex + "-normals" + "\"/>\n" );
      streamWriter.Write( "<p>\n" );
      PolymeshFacet facet;

      switch( polymesh.DistributionOfNormals )
      {
        case DistributionOfNormals.AtEachPoint:
          for( int i = 0; i < polymesh.NumberOfFacets; ++i )
          {
            facet = polymesh.GetFacet( i );
            streamWriter.Write( facet.V1 + " " + facet.V1 + " " +
                        facet.V2 + " " + facet.V2 + " " +
                        facet.V3 + " " + facet.V3 + " " +
                        "\n" );
          }
          break;

        case DistributionOfNormals.OnEachFacet:
        //TODO : DistributionOfNormals.OnEachFacet
        case DistributionOfNormals.OnePerFace:
          for( int i = 0; i < polymesh.NumberOfFacets; ++i )
          {
            facet = polymesh.GetFacet( i );
            streamWriter.Write( facet.V1 + " 0 " +
                        facet.V2 + " 0 " +
                        facet.V3 + " 0 " +
                        "\n" );
          }
          break;
      }
      streamWriter.Write( "</p>\n" );
      streamWriter.Write( "</triangles>\n" );
    }

    private void WriteXmlGeometryTrianglesWithMap( PolymeshTopology polymesh )
    {
      streamWriter.Write( "<triangles count=\"" + polymesh.NumberOfFacets + "\"" );
      if( IsMaterialValid( currentMaterialId ) )
        streamWriter.Write( " material=\"material-" + currentMaterialId.ToString() + "\"" );
      streamWriter.Write( ">\n" );
      streamWriter.Write( "<input offset=\"0\" semantic=\"VERTEX\" source=\"#geom-" + CurrentPolymeshIndex + "-vertices" + "\"/>\n" );
      streamWriter.Write( "<input offset=\"1\" semantic=\"NORMAL\" source=\"#geom-" + CurrentPolymeshIndex + "-normals" + "\"/>\n" );
      streamWriter.Write( "<input offset=\"2\" semantic=\"TEXCOORD\" source=\"#geom-" + CurrentPolymeshIndex + "-map" + "\" set=\"0\"/>\n" );
      streamWriter.Write( "<p>\n" );
      PolymeshFacet facet;

      switch( polymesh.DistributionOfNormals )
      {
        case DistributionOfNormals.AtEachPoint:
          for( int i = 0; i < polymesh.NumberOfFacets; ++i )
          {
            facet = polymesh.GetFacet( i );
            streamWriter.Write( facet.V1 + " " + facet.V1 + " " + facet.V1 + " " +
                        facet.V2 + " " + facet.V2 + " " + facet.V2 + " " +
                        facet.V3 + " " + facet.V3 + " " + facet.V3 + " " +
                        "\n" );
          }
          break;

        case DistributionOfNormals.OnEachFacet:
        //TODO : DistributionOfNormals.OnEachFacet
        case DistributionOfNormals.OnePerFace:
          for( int i = 0; i < polymesh.NumberOfFacets; ++i )
          {
            facet = polymesh.GetFacet( i );
            streamWriter.Write( facet.V1 + " 0 " + facet.V1 + " " +
                        facet.V2 + " 0 " + facet.V2 + " " +
                        facet.V3 + " 0 " + facet.V3 + " " +
                        "\n" );
          }
          break;
      }
      streamWriter.Write( "</p>\n" );
      streamWriter.Write( "</triangles>\n" );
    }

    private void WriteXmlLibraryMaterials()
    {
      streamWriter.Write( "<library_materials>\n" );

      foreach( var materialId in polymeshToMaterialId.Values.Distinct() )
      {
        if( IsMaterialValid( materialId ) == false )
          continue;

        streamWriter.Write( "<material id=\"material-" + materialId.ToString() + "\" name=\"" + GetMaterialName( materialId ) + "\">\n" );
        streamWriter.Write( "<instance_effect url=\"#effect-" + materialId.ToString() + "\" />\n" );
        streamWriter.Write( "</material>\n" );
      }
      streamWriter.Write( "</library_materials>\n" );
    }

    private void WriteXmlLibraryEffects()
    {
      streamWriter.Write( "<library_effects>\n" );

      foreach( var materialId in polymeshToMaterialId.Values.Distinct() )
      {
        if( IsMaterialValid( materialId ) == false )
          continue;

        Material material = _doc.GetElement( materialId ) as Material;

        streamWriter.Write( "<effect id=\"effect-" + materialId.ToString() + "\" name=\"" + GetMaterialName( materialId ) + "\">\n" );
        streamWriter.Write( "<profile_COMMON>\n" );

        streamWriter.Write( "<technique sid=\"common\">\n" );
        streamWriter.Write( "<phong>\n" );
        streamWriter.Write( "<ambient>\n" );
        streamWriter.Write( "<color>0.1 0.1 0.1 1.000000</color>\n" );
        streamWriter.Write( "</ambient>\n" );

        //diffuse
        streamWriter.Write( "<diffuse>\n" );
        streamWriter.Write( "<color>" + material.Color.Red + " " + material.Color.Green + " " + material.Color.Blue + " 1.0</color>\n" );
        streamWriter.Write( "</diffuse>\n" );

        streamWriter.Write( "<specular>\n" );
        streamWriter.Write( "<color>1.000000 1.000000 1.000000 1.000000</color>\n" );
        streamWriter.Write( "</specular>\n" );

        streamWriter.Write( "<shininess>\n" );
        streamWriter.Write( "<float>" + material.Shininess + "</float>\n" );
        streamWriter.Write( "</shininess>\n" );

        streamWriter.Write( "<reflective>\n" );
        streamWriter.Write( "<color>0 0 0 1.000000</color>\n" );
        streamWriter.Write( "</reflective>\n" );
        streamWriter.Write( "<reflectivity>\n" );
        streamWriter.Write( "<float>1.000000</float>\n" );
        streamWriter.Write( "</reflectivity>\n" );

        streamWriter.Write( "<transparent opaque=\"RGB_ZERO\">\n" );
        streamWriter.Write( "<color>1.000000 1.000000 1.000000 1.000000</color>\n" );
        streamWriter.Write( "</transparent>\n" );

        streamWriter.Write( "<transparency>\n" );
        streamWriter.Write( "<float>" + material.Transparency + "</float>\n" );
        streamWriter.Write( "</transparency>\n" );

        streamWriter.Write( "</phong>\n" );
        streamWriter.Write( "</technique>\n" );


        streamWriter.Write( "</profile_COMMON>\n" );
        streamWriter.Write( "</effect>\n" );
      }

      streamWriter.Write( "</library_effects>\n" );
    }

    public void WriteXmlLibraryVisualScenes()
    {
      streamWriter.Write( "<library_visual_scenes>\n" );
      streamWriter.Write( "<visual_scene id=\"Revit_project\">\n" );

      foreach( var pair in polymeshToMaterialId )
      {
        streamWriter.Write( "<node id=\"node-" + pair.Key + "\" name=\"" + "elementName" + "\">\n" );
        streamWriter.Write( "<instance_geometry url=\"#geom-" + pair.Key + "\">\n" );
        if( IsMaterialValid( pair.Value ) )
        {
          streamWriter.Write( "<bind_material>\n" );
          streamWriter.Write( "<technique_common>\n" );
          streamWriter.Write( "<instance_material target=\"#material-" + pair.Value + "\" symbol=\"material-" + pair.Value + "\" >\n" );
          streamWriter.Write( "</instance_material>\n" );
          streamWriter.Write( "</technique_common>\n" );
          streamWriter.Write( "</bind_material>\n" );
        }
        streamWriter.Write( "</instance_geometry>\n" );
        streamWriter.Write( "</node>\n" );
      }

      streamWriter.Write( "</visual_scene>\n" );
      streamWriter.Write( "</library_visual_scenes>\n" );

      streamWriter.Write( "<scene>\n" );
      streamWriter.Write( "<instance_visual_scene url=\"#Revit_project\"/>\n" );
      streamWriter.Write( "</scene>\n" );
    }
#endif // COLLADA
    #endregion // Collada output methods
  }
}
