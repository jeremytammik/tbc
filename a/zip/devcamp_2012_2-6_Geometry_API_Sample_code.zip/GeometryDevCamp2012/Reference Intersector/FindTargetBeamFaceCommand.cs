﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB;

namespace GeometryDevCamp2012.RefInt
{
    /// <summary>
    /// The external command to add a connector family to the end points of the selected beam.
    /// </summary>
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    class FindTargetBeamFaceCommand : IExternalCommand
    {
        #region IExternalCommand Members

        /// <summary>
        /// Executes the command.  
        /// </summary>
        /// <param name="commandData">The command data.</param>
        /// <param name="message">The output error message.</param>
        /// <param name="elements">The output element set.</param>
        /// <returns>Succeeded.</returns>
        public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
        {      
            UIDocument uiDoc = commandData.Application.ActiveUIDocument;
            Document doc = uiDoc.Document;

            // Find connector family symbol
            FilteredElementCollector symbolCollector = new FilteredElementCollector(doc);
            symbolCollector.WhereElementIsElementType().OfCategory(BuiltInCategory.OST_StructConnections);
            FamilySymbol connectorSymbol = symbolCollector.FirstElement() as FamilySymbol;

            // Pick beam
            Reference beamRef = uiDoc.Selection.PickObject(ObjectType.Element, new BeamInstanceSelectionFilter());
            FamilyInstance famInst = doc.GetElement(beamRef) as FamilyInstance;

            // Start group to assimilate all changes
            TransactionGroup group = new TransactionGroup(doc, "Place families");
            group.Start();
            
            // Get locations at the end of beams
            BeamLocationFinder finder = new BeamLocationFinder(famInst);
            IEnumerable<TargetBeamLocation> locations = finder.GetEndPointBeamLocations();

            // Put connector family on target locations
            using (Transaction t = new Transaction(doc, "Add connectors"))
            {
                t.Start();
                foreach (TargetBeamLocation location in locations)
                {
                    doc.Create.NewFamilyInstance(location.Reference, location.Location, location.ReferenceDirection, connectorSymbol);
                }
                t.Commit();
            }

            // Assimilate all changes into one undo record
            group.Assimilate();

            return Result.Succeeded;
        }

        #endregion

        /// <summary>
        /// Selection filter to enforce selection of beam.
        /// </summary>
        class BeamInstanceSelectionFilter : ISelectionFilter
        {
            #region ISelectionFilter Members

            /// <summary>
            /// Returns true if the selected element is a beam.
            /// </summary>
            /// <param name="elem"></param>
            /// <returns></returns>
            public bool AllowElement(Element elem)
            {
                return elem is FamilyInstance && elem.Category.Id == new ElementId(BuiltInCategory.OST_StructuralFraming);
            }


            /// <summary>
            /// Always passes.
            /// </summary>
            /// <param name="reference"></param>
            /// <param name="position"></param>
            /// <returns></returns>
            public bool AllowReference(Reference reference, XYZ position)
            {
                return true;
            }

            #endregion
        }

    }
}
