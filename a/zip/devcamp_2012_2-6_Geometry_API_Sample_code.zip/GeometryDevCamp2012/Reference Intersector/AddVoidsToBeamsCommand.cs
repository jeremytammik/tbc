﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB;

namespace GeometryDevCamp2012.RefInt
{
    /// <summary>
    /// The external command to apply voids to beam families at the designated locations.
    /// </summary>
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    class AddVoidsToBeamsCommand : IExternalCommand
    {
        #region IExternalCommand Members

        /// <summary>
        /// Executes the command.  
        /// </summary>
        /// <param name="commandData">The command data.</param>
        /// <param name="message">The output error message.</param>
        /// <param name="elements">The output element set.</param>
        /// <returns>Succeeded.</returns>
        public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
        {
            UIDocument uiDoc = commandData.Application.ActiveUIDocument;
            Document doc = uiDoc.Document;

            // Find void family
            FilteredElementCollector symbolCollector = new FilteredElementCollector(doc);
            symbolCollector.WhereElementIsElementType().OfCategory(BuiltInCategory.OST_StructuralFraming);
            FamilySymbol voidSymbol = symbolCollector.Cast<FamilySymbol>().First<FamilySymbol>(fs => fs.Name == "Framing void");

            // Find all target beams in the document
            FilteredElementCollector instanceCollector = new FilteredElementCollector(doc);
            instanceCollector.OfCategory(BuiltInCategory.OST_StructuralFraming).OfClass(typeof(FamilyInstance)).WhereElementIsCurveDriven();
            ICollection<ElementId> beamCollection = instanceCollector.ToElementIds();

            // TransactionGroup to encapsulate all changes
            TransactionGroup group = new TransactionGroup(doc, "Add voids");
            group.Start();

            double[] parameters = { 0.2, 0.4, 0.6, 0.8 };  // The curve parameters where the voids will be placed (chosen arbitrarily for this sample).

            Dictionary<ElementId, ElementId> createdVoidsDictionary = 
                new Dictionary<ElementId, ElementId>();  // Stores a list of voids to the elements they should cut.

            // Add void families at each parameter
            foreach (ElementId elemId in beamCollection)
            {
                FamilyInstance famInst = doc.GetElement(elemId) as FamilyInstance;
                BeamLocationFinder finder = new BeamLocationFinder(famInst);
                foreach (double parameter in parameters)
                {          
                    TargetBeamLocation location = finder.FindFaceLocationForBrace(parameter);                    
                    using (Transaction t = new Transaction(doc, "Add void families"))
                    {

                        t.Start();
                        // Put void family on target location
                        FamilyInstance voidInst = doc.Create.NewFamilyInstance(location.Reference, location.Location,
                                                                            location.ReferenceDirection, voidSymbol);
                        // Remember relationship of void and target beam
                        createdVoidsDictionary.Add(voidInst.Id, famInst.Id);
                        
                        t.Commit();
                    }
                }
            }

            // Postprocess to apply void cuts for each void family
            using (Transaction t = new Transaction(doc, "Cut voids"))
            {
                t.Start();
                foreach (ElementId voidId in createdVoidsDictionary.Keys)
                {
                    Element voidElem = doc.GetElement(voidId);
                    Element instElem = doc.GetElement(createdVoidsDictionary[voidId]);

                    InstanceVoidCutUtils.AddInstanceVoidCut(doc, instElem, voidElem);
                }
                t.Commit();
            }

            // Roll all changes into one Undo record
            group.Assimilate();

            return Result.Succeeded;
        }

        #endregion
    }
}
