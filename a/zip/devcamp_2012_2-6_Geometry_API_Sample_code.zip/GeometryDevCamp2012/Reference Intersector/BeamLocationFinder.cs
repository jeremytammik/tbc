﻿using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace GeometryDevCamp2012.RefInt
{
    /// <summary>
    /// The output class for utilities that find target faces and locations on beams.
    /// </summary>
    class TargetBeamLocation
    {
        public TargetBeamLocation(Reference r, XYZ loc, XYZ refDir)
        {
            Reference = r;
            Location = loc;
            ReferenceDirection = refDir;
        }
        public Reference Reference { get; set; }
        public XYZ Location { get; set; }
        public XYZ ReferenceDirection { get; set; }
    }

    /// <summary>
    /// Utility class to find target faces and locations on beams.
    /// </summary>
    class BeamLocationFinder
    {
        private FamilyInstance m_familyInstance;

        /// <summary>
        /// Constructs an instance of this class for a given beam.
        /// </summary>
        /// <param name="familyInstance"></param>
        public BeamLocationFinder(FamilyInstance familyInstance)
        {
            m_familyInstance = familyInstance;
        }

        /// <summary>
        /// Gets most suitable locations for attachment at the ends of the beam. 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<TargetBeamLocation> GetEndPointBeamLocations()
        {
            return new List<TargetBeamLocation> { GetEndPointBeamLocation(true), GetEndPointBeamLocation(false) };
        }

        /// <summary>
        /// Gets the most suitable location for attachment at the start or end of the beam.
        /// </summary>
        /// <param name="start">True for the start (parameter = 0), false for the end (parameter = 1).</param>
        /// <returns></returns>
        private TargetBeamLocation GetEndPointBeamLocation(bool start)
        {
            double parameter = start ? 0.0 : 1.00;
            double increment = start ? 0.01 : -0.01;
            
            TargetBeamLocation endPointLocation = null;
            while (endPointLocation == null)
            {
                endPointLocation = FindFaceLocationForBrace(parameter);
                parameter += increment;
            }
            return endPointLocation;
        }

        /// <summary>
        /// Gets the location for attachment at the given parameter along the beam.
        /// </summary>
        /// <param name="parameter">The beam parameter (range 0-1).</param>
        /// <returns>The location, or null if no face intersection could be found.</returns>
        public TargetBeamLocation FindFaceLocationForBrace(double parameter)
        {
            // Calculate target point for beam location line
            Curve beamCurve = (m_familyInstance.Location as LocationCurve).Curve;
 
            Transform transformAtParam = beamCurve.ComputeDerivatives(parameter, true);
            XYZ targetPoint = transformAtParam.Origin;

            // Calculate tangent and normal for this point
            XYZ tangentAtPoint = transformAtParam.BasisX != null ? transformAtParam.BasisX.Normalize() : (beamCurve.Evaluate(1.0, true) - targetPoint).Normalize();
            XYZ normalToCurveAtPoint = tangentAtPoint.CrossProduct(XYZ.BasisZ).Normalize();

            // Offset endpoint away from beam
            XYZ offsetDirection = -normalToCurveAtPoint;

            // Assume 100 ft is far enough away from the beam
            XYZ offsetEndpoint = targetPoint - 100 * offsetDirection;

            // Create a default view3D to ensure that we don't rely on a view with filters, hidden categories, etc.
            TransactionGroup viewCreationGroup = new TransactionGroup(Document, "Create view if necessary");
            viewCreationGroup.Start();

            View3D defaultView3D = CreateDefaultView3D();

            // ReferenceIntersector fired towards beam to get target reference
            ReferenceIntersector intersector = new ReferenceIntersector(m_familyInstance.Id, FindReferenceTarget.Face, defaultView3D);
            IList<ReferenceWithContext> referencesFound = intersector.Find(offsetEndpoint, offsetDirection);

            // Rollback creation of the temp 3D view
            viewCreationGroup.RollBack();

            // No intersections found
            if (referencesFound.Count == 0)
            {
                return null;
            }

            // Find the nearest reference with the right orientation
            // These local variables store the current "best candidate"
            ReferenceWithContext targetReference = null;
            double targetProximity = Double.PositiveInfinity;
            foreach (ReferenceWithContext refWC in referencesFound)
            {         
                // Skip non-planar faces
                Face face = m_familyInstance.GetGeometryObjectFromReference(refWC.GetReference()) as Face;
                if (!(face is PlanarFace))
                    continue;

                // Skip faces not perpendicular to target normal
                XYZ normal = (face as PlanarFace).Normal;
                if (!AreParallel(offsetDirection, normal))
                    continue;

                // Store if closer than previous target
                if (refWC.Proximity >= targetProximity)
                    continue;

                targetReference = refWC;
                targetProximity = refWC.Proximity;
            }

            // No usable matches
            if (targetReference == null)
                return null;

            // Calculate reference direction based on the orientation of the beam
            XYZ targetReferenceDirection = offsetDirection.CrossProduct(tangentAtPoint);

            return new TargetBeamLocation(targetReference.GetReference(), targetReference.GetReference().GlobalPoint, 
                targetReferenceDirection);
        }

        /// <summary>
        /// Utility to compare two vectors, which should be the in the same direction or 180 degrees opposite.
        /// </summary>
        /// <param name="vector1"></param>
        /// <param name="vector2"></param>
        /// <returns></returns>
        public static bool AreParallel(XYZ vector1, XYZ vector2)
        {
            double angle = vector1.AngleTo(vector2);
            return Math.Abs(Math.Sin(angle)) < 1e-9;
        }

        /// <summary>
        /// Filter function to identify a default 3D view family type.
        /// </summary>
        /// <param name="viewFamilyType"></param>
        /// <returns></returns>
        private bool IsDefaultView3DType(ViewFamilyType viewFamilyType)
        {
            return viewFamilyType.ViewFamily == ViewFamily.ThreeDimensional && viewFamilyType.DefaultTemplateId == ElementId.InvalidElementId;
        }

        /// <summary>
        /// Filter function to identify any 3D view family type.
        /// </summary>
        /// <param name="viewFamilyType"></param>
        /// <returns></returns>
        private bool IsView3DType(ViewFamilyType viewFamilyType)
        {
            return viewFamilyType.ViewFamily == ViewFamily.ThreeDimensional;
        }

        /// <summary>
        /// Creates a default 3D view for use in ReferenceIntersector.
        /// </summary>
        /// <returns>The default 3D view.</returns>
        private View3D CreateDefaultView3D()
        {
            using (Transaction t = new Transaction(Document, "Create temp default view."))
            {
                t.Start();

                FilteredElementCollector findDefaultView3DType = new FilteredElementCollector(Document);
                findDefaultView3DType.OfClass(typeof(ViewFamilyType));
                ViewFamilyType defaultView3DType = findDefaultView3DType.Cast<ViewFamilyType>().FirstOrDefault<ViewFamilyType>(IsDefaultView3DType);

                if (defaultView3DType == null)
                {
                    // Create a view 3D type
                    ViewFamilyType anyView3DType = findDefaultView3DType.Cast<ViewFamilyType>().FirstOrDefault(IsView3DType);
                    defaultView3DType = anyView3DType.Duplicate("Default") as ViewFamilyType;
                    defaultView3DType.DefaultTemplateId = ElementId.InvalidElementId;
                }

                View3D defaultView3D = View3D.CreateIsometric(Document, defaultView3DType.Id);

                t.Commit();

                return defaultView3D;
            }
        }

        /// <summary>
        /// The document that contains the instance.
        /// </summary>
        private Document Document
        {
            get { return m_familyInstance.Document; }
        }
    }
}
