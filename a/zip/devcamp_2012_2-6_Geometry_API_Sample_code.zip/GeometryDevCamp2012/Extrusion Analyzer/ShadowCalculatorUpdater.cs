﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;

namespace GeometryDevCamp2012
{
	/// <summary>
	/// Description of ShadowCalculatorUpdater.
	/// </summary>
	public class ShadowCalculatorUpdater: IUpdater
	{
	    private ICollection<ElementId> m_shadowCurves;
	    private UpdaterId m_updaterId;
	    private Element m_targetMass;
	    //private String m_documentId;
	
	    public ShadowCalculatorUpdater(AddInId id, Element targetMass, ICollection<ElementId> shadowCurves)
		{
			m_shadowCurves = shadowCurves;
			m_updaterId = new UpdaterId(id, new Guid("A61C6798-7269-45c0-9352-42699E4541A4"));
			m_targetMass = targetMass;
			//m_documentId = m_targetMass.Document.ProjectInformation.UniqueId;
		}
		
	    public void ProcessFailures(object sender, FailuresProcessingEventArgs args)
	    {
	    	FailuresAccessor accessor = args.GetFailuresAccessor();
	    	
	    	IList<FailureMessageAccessor> messages = accessor.GetFailureMessages(FailureSeverity.Warning);
	    	foreach (FailureMessageAccessor message in messages)
	    	{
	    		if (message.GetFailureDefinitionId() == BuiltInFailures.InaccurateFailures.InaccurateLine)
	    		{
	    			ICollection<ElementId> failingElementIds = message.GetFailingElementIds();
	    			bool myWarning = true;
	    			foreach (ElementId failingElementId in failingElementIds)
	    			{
	    				if (!m_shadowCurves.Contains(failingElementId))
	    				{
	    					myWarning = false;
	    					break;
	    				}
	    			}
	    			if (!myWarning)
	    			   break;
	    			   
	    			accessor.DeleteWarning(message);
	    		}
	    	
	    	}
	    }
		
		public void Execute(UpdaterData data)
		{
			Document doc = data.GetDocument();
			foreach (ElementId id in data.GetModifiedElementIds())
			{
				SunAndShadowSettings sunSettings = doc.GetElement(id) as SunAndShadowSettings;
				
				if (sunSettings != null)
				{
					// Delete existing shadow curves
					if (m_shadowCurves.Count > 0)
						doc.Delete(m_shadowCurves);
				
					// Create new shadow curves
					XYZ sunDirection = ShadowCalculatorUtils.GetSunDirection(doc.GetElement(sunSettings.OwnerViewId) as View);
					
					try
					{
						m_shadowCurves = new ShadowCalculator(m_targetMass, sunDirection).DrawShadow();
					}
					catch (Exception)
					{
						// Sometimes the analysis fails for certain angles/configs
						m_shadowCurves = new List<ElementId>();
					}
				}
			}
		}
		
		public UpdaterId GetUpdaterId()
		{
			return m_updaterId;
		}
		
		public ChangePriority GetChangePriority()
		{
			return ChangePriority.Annotations;
		}
		
		public string GetUpdaterName()
		{
			return "ShadowCalculator";
		}
		
		public string GetAdditionalInformation()
		{
			return "Shadow calculator";
		}
	}
}
