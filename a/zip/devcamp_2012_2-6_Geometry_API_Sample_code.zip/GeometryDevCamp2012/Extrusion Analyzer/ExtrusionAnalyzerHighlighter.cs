﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Data;

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace GeometryDevCamp2012
{
	/// <summary>
	/// Class that highlights the elements which cut a target element 
	/// (determined as a result of an ExtrusionAnalysis).
	/// </summary>
	public class ExtrusionAnalyzerHighlighter
	{
		static ExtrusionAnalyzerHighlighter s_example;
		
		Solid m_solid = null;
		Element m_element = null;
		ExtrusionAnalyzer m_analyzer = null;
		Document m_document = null;
		bool m_processedOpenings = false;
		Dictionary<ElementId, IList<Face>> m_intersectingElements = 
			new Dictionary<ElementId, IList<Face>>();
		IEnumerator<ElementId> m_enumerator;
		
		private ExtrusionAnalyzerHighlighter()
		{
		}
		
		/// <summary>
		/// Gets the singleton instance of this class.
		/// </summary>
		/// <returns>The instance.</returns>
		public static ExtrusionAnalyzerHighlighter Get()
		{
			if (s_example == null)
				s_example = new ExtrusionAnalyzerHighlighter();
			return s_example;
		}
		
		/// <summary>
		/// Initialize the ExtrusionAnalyzer for the given element.
		/// </summary>
		/// <param name="toAnalyze">The element.</param>
		/// <returns>True if analysis succeeded.</returns>
		public bool Analyze(Element toAnalyze)
		{
			m_document = toAnalyze.Document;
			m_element = toAnalyze;
			
			GetTargetSolid();
			
			if (m_solid == null)
				throw new Exception("Element has no solid!");
			
			// We are planning to analyze in -Z (finding the bottom profile).
			// The profile is offet 5' below the bounding box of the element
			// to be able to see the calculated profile.
			BoundingBoxXYZ bbox = toAnalyze.get_BoundingBox(null);
			XYZ planePoint  = bbox.Min - new XYZ(0, 0, 5);
			Plane plane = 
				toAnalyze.Document.Application.Create.NewPlane(XYZ.BasisZ, planePoint);
			
			// Create extrusion analyzer with the calculated inputs.
			m_analyzer = ExtrusionAnalyzer.Create(m_solid, plane, -XYZ.BasisZ);

			return m_analyzer.GetExtrusionBase() != null;
		}
		
		/// <summary>
		/// Shows the calculated extrusion base as a set of model curves.
		/// </summary>
		public void ShowExtrusionBase()
		{
			// Convert face to curve array
			Face face = m_analyzer.GetExtrusionBase();
			
			CurveArray curves = m_document.Application.Create.NewCurveArray();
			foreach (EdgeArray edgeLoop in face.EdgeLoops)
			{
				foreach (Edge edge in edgeLoop)
				{
					curves.Append(edge.AsCurve());
				}
			}
			
			Transaction t = new Transaction(m_document, "Create extrusion analysis curves");
			t.Start();
			// Curves should all be in the target plane.
			Plane plane = m_document.Application.Create.NewPlane(curves);
			SketchPlane sketchPlane = 
				m_document.Create.NewSketchPlane(plane);  
			m_document.Regenerate();
			m_document.Create.NewModelCurveArray(curves, sketchPlane);
			t.Commit();
		}
		
		/// <summary>
		/// Highlights the openings and clippings from elements which cut the target element.
		/// </summary>
		public void ShowOpenings()
		{
			TransactionGroup tg = new TransactionGroup(m_document, "Show openings");
			tg.Start();
			int counter = 0;
			
			bool stillShowingResults;
			do
			{
				Transaction t = new Transaction(m_document, "Show opening");
				t.Start();
				stillShowingResults = ShowNextOpening();
				counter ++;
				t.Commit();
				new UIDocument(m_document).RefreshActiveView();
				System.Threading.Thread.Sleep(1000);
			}
			while (stillShowingResults);

			tg.Commit();
		}
		
		/// <summary>
		/// Highlights the opening from an element which cuts the target element.
		/// </summary>
		/// <returns>True if there are more cutting elements to be highlighted.</returns>
		private bool ShowNextOpening()
		{
			bool hasMore = false;
			// First time this is run, check alignment of the faces vs. the calculated extrusion
			if (!m_processedOpenings)
			{
				IDictionary<Face, ExtrusionAnalyzerFaceAlignment> faceAlignment = 
					m_analyzer.CalculateFaceAlignment();
				
				// Sort unaligned and partially aligned faces vs. generating element id.
				foreach (Face face in faceAlignment.Keys)
				{
					if (faceAlignment[face] == ExtrusionAnalyzerFaceAlignment.FullyAligned)
						continue;
					
					ICollection<ElementId> generatingIds = 
						m_element.GetGeneratingElementIds(face);
					
					foreach (ElementId id in generatingIds)
					{
						// Skip self references (these are partially aligned faces formed 
						// with the wall openings)
						if (id == m_element.Id)
							continue;
						
						IList<Face> elementFaces;
						if (m_intersectingElements.ContainsKey(id))
						{
							elementFaces = m_intersectingElements[id];
						}
						else
						{
							elementFaces = new List<Face>();
							m_intersectingElements[id] = elementFaces;
						}
						elementFaces.Add(face);
					}
				}
				
				m_processedOpenings = true;
				m_enumerator = m_intersectingElements.Keys.GetEnumerator();
				hasMore = m_enumerator.MoveNext();
			}
			// Second and successive times this is run, increment to the next element.
			else
			{
				ElementId previousElementId = m_enumerator.Current;
				Element previousElement = m_document.GetElement(previousElementId);
				// Unhide the previous element.
				if (previousElement.IsHidden(m_document.ActiveView))
				{
					List<ElementId> toUnhide =  new List<ElementId>();
					toUnhide.Add(previousElementId);
					m_document.ActiveView.UnhideElements(toUnhide);
				}
				hasMore = m_enumerator.MoveNext();
			}
			
			// Highlight an intersection
            if (hasMore)
            {
                ElementId currentElementId = m_enumerator.Current;
                Element currentElement = m_document.GetElement(currentElementId);

                // Hide the generating element
                List<ElementId> toHide = new List<ElementId>();
                toHide.Add(currentElementId);
                m_document.ActiveView.HideElements(toHide);

                // Paint faces from the generating element.
                AnalysisVisualizationFramework framework =
                    AnalysisVisualizationFramework.getInstance(m_document);
                framework.PaintFaces(m_intersectingElements[currentElementId],
                                     m_document.ActiveView.Name);
            }
            else
            {
                m_enumerator = null;
                m_processedOpenings = false;
            }
			return hasMore;
		}
		
		/// <summary>
		/// Find first non-empty solid to analyze.  Note that for some elements there may be
		/// multiple viable solids, this example ignores this.
		/// </summary>
		private void GetTargetSolid()
		{
			m_solid = GeometryUtil.GetTargetSolid(m_element);
		}
		
		public static void Reset()
		{
			s_example = null;
		}
	}
}
