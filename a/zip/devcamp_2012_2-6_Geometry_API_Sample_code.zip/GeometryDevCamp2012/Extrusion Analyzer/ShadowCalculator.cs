﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;

namespace GeometryDevCamp2012
{
	/// <summary>
	/// Description of ShadowCalculator.
	/// </summary>
	public class ShadowCalculator
	{
		private Element m_targetElement;
		private XYZ m_sunDirection;
		
		public ShadowCalculator(Element targetElement, XYZ sunDirection)
		{
			m_targetElement = targetElement;
			m_sunDirection = sunDirection;
		}
		
		/// <summary>
		/// Draw the shadow of the target element with the sun direction specified.
		/// </summary>
		/// <returns></returns>
		public ICollection<ElementId> DrawShadow()
		{
			Document document = m_targetElement.Document;
			Solid solid = GeometryUtil.GetTargetSolid(m_targetElement);
			Level lowestLevel = GeometryUtil.GetLowestLevel(document);
			return DrawShadow(document, solid, lowestLevel, m_sunDirection);
			
		}
		
		/// <summary>
		/// Draw the shadow of the indicated solid with the sun direction specified.
		/// </summary>
		/// <remarks>The shadow will be outlined with model curves added to the document.
		/// A transaction must be open in the document.</remarks>
		/// <param name="document">The document.</param>
		/// <param name="solid">The target solid.</param>
		/// <param name="targetLevel">The target level where to measure and draw the shadow.</param>
		/// <param name="sunDirection">The direction from the sun (or light source).</param>
		/// <returns>The curves created for the shadow.</returns>
		/// <throws cref="Autodesk.Revit.Exceptions.InvalidOperationException">Thrown by ExtrusionAnalyzer when the geometry and 
		/// direction combined do not permit a successful analysis.</throws>
		private static ICollection<ElementId> DrawShadow(Document document, Solid solid, Level targetLevel, XYZ sunDirection)
		{		
			// Create target plane from level.		
			Plane plane = document.Application.Create.NewPlane(XYZ.BasisZ, new XYZ(0, 0, targetLevel.ProjectElevation));
			
			// Create extrusion analyzer.
			ExtrusionAnalyzer analyzer = ExtrusionAnalyzer.Create(solid, plane, sunDirection);
			
			// Get the resulting face at the base of the calculated extrusion.
			Face result = analyzer.GetExtrusionBase();
			
			// Convert edges of the face to curves.
			CurveArray curves = document.Application.Create.NewCurveArray();
			foreach (EdgeArray edgeLoop in result.EdgeLoops)
			{
				foreach (Edge edge in edgeLoop)
				{
					curves.Append(edge.AsCurve());
				}
			}
			
			// Get the model curve factory object.
			Autodesk.Revit.Creation.ItemFactoryBase itemFactory;
			if (document.IsFamilyDocument)
				itemFactory = document.FamilyCreate;
			else
				itemFactory = document.Create;
				
			// Add a sketch plane for the curves.				
			SketchPlane sketchPlane = itemFactory.NewSketchPlane(document.Application.Create.NewPlane(curves));
			document.Regenerate();
			
			// Add the shadow curves
			ModelCurveArray curveElements = itemFactory.NewModelCurveArray(curves, sketchPlane);
			
			// Return the ids of the curves created
			List<ElementId> curveElementIds = new List<ElementId>();
			foreach (ModelCurve curveElement in curveElements)
			{
				curveElementIds.Add(curveElement.Id);
			}
			
			return curveElementIds;
		}
	}
}
