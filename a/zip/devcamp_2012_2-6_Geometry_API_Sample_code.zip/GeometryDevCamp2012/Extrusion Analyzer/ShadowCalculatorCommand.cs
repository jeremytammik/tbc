﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

namespace GeometryDevCamp2012
{
	/// <summary>
	/// Description of ShadowCalculatorCommand.
	/// </summary>
	[Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
	public class ShadowCalculatorCommand: IExternalCommand
	{
		public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
		{
			Document document = commandData.View.Document;
		
			// Get sun path direction
			SunAndShadowSettings sunSettings = commandData.View.SunAndShadowSettings;
			XYZ initialDirection = XYZ.BasisY;	
			
			double altitude = sunSettings.GetFrameAltitude(sunSettings.ActiveFrame);
			Transform altitudeRotation = Transform.get_Rotation(XYZ.Zero, XYZ.BasisX, altitude);
			XYZ altitudeDirection = altitudeRotation.OfVector(initialDirection);
			
			double azimuth = sunSettings.GetFrameAzimuth(sunSettings.ActiveFrame);
			double actualAzimuth = 2* Math.PI - azimuth;  // Adjustment based on Revit's internal definition of azimuth value
			Transform azimuthRotation = Transform.get_Rotation(XYZ.Zero, XYZ.BasisZ, actualAzimuth);
			XYZ sunDirection = azimuthRotation.OfVector(altitudeDirection);
			
			
			// Get target mass
			Element targetMass;
			
			Selection currentSelection = commandData.Application.ActiveUIDocument.Selection;
			if (currentSelection.Elements.Size > 0)
			{
				ElementSetIterator iterator = currentSelection.Elements.ForwardIterator();
				iterator.Reset();
				iterator.MoveNext();
				
				targetMass = iterator.Current as Element;
			}
			else
			{
				FilteredElementCollector collector = new FilteredElementCollector(document, commandData.View.Id);
				collector.OfClass(typeof(FamilyInstance));
				collector.OfCategory(BuiltInCategory.OST_Mass);
				
				targetMass = collector.FirstElement();
			}
			
			
			Transaction t = new Transaction(document, "Draw shadow");
			t.Start();
			ICollection<ElementId> shadowCurves = null;
			// Calculate shadow
			try
			{
				shadowCurves = new ShadowCalculator(targetMass, sunDirection).DrawShadow();
			}
			catch (Exception)
			{
				t.RollBack();
				message = "Probably the shadow analysis failed.";
				elements.Insert(targetMass);
				return Result.Failed;
			}
			t.Commit();
			
			ShadowCalculatorUpdater updater = new ShadowCalculatorUpdater(commandData.Application.ActiveAddInId, targetMass, shadowCurves);
			UpdaterRegistry.RegisterUpdater(updater, document, true);
			UpdaterRegistry.AddTrigger(updater.GetUpdaterId(), new ElementClassFilter(typeof(SunAndShadowSettings)), Element.GetChangeTypeAny());
			
			document.Application.FailuresProcessing += updater.ProcessFailures;
			
			return Result.Succeeded;
		}
	}
}
