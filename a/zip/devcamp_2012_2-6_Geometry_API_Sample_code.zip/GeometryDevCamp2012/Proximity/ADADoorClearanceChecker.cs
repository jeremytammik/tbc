﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;
using System.Collections.Generic;
using System.Linq;

using Autodesk.Revit.DB;

namespace GeometryDevCamp2012
{
	/// <summary>
	/// Description of ADAClearanceChecker.
	/// </summary>
	public class ADADoorClearanceChecker
	{
		private Document m_document;
		public ADADoorClearanceChecker(Document document)
		{
			m_document = document;
		}
		
		/// <summary>
		/// Gets a list of doors which fail the proximity check
		/// </summary>
		/// <returns>The ids of the doors.</returns>
		public IEnumerable<ElementId> GetFailingDoors()
		{
			// Find all floor plan views and associate to their level
			FilteredElementCollector viewPlanCollector = new FilteredElementCollector(m_document);
			viewPlanCollector.OfClass(typeof(ViewPlan));
			
			Dictionary<ElementId, ViewPlan> levelsToViewPlansMap = new Dictionary<ElementId, ViewPlan>();
			foreach (ViewPlan viewPlan in viewPlanCollector.Cast<ViewPlan>().Where<ViewPlan>(vp => !vp.IsTemplate && vp.ViewType == ViewType.FloorPlan))
			{
				//TODO- why are there multiple floor plans referencing one level?
				if (!levelsToViewPlansMap.ContainsKey(viewPlan.GenLevel.Id))
					levelsToViewPlansMap.Add(viewPlan.GenLevel.Id, viewPlan);
			}
			
			// Get doors
			FilteredElementCollector doorCollector = new FilteredElementCollector(m_document);
			ElementFilter isADoorFilter = new LogicalAndFilter(new ElementIsElementTypeFilter(true), new ElementCategoryFilter(BuiltInCategory.OST_Doors));
			doorCollector.WherePasses(isADoorFilter);
			List<ElementId> failingDoors = new List<ElementId>();
			
			// Setup analysis visualization framework utility to draw green and red volumes
			AnalysisVisualizationFramework framework = AnalysisVisualizationFramework.getInstance(m_document);
			List<System.Drawing.Color> colors = new List<System.Drawing.Color>();
			colors.Add(System.Drawing.Color.Green);
			colors.Add(System.Drawing.Color.Red);
			framework.SetMultipleColors(colors);
			
			// For each door, build a temporary 3D extension based on ADA standards.
			foreach (FamilyInstance doorInstance in doorCollector.Cast<FamilyInstance>())
			{
				Level level = doorInstance.Level;
				ViewPlan viewPlan;
				if (levelsToViewPlansMap.TryGetValue(level.Id, out viewPlan))
				{
					// Create the approach volumes on either side of the door
					Tuple<Solid, Solid> adaExtensions = CreateADASolidExtensions(doorInstance, viewPlan);
					
					if (!framework.SchemaInitialized)
					{
						Transaction t = new Transaction(m_document, "Create display style");
						t.Start();
						framework.View = m_document.ActiveView;
						framework.SetupDisplaySettings();
						t.Commit();
					}
					
					// See if elements intersect the extension
					bool hasInterferences = false;
					
					if (FindAndHighlightInterferences(framework, doorInstance, adaExtensions.Item1))
						hasInterferences = true;
					
					if (FindAndHighlightInterferences(framework, doorInstance, adaExtensions.Item2))
						hasInterferences = true;
					
					if (hasInterferences)
						failingDoors.Add(doorInstance.Id);
				}
			}
			
			return failingDoors;
		}
		
		/// <summary>
		/// Finds and highlights the extensions that surround doors.
		/// </summary>
		/// <remarks>If an extension includes an interference, the highlight is Red.  Otherwise, Green.</remarks>
		/// <param name="framework">The AnalysisVisualizationFramework utility.</param>
		/// <param name="doorInstance">The door instance.</param>
		/// <param name="extension">The calculated extension.</param>
		/// <returns></returns>
		private bool FindAndHighlightInterferences(AnalysisVisualizationFramework framework,
		                                           FamilyInstance doorInstance, Solid extension)
		{
			ICollection<ElementId> interferingElements = FindElementsInterferingWithDoor(doorInstance, extension);
			
			System.Drawing.Color paintColor = System.Drawing.Color.Green;
			if (interferingElements.Count > 0)
			{
				paintColor = System.Drawing.Color.Red;
			}
			
			framework.PaintSolid(extension, paintColor);
			
			return interferingElements.Count > 0;
		}
		
		/// <summary>
		/// Try to get the double value of a parameter if available.
		/// If the parameter is not found on the instance, the type will be checked.
		/// If the parameter is found on the instance but the value is 0.0, the type will be checked.
		/// </summary>
		/// <param name="element">The element.</param>
		/// <param name="parameterIdentifier">The identifier of  the parameter.</param>
		/// <param name="value">The value (output).</param>
		/// <returns>True if the value was found, false otherwise.</returns>
		private bool TryGetInstanceOrTypeParameterValueIfSet(Element element, BuiltInParameter parameterIdentifier, out double value)
		{
			value = 0.0;
			Parameter parameter = element.get_Parameter(parameterIdentifier);
			if (parameter != null && parameter.StorageType == StorageType.Double)
			{
				value = parameter.AsDouble();
				if (value != 0)
					return true;
			}
			if (!(element is ElementType))
			{
				Element typeElement = element.Document.GetElement(element.GetTypeId());
				if (typeElement != null)
				{
					parameter = typeElement.get_Parameter(parameterIdentifier);
					if (parameter != null && parameter.StorageType == StorageType.Double)
					{
						value = parameter.AsDouble();
						return true;
					}
				}
			}
			
			return false;
		}
		
		/// <summary>
		/// Try to get the double value of a parameter if available.
		/// If the parameter is not found on the instance, the type will be checked.
		/// If the parameter is found on the instance but the value is 0.0, the type will be checked.
		/// </summary>
		/// <param name="element">The element.</param>
		/// <param name="parameterIdentifier">The name of  the parameter.</param>
		/// <param name="value">The value (output).</param>
		/// <returns>True if the value was found, false otherwise.</returns>
		private bool TryGetInstanceOrTypeParameterValueIfSet(Element element, string parameterIdentifier, out double value)
		{
			value = 0.0;
			Parameter parameter = element.get_Parameter(parameterIdentifier);
			if (parameter != null && parameter.StorageType == StorageType.Double)
			{
				value = parameter.AsDouble();
				if (value != 0.0)
					return true;
			}
			if (!(element is ElementType))
			{
				Element typeElement = element.Document.GetElement(element.GetTypeId());
				if (typeElement != null)
				{
					parameter = typeElement.get_Parameter(parameterIdentifier);
					if (parameter != null && parameter.StorageType == StorageType.Double)
					{
						value = parameter.AsDouble();
						return true;
					}
				}
			}
			
			return false;
		}
		
		/// <summary>
		/// The possible types of doors which can be recognized by the heuristic utility.
		/// </summary>
		enum DoorType
		{
			/// <summary>
			/// A door without a swing path (e.g. a slider or pocket door).
			/// </summary>
			NoSwingDoor,
			/// <summary>
			/// A door with a single swing path.
			/// </summary>
			SingleDoor,
			/// <summary>
			/// A double door or a door with more than 2 swing paths.
			/// </summary>
			DoubleDoor
		}
		
		/// <summary>
		/// The possible locations for the door swing as determined by the heuristic utility.
		/// </summary>
		enum DoorSwingSide
		{
			/// <summary>
			/// The door has no swing path.
			/// </summary>
			NoSwing,
			/// <summary>
			/// The door swing occurs on the "Max" side of the bounding box.
			/// </summary>
			SwingOnMaxSide,
			/// <summary>
			/// The door swing occurs on the "Min" side of the bounding box.
			/// </summary>
			SwingOnMinSide
		}
		
		/// <summary>
		/// The possible location for the target boundary box point relative to the door hinge (single doors only).
		/// </summary>
		enum DoorBoundingBoxSide
		{
			/// <summary>
			/// The bounding box point is near the hinge side.
			/// </summary>
			HingeSide,
			/// <summary>
			/// The bounding box point is near the latch side.
			/// </summary>
			LatchSide
		}
		
		/// <summary>
		/// Creates door extensions based on the front approach required for the ADA.
		/// </summary>
		/// <remarks>Uses heuristics to recognize and identify door swing, latch location, and the extension volume.</remarks>
		/// <param name="doorInstance">The door instance.</param>
		/// <param name="viewPlan">The floor plan to which it is associated.</param>
		/// <returns></returns>
		private Tuple<Solid, Solid> CreateADASolidExtensions(FamilyInstance doorInstance, ViewPlan viewPlan)
		{
			// Front approach
			// Get the bounding box geometry of the 3D geometry
			Document document = doorInstance.Document;
			Autodesk.Revit.Creation.Application create = document.Application.Create;
			FamilySymbol doorSymbol = document.GetElement(doorInstance.GetTypeId()) as FamilySymbol;
			
			// Get door width
			double widthOfDoor;
			if (!TryGetInstanceOrTypeParameterValueIfSet(doorInstance, BuiltInParameter.DOOR_WIDTH, out widthOfDoor))
			{
				widthOfDoor = 6.0;
			}
			
			// Add trim width if present
			// This works for english language door content only
			double trimWidth = 0.0;
			if (TryGetInstanceOrTypeParameterValueIfSet(doorInstance, "Trim Width", out trimWidth))
			{
				widthOfDoor += 2 * trimWidth;
			}
			
			// The extension is built from the bounding box.  We use the bounding box of the
			// door type, not the door instance, because most door content will be placed to
			// a wall aligned to the coordinate axes.
			BoundingBoxXYZ bbox = doorSymbol.get_BoundingBox(null);
			
			// Transform bounding box to instance coordinates.
			Transform transform = doorInstance.GetTransform();
			XYZ instanceMin = transform.OfPoint(bbox.Min);
			XYZ instanceMax = transform.OfPoint(bbox.Max);
			
			// The bounding box includes the symbolic curves of the door swing (if present)
			// We want the extents to begin from the wall, not the door swing extents,
			// so we project the boundaries to the wall.
			
			// The algorithm also uses the fact that the symbolic curves are included to figure out
			// which side of the wall the door swings into (which is necessary for some calculations
			// of the front approach).
			
			Wall wall = doorInstance.Host as Wall;
			DoorSwingSide swingSide = DoorSwingSide.NoSwing;
			DoorBoundingBoxSide bBoxSide = DoorBoundingBoxSide.HingeSide;
			DoorType doorType = DoorType.NoSwingDoor;
			
			if (wall != null)
			{
				// Get the side faces of the wall.  If only one face is found we can proceed.
				IList<Reference> faceReferences = HostObjectUtils.GetSideFaces(wall, ShellLayerType.Exterior);
				if (faceReferences.Count == 1)
				{
					Face exteriorFace = wall.GetGeometryObjectFromReference(faceReferences[0]) as Face;
					faceReferences = HostObjectUtils.GetSideFaces(wall, ShellLayerType.Interior);
					Face interiorFace = wall.GetGeometryObjectFromReference(faceReferences[0]) as Face;
					
					IntersectionResult minToExterior = exteriorFace.Project(instanceMin);
					IntersectionResult minToInterior = interiorFace.Project(instanceMin);
					bool minNearestToExterior = (minToExterior.Distance < minToInterior.Distance);
					double minDistance = minNearestToExterior ? minToExterior.Distance : minToInterior.Distance;
					instanceMin = minNearestToExterior ? minToExterior.XYZPoint : minToInterior.XYZPoint;
					
					IntersectionResult maxToFace = minNearestToExterior ? interiorFace.Project(instanceMax) : exteriorFace.Project(instanceMax);
					swingSide = maxToFace.Distance > minDistance ? DoorSwingSide.SwingOnMaxSide : DoorSwingSide.SwingOnMinSide;
					instanceMax = maxToFace.XYZPoint;
					
					if (doorInstance.FacingFlipped || doorInstance.HandFlipped)
					{
						if (!(doorInstance.FacingFlipped && doorInstance.HandFlipped))
						{
							if (swingSide == DoorSwingSide.SwingOnMaxSide)
								swingSide = DoorSwingSide.SwingOnMinSide;
							else
								swingSide = DoorSwingSide.SwingOnMaxSide;
						}
					}
					
					// Try to find the doorswing curve
					IList<Arc> allArcs = GetAllArcsInInstanceGeometry(doorInstance, viewPlan);
					 
					List<Arc> allSwingArcs = new List<Arc>();
					Arc swingArc = null;
					double swingRadius = 0.0;					 
					foreach (Arc arc in allArcs)
					{
						// If arc is less than 1/5 of door width, may not represent door swing; skip it.
						if (arc.Radius > 0.2 * widthOfDoor) 
						{
								allSwingArcs.Add(arc);
								if (arc.Radius > swingRadius) 
								{
									swingArc = arc;
									swingRadius = arc.Radius;
								}
						}
					}
					
					// Double door
					if (allSwingArcs.Count > 1)
					{
						// TODO - what if there are more than 2?
						doorType = DoorType.DoubleDoor;
					}
					//This is the biggest arc.  Get the endpoint away from the target face
					else if (swingArc != null)
					{
						doorType = DoorType.SingleDoor;
						XYZ arcEnd1 = swingArc.get_EndPoint(0);
						XYZ arcEnd2 = swingArc.get_EndPoint(1);
						
						Face targetFace = (minNearestToExterior && swingSide == DoorSwingSide.SwingOnMinSide ||
						                   !minNearestToExterior && swingSide == DoorSwingSide.SwingOnMaxSide) ? exteriorFace : interiorFace;
						XYZ targetPoint = swingSide == DoorSwingSide.SwingOnMaxSide ? instanceMax : instanceMin;
						IntersectionResult projection1 = targetFace.Project(arcEnd1);
						IntersectionResult projection2 = targetFace.Project(arcEnd2);
						XYZ hingeSidePoint = (projection1.Distance > projection2.Distance) ? arcEnd1 : arcEnd2;
						XYZ otherSidePoint = (projection1.Distance > projection2.Distance) ? arcEnd2 : arcEnd1;
						double distanceToHinge = hingeSidePoint.DistanceTo(targetPoint);
						double distanceToOther = otherSidePoint.DistanceTo(targetPoint);
						bBoxSide = distanceToOther > distanceToHinge ? DoorBoundingBoxSide.HingeSide : DoorBoundingBoxSide.LatchSide;
					}
					// else - No swing arcs found
				}
			}
			
			// Offset min  by using the hand vector (x-vector).
			XYZ xVector = doorInstance.HandOrientation;

			double deltaNearSide = 0.0;
			double deltaFarSide = 0.0;
			double LatchApproachOffset = 1.5;
			double ReverseLatchApproachOffset = 1.0;
			if (doorType == DoorType.SingleDoor)
			{
				if (swingSide == DoorSwingSide.SwingOnMaxSide)
				{
					if (bBoxSide == DoorBoundingBoxSide.HingeSide)
					{
						deltaNearSide = ReverseLatchApproachOffset;
					}
					else
					{
						deltaFarSide = ReverseLatchApproachOffset;
					}
				}
				else
				{
					if (bBoxSide == DoorBoundingBoxSide.HingeSide)
					{
						deltaFarSide = LatchApproachOffset;
					}
					else
					{
						deltaNearSide = LatchApproachOffset;
					}
				}
			}
			
			// Near point
			XYZ pointA1 = instanceMin - xVector * deltaNearSide;
			XYZ pointA2 = instanceMin + xVector * (deltaFarSide + widthOfDoor);
			XYZ deltaZ = new XYZ(0, 0, instanceMax.Z - instanceMin.Z);
			XYZ pointB1 = pointA1 + deltaZ;
			XYZ pointB2 = pointA2 + deltaZ;
			
			// Create boundaries of extension
			List<CurveLoop> curveLoops = new List<CurveLoop>();
			List<Curve> curves = new List<Curve>();
			
			curves.Add(Line.get_Bound(pointA1, pointA2));
			curves.Add(Line.get_Bound(pointA2, pointB2));
			curves.Add(Line.get_Bound(pointB2, pointB1));
			curves.Add(Line.get_Bound(pointB1, pointA1));
			
			CurveLoop curveLoop = CurveLoop.Create(curves);
			curveLoops.Add(curveLoop);
			
			double extensionDistance = 5;  // Front approach mandated value
			XYZ extensionDirection = -doorInstance.FacingOrientation;
			Solid side1Extension = GeometryCreationUtilities.CreateExtrusionGeometry(curveLoops, extensionDirection, extensionDistance);
			
			// Ofset max by using the hand vector
			deltaNearSide = 0.0;
			deltaFarSide = 0.0;
			
			if (doorType == DoorType.SingleDoor)
			{
				if (swingSide == DoorSwingSide.SwingOnMaxSide)
				{
					if (bBoxSide == DoorBoundingBoxSide.HingeSide)
					{
						deltaFarSide = LatchApproachOffset;
					}
					else
					{
						deltaNearSide = LatchApproachOffset;
					}
				}
				else
				{
					if (bBoxSide == DoorBoundingBoxSide.HingeSide)
					{
						deltaNearSide = ReverseLatchApproachOffset;
					}
					else
					{
						deltaNearSide = ReverseLatchApproachOffset;
					}
				}
			}
			
			XYZ pointC1 = instanceMax + xVector * deltaNearSide;
			XYZ pointC2 = instanceMax - xVector * (deltaFarSide + widthOfDoor); // 
			XYZ pointD1 = pointC1 - deltaZ;
			XYZ pointD2 = pointC2 - deltaZ;
			
			// Create boundaries of extension
			List<CurveLoop> curveLoopsMax = new List<CurveLoop>();
			List<Curve> curvesMax = new List<Curve>();
			
			curvesMax.Add(Line.get_Bound(pointC1, pointC2));
			curvesMax.Add(Line.get_Bound(pointC2, pointD2));
			curvesMax.Add(Line.get_Bound(pointD2, pointD1));
			curvesMax.Add(Line.get_Bound(pointD1, pointC1));
			
			curveLoop = CurveLoop.Create(curvesMax);
			curveLoopsMax.Add(curveLoop);
			
			Solid side2Extension = GeometryCreationUtilities.CreateExtrusionGeometry(curveLoopsMax, -extensionDirection, extensionDistance);
			
			
			// Combine the two extensions
			// If they are intersecting, our vectors need to be reversed.
			Solid intersection = BooleanOperationsUtils.ExecuteBooleanOperation(side1Extension, side2Extension, BooleanOperationsType.Intersect);
			if (intersection.Volume > 0)
			{
				side1Extension = GeometryCreationUtilities.CreateExtrusionGeometry(curveLoops, -extensionDirection, extensionDistance);
				side2Extension = GeometryCreationUtilities.CreateExtrusionGeometry(curveLoopsMax, extensionDirection, extensionDistance);
			}
			
			return new Tuple<Solid, Solid>(side1Extension, side2Extension);
		}


		/// <summary>
		/// Finds all arc curves in the geometry
		/// </summary>
		/// <param name="doorInstance">The instance.</param>
		/// <param name="viewPlan">The plan view from which to get the view-specific geometry.</param>
		/// <returns></returns>
		IList<Arc> GetAllArcsInInstanceGeometry(FamilyInstance doorInstance, ViewPlan viewPlan)
		{
			Options options = new Options();
			options.View = viewPlan;
			GeometryElement geomElem = doorInstance.get_Geometry(options);
			List<Arc> arcs = new List<Arc>();
			foreach (GeometryObject geomObj in geomElem) 
			{
				if (geomObj is GeometryInstance) 
				{
					GeometryInstance geomInst = (GeometryInstance)geomObj;
					GeometryElement instGeomElem = geomInst.GetInstanceGeometry();
					foreach (GeometryObject instGeomObj in instGeomElem) 
					{
						if (instGeomObj is Arc) 
						{
							Arc arc = (Arc)instGeomObj;
							arcs.Add(arc);
						}
					}
				}
			}
			return arcs;
		}
		
		/// <summary>
		/// Finds any Revit physical elements which interfere with the target solid region surrounding a door.
		/// </summary>
		/// <remarks>This routine is useful for detecting interferences which are violations of the Americans with
		/// Disabilities Act or other local disabled access codes.</remarks>
		/// <param name="doorInstance">The door instance.</param>
		/// <param name="doorAccessibilityRegion">The accessibility region calculated to surround the approach of the door.</param>
		/// <returns>A collection of interfering element ids.</returns>
		private ICollection<ElementId> FindElementsInterferingWithDoor(FamilyInstance doorInstance, Solid doorAccessibilityRegion)
		{
			// Setup the filtered element collector for all document elements.
			FilteredElementCollector interferingCollector = new FilteredElementCollector(doorInstance.Document);
			
			// Only accept element instances
			interferingCollector.WhereElementIsNotElementType();
			
			// Exclude intersections with the door itself or the host wall for the door.
			List<ElementId> excludedElements = new List<ElementId>();
			excludedElements.Add(doorInstance.Id);
			excludedElements.Add(doorInstance.Host.Id);
			ExclusionFilter exclusionFilter = new ExclusionFilter(excludedElements);
			interferingCollector.WherePasses(exclusionFilter);
			
			// Set up a filter which matches elements whose solid geometry intersects with the accessibility region
			ElementIntersectsSolidFilter intersectionFilter = new ElementIntersectsSolidFilter(doorAccessibilityRegion);
			interferingCollector.WherePasses(intersectionFilter);
			
			// Return all elements passing the collector
			return interferingCollector.ToElementIds();
		}
	}
}
