﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Media.Imaging;
using System.IO;
using System.Xaml;
using Autodesk.Revit.UI;

namespace GeometryDevCamp2012
{
	/// <summary>
	/// Description of MyClass.
	/// </summary>
	public class GeometryDevCamp2012Application : IExternalApplication
	{
		static string buttonIconsFolder = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "images");
		
		public Result OnStartup(UIControlledApplication application)
		{
			application.CreateRibbonTab("Geometry");
			CreateBasicsPanel(application);
			CreateExtrusionAnalyzerPanel(application);
			CreateIntersectionFiltersPanel(application);
			CreatePartsPanel(application);
			CreatePointCloudsPanel(application);
			CreateSpatialElementsPanel(application);
            CreateReferenceIntersectorPanel(application);
			
			return Result.Succeeded;
		}

        public void CreateReferenceIntersectorPanel(UIControlledApplication application)
        {

            RibbonPanel geometryPanel = application.CreateRibbonPanel("Geometry", "Reference Intersector");

            RibbonItem item = geometryPanel.AddItem(new PushButtonData("RefInt.BeamConnectors", "Add beam connectors to ends", 
                                                                        Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.RefInt.FindTargetBeamFaceCommand"));
            PushButton button = (PushButton)item;
            button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "parts_create.png"), UriKind.Absolute));
            button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ExtrusionAnalyzer-S.png"), UriKind.Absolute));
            item.ToolTip = "Create connectors on ends of selected beam.";

            item = geometryPanel.AddItem(new PushButtonData("RefInt.BeamVoids", "Add voids",
                                                                        Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.RefInt.AddVoidsToBeamsCommand"));
            button = (PushButton)item;
            button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "parts_create.png"), UriKind.Absolute));
            button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ExtrusionAnalyzer-S.png"), UriKind.Absolute));
            item.ToolTip = "Create voids at specified locations of all beams.";
        }

		public void CreatePartsPanel(UIControlledApplication application)
		{
			
			RibbonPanel geometryPanel = application.CreateRibbonPanel("Geometry", "Parts");
			
			RibbonItem item = geometryPanel.AddItem(new PushButtonData("Part.Layers", "Highlight layer extents", Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.Parts.PartExtentsCommand"));
			PushButton  button = (PushButton)item;
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "parts_create.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ExtrusionAnalyzer-S.png"), UriKind.Absolute));
			item.ToolTip = "Highlight extents of part layers.";			                                                               
		}
		
		public void CreateSpatialElementsPanel(UIControlledApplication application)
		{
			
			RibbonPanel geometryPanel = application.CreateRibbonPanel("Geometry", "Spatial Elements");
			
			RibbonItem item = geometryPanel.AddItem(new PushButtonData("SpatialElements.Calculate", "Calculate boundary areas", Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.SpatialElements.SpatialElementBoundaryAreasCommand"));
			PushButton  button = (PushButton)item;
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "room_object_place.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "room_object_place.ico"), UriKind.Absolute));
			item.ToolTip = "Calculate spatial elements' boundaries.";			                                                               
		}
		
		public void CreatePointCloudsPanel(UIControlledApplication application)
		{
			
			RibbonPanel geometryPanel = application.CreateRibbonPanel("Geometry", "Point Clouds");
			
			RibbonItem item = geometryPanel.AddItem(new PushButtonData("PointClouds.EvaluateIsolate", "Evaluate cloud - Isolate", Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.PointClouds.EvaluatePointCloudIsolateCommand"));
			PushButton  button = (PushButton)item;
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "point_cloud_link.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ExtrusionAnalyzer-S.png"), UriKind.Absolute));
			item.ToolTip = "Evaluate point cloud proximity to element faces.";	

			item = geometryPanel.AddItem(new PushButtonData("PointClouds.EvaluateHighlight", "Evaluate cloud - Highlight", Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.PointClouds.EvaluatePointCloudHighlightCommand"));
			button = (PushButton)item;
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "point_cloud_link.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ExtrusionAnalyzer-S.png"), UriKind.Absolute));
			item.ToolTip = "Evaluate point cloud proximity to element faces.";	

			item = geometryPanel.AddItem(new PushButtonData("PointClouds.Reset", "Reset cloud visibility", Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.PointClouds.ResetPointCloudCommand"));
			button = (PushButton)item;
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "point_cloud_link - restore.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ExtrusionAnalyzer-S.png"), UriKind.Absolute));
			item.ToolTip = "Reset filters on point cloud.";				
		}
		
		public void CreateBasicsPanel(UIControlledApplication application)
		{
			
			RibbonPanel geometryPanel = application.CreateRibbonPanel("Geometry", "Basics");
			
			RibbonItem item = geometryPanel.AddItem(new PushButtonData("Place.Corbel", "Place corbels", Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.Basics.CorbelPlacementCommand"));
			PushButton  button = (PushButton)item;
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "corbels.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ExtrusionAnalyzer-S.png"), UriKind.Absolute));
			item.ToolTip = "Place corbels on the north-facing faces of columns.";			                                                               
		}
		
		private void CreateExtrusionAnalyzerPanel(UIControlledApplication application)
		{
			
			RibbonPanel geometryPanel = application.CreateRibbonPanel("Geometry", "Extrusion analyzer");
			
			RibbonItem item = geometryPanel.AddItem(new PushButtonData("Ext.Analyze", "Extrusion\nAnalyzer", Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.ExtrusionAnalyzerHighlighterCommand"));
			PushButton  button = (PushButton)item;
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "extrusion_analyze.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ExtrusionAnalyzer-S.png"), UriKind.Absolute));
			item.ToolTip = "Execute an extrusion analysis in Z for the input extrusion and highlight results.";
			
			item = geometryPanel.AddItem(new PushButtonData("Solar.Shadow", "Shadow\nCalculate", Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.ShadowCalculatorCommand"));
			                                                           
			                                                           button = (PushButton)item;
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "shadow.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ExtrusionAnalyzer-S.png"), UriKind.Absolute));
			item.ToolTip = "Calculate the exterior shadow of a given element based on the sun path.";
			
		}
		
		private void CreateIntersectionFiltersPanel(UIControlledApplication application)
		{
			RibbonPanel geometryPanel = application.CreateRibbonPanel("Geometry", "Intersection filters");
		
			IList<RibbonItem> items = geometryPanel.AddStackedItems(new PushButtonData("Proximity.WallColumn", "Highlight Intersections", 
																    Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.WallColumnIntersectionProximityCommand"),
			                                                        new PushButtonData("Proximity.WallColumnRestore", "Restore View", 
																    Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.RestoreViewCommand"));
			PushButton button = (PushButton)items[0];
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "interference_check_run.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "interference_check_run.png"), UriKind.Absolute));
			button.ToolTip = "Find and highlight the geometry of intersections between walls and columns.";

			button = (PushButton)items[1];
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "restore.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "restore.png"), UriKind.Absolute));
			button.ToolTip = "Restore the view after highlight.";
			
			RibbonItem item = geometryPanel.AddItem(new PushButtonData("Door.Clearance", "ADA Door\nClearance", Assembly.GetExecutingAssembly().Location,
                                                                       "GeometryDevCamp2012.ADADoorClearanceCheckerCommand"));
			button = (PushButton)item;
			button.LargeImage = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ada.png"), UriKind.Absolute));
			button.Image = new BitmapImage(new Uri(Path.Combine(buttonIconsFolder, "ExtrusionAnalyzer-S.png"), UriKind.Absolute));
			button.ToolTip = "Highlight doors that have obstructions in violation of ADA code.";
		}
		
		public Result OnShutdown(UIControlledApplication application)
		{
			return Result.Succeeded;
		}
	}
}