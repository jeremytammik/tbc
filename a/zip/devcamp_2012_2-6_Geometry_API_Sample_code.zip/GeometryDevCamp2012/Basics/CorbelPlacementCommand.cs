﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;
using System.Linq;

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace GeometryDevCamp2012.Basics
{
	/// <summary>
	/// Corbel Placement command.
	/// </summary>
	[Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
	public class CorbelPlacementCommand : IExternalCommand
	{
		public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
		{
			Document doc = commandData.View.Document;
		
		    // Find corbel type
		    FilteredElementCollector corbelSymbolFinder = new FilteredElementCollector(doc);
		    corbelSymbolFinder.OfClass(typeof(FamilySymbol));
		    
		    FamilySymbol corbelSymbol = corbelSymbolFinder.Cast<FamilySymbol>().Where<FamilySymbol>(fs => fs.Name == "Corbel 35x61.5x25").First<FamilySymbol>();
		    
		    
			//Find all columns by type
			FilteredElementCollector columnFinder = new FilteredElementCollector(doc);
			columnFinder.OfClass(typeof(FamilyInstance));
			columnFinder.OfCategory(BuiltInCategory.OST_StructuralColumns);
			
			//For each column, add corbel
			CorbelPlacement placement = new CorbelPlacement(corbelSymbol);
			foreach (FamilyInstance column in columnFinder)
			{
				placement.PlaceCorbelOnNorthFace(column);
			}
			
			return Result.Succeeded;
		}
	}
}
