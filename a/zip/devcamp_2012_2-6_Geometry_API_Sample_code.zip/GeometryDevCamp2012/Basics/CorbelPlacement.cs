﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;

using Autodesk.Revit.DB;

using Autodesk.Revit.UI;

namespace GeometryDevCamp2012.Basics
{
	/// <summary>
	/// Application class for demonstrating of family instance placement on faces found by geometry analysis.
	/// </summary>
	public class CorbelPlacement
	{
		private FamilySymbol m_corbelSymbol;
		
		/// <summary>
		/// Constructs the application class.
		/// </summary>
		/// <param name="corbelSymbol">The family type for the corbel.</param>
		public CorbelPlacement(FamilySymbol corbelSymbol)
		{
			m_corbelSymbol = corbelSymbol;
		}
		
		/// <summary>
		/// Places a corbel family instance on the upper midpoint of a north facing face of the column.
		/// </summary>
		/// <remarks>If no north-facing planar face is found, no corbel will be placed.</remarks>
		/// <param name="column">The column.</param>
		public void PlaceCorbelOnNorthFace(FamilyInstance column)
		{
			Document document = column.Document;
			Transaction t = new Transaction(document, "Place corbel");
            t.Start();
            
            XYZ normal = new XYZ(0, 1, 0);
            TransformedPlanarFace face = GetFaceNormalTo(column, normal, FindUppermostPlanarFaceByMidpoint);
            if (face != null)
            {
	            XYZ location = GetMidpointOfUpperEdge(face.PlanarFace, face.Transform);
	            
                XYZ corbelXAxis = XYZ.BasisZ;
                FamilyInstance corbel = document.Create.NewFamilyInstance(face.PlanarFace, location, corbelXAxis, m_corbelSymbol);
	            
	            t.Commit();
            }
            else
            {
            	t.RollBack();
            }
		}
		
		/// <summary>
		/// Data class representing a planar face and the transform applied to it in model coordinates.
		/// </summary>
		private class TransformedPlanarFace
		{
			public PlanarFace PlanarFace { get; set; }
			public Transform Transform { get; set; }
			public TransformedPlanarFace(PlanarFace face, Transform trf)
			{
				PlanarFace = face;
				Transform = trf;
			}
		}
		
		/// <summary>
		/// Comparator for choosing faces based on which face has a higher uppermost midpoint suitable for corbel placement.
		/// </summary>
		/// <param name="face1">The first face.</param>
		/// <param name="face2">The second face.</param>
		/// <returns>A negative value if the first face has a higher uppermost point.  A positive value if the second face has a higher uppermost point.</returns>
		private static int FindUppermostPlanarFaceByMidpoint(TransformedPlanarFace face1, TransformedPlanarFace face2)
		{
			XYZ upperMidPoint1 = GetMidpointOfUpperEdge(face1.PlanarFace, face1.Transform);
			XYZ upperMidPoint2 = GetMidpointOfUpperEdge(face2.PlanarFace, face2.Transform);
			
			return (int)(upperMidPoint2.Z - upperMidPoint1.Z);
		}
		
		/// <summary>
		/// Searches a given element to find the best planar face normal to the input vector based on a given comparison criterion.
		/// </summary>
		/// <param name="element">The element.</param>
		/// <param name="normal">The normal.</param>
		/// <param name="faceComparer">The comparison function.</param>
		/// <returns>The face which best fits the criteria, or null, if no face meets the criteria.</returns>
		private static TransformedPlanarFace GetFaceNormalTo(Element element, XYZ normal, Comparison<TransformedPlanarFace> faceComparer)
        {
            Options options = new Options();
            options.ComputeReferences = true;
            GeometryElement geo = element.get_Geometry(options);
            TransformedPlanarFace result = null;
            
            // Traverse top level objects
            foreach (GeometryObject obj in geo)
            {
                GeometryInstance ins = obj as GeometryInstance;
                
                // Find GeometryInstances in the FamilyInstance geometry
                if (ins != null)
                {
                    Transform trf = ins.Transform;
               		
                    // Traverse symbol geometry
                    // Symbol geometry is used because this utility needs to supply a 
                    // usable reference for attachment of other elements.
                    foreach (GeometryObject obj2 in ins.GetSymbolGeometry())
                    {

                    	// Skip empty solids
                        Solid solid2 = obj2 as Solid;
                        if (solid2 != null && solid2.Volume > 0)
                        {
                            foreach (Face face in solid2.Faces)
                            {
                            	// Compare normal with the target normal
                            	// Use GetNormal() to ensure that a normal passing out of the solid body
                            	// is returned.  
                                PlanarFace p = face as PlanarFace;
                                UV faceCenter = (p.GetBoundingBox().Min + p.GetBoundingBox().Max)/2;
                                if (p != null && trf.OfVector(p.ComputeNormal(faceCenter)).IsAlmostEqualTo(normal))
                                {
                                	// Compare candidate face vs. previously uppermost saved face
                                	TransformedPlanarFace candidate = new TransformedPlanarFace(p, trf);
                                	if (result == null || faceComparer.Invoke(result, candidate) > 0)
                                	{
                                		result = candidate;
                                	}
                                }
                            }
                        }
                    }
                }
                
                // Find solids in the FamilyInstance geometry
                // Solids may be found if the instance geometry is unique/modified by related elements
                Solid solid = obj as Solid;
                if (solid != null && solid.Volume > 0)
                {
                    foreach (Face face in solid.Faces)
                    {
                    	// Compare normal with the target normal
                        // Use GetNormal() to ensure that a normal passing out of the solid body
                        // is returned.  
                        PlanarFace p = face as PlanarFace;
                        UV faceCenter = (p.GetBoundingBox().Min + p.GetBoundingBox().Max)/2;
                        if (p != null && p.ComputeNormal(faceCenter).IsAlmostEqualTo(normal))
                        {
                        	// Compare candidate face vs. previously uppermost saved face
                        	TransformedPlanarFace candidate = new TransformedPlanarFace(p, Transform.Identity);
                            if (result == null || faceComparer.Invoke(result, candidate) > 0)
                            {
                                result = candidate;
                             }
                         }
                    }
                }
            }
            
            return result;
        }
        
        /// <summary>
        /// Finds the midpoint of the uppermost horizontal edge of the planar face.
        /// </summary>
        /// <remarks>The face is evaluated as transformed per the input transformed.</remarks>
        /// <param name="face">The planar face.</param>
        /// <param name="trf">The transform.</param>
        /// <returns>The midpoint of the uppermost edge.  Null if no horizontal linear edge is encountered.</returns>
		private static XYZ GetMidpointOfUpperEdge(PlanarFace face, Transform trf)
		{
			// Find horizontal edges
			XYZ topMidPoint = null;
			Edge topEdge = null;
			XYZ verticalVector = trf.OfVector(XYZ.BasisZ);
			
			// Traverse edges
			foreach (EdgeArray edgeLoop in face.EdgeLoops)
			{
				foreach (Edge edge in edgeLoop)
				{
					Curve curve = edge.AsCurve();
					
					// Utility supports only linear edges
					if (curve is Line)
					{
						Transform derivatives = curve.ComputeDerivatives(0.5, true);
						
						// If edge is hortizontal
						if (Math.Abs(Math.Cos(derivatives.BasisX.AngleTo(verticalVector))) < 0.000001)
						{
							// Transform and store point
							XYZ midPoint = trf.OfPoint(curve.Evaluate(0.5, true));
							
							// Store uppermost point encountered
							if (topMidPoint == null || midPoint.Z > topMidPoint.Z)
							{
								topMidPoint = midPoint;
								topEdge = edge;
							}
						}
					}
				}
			}
			
			return topMidPoint;
		}
	}
}
