﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.PointClouds;

namespace GeometryDevCamp2012.PointClouds
{
	/// <summary>
	/// Class to evaluate the geometric relationship of a point cloud and element face.
	/// </summary>
	public class EvaluatePointCloud
	{
		private Autodesk.Revit.Creation.Application m_appCreate;
		private PointCloudInstance m_pointCloud;
		private double epsilon = 0.5 / 12;  // 1/2"
		
		public EvaluatePointCloud(PointCloudInstance pointCloud)
		{
			m_pointCloud = pointCloud;
			m_appCreate = pointCloud.Document.Application.Create;
		}
		
		/// <summary>
		/// Evaluates the points in a point cloud which lie within a designated distance of an element face.
		/// </summary>
		/// <param name="planarFace">The face.</param>
		/// <param name="numberOfPoints">The maximum number of points to extract.</param>
		/// <param name="filterAction">The visual modification to apply to the point cloud.</param>
		/// <returns></returns>
		public int EvaluatePointsNearFace(PlanarFace planarFace, int numberOfPoints, SelectionFilterAction filterAction)
		{
			// Build a volume of planes around the input plane's bounding box.
			List<Plane> planes = new List<Plane>();
			BoundingBoxUV uvBounds = planarFace.GetBoundingBox();
			XYZ normal = planarFace.ComputeNormal((uvBounds.Min + uvBounds.Max)/2);
			XYZ origin = planarFace.Origin;
			
			// Offset of the planar faces itself
			// Normal is set to face into the intercepted volume
			planes.Add(m_appCreate.NewPlane(-normal, origin + epsilon * normal));
			planes.Add(m_appCreate.NewPlane(normal, origin - epsilon * normal));
			
			// boundary planes, use the faces extents
			XYZ lowerLeft = planarFace.Evaluate(uvBounds.Min);
			XYZ lowerRight = planarFace.Evaluate(new UV(uvBounds.Min.U, uvBounds.Max.V));
			XYZ upperLeft = planarFace.Evaluate(new UV(uvBounds.Max.U, uvBounds.Min.V));
			XYZ upperRight = planarFace.Evaluate(uvBounds.Max);
			
			XYZ lowerBoundLine = (lowerRight - lowerLeft).Normalize();
			XYZ lowerNormal = lowerBoundLine.CrossProduct(normal);
			planes.Add(m_appCreate.NewPlane(lowerNormal, lowerLeft));
			           
			XYZ rightBoundLine = (upperRight - lowerRight).Normalize();
			XYZ rightNormal = rightBoundLine.CrossProduct(normal);
			planes.Add(m_appCreate.NewPlane(rightNormal, lowerRight));
				
			XYZ upperBoundLine = (upperLeft - upperRight).Normalize();
			XYZ upperNormal = upperBoundLine.CrossProduct(normal);
			planes.Add(m_appCreate.NewPlane(upperNormal, upperRight));
			
			XYZ leftBoundLine = (lowerLeft - upperLeft).Normalize();
			XYZ leftNormal = leftBoundLine.CrossProduct(normal);
			planes.Add(m_appCreate.NewPlane(leftNormal, upperLeft));
			
			// Create a filter from the boundary planes
			PointCloudFilter filter = PointCloudFilterFactory.CreateMultiPlaneFilter(planes);
			
			// Apply visual filter to point cloud
			Transaction transaction = new Transaction(m_pointCloud.Document, "Isolate point cloud");
			transaction.Start();
			m_pointCloud.FilterAction = filterAction;
			m_pointCloud.SetSelectionFilter(filter);
			transaction.Commit();
			
			// Calculate points in point cloud
			PointCollection collection = m_pointCloud.GetPoints(filter, numberOfPoints);
			return collection.Count;
		}
	}
}
