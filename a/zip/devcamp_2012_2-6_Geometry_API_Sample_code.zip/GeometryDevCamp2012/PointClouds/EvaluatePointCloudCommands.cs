﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.DB;

namespace GeometryDevCamp2012.PointClouds
{
	/// <summary>
	/// Description of IsolatePointCloudCommand.
	/// </summary>
	internal class EvaluatePointCloudCommand
	{
		
		public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements, SelectionFilterAction filterAction)
		{
			UIDocument uiDocument = commandData.Application.ActiveUIDocument;
			Document document = uiDocument.Document;
			
			// select wall, floor, roof, face
			PlanarFace face = null;
			try
			{
				Reference reference = uiDocument.Selection.PickObject(ObjectType.Face, new SelectHostObjectFaceFilter(document), "Pick wall, floor, or roof face.");
				Element element = document.GetElement(reference);
			    face = element.GetGeometryObjectFromReference(reference) as PlanarFace;
			}
			catch (Exception)
			{
				message = "User aborted the selection";
				return Result.Cancelled;
			}
			
			if (face == null)
			{
				message = "Planar face was not selected.";
				return Result.Cancelled;
			}
			
			// find point cloud
			PointCloudInstance pointCloud  = FindPointCloud(document);
			
			// find point cloud points within tolerance of face
			EvaluatePointCloud pointCloudEvaluator = new EvaluatePointCloud(pointCloud);
			int numberOfPoints = 500000;
			int foundPoints = pointCloudEvaluator.EvaluatePointsNearFace(face, numberOfPoints, filterAction);
			
			if (foundPoints == numberOfPoints)
			{
				TaskDialog.Show("Evaluate point cloud", "Maximum number of points found near face.");
			}
			else
			{
				TaskDialog.Show("Evaluate point cloud", "" + foundPoints + " points found near face.");
			}
			return Result.Succeeded;
		}
		
		private PointCloudInstance FindPointCloud(Document document)
		{
			FilteredElementCollector collector = new FilteredElementCollector(document);
			collector.OfClass(typeof(PointCloudInstance));
			PointCloudInstance pointCloud = collector.FirstElement() as PointCloudInstance;
			return pointCloud;
		}
		
		public Result Reset(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
		{
			UIDocument uiDocument = commandData.Application.ActiveUIDocument;
			Document document = uiDocument.Document;
			
			// find point cloud
			PointCloudInstance pointCloud  = FindPointCloud(document);
			
			Transaction transaction = new Transaction(document, "Reset point cloud");
			transaction.Start();
			pointCloud.SetSelectionFilter(null);
			transaction.Commit();
			
			return Result.Succeeded;
		}
		
		private class SelectHostObjectFaceFilter : ISelectionFilter 
		{
			private Document m_doc;
			public SelectHostObjectFaceFilter(Document doc)
			{
				m_doc = doc;
			}
			
			public bool AllowElement(Element elem)
			{
				return (elem is Wall) || (elem is Floor) || (elem is RoofBase);
			}
			
			public bool AllowReference(Reference reference, XYZ position)
			{
				Element element = m_doc.GetElement(reference);
				GeometryObject geomObj = element.GetGeometryObjectFromReference(reference);
				
				return (geomObj is PlanarFace);
			}
		}
	}
	
	[Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
	public class EvaluatePointCloudIsolateCommand: IExternalCommand
	{
		public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
		{
			return new EvaluatePointCloudCommand().Execute(commandData, ref message, elements, SelectionFilterAction.Isolate);
		}
	}
	
	[Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
	public class EvaluatePointCloudHighlightCommand: IExternalCommand
	{
		public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
		{
			return new EvaluatePointCloudCommand().Execute(commandData, ref message, elements, SelectionFilterAction.Highlight);
		}
	}
	
	[Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
	public class ResetPointCloudCommand: IExternalCommand
	{
		public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
		{
			return new EvaluatePointCloudCommand().Reset(commandData, ref message, elements);
		}
	}
		
}
