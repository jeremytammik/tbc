﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
// 
using System;
using System.Text;
using System.Collections.Generic;

using Autodesk.Revit.DB;

namespace GeometryDevCamp2012.SpatialElements
{
	/// <summary>
	/// Description of SpatialElementBoundaryAreas.
	/// </summary>
	public class SpatialElementBoundaryAreas
	{
		
		public SpatialElementBoundaryAreas(SpatialElement element)
		{
			m_spatialElement = element;
		}
		
		private SpatialElement m_spatialElement;
		private IDictionary<ElementId, double> m_boundaryAreasByMaterial = new Dictionary<ElementId, double>();
		
		public void CalculateSpatialElementBoundaryAreas()
		{
			CalculateSpatialElementBoundaryAreas(m_spatialElement);
		}
		
		/// <summary>
		/// Calculates the surface area (per material) of the elements which 
		/// bound the spatial element.
		/// </summary>
		private void CalculateSpatialElementBoundaryAreas(SpatialElement element)
		{
			// Setup options - finish face option is required to match 
			// up to boundary faces
			SpatialElementBoundaryOptions options = 
				new SpatialElementBoundaryOptions();
			options.StoreFreeBoundaryFaces = true;
			options.SpatialElementBoundaryLocation = 
				SpatialElementBoundaryLocation.Finish;
			
			// Calculate results
			SpatialElementGeometryCalculator calculator = 
				new SpatialElementGeometryCalculator(element.Document, options);
			SpatialElementGeometryResults results = 
				calculator.CalculateSpatialElementGeometry(element);
			Solid solid = results.GetGeometry();
			
			
			if (solid != null)
			{
				// Traverse each face in the spatial element volume
				FaceArray faces = solid.Faces;
				foreach (Face face in faces)
				{
					IList<SpatialElementBoundarySubface> subfaces = 
						results.GetBoundaryFaceInfo(face);
					foreach (SpatialElementBoundarySubface subface in subfaces)
					{
						Face spatialElementFace = 
							subface.GetSpatialElementFace();
									
						// Bottom faces never have a boundary face reference.  
						// Find floors with another technique.
						if (subface.SubfaceType == SubfaceType.Bottom)
						{
							double spatialElementFaceArea = 
								spatialElementFace.Area;
							FindFloorBoundaries(element, options, 
							                    spatialElementFaceArea);
							continue;
						}
						
						// Get material id from bounding face.
						Face boundingElementFace = 
							subface.GetBoundingElementFace();
						ElementId materialElementId = boundingElementFace != null ? 
							boundingElementFace.MaterialElementId : ElementId.InvalidElementId;
						
						// Get area frm subface
						double subFaceArea = subface.GetSubface().Area;
						
						// Store information
						AddSurfaceArea(materialElementId, subFaceArea);
					}
				}
			}
		}
		
		/// <summary>
		/// Add a surface area value to the cache using value in square meters.
		/// </summary>
		/// <param name="materialElementId">The material element id.</param>
		/// <param name="area">The surface area value (in Revit default units: square feeet).</param>
		private void AddSurfaceArea(ElementId materialElementId, double area)
		{
			double areaInM = SquareFeetToSquareM(area);
			if (m_boundaryAreasByMaterial.ContainsKey(materialElementId))
			{
				double currentArea = m_boundaryAreasByMaterial[materialElementId];
				m_boundaryAreasByMaterial[materialElementId] = currentArea + areaInM;
			}
			else
			{
				m_boundaryAreasByMaterial.Add(materialElementId, areaInM);
			}
		}
		
		/// <summary>
		/// Find floor boundaries for a given spatial element.
		/// </summary>
		/// <param name="element">The spatial element.</param>
		/// <param name="options">The options applied to the boundary extraction.</param>
		/// <param name="area">The area of the boundary face.</param>
		private void FindFloorBoundaries(SpatialElement element, 
		                                 SpatialElementBoundaryOptions options, 
		                                 double area)
		{
			// Get 2D boundary of element
			IList<IList<BoundarySegment>> boundarySegments = 
				element.GetBoundarySegments(options);
			
			foreach (IList<BoundarySegment> segmentGroups in boundarySegments)
			{
				// Build volume extending just below boundary
				List<Curve> curves = new List<Curve>();
				foreach (BoundarySegment segment in segmentGroups)
				{
					curves.Add(segment.Curve);
				}
				CurveLoop curveLoop = CurveLoop.Create(curves);
				List<CurveLoop> curveLoops = new List<CurveLoop>();
				curveLoops.Add(curveLoop);
				
				// Volume extruded downward 1 inch
				Solid volumeOfIntersection = 
					GeometryCreationUtilities.CreateExtrusionGeometry(curveLoops, 
					                                                  -XYZ.BasisZ, 
					                                                  1/12.0);
				
				// Look for floors
				FilteredElementCollector collector = 
					new FilteredElementCollector(element.Document);
				// Filter by category because in-place families could be floors too.
				collector.OfCategory(BuiltInCategory.OST_Floors);
				collector.WhereElementIsNotElementType();
				collector.WherePasses(new ElementIntersectsSolidFilter(volumeOfIntersection));
				
				// Look at intersections
				List<ElementId> materialElementIds = new List<ElementId>();
				foreach (Element intersectElement in collector)
				{
					if (intersectElement is Floor)
					{
						Floor floor = intersectElement as Floor;
						IList<Reference> topReferences = 
							HostObjectUtils.GetTopFaces(floor);
						
						foreach (Reference reference in topReferences)
						{
							Face face = 
								floor.GetGeometryObjectFromReference(reference) as Face;
							if (face != null)
							{
								ElementId materialElementId = face.MaterialElementId;
								if (!materialElementIds.Contains(materialElementId))
									materialElementIds.Add(materialElementId);
							}
						}
					}
					else
					{
						// TODO - not a floor, in-place family perhaps.  
						// This case is not handled by this sample.
					}
				}
					
				if (materialElementIds.Count == 1)
				{
					AddSurfaceArea(materialElementIds[0], area);
				}
				else
				{
					//TODO - multiple element faces or elements found by intersection. 
					// This case is not handled by this sample.
				}

			}
		}
		
		private double SquareFeetToSquareM (double sqFt)
		{
			return sqFt * 0.09290304;
		}
		
		/// <summary>
		/// Gets the cached surface areas formatted for display.
		/// </summary>
		/// <returns>The result.</returns>
		public String GetResult()
		{
			StringBuilder builder = new StringBuilder();
			
			Document doc = m_spatialElement.Document;
			
			foreach (ElementId materialId in m_boundaryAreasByMaterial.Keys)
			{
				builder.Append("Material: ");
				if (materialId != ElementId.InvalidElementId)
				{
					Element material = doc.GetElement(materialId);
					builder.Append(material.Name);
				}
				else
				{
					builder.Append("Unassociated");
				}
				builder.Append(" | Area: ");
				builder.Append(String.Format("{0:0.00}", m_boundaryAreasByMaterial[materialId]));
				builder.Append("m²");
				builder.AppendLine();
			}
			
			return builder.ToString();
		}
	}
}

