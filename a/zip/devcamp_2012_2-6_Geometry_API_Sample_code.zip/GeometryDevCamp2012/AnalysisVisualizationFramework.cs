﻿//
// (C) Copyright 2003-2011 by Autodesk, Inc.
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted,
// provided that the above copyright notice appears in all copies and
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC.
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Analysis;

namespace GeometryDevCamp2012
{
   class AnalysisVisualizationFramework
   {
      /// <summary>
      /// The singleton instance of AnalysisVisualizationFramework
      /// </summary>
      private static AnalysisVisualizationFramework Instance;

      /// <summary>
      /// revit document
      /// </summary>
      private Autodesk.Revit.DB.Document m_doc;

      /// <summary>
      /// The created view list
      /// </summary>
      private List<String> viewNameList = new List<string>();

      /// <summary>
      /// The ID of schema which SpatialFieldManager register
      /// </summary>
      private static int SchemaId = -1;
      
      /// <summary>
      /// The map of predefined colors to values.
      /// </summary>
      private Dictionary<System.Drawing.Color, double> m_colorMap;

      /// <summary>
      /// Constructor
      /// </summary>
      /// <param name="doc">Revit document</param>
      private AnalysisVisualizationFramework(Autodesk.Revit.DB.Document doc)
      {
         m_doc = doc;
         m_legendSettings = new AnalysisDisplayLegendSettings();
         m_colorMap = new Dictionary<System.Drawing.Color, double>();
         SetSingleColor(System.Drawing.Color.Blue);
         ShowLegend = false;
      }
      
      /// <summary>
      /// Setup the display to use a single color.
      /// </summary>
      /// <param name="color"></param>
      public void SetSingleColor(System.Drawing.Color color)
      {
      	m_colorMap.Clear();
      	m_colorMap.Add(color, 0.0);
      }
      
      /// <summary>
      /// Setup the display to use multiple distinct colors.
      /// </summary>
      /// <param name="colors"></param>
      public void SetMultipleColors(IEnumerable<System.Drawing.Color> colors)
      {
      	m_colorSettings = new AnalysisDisplayColorSettings();
      	m_colorMap.Clear();
 
        int index = 0;    
        int colorCount = colors.Count<System.Drawing.Color>();
        List<AnalysisDisplayColorEntry> colorEntries = new List<AnalysisDisplayColorEntry>();
        foreach (System.Drawing.Color color in colors)
        {
    		Autodesk.Revit.DB.Color revitColor = new Autodesk.Revit.DB.Color(color.R, color.G, color.B);
    		m_colorMap.Add(color, (double)index);
        	if (index == 0)
        	{
            	m_colorSettings.MinColor = revitColor;
        	}
        	if (index == colorCount - 1)
        	{
        		m_colorSettings.MaxColor = revitColor;
        	}
 
        	AnalysisDisplayColorEntry entry = new AnalysisDisplayColorEntry(revitColor, (double)index);
            colorEntries.Add(entry);

        	index ++;	
        }
        if (colorEntries.Count > 0)
        	m_colorSettings.SetIntermediateColors(colorEntries);
      }

      /// <summary>
      /// Get the singleton instance of AnalysisVisualizationFramework
      /// </summary>
      /// <param name="doc">Revit document</param>
      /// <returns>The singleton instance of AnalysisVisualizationFramework</returns>
      public static AnalysisVisualizationFramework getInstance(Autodesk.Revit.DB.Document doc)
      {
         if (Instance == null || Instance.m_doc.Title != doc.Title)
         {
            Instance = new AnalysisVisualizationFramework(doc);
         }
         return Instance;
      }
      
      private AnalysisDisplayLegendSettings m_legendSettings;
      private AnalysisDisplayColorSettings m_colorSettings;
      
      /// <summary>
      /// Whether or not to show the legend.
      /// </summary>
      public bool ShowLegend
      {
      	get
      	{
      		return m_legendSettings.ShowLegend;
      	}
      	
      	set
      	{
      		m_legendSettings.ShowLegend = value;
      	}
      }
      
      public View View
      {
        get;
        set;
      }
      
      public bool SchemaInitialized
      {
      	get
      	{ 
      		if (SchemaId != -1)
	        {
		        SpatialFieldManager sfm = SpatialFieldManager.GetSpatialFieldManager(View);
	      	    if (sfm == null)
	      	    	return false;
	            IList<int> results = sfm.GetRegisteredResults();
	
	            if (!results.Contains(SchemaId))
	            {
	               SchemaId = -1;
	            }
	        }
      		return SchemaId != -1;
      	}
      }
      
      public void SetupDisplaySettings()
      {
        SpatialFieldManager sfm = SpatialFieldManager.GetSpatialFieldManager(View);
        if (sfm == null) sfm = SpatialFieldManager.CreateSpatialFieldManager(View, 1);
        
      	if (SchemaId != -1)
         {
            IList<int> results = sfm.GetRegisteredResults();

            if (!results.Contains(SchemaId))
            {
               SchemaId = -1;
            }
         }
      	if (!SchemaInitialized)
         {
            AnalysisResultSchema resultSchema1 = new AnalysisResultSchema("PaintedSolid" + View.Name, "Description");
           		
            AnalysisDisplayStyle displayStyle = AnalysisDisplayStyle.CreateAnalysisDisplayStyle(
               m_doc, 
               "Real_Color_Surface" + View.Name, 
               new AnalysisDisplayColoredSurfaceSettings(), 
               m_colorSettings,
               m_legendSettings);

            resultSchema1.AnalysisDisplayStyleId = displayStyle.Id;

            SchemaId = sfm.RegisterResult(resultSchema1);
         }
      }
      

      /// <summary>
      /// Paint a solid in a new named view
      /// </summary>
      /// <param name="s">solid</param>
      /// <param name="viewName">Given the name of view</param>
      public void PaintSolid(Solid s, System.Drawing.Color color)
      {
      	if (!m_colorMap.ContainsKey(color))
      		throw new Exception("Color is not recognized by this AVF color settings");
      	if (!SchemaInitialized)
      		throw new Exception("Analysis results schema is not initialized!");
      	      	
         SpatialFieldManager sfm = SpatialFieldManager.GetSpatialFieldManager(View);
         if (sfm == null) sfm = SpatialFieldManager.CreateSpatialFieldManager(View, 1);

         FaceArray faces = s.Faces;
         Transform trf = Transform.Identity;

         foreach (Face face in faces)
         {
            int idx = sfm.AddSpatialFieldPrimitive(face, trf);

            IList<UV> uvPts = null;
            IList<ValueAtPoint> valList = null;
            ComputeSinglePointFaceResults(face, m_colorMap[color], out uvPts, out valList);

            FieldDomainPointsByUV pnts = new FieldDomainPointsByUV(uvPts);
            FieldValues vals = new FieldValues(valList);

            sfm.UpdateSpatialFieldPrimitive(idx, pnts, vals, SchemaId);
         }
      }
      
      /// <summary>
      /// Paint a solid in a new named view
      /// </summary>
      /// <param name="s">solid</param>
      /// <param name="viewName">Given the name of view</param>
      public void PaintFaces(IList<Face> faces, String viewName)
      {
         View view;
 
         view = (((new FilteredElementCollector(m_doc).
               OfClass(typeof(View))).Cast<View>()).
               Where(e => e.Name == viewName)).First<View>();
         
         
         if (viewName == "{3D}")
         	viewName = "DEFAULT3D";

         SpatialFieldManager sfm = SpatialFieldManager.GetSpatialFieldManager(view);
         if (sfm == null) sfm = SpatialFieldManager.CreateSpatialFieldManager(view, 1);

         if (SchemaId != -1)
         {
            IList<int> results = sfm.GetRegisteredResults();

            if (!results.Contains(SchemaId))
            {
               SchemaId = -1;
            }
         }

         if (SchemaId == -1)
         {
            AnalysisResultSchema resultSchema1 = new AnalysisResultSchema("PaintedFaces" + viewName, "Description");

            AnalysisDisplayStyle displayStyle = AnalysisDisplayStyle.CreateAnalysisDisplayStyle(
               m_doc, 
               "Real_Color_Surface" + viewName, 
               new AnalysisDisplayColoredSurfaceSettings(), 
               new AnalysisDisplayColorSettings(), 
               m_legendSettings);

            resultSchema1.AnalysisDisplayStyleId = displayStyle.Id;

            SchemaId = sfm.RegisterResult(resultSchema1);
         }

         

         foreach (Face face in faces)
         {
         	BoundingBoxUV uvBBox = face.GetBoundingBox();
         	UV centerOfFace = (uvBBox.Max + uvBBox.Min) / 2;
         	Transform trf = Transform.get_Translation(face.ComputeNormal(centerOfFace).Multiply(0.01));
            int idx = sfm.AddSpatialFieldPrimitive(face, trf);

            IList<UV> uvPts = null;
            IList<ValueAtPoint> valList = null;
            ComputeValueAtPointForFace(face, out uvPts, out valList, 1);

            FieldDomainPointsByUV pnts = new FieldDomainPointsByUV(uvPts);

            FieldValues vals = new FieldValues(valList);

            sfm.UpdateSpatialFieldPrimitive(idx, pnts, vals, SchemaId);
         }
      }

      /// <summary>
      /// Compute the value of face on specific point
      /// </summary>
      /// <param name="face"></param>
      /// <param name="uvPts"></param>
      /// <param name="valList"></param>
      /// <param name="measurementNo"></param>
      private static void ComputeValueAtPointForFace(Face face, out IList<UV> uvPts, out IList<ValueAtPoint> valList, int measurementNo)
      {
         List<double> doubleList = new List<double>();
         uvPts = new List<UV>();
         valList = new List<ValueAtPoint>();
         BoundingBoxUV bb = face.GetBoundingBox();
         for (double u = bb.Min.U; u < bb.Max.U + 0.0000001; u = u + (bb.Max.U - bb.Min.U) / 1)
         {
            for (double v = bb.Min.V; v < bb.Max.V + 0.0000001; v = v + (bb.Max.V - bb.Min.V) / 1)
            {
               UV uvPnt = new UV(u, v);
               uvPts.Add(uvPnt);
               XYZ faceXYZ = face.Evaluate(uvPnt);
               // Specify three values for each point
               for (int ii = 1; ii <= measurementNo; ii++)
                  doubleList.Add(faceXYZ.DistanceTo(XYZ.Zero) * ii);
               valList.Add(new ValueAtPoint(doubleList));
               doubleList.Clear();
            }
         }
      }
      
      
      private static void ComputeSinglePointFaceResults(Face face, double value, out IList<UV> uvPts, out IList<ValueAtPoint> valList)
      {
         List<double> doubleList = new List<double>();
         uvPts = new List<UV>();
         valList = new List<ValueAtPoint>();
         BoundingBoxUV bb = face.GetBoundingBox();
         UV uvPnt = bb.Min + bb.Max / 2;
         uvPts.Add(uvPnt);
         doubleList.Add(value);
         valList.Add(new ValueAtPoint(doubleList));
      }
   }
}
