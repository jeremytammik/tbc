﻿using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Windows.Forms;

//using Print_and_Export_Manager;

namespace RoomViews
{
    [Transaction(TransactionMode.Manual)]
    public class Command : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            Autodesk.Revit.DB.Transaction newTran = null;
            try
            {
                //newTran = new Autodesk.Revit.DB.Transaction(commandData.Application.ActiveUIDocument.Document, "ViewPrinter");
                //newTran.Start();

                //PrintMgr pMgr = new PrintMgr(commandData);

                //if (null == pMgr.InstalledPrinterNames)
                //{
                //    PrintMgr.MyMessageBox("No installed printer, the external command can't work.");
                //    return Autodesk.Revit.UI.Result.Cancelled;
                //}

                //using (Form1 pmDlg = new Form1(pMgr))
                using (Form1 pmDlg = new Form1(commandData))
                {
                    //if (pmDlg.ShowDialog() != DialogResult.Cancel)
                    //{
                    pmDlg.ShowDialog();
                        //newTran.Commit();
                        return Autodesk.Revit.UI.Result.Succeeded;
                    //}
                    //newTran.RollBack();
                }

            }
            catch (Exception ex)
            {
                if (null != newTran)
                    newTran.RollBack();
                message = ex.ToString();
                return Autodesk.Revit.UI.Result.Failed;
            }

            return Autodesk.Revit.UI.Result.Cancelled;
        }
    }
}