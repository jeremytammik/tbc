﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace RoomViews
{
	public partial class Form1 : System.Windows.Forms.Form
	{
		public UIApplication uiApp { get; set; }
		public Autodesk.Revit.ApplicationServices.Application app;
		private Autodesk.Revit.DB.Document RevitDoc;
		public Form1(ExternalCommandData commandData)
		{
			uiApp = commandData.Application;
			UIDocument uiDoc = uiApp.ActiveUIDocument;
			app = uiApp.Application;
			RevitDoc = uiDoc.Document;
			InitializeComponent();
            FilteredElementCollector allrooms = new FilteredElementCollector(RevitDoc).OfCategory(BuiltInCategory.OST_Rooms);
			foreach (Autodesk.Revit.DB.Architecture.Room room in allrooms)
            { 
                comboBox1.Items.Add(room.Number);
            }
		}

		private void button1_Click(object sender, EventArgs e)
		{
            string roomNumber;
            if (comboBox1.SelectedItem == "")
            {
                roomNumber="7";
            }
            else
            {
                roomNumber = comboBox1.SelectedItem.ToString();
            }
			FilteredElementCollector view3D = new FilteredElementCollector(RevitDoc);
			view3D.OfClass(typeof(Autodesk.Revit.DB.View3D));
			FilteredElementCollector allrooms = new FilteredElementCollector(RevitDoc).OfCategory(BuiltInCategory.OST_Rooms);
			foreach (Autodesk.Revit.DB.Architecture.Room room in allrooms)
			{
				ViewFamilyType viewFamilyTypePlan = new FilteredElementCollector(RevitDoc).OfClass(typeof (ViewFamilyType)).Cast<ViewFamilyType>().FirstOrDefault<ViewFamilyType>((Func<ViewFamilyType, bool>) (x => ViewFamily.FloorPlan == x.ViewFamily));
				if (room.Number == roomNumber)
				{ 
					using (Transaction t = new Transaction(RevitDoc, "Duplicate View:"))
					{
						t.Start();
						RevitDoc.ActiveView.CropBoxVisible = true;
						RevitDoc.ActiveView.CropBoxActive = true;
						CropAroundRoom(room, RevitDoc.ActiveView);
						t.Commit();
					}
				}
			}
			
		}

        public void CropAroundRoom(Autodesk.Revit.DB.Architecture.Room room, Autodesk.Revit.DB.View view) //This provides the required shape now how to combine with the offset and tie into wall thickness
        {
            if (view != null)
            {
                IList<IList<Autodesk.Revit.DB.BoundarySegment>>  segments = room.GetBoundarySegments(new SpatialElementBoundaryOptions());

                if (null != segments)  //the room may not be bound
                {
                    foreach (IList<Autodesk.Revit.DB.BoundarySegment> segmentList in segments)
                    {
                        CurveLoop loop = new CurveLoop();
                        foreach (Autodesk.Revit.DB.BoundarySegment boundarySegment in segmentList)
                        {
                            List<XYZ> points = boundarySegment.GetCurve().Tessellate().ToList();
                            for(int ip=0; ip< points.Count-1; ip++)
                            {
                                Line l = Line.CreateBound(points[ip],points[ip+1]);
                                    loop.Append(l);
                            }
                        }
                        ViewCropRegionShapeManager vcrShapeMgr = view.GetCropRegionShapeManager();
                        bool cropValid = vcrShapeMgr.IsCropRegionShapeValid(loop);
                        if (cropValid)
                        {
                            vcrShapeMgr.SetCropShape(loop);
                            break;  // if more than one set of boundary segments for room, crop around the first one
                        }
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string roomNumber;
            if (comboBox1.SelectedItem == "")
            {
                roomNumber="7";
            }
            else
            {
                roomNumber = comboBox1.SelectedItem.ToString();
            }
			FilteredElementCollector view3D = new FilteredElementCollector(RevitDoc);
			view3D.OfClass(typeof(Autodesk.Revit.DB.View3D));
			FilteredElementCollector allrooms = new FilteredElementCollector(RevitDoc).OfCategory(BuiltInCategory.OST_Rooms);
			foreach (Autodesk.Revit.DB.Architecture.Room room in allrooms)
			{
				ViewFamilyType viewFamilyTypePlan = new FilteredElementCollector(RevitDoc).OfClass(typeof (ViewFamilyType)).Cast<ViewFamilyType>().FirstOrDefault<ViewFamilyType>((Func<ViewFamilyType, bool>) (x => ViewFamily.FloorPlan == x.ViewFamily));
				if (room.Number == roomNumber)
				{ 
					using (Transaction t = new Transaction(RevitDoc, "Duplicate View with Offset:"))
					{
						t.Start();
						RevitDoc.ActiveView.CropBoxVisible = true;
						RevitDoc.ActiveView.CropBoxActive = true;
						CropAroundRoomWithOffset(room, RevitDoc.ActiveView);
						t.Commit();
					}
				}
			}
        }

        public void CropAroundRoomWithOffset(Autodesk.Revit.DB.Architecture.Room room, Autodesk.Revit.DB.View view)
		{
            List<XYZ> points = new List<XYZ>();
		    if (view != null)
		    {
		        IList<IList<Autodesk.Revit.DB.BoundarySegment>>  segments = room.GetBoundarySegments(new SpatialElementBoundaryOptions());

		        if (null != segments)
		        {
		            foreach (IList<Autodesk.Revit.DB.BoundarySegment> segmentList in segments)
		            {
		                CurveLoop loop = new CurveLoop();
		                foreach (Autodesk.Revit.DB.BoundarySegment boundarySegment in segmentList)
		                {
                            points.AddRange(boundarySegment.GetCurve().Tessellate());
		                }
                        CurveLoop loop2 = new CurveLoop();
                        double offset = 2.0;
                        XYZ normal = new XYZ(0,0,-1);
                        List<XYZ> pts = OffsetPoints(points,offset,normal).ToList();
                        for(int ip=0; ip< points.Count-1; ip++)
                        {
                            Line l = Line.CreateBound(pts[ip],pts[ip+1]);

                                loop2.Append(l);
                        }
		                ViewCropRegionShapeManager vcrShapeMgr = view.GetCropRegionShapeManager();
		                bool cropValid = vcrShapeMgr.IsCropRegionShapeValid(loop);
		                if (cropValid)
		                {
		                    vcrShapeMgr.SetCropShape(loop);
		                    break;
		                }
		            }
		        }
		    }
		}
		public static CurveLoop CreateCurveLoop(List<XYZ> pts )
		{
			int n = pts.Count;
			CurveLoop curveLoop = new CurveLoop();
			for( int i = 1; i < n; ++i )
			{
				curveLoop.Append( Line.CreateBound(pts[i - 1], pts[i] ) );
			}
			curveLoop.Append( Line.CreateBound(pts[n], pts[0] ) );
			return curveLoop;
		}

		public static IEnumerable<XYZ> OffsetPoints( List<XYZ> pts,double offset,XYZ normal )
		{
			CurveLoop curveLoop = CreateCurveLoop( pts );
			CurveLoop curveLoop2 = CurveLoop.CreateViaOffset( curveLoop, offset, normal );
			return curveLoop2.Select<Curve, XYZ>(  c => c.GetEndPoint( 0 ) );
		}

		private void CloseBtn_Click(object sender, EventArgs e)
		{
			Close();
		}
    }
}
