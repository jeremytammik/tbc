﻿using Autodesk.Revit.UI;
using System;
using System.IO;
using System.Reflection;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace RoomViews
{
    public class Application : IExternalApplication
    {
        public static UIControlledApplication app;

        public Result OnStartup(UIControlledApplication app)
        {
            string helpPath = "";
            string panelName = "Test Code";
            string buttonName = "Test";
            FileInfo fileInfo = new FileInfo(Assembly.GetExecutingAssembly().Location);
            string thisAssemblyPath = Assembly.GetExecutingAssembly().Location;
            string resourcesPath = Path.Combine(fileInfo.Directory.Parent.FullName + "\\Resources\\");
            try
            {
                if ("2018" == app.ControlledApplication.VersionNumber)
                {
                    //Add a new ribbon panel
                    RibbonPanel m_projectPanel = app.CreateRibbonPanel(panelName);
                    //Create a push button to trigger a command and add it to the ribbon panel
                    PushButtonData buttonData = new PushButtonData("cmdTest", buttonName, thisAssemblyPath, "RoomViews.Command");
                    PushButton pushButton = m_projectPanel.AddItem(buttonData) as PushButton;

                    //Add tool tip and button images
                    pushButton.ToolTip = "Test";
                    pushButton.LongDescription = "Test";
                    pushButton.LargeImage = (ImageSource)new BitmapImage(new Uri(resourcesPath + "TestCode.png"));
                    //pushButton.Image= (ImageSource)new BitmapImage(new Uri(resourcesPath + "Cleaner16x16.png"));
                    helpPath = (resourcesPath + "Help.htm");
                    if (File.Exists(helpPath))
                    {
                        ContextualHelp contextualHelp = new ContextualHelp(ContextualHelpType.Url, helpPath);
                        pushButton.SetContextualHelp(contextualHelp);
                    }
                }
                else
                {
                    TaskDialog tD = new TaskDialog("Unsupported Version.");
                    tD.MainInstruction = (string.Format("The installer has encountered an unexpected\n error installing Print & Export Manager {0}.", app.ControlledApplication.VersionNumber));
                    tD.MainIcon = TaskDialogIcon.TaskDialogIconWarning;
                    tD.CommonButtons = TaskDialogCommonButtons.Ok;
                    TaskDialogResult result = tD.Show();
                    return Autodesk.Revit.UI.Result.Failed;
                }
                // app.DialogBoxShowing += new EventHandler<DialogBoxShowingEventArgs>(HandleDialogBoxShowing); Didnt capture Dialog
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                // If there are something wrong, give error information and return failed
                TaskDialog tD = new TaskDialog("Error.");
                tD.MainInstruction = "The installer has encountered an unexpected\n error installing Print & Export Manager.";
                tD.MainIcon = TaskDialogIcon.TaskDialogIconWarning;
                tD.CommonButtons = TaskDialogCommonButtons.Ok;
                TaskDialogResult result = tD.Show();
                return Autodesk.Revit.UI.Result.Failed;
            }
        }

        public Result OnShutdown(UIControlledApplication app)
        {
            return Result.Succeeded;
        }
    }
}