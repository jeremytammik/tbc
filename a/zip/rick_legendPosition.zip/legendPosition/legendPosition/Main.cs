﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.Attributes;

namespace legendPosition
{
  [Autodesk.Revit.Attributes.Transaction(TransactionMode.Manual)]
    public class Main : IExternalCommand
    {
      Document m_Document;

      public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
      {
        m_Document = commandData.Application.ActiveUIDocument.Document;

        UIDocument uidoc = null;
        Selection choices = null;
        Reference hasPickOne = null;
        Transaction transaction = null;
        View curSelView = null;
        Element pickedElem = null;
        Element positionElem = null;
        Element newElem = null;
        IList<Element> families;
        Parameter viewPara = null;
        Parameter heightPara = null;
        Parameter widthPara = null;
        Parameter sillHeightPara = null;
        GeometryElement geoElem = null;
        IEnumerator<GeometryObject> geoNumerator;
        GeometryInstance geoInst = null;
        FamilyInstance familyElem = null;
        Element symbolElem = null;
        XYZ basePoint = null;
        XYZ newBasePoint = null;
        XYZ boundPt1 = null;
        XYZ boundPt2 = null;
        XYZ boundWallLenPt = null;
        XYZ dupObjPoint = null;
        List<IGrouping<GroupField, FamilyInstance>> m_doorFamilies;
        List<IGrouping<GroupField, FamilyInstance>> m_windowFamilies;
        IEnumerable<IGrouping<GroupField, FamilyInstance>> unionFamilies = null;
        Autodesk.Revit.DB.View[] manipulateViews = null;
        TextNote textNote = null;
        IEnumerable<ElementId> newSets;
        Line boundLine = null;
        string noteString;
        int pageCnt;
        int viewIndex;
        int colCnt;
        int rowCnt;
        int viewPages;
        float sillHeight;
        float height;
        float width;
        float rowOffset;
        float colOffset;
        float cellHeight;
        float cellWidth;

        try
        {
          colCnt = 3; //Make 3x2 Component Each Page
          rowCnt = 2;
          cellWidth = 15; //Make Cell Width bound
          cellHeight = 18; //Make Cell Height bound

          transaction = new Transaction(m_Document);//Create Transaction

          uidoc = new UIDocument(m_Document);
          choices = uidoc.Selection;

          //Pick Object with LegendComponent
          hasPickOne = choices.PickObject(ObjectType.Element, new LegendFilter(), "Pick LegendComponent");

          if (hasPickOne != null)
          {
            pageCnt = colCnt * rowCnt;
            curSelView = m_Document.ActiveView;
            pickedElem = uidoc.Document.GetElement(hasPickOne);

            //View type to Floor Plant
            if (transaction.Start("setView") == TransactionStatus.Started)
            {
              viewPara = pickedElem.get_Parameter(BuiltInParameter.LEGEND_COMPONENT_VIEW);
              viewPara.Set(-8);
              transaction.Commit();
            }

            //Get Geometry Origin for all duplicated Base Component
            geoElem = pickedElem.get_Geometry(new Options());
            geoNumerator = geoElem.GetEnumerator();
            geoNumerator.Reset();

            while (geoNumerator.MoveNext())
            {
              geoInst = geoNumerator.Current as GeometryInstance;
              if (geoInst != null)
                basePoint = geoInst.Transform.Origin;
            }

            if (basePoint == null)
              throw new Exception("Geometry Origin does't Exist");
            //----------------------------------------------------------------------------------------

            //Get families we want to list, for this sample to write  Windows and Doors
            families = new FilteredElementCollector(m_Document).OfClass(typeof(FamilyInstance)).ToElements();

            m_doorFamilies = families.Cast<FamilyInstance>().Where(c => c.Category.Id.IntegerValue == (int)BuiltInCategory.OST_Doors).GroupBy(c => new GroupField(c.Name, (float)c.get_Parameter(BuiltInParameter.INSTANCE_SILL_HEIGHT_PARAM).AsDouble()), new GroupFieldComparer()).ToList();
            m_windowFamilies = families.Cast<FamilyInstance>().Where(c => c.Category.Id.IntegerValue == (int)BuiltInCategory.OST_Windows).GroupBy(c => new GroupField(c.Name, (float)c.get_Parameter(BuiltInParameter.INSTANCE_SILL_HEIGHT_PARAM).AsDouble()), new GroupFieldComparer()).ToList();
            unionFamilies = m_doorFamilies.Union(m_windowFamilies);

            //LegendView create
            if (transaction.Start("createRequiredView") == TransactionStatus.Started)
            {
              viewPages = (unionFamilies.Count() / pageCnt) + (((unionFamilies.Count() % pageCnt) > 0) ? 1 : 0);
              manipulateViews = new Autodesk.Revit.DB.View[viewPages];

              for (int i = 0; i < viewPages; i++)
              {
                manipulateViews[i] = m_Document.GetElement(curSelView.Duplicate(ViewDuplicateOption.WithDetailing)) as Autodesk.Revit.DB.View;
                manipulateViews[i].ViewName = String.Format("LegendSchedule:Page[{0}]", i + 1);
              }
              transaction.Commit();
            }
            //----------------------------------------------------------------------------------------

            //Start To Write Component
            viewIndex = 0;
            for (int i = 0; i < unionFamilies.Count(); i++)
            {
              if (transaction.Start("duplicateComponet") == TransactionStatus.Started)
              {
                //Switch to next Page and get the element to located when page filled
                if ((i % pageCnt) == 0)
                {
                  if (positionElem != null)
                    m_Document.Delete(positionElem);

                  positionElem = GetPositionElem(manipulateViews[viewIndex]); //Get the element for Located
                  curSelView = manipulateViews[viewIndex++]; //Set Current View
                }

                //Get the family and symbol
                familyElem = unionFamilies.ElementAt(i).First();
                symbolElem = familyElem.Symbol;

                if (symbolElem.Category.Id.IntegerValue == (int)BuiltInCategory.OST_Windows)
                {
                  heightPara = symbolElem.get_Parameter(BuiltInParameter.WINDOW_HEIGHT);
                  widthPara = symbolElem.get_Parameter(BuiltInParameter.WINDOW_WIDTH);
                }
                else if (symbolElem.Category.Id.IntegerValue == (int)BuiltInCategory.OST_Doors)
                {
                  heightPara = symbolElem.get_Parameter(BuiltInParameter.DOOR_HEIGHT);
                  widthPara = symbolElem.get_Parameter(BuiltInParameter.DOOR_WIDTH);
                }

                sillHeightPara = familyElem.get_Parameter(BuiltInParameter.INSTANCE_SILL_HEIGHT_PARAM);

                sillHeight = (float)sillHeightPara.AsDouble();
                height = (float)heightPara.AsDouble();
                width = (float)widthPara.AsDouble();

                //set right position to place duplicated component
                colOffset = (i % colCnt) * cellWidth; //Component on col offset
                rowOffset = (i / colCnt) * cellHeight; //Component on row offset

                //Set new Location for Annotation , now for duplicated Component
                newBasePoint = new XYZ(basePoint.X + colOffset, basePoint.Y - rowOffset, basePoint.Z);

                //Copy Legend Component
                dupObjPoint = new XYZ(colOffset, -rowOffset, basePoint.Z);
                dupObjPoint = dupObjPoint.Add(new XYZ(0, sillHeight, 0)); //offset Sill Height

                newSets = ElementTransformUtils.CopyElement(m_Document, positionElem.Id, dupObjPoint);
                newElem = m_Document.GetElement(newSets.First());
                viewPara = newElem.get_Parameter(BuiltInParameter.LEGEND_COMPONENT_VIEW);

                //Set Symbol Type
                viewPara.Set(-7); //Set to Front view
                viewPara = newElem.get_Parameter(BuiltInParameter.LEGEND_COMPONENT);
                viewPara.Set(symbolElem.Id);

                // create the new dimension - width
                boundPt1 = new XYZ(newBasePoint.X - width / 2, (newBasePoint.Y + sillHeight) + height / 2 + 0.5, 0);
                boundPt2 = new XYZ(newBasePoint.X + width / 2, (newBasePoint.Y + sillHeight) + height / 2 + 0.5, 0);
                CreateDimension(curSelView, boundPt1, boundPt2);

                // create the new dimension - height
                boundPt1 = new XYZ(newBasePoint.X - width / 2 - 0.5, (newBasePoint.Y + sillHeight) + height / 2, 0);
                boundPt2 = new XYZ(newBasePoint.X - width / 2 - 0.5, (newBasePoint.Y + sillHeight) - height / 2, 0);
                CreateDimension(curSelView, boundPt1, boundPt2);

                //for sillHeight dimension
                if (sillHeight > 0)
                {
                  boundPt1 = new XYZ(newBasePoint.X - width / 2 - 0.5, newBasePoint.Y - height / 2 + sillHeight, 0);
                  boundPt2 = new XYZ(newBasePoint.X - width / 2 - 0.5, newBasePoint.Y - height / 2, 0);
                  CreateDimension(curSelView, boundPt1, boundPt2);
                }

                //------------------------------------------------------------------------------------------------------
                //Set F.L Line
                boundPt1 = m_Document.Application.Create.NewXYZ(newBasePoint.X - 3, newBasePoint.Y - height / 2, newBasePoint.Z);
                boundPt2 = m_Document.Application.Create.NewXYZ(newBasePoint.X + 3, newBasePoint.Y - height / 2, newBasePoint.Z);
                boundLine = m_Document.Application.Create.NewLineBound(boundPt1, boundPt2);
                m_Document.Create.NewDetailCurve(curSelView, boundLine);

                boundWallLenPt = m_Document.Application.Create.NewXYZ(newBasePoint.X - 5, newBasePoint.Y - height / 2 + 0.5, newBasePoint.Z);
                noteString = "F.L";
                textNote = m_Document.Create.NewTextNote(curSelView, boundWallLenPt, XYZ.Zero, XYZ.Zero, 0.02f, TextAlignFlags.TEF_ALIGN_LEFT, noteString);
                //------------------------------------------------------------------------------------------------------

                transaction.Commit();
              }
            }

            if (transaction.Start("DeletePositionElem") == TransactionStatus.Started)
            {
              m_Document.Delete(positionElem);
              transaction.Commit();
            }
          }
        }
        catch (Exception ex)
        {
          if (transaction.HasStarted())
            transaction.RollBack();

          System.Diagnostics.Debug.WriteLine(ex.Message);

          message = ex.Message;
          return Result.Failed;
        }

        return Result.Succeeded;
      }

      class Common
      {
        static public Boolean nearlyEqual(float a, float b, float epsilon = 0.0001f)
        {
          float diff = Math.Abs(a - b);

          if (float.IsNaN(diff))
            return true;
          else
            return diff < epsilon;
        }
      }

      class GroupFieldComparer : IEqualityComparer<GroupField>
      {
        public bool Equals(GroupField x, GroupField y)
        {
          if (Object.ReferenceEquals(x, y))
            return true;

          if (Object.ReferenceEquals(x, null) || Object.ReferenceEquals(y, null))
            return false;

          if (String.Compare(x.Name, y.Name) == 0)
            return Common.nearlyEqual(x.SillHeight, y.SillHeight);

          return false;
        }

        public int GetHashCode(GroupField obj)
        {
          //Check whether the object is null
          if (Object.ReferenceEquals(obj, null)) return 0;

          //Get hash code for the Name field if it is not null.
          return obj.ToString().ToLower().GetHashCode();
        }
      }

      class LegendFilter : ISelectionFilter
      {
        public bool AllowElement(Element elem)
        {
          if (elem.Category == null)
            return false;

          if (elem.Category.Id.IntegerValue == (int)BuiltInCategory.OST_LegendComponents)
            return true;

          return false;
        }

        public bool AllowReference(Reference reference, XYZ position)
        {
          return false;
        }
      }

      class GroupField
      {
        String m_Name;
        float m_SillHeight;

        public String Name
        {
          get { return m_Name; }
        }

        public float SillHeight
        {
          get { return m_SillHeight; }
        }

        public GroupField(String name, float sillheight)
        {
          m_Name = name;
          m_SillHeight = sillheight;
        }
      }

      private void CreateDimension(View curSelView, XYZ boundPt1, XYZ boundPt2)
      {
        Line boundLine = m_Document.Application.Create.NewLineBound(boundPt1, boundPt2);
        DetailCurve newCurve = m_Document.Create.NewDetailCurve(curSelView, boundLine);
        ReferenceArray curveRefs = new ReferenceArray();

        curveRefs.Append(newCurve.GeometryCurve.get_EndPointReference(0));
        curveRefs.Append(newCurve.GeometryCurve.get_EndPointReference(1));
        m_Document.Create.NewDimension(curSelView, boundLine, curveRefs);
      }

      Element GetPositionElem(Autodesk.Revit.DB.View view)
      {
        FilteredElementCollector viewCollector = new FilteredElementCollector(m_Document, view.Id);
        return viewCollector.OfCategory(BuiltInCategory.OST_LegendComponents).ToElements().First();

        //need some exception handler here
      }
    }

}
