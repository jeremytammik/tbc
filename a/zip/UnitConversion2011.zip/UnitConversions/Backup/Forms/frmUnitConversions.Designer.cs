﻿namespace Revit.SDK.Samples.UnitConversion.CS
{
    partial class frmUnitConversions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblConvertToUnits = new System.Windows.Forms.Label();
            this.lblNewLengthValue = new System.Windows.Forms.Label();
            this.txtNewValue = new System.Windows.Forms.TextBox();
            this.lblNewValueUnits = new System.Windows.Forms.Label();
            this.cboNewValueUnits = new System.Windows.Forms.ComboBox();
            this.btnSetNewValue = new System.Windows.Forms.Button();
            this.cboConvertToUnits = new System.Windows.Forms.ComboBox();
            this.lblConvertedValue = new System.Windows.Forms.Label();
            this.lblInternalValue = new System.Windows.Forms.Label();
            this.lblOverrideNote = new System.Windows.Forms.Label();
            this.lblRoundingPrecision = new System.Windows.Forms.Label();
            this.txtRoundingPrecision = new System.Windows.Forms.TextBox();
            this.txtConversionRoundingPrecision = new System.Windows.Forms.TextBox();
            this.lblConversionRoundingPrecision = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtScaleFactor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboUnitType = new System.Windows.Forms.ComboBox();
            this.lblUnitType = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblConvertToUnits
            // 
            this.lblConvertToUnits.AutoSize = true;
            this.lblConvertToUnits.Location = new System.Drawing.Point(9, 210);
            this.lblConvertToUnits.Name = "lblConvertToUnits";
            this.lblConvertToUnits.Size = new System.Drawing.Size(121, 13);
            this.lblConvertToUnits.TabIndex = 13;
            this.lblConvertToUnits.Text = "Get value in these units:";
            // 
            // lblNewLengthValue
            // 
            this.lblNewLengthValue.AutoSize = true;
            this.lblNewLengthValue.Location = new System.Drawing.Point(9, 103);
            this.lblNewLengthValue.Name = "lblNewLengthValue";
            this.lblNewLengthValue.Size = new System.Drawing.Size(61, 13);
            this.lblNewLengthValue.TabIndex = 7;
            this.lblNewLengthValue.Text = "New value:";
            // 
            // txtNewValue
            // 
            this.txtNewValue.Location = new System.Drawing.Point(151, 101);
            this.txtNewValue.Name = "txtNewValue";
            this.txtNewValue.Size = new System.Drawing.Size(104, 20);
            this.txtNewValue.TabIndex = 8;
            this.txtNewValue.Text = "1.0";
            // 
            // lblNewValueUnits
            // 
            this.lblNewValueUnits.AutoSize = true;
            this.lblNewValueUnits.Location = new System.Drawing.Point(9, 39);
            this.lblNewValueUnits.Name = "lblNewValueUnits";
            this.lblNewValueUnits.Size = new System.Drawing.Size(101, 13);
            this.lblNewValueUnits.TabIndex = 2;
            this.lblNewValueUnits.Text = "Units for new value:";
            // 
            // cboNewValueUnits
            // 
            this.cboNewValueUnits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNewValueUnits.FormattingEnabled = true;
            this.cboNewValueUnits.Items.AddRange(new object[] {
            "DUT_CENTIMETERS",
            "DUT_DECIMAL_FEET",
            "DUT_DECIMAL_INCHES",
            "DUT_FEET_FRACTIONAL_INCHES",
            "DUT_FRACTIONAL_INCHES",
            "DUT_METERS",
            "DUT_METERS_CENTIMETERS",
            "DUT_MILLIMETERS"});
            this.cboNewValueUnits.Location = new System.Drawing.Point(151, 36);
            this.cboNewValueUnits.Name = "cboNewValueUnits";
            this.cboNewValueUnits.Size = new System.Drawing.Size(303, 21);
            this.cboNewValueUnits.Sorted = true;
            this.cboNewValueUnits.TabIndex = 3;
            this.cboNewValueUnits.SelectedIndexChanged += new System.EventHandler(this.cboNewValueUnits_SelectedIndexChanged);
            // 
            // btnSetNewValue
            // 
            this.btnSetNewValue.Location = new System.Drawing.Point(12, 155);
            this.btnSetNewValue.Name = "btnSetNewValue";
            this.btnSetNewValue.Size = new System.Drawing.Size(186, 23);
            this.btnSetNewValue.TabIndex = 12;
            this.btnSetNewValue.Text = "Set New Value";
            this.btnSetNewValue.UseVisualStyleBackColor = true;
            this.btnSetNewValue.Click += new System.EventHandler(this.btnSetNewValue_Click);
            // 
            // cboConvertToUnits
            // 
            this.cboConvertToUnits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboConvertToUnits.FormattingEnabled = true;
            this.cboConvertToUnits.Items.AddRange(new object[] {
            "DUT_CENTIMETERS",
            "DUT_DECIMAL_FEET",
            "DUT_DECIMAL_INCHES",
            "DUT_FEET_FRACTIONAL_INCHES",
            "DUT_FRACTIONAL_INCHES",
            "DUT_METERS",
            "DUT_METERS_CENTIMETERS",
            "DUT_MILLIMETERS"});
            this.cboConvertToUnits.Location = new System.Drawing.Point(151, 208);
            this.cboConvertToUnits.Name = "cboConvertToUnits";
            this.cboConvertToUnits.Size = new System.Drawing.Size(303, 21);
            this.cboConvertToUnits.Sorted = true;
            this.cboConvertToUnits.TabIndex = 14;
            this.cboConvertToUnits.SelectedIndexChanged += new System.EventHandler(this.cboConvertToUnits_SelectedIndexChanged);
            // 
            // lblConvertedValue
            // 
            this.lblConvertedValue.AutoSize = true;
            this.lblConvertedValue.ForeColor = System.Drawing.Color.Red;
            this.lblConvertedValue.Location = new System.Drawing.Point(12, 271);
            this.lblConvertedValue.Name = "lblConvertedValue";
            this.lblConvertedValue.Size = new System.Drawing.Size(88, 13);
            this.lblConvertedValue.TabIndex = 17;
            this.lblConvertedValue.Text = "Converted value:";
            // 
            // lblInternalValue
            // 
            this.lblInternalValue.AutoSize = true;
            this.lblInternalValue.ForeColor = System.Drawing.Color.Red;
            this.lblInternalValue.Location = new System.Drawing.Point(12, 293);
            this.lblInternalValue.Name = "lblInternalValue";
            this.lblInternalValue.Size = new System.Drawing.Size(74, 13);
            this.lblInternalValue.TabIndex = 18;
            this.lblInternalValue.Text = "Internal value:";
            // 
            // lblOverrideNote
            // 
            this.lblOverrideNote.ForeColor = System.Drawing.Color.Blue;
            this.lblOverrideNote.Location = new System.Drawing.Point(261, 98);
            this.lblOverrideNote.Name = "lblOverrideNote";
            this.lblOverrideNote.Size = new System.Drawing.Size(349, 27);
            this.lblOverrideNote.TabIndex = 9;
            this.lblOverrideNote.Text = "Include symbols like \"cm\" here to override the \"Units for new value\" units shown " +
                "above.";
            // 
            // lblRoundingPrecision
            // 
            this.lblRoundingPrecision.AutoSize = true;
            this.lblRoundingPrecision.Location = new System.Drawing.Point(9, 132);
            this.lblRoundingPrecision.Name = "lblRoundingPrecision";
            this.lblRoundingPrecision.Size = new System.Drawing.Size(101, 13);
            this.lblRoundingPrecision.TabIndex = 10;
            this.lblRoundingPrecision.Text = "Rounding precision:";
            // 
            // txtRoundingPrecision
            // 
            this.txtRoundingPrecision.Location = new System.Drawing.Point(151, 129);
            this.txtRoundingPrecision.Name = "txtRoundingPrecision";
            this.txtRoundingPrecision.Size = new System.Drawing.Size(104, 20);
            this.txtRoundingPrecision.TabIndex = 11;
            this.txtRoundingPrecision.Text = "0.000000000001";
            // 
            // txtConversionRoundingPrecision
            // 
            this.txtConversionRoundingPrecision.Location = new System.Drawing.Point(151, 236);
            this.txtConversionRoundingPrecision.Name = "txtConversionRoundingPrecision";
            this.txtConversionRoundingPrecision.Size = new System.Drawing.Size(104, 20);
            this.txtConversionRoundingPrecision.TabIndex = 16;
            this.txtConversionRoundingPrecision.Text = "0.000000000001";
            this.txtConversionRoundingPrecision.TextChanged += new System.EventHandler(this.txtConversionRoundingPrecision_TextChanged);
            // 
            // lblConversionRoundingPrecision
            // 
            this.lblConversionRoundingPrecision.AutoSize = true;
            this.lblConversionRoundingPrecision.Location = new System.Drawing.Point(9, 239);
            this.lblConversionRoundingPrecision.Name = "lblConversionRoundingPrecision";
            this.lblConversionRoundingPrecision.Size = new System.Drawing.Size(101, 13);
            this.lblConversionRoundingPrecision.TabIndex = 15;
            this.lblConversionRoundingPrecision.Text = "Rounding precision:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Scale factor to internal units:";
            // 
            // txtScaleFactor
            // 
            this.txtScaleFactor.Location = new System.Drawing.Point(151, 67);
            this.txtScaleFactor.Name = "txtScaleFactor";
            this.txtScaleFactor.ReadOnly = true;
            this.txtScaleFactor.Size = new System.Drawing.Size(104, 20);
            this.txtScaleFactor.TabIndex = 5;
            this.txtScaleFactor.Text = "?";
            // 
            // label2
            // 
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(263, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(347, 27);
            this.label2.TabIndex = 6;
            this.label2.Text = "Multiply values that are in the \"Units for new value\" units shown above by this v" +
                "alue to store directly into Revit";
            // 
            // cboUnitType
            // 
            this.cboUnitType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboUnitType.FormattingEnabled = true;
            this.cboUnitType.Items.AddRange(new object[] {
            "DUT_CENTIMETERS",
            "DUT_DECIMAL_FEET",
            "DUT_DECIMAL_INCHES",
            "DUT_FEET_FRACTIONAL_INCHES",
            "DUT_FRACTIONAL_INCHES",
            "DUT_METERS",
            "DUT_METERS_CENTIMETERS",
            "DUT_MILLIMETERS"});
            this.cboUnitType.Location = new System.Drawing.Point(151, 6);
            this.cboUnitType.Name = "cboUnitType";
            this.cboUnitType.Size = new System.Drawing.Size(303, 21);
            this.cboUnitType.Sorted = true;
            this.cboUnitType.TabIndex = 1;
            this.cboUnitType.SelectedIndexChanged += new System.EventHandler(this.cboUnitType_SelectedIndexChanged);
            // 
            // lblUnitType
            // 
            this.lblUnitType.AutoSize = true;
            this.lblUnitType.Location = new System.Drawing.Point(9, 9);
            this.lblUnitType.Name = "lblUnitType";
            this.lblUnitType.Size = new System.Drawing.Size(52, 13);
            this.lblUnitType.TabIndex = 0;
            this.lblUnitType.Text = "Unit type:";
            // 
            // frmUnitConversions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 344);
            this.Controls.Add(this.cboUnitType);
            this.Controls.Add(this.lblUnitType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtScaleFactor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtConversionRoundingPrecision);
            this.Controls.Add(this.lblConversionRoundingPrecision);
            this.Controls.Add(this.txtRoundingPrecision);
            this.Controls.Add(this.lblRoundingPrecision);
            this.Controls.Add(this.lblOverrideNote);
            this.Controls.Add(this.lblInternalValue);
            this.Controls.Add(this.lblConvertedValue);
            this.Controls.Add(this.cboConvertToUnits);
            this.Controls.Add(this.btnSetNewValue);
            this.Controls.Add(this.cboNewValueUnits);
            this.Controls.Add(this.lblNewValueUnits);
            this.Controls.Add(this.txtNewValue);
            this.Controls.Add(this.lblNewLengthValue);
            this.Controls.Add(this.lblConvertToUnits);
            this.Name = "frmUnitConversions";
            this.Text = "Sample Unit Conversion";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblConvertToUnits;
        private System.Windows.Forms.Label lblNewLengthValue;
        private System.Windows.Forms.TextBox txtNewValue;
        private System.Windows.Forms.Label lblNewValueUnits;
        private System.Windows.Forms.ComboBox cboNewValueUnits;
        private System.Windows.Forms.Button btnSetNewValue;
        private System.Windows.Forms.ComboBox cboConvertToUnits;
        private System.Windows.Forms.Label lblConvertedValue;
        private System.Windows.Forms.Label lblInternalValue;
        private System.Windows.Forms.Label lblOverrideNote;
        private System.Windows.Forms.Label lblRoundingPrecision;
        private System.Windows.Forms.TextBox txtRoundingPrecision;
        private System.Windows.Forms.TextBox txtConversionRoundingPrecision;
        private System.Windows.Forms.Label lblConversionRoundingPrecision;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtScaleFactor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboUnitType;
        private System.Windows.Forms.Label lblUnitType;
    }
}